# -*- coding: utf-8 -*-

#!/usr/bin/env python

import sys

from PySide import QtCore, QtGui
import sqlalchemy
import cPickle as pickle
import os
import collections
import Pyro4
import time
import socket
from socket import error as socket_error

from spyndle.io import DatabaseMng

from PyBlockWork import Schema, NameServer, registerPyros

from widgets.processingNodeWidget import ProcessingNodeWidget
from widgets.comConsumerWidget import ComConsumerWidget


#import warnings
#warnings.simplefilter('error', UserWarning)


dbMng = DatabaseMng()

"""
class ServerWidget(QtGui.QWidget):
    
    def __init__(self, parent = None):
        super(ServerWidget, self).__init__(parent)            

        self.serverPath   = QtGui.QLineEdit("localhost")   
        self.connectBtn   = QtGui.QPushButton("Connect")   
        self.disconnecBtn = QtGui.QPushButton("Disconnect")   
        self.serverStatus = QtGui.QLabel("Unconnected. Working on localhost.") 

        self.layout().addWidget(QtGui.QLabel("Server:"))
        self.layout().addWidget(self.serverPath)    
        self.layout().addWidget(self.setServerBtn)    
        self.layout().addWidget(self.serverStatus)    
"""        
        
        

class DatabaseWidget(QtGui.QWidget):
    
    def __init__(self, parent = None):
        super(DatabaseWidget, self).__init__(parent)        
      
        self.databasePath   = QtGui.QLineEdit()     
        
        self.completer = QtGui.QCompleter(persistReg.getList("DatabaseWidget.databasePath"), self)
        self.completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        self.completer.setCompletionMode(QtGui.QCompleter.UnfilteredPopupCompletion)
        self.databasePath.setCompleter(self.completer)    

        self.databasePath.returnPressed.connect(self.databasePathReturned)
        self.databasePath.installEventFilter(self)

        self.connectBtn     = QtGui.QPushButton("Connect")
        self.disconnectBtn  = QtGui.QPushButton("Disconnect")
        self.viewBtn        = QtGui.QPushButton("View")
        self.newBtn         = QtGui.QPushButton("New")
        
        self.connectBtn.clicked.connect(self.connectDatabase)
        self.disconnectBtn.clicked.connect(self.disconnectDatabase)
        self.viewBtn.clicked.connect(self.viewDatabase)
        self.newBtn.clicked.connect(self.createDatabase)
        
        self.disconnectBtn.setEnabled(False)
        self.viewBtn.setEnabled(False)
        
        self.setLayout(QtGui.QHBoxLayout())
      
        self.layout().addWidget(QtGui.QLabel("Database:"))
        self.layout().addWidget(self.databasePath)
        self.layout().addWidget(self.connectBtn)
        self.layout().addWidget(self.disconnectBtn)
        self.layout().addWidget(self.viewBtn)
        self.layout().addWidget(self.newBtn)




    def eventFilter(self, object, event):    
        
        if object == self.databasePath:
            if event.type() == QtCore.QEvent.Type.MouseButtonRelease :
                if event.button()== QtCore.Qt.LeftButton :
                    self.completer.complete()
                    return True
        return False



    def databasePathReturned(self):
        
        if self.databasePath.text() == "":
            self.completer.complete()
        else:
            self.connectDatabase()

    def connectDatabase(self) :
        
        try:
            dbMng.connectDatabase(self.databasePath.text())

            if dbMng.isConnected():
                self.connectBtn.setEnabled(False)
                self.disconnectBtn.setEnabled(True)
                self.databasePath.setEnabled(False)
                self.viewBtn.setEnabled(True)
            
            persistReg.addToList("DatabaseWidget.databasePath", self.databasePath.text())            
            
        except sqlalchemy.exc.ArgumentError, e:
             QtGui.QMessageBox.critical(self, "Error connecting to the specified database URL", 
                                 "The format of the database path is invalid."\
                                 "\n\nSQLAlchemy error message: " + str(e))

        
    def disconnectDatabase(self):
        dbMng.disconnectDatabase()
        
        if not dbMng.isConnected():
            self.connectBtn.setEnabled(True)
            self.disconnectBtn.setEnabled(False)
            self.databasePath.setEnabled(True)
            self.viewBtn.setEnabled(False)        
        
    def viewDatabase(self) :
        pass
        
        
    def createDatabase(self):
        pass
        
        






class PersistentProperty(object):
    def __init__(self, name, func, initval=None):
        self.func      = func
        self.attr_name = '__' + name
        setattr(self, self.attr_name, initval)
        
    def __get__(self, instance, owner):
        return getattr(self, self.attr_name)
        
    def __set__(self, instance, value):
        setattr(self, self.attr_name, value)
        self.func(instance)
        



class SchemaObject:
    
    def __init__(self, filePath, schemaDictName, schemaDictObj):
        self.isRunning  = False
        
        self._schemaDictName    = schemaDictName
        self._schemaDictObj     = schemaDictObj
        self.filePath           = filePath
        self.schedulerName      = "scheduler"
        self.registerPath       = os.path.join(os.path.dirname(filePath), "register.bin")

    def persistenceManagement(self):
        persistReg.setObject(self._schemaDictName , self._schemaDictObj)   

    filePath               = PersistentProperty('filePath', persistenceManagement, "")
    requestedNbProcesses   = PersistentProperty('requestedNbProcesses', persistenceManagement, 1)
    schedulerName          = PersistentProperty('schedulerName', persistenceManagement, "scheduler" ) 
    registerPath           = PersistentProperty('registerPath', persistenceManagement, "")  



class SchemaDict(collections.MutableMapping):
    
    def __init__(self, name, *args, **kwargs):
        self.store = dict()
        self.update(dict(*args, **kwargs))  # use the free update to set keys
        
        self.__name                 = name 


    def __getitem__(self, key):
        return self.store[self.__keytransform__(key)]

    def __setitem__(self, key, value):
        self.store[self.__keytransform__(key)] = value
        persistReg.setObject(self.__name, self)

    def __delitem__(self, key):
        del self.store[self.__keytransform__(key)]
        persistReg.setObject(self.__name, self)
        
    def __iter__(self):
        return iter(self.store)

    def __len__(self):
        return len(self.store)

    def __keytransform__(self, key):
        return key

        


class SchemaPropertyWidget(QtGui.QWidget):
    
    def __init__(self, parent = None):
        super(SchemaPropertyWidget, self).__init__(parent)
        
        self.setLayout(QtGui.QGridLayout())

        self.startBtn       = QtGui.QPushButton("Start")
        self.stopBtn        = QtGui.QPushButton("Stop")
        self.propertiesBtn  = QtGui.QPushButton("Edit schema properties")
        self.viewBtn        = QtGui.QPushButton("View schema")
        self.addBtn         = QtGui.QPushButton("Add schema")
        self.removeBtn      = QtGui.QPushButton("Remove selected schema")
        
        self.filePath               = QtGui.QLineEdit()
        self.requestedNbProcesses   = QtGui.QLineEdit() 
        self.schedulerName          = QtGui.QLineEdit() 
        self.registerPath           = QtGui.QLineEdit()         
        self.isRunning              = QtGui.QLineEdit()   
        
        
        self.filePath.textChanged.connect(self.filePathChanged)
        self.requestedNbProcesses.textChanged.connect(self.requestedNbProcessesChanged) 
        self.schedulerName.textChanged.connect(self.schedulerNameChanged) 
        self.registerPath.textChanged.connect(self.registerPathChanged)          
        
        self.setEnabled(False)         
        self.isRunning.setEnabled(False)   
        
        
        self.layout().addWidget(QtGui.QLabel("File path:"),                 0, 0, 1, 1)
        self.layout().addWidget(self.filePath ,                             0, 1, 1, 1)
        self.layout().addWidget(QtGui.QLabel("Requested # of processes:"),  1, 0, 1, 1)
        self.layout().addWidget(self.requestedNbProcesses,                  1, 1, 1, 1)
        self.layout().addWidget(QtGui.QLabel("Scheduler name:"),            2, 0, 1, 1)
        self.layout().addWidget(self.schedulerName,                         2, 1, 1, 1)
        self.layout().addWidget(QtGui.QLabel("Register path:"),             3, 0, 1, 1)
        self.layout().addWidget(self.registerPath,                          3, 1, 1, 1)
        self.layout().addWidget(QtGui.QLabel("Is running:"),                4, 0, 1, 1)
        self.layout().addWidget(self.isRunning,                             4, 1, 1, 1)
        
        self.schemaObject = None


    def setEnabled(self, enabled):
        self.filePath.setEnabled(enabled)  
        self.requestedNbProcesses.setEnabled(enabled)  
        self.schedulerName.setEnabled(enabled)  
        self.registerPath.setEnabled(enabled)         



    def setSchemaObject(self, schemaObject):
        if schemaObject is None:
            self.schemaObject = None
            self.filePath.setText("")
            self.requestedNbProcesses.setText("")
            self.schedulerName.setText("")
            self.registerPath.setText("")
            self.isRunning.setText("")
            self.setEnabled(False)
        else:
            self.schemaObject = schemaObject
            self.filePath.setText(schemaObject.filePath)
            self.requestedNbProcesses.setText(str(schemaObject.requestedNbProcesses))
            self.schedulerName.setText(schemaObject.schedulerName)
            self.registerPath.setText(schemaObject.registerPath)
            self.isRunning.setText(str(schemaObject.isRunning))
            self.setEnabled(True)
   
   
    def filePathChanged(self):
        if not self.schemaObject is None:
            self.schemaObject.filePath = self.filePath.text()
       
    def requestedNbProcessesChanged(self):
        if not self.schemaObject is None:
            self.schemaObject.requestedNbProcesses = int(self.requestedNbProcesses.text())
        
        
    def schedulerNameChanged(self):
        if not self.schemaObject is None:
            self.schemaObject.schedulerName = self.schedulerName.text()
        
        
    def registerPathChanged(self):
        if not self.schemaObject is None:
            self.schemaObject.registerPath = self.registerPath.text()
          
   
   
   

class SchemaWidget(QtGui.QWidget):
    
    def __init__(self, parent = None):
        super(SchemaWidget, self).__init__(parent)
        self.mainWindow = parent      
        
        #QtGui.QtTreePropertyBrowser()        
        
        self.setLayout(QtGui.QGridLayout())

        self.schemaListWidget     = QtGui.QListWidget()      

        self.startBtn       = QtGui.QPushButton("Start")
        self.stopBtn        = QtGui.QPushButton("Stop")
        self.propertiesBtn  = QtGui.QPushButton("Edit schema properties")
        self.viewBtn        = QtGui.QPushButton("View schema")
        self.addBtn         = QtGui.QPushButton("Add schema")
        self.removeBtn      = QtGui.QPushButton("Remove selected schema")
        
        self.propertyWidget = SchemaPropertyWidget(self)
        
        self.removeBtn.setEnabled(False)
        self.stopBtn.setEnabled(False)
        self.startBtn.setEnabled(False)
        self.propertiesBtn.setEnabled(False)   
        self.viewBtn.setEnabled(False)     

        self.layout().addWidget(QtGui.QLabel("BlockWork schema:"),  0, 0, 6, 1)
        self.layout().addWidget(self.schemaListWidget,              0, 1, 6, 1)
        self.layout().addWidget(self.propertyWidget,                0, 2, 6, 1)
        self.layout().addWidget(self.startBtn ,                     0, 3, 1, 1)
        self.layout().addWidget(self.stopBtn ,                      1, 3, 1, 1)
        self.layout().addWidget(self.propertiesBtn ,                2, 3, 1, 1)
        self.layout().addWidget(self.viewBtn ,                      3, 3, 1, 1)
        self.layout().addWidget(self.addBtn ,                       4, 3, 1, 1)
        self.layout().addWidget(self.removeBtn,                     5, 3, 1, 1)

        self.schemaListWidget.itemSelectionChanged.connect(self.schemaSelectionChanged)
        
        self.startBtn.clicked.connect(self.startSchema)
        self.stopBtn.clicked.connect(self.stopSchema)
        self.propertiesBtn.clicked.connect(self.editSchemaProperties)
        self.viewBtn.clicked.connect(self.viewSchema)
        self.addBtn.clicked.connect(self.addchema)
        self.removeBtn.clicked.connect(self.removechema)
        
        
        self._schemaDict = persistReg.getObject("SchemaWidget.schemaDict")
        if self.schemaDict is None:
            self.schemaDict = SchemaDict("SchemaWidget.schemaDict")
        else:
            for schemaKey in self.schemaDict:
                self.schemaDict[schemaKey].schemaDictObj = self.schemaDict            
            
        self.updateSchemaListWidget()


    @property
    def schemaDict(self):
        return self._schemaDict
        
    @schemaDict.setter
    def schemaDict(self, value):
        self._schemaDict = value    
        persistReg.setObject("SchemaWidget.schemaDict", value)
        

    def schemaSelectionChanged(self):
        if (not self.schemaListWidget.currentItem() is None and 
                                    self.schemaListWidget.currentRow() >= 0) :
                                        
            schemaObject = self.schemaDict[self.schemaListWidget.currentItem().text()]
            self.removeBtn.setEnabled(True)
            self.propertiesBtn.setEnabled(True)   
            self.viewBtn.setEnabled(True)               
            
            self.startBtn.setEnabled(not schemaObject.isRunning)   
            self.stopBtn.setEnabled(schemaObject.isRunning)           
            
            self.propertyWidget.setSchemaObject(schemaObject)
  
        else:
            self.removeBtn.setEnabled(False)
            self.propertiesBtn.setEnabled(False)   
            self.viewBtn.setEnabled(False)               
            self.startBtn.setEnabled(False)   
            self.stopBtn.setEnabled(False)                    

            self.propertyWidget.setSchemaObject(None)


    def startSchema(self):

        schemaName = self.schemaListWidget.currentItem().text()
        try :
            schema = Schema.load(schemaName)
        except IOError, e:
             QtGui.QMessageBox.critical(self, "Error opening file.", 
                                 "Error: " + str(e))
                        
            
        self.mainWindow.checkNameServer()

        """
        scheduler = Scheduler(self.schemaDict[schemaName].registerPath, 
                              self.schemaDict[schemaName].requestedNbProcesses)
        self.mainWindow.pyroNSWidget.nameServer.ns_daemon.register(scheduler, 
                                                                   self.schemaDict[schemaName].schedulerName)
        """
        
        #startScheduler(self.schemaDict[schemaName].registerPath, 
         #                  self.schemaDict[schemaName].requestedNbProcesses, 
          #                 self.mainWindow.pyroNSWidget.nameServer.ns, 
           #                schedulerName=self.schemaDict[schemaName].schedulerName)    
        
        # We just start the register here because it is the only object that should
        # be different from schema to schema. The stagingRoom and the communicationHub
        # are started at same time as the name server.
        pyroInfos={"registerName":(self.schemaDict[schemaName].schedulerName, self.schemaDict[schemaName].registerPath),
                   "HMAC_KEY":str(self.mainWindow.pyroNSWidget.hmacKeyWidget.text())}        
        registerPyros(pyroInfos, self.mainWindow.pyroNSWidget.nameServer.ns,
                          host=self.mainWindow.host)


        pyroInfos={"registerName":self.schemaDict[schemaName].schedulerName,
                   "stagingRoomName":"stagingRoom",
                   "HMAC_KEY":str(self.mainWindow.pyroNSWidget.hmacKeyWidget.text())}    
        schema.start(pyroInfos)


    
    def stopSchema(self):
        pass
    
    def editSchemaProperties(self):
        pass
    
    def viewSchema(self):
        pass
    
    def addchema(self):
        path = persistReg.getObject("loadSavePath") 
        if path is None:
            path = ""

        fname, _ = QtGui.QFileDialog.getOpenFileName(self, 'Select the schema file to add', path)
        if os.path.isfile(fname):
            if fname in self.schemaDict:
                 QtGui.QMessageBox.critical(self, "Error adding schema", 
                                     "This schema is already in your schema list.")                
            else:
                persistReg.setObject("loadSavePath", os.path.dirname(fname)) 
                self.schemaDict[fname] = SchemaObject(fname, "SchemaWidget.schemaDict", self.schemaDict)
                self.schemaListWidget.addItem(fname)       



    def removechema(self):
        del self.schemaDict[self.schemaListWidget.currentItem().text()]   
        self.schemaListWidget.takeItem(self.schemaListWidget.currentRow())

                
                

    def updateSchemaListWidget(self):
        self.schemaListWidget.clear()
        for key in self.schemaDict:
           #if self.schemaDict[key].isRunning :
            #    key += " - Running..."
            self.schemaListWidget.addItem(key)            




class PyroNSWidget(QtGui.QWidget):

    def __init__(self, parent = None):
        super(PyroNSWidget, self).__init__(parent)
        self.mainWindow = parent
        
        self.setLayout(QtGui.QHBoxLayout())
     
        HMAC_KEY = persistReg.getObject("PyroNSWidget.HMAC_KEY")
        if HMAC_KEY is None:
            HMAC_KEY = ""
        
        self.hmacKeyWidget  = QtGui.QLineEdit(HMAC_KEY)    
        self.startBtn       = QtGui.QPushButton("Start")
        self.stopBtn        = QtGui.QPushButton("Stop")      

        self.layout().addWidget(self.hmacKeyWidget)
        self.layout().addWidget(self.startBtn)
        self.layout().addWidget(self.stopBtn)

        self.stopBtn.setEnabled(False)

        self.startBtn.clicked.connect(self.startNSServer)
        self.stopBtn.clicked.connect(self.stopNSServer) 
        
        self.hmacKeyWidget.textChanged.connect(self.hmacKeyChanged)
        
        self.nameServer = None

        sys.excepthook                      = Pyro4.util.excepthook    
        Pyro4.config.HMAC_KEY               = str(self.hmacKeyWidget.text())
        Pyro4.config.THREADPOOL_MAXTHREADS  = 500



    def hmacKeyChanged(self):
        persistReg.setObject("PyroNSWidget.HMAC_KEY", self.hmacKeyWidget.text())
        Pyro4.config.HMAC_KEY = str(self.hmacKeyWidget.text())



    def startNSServer(self):

        NSisDeamon=False
        
        try:
            self.nameServer = NameServer(socket.gethostbyname(socket.gethostname()), NSisDeamon)
        except socket_error  as e:
              QtGui.QMessageBox.critical(self, "Error starting the name server socket.", str(e))   
              return
            
            
        self.nameServer.startNS()
        
        time.sleep(2.5)

        for i in range(100):
            try:
                Pyro4.locateNS()
                self.hmacKeyWidget.setEnabled(False)    

                # Launching the stagingRoom and the communicationHub
                pyroInfos={"stagingRoomName":"stagingRoom", 
                           "comHubName":"communicationHub",
                           "HMAC_KEY":str(self.hmacKeyWidget.text())}        
                
                registerPyros(pyroInfos, self.nameServer.ns, host=self.mainWindow.host)

                self.mainWindow.consumerWidget.connectHub(str(self.hmacKeyWidget.text()), 
                                                          "communicationHub")
                
                self.startBtn.setEnabled(False)
                self.stopBtn.setEnabled(True)
                
                return 
            except Pyro4.errors.PyroError:
                time.sleep(0.1)
                
        QtGui.QMessageBox.critical(self, "Error launching Pyro's name server.", 
                                     "After waiting 10 seconds, the server was still not running.")            



    def nsIsRunning(self): 
        try:
            Pyro4.locateNS()
            return True
        except Pyro4.errors.PyroError:
            return False
            
            

    def stopNSServer(self):
        self.nameServer.stopNS()        
        self.hmacKeyWidget.setEnabled(True)    
        self.startBtn.setEnabled(True)
        self.stopBtn.setEnabled(False)
        self.nameServer = None


    def checkNameServer(self):

        if not self.nsIsRunning():
            msgBox = QtGui.QMessageBox()
            msgBox.setText("Pyro's nameserver is not running.")
            msgBox.setInformativeText("Do you want it to be started?")
            msgBox.setStandardButtons(QtGui.QMessageBox.Yes | QtGui.QMessageBox.No)
            msgBox.setDefaultButton(QtGui.QMessageBox.Yes)
            ret = msgBox.exec_()            
            
            if ret == QtGui.QMessageBox.Yes:
                self.startNSServer()
                if not self.nsIsRunning():
                    return
            elif ret == QtGui.QMessageBox.No:
                msgBox = QtGui.QMessageBox()
                msgBox.setText("The schema could not be started.")
                msgBox.setInformativeText("A Pyro nameserver must be running for schema to be process.")
                msgBox.setStandardButtons(QtGui.QMessageBox.Ok)
                msgBox.setDefaultButton(QtGui.QMessageBox.Ok)
                ret = msgBox.exec_()            
                return









class PyperWidget(QtGui.QWidget):
    
    def __init__(self, parent = None):
        super(PyperWidget, self).__init__(parent)        
        
        
        self.setLayout(QtGui.QHBoxLayout())
      
        self.layout().addWidget(QtGui.QLabel("Pypers:"))



class PersistenceRegister:
    
    def __init__(self):
        self._lists     = {}
        self._objects   = {}
    
    def getList(self, listName):
        if not listName in self._lists:
            self._lists[listName] = []
        return self._lists[listName]
        
    def addToList(self, listName, value):
        
        if listName in self._lists:   
            if value in self._lists[listName]:
                self._lists[listName].remove(value)
            self._lists[listName].insert(0, value)                       
        else:
            self._lists[listName] = [value]
        
        pickle.dump(self, open(pickleFile, "wb" ) )
    
    
    def getObject(self, objectName):
        if not objectName in self._objects:
            self._objects[objectName] = None
        return self._objects[objectName]
        
    def setObject(self, objectName, value):
        self._objects[objectName] = value                     
        pickle.dump(self, open(pickleFile, "wb" ) )







class MainWindow(QtGui.QMainWindow):

    def __init__(self, *args):
        apply(QtGui.QMainWindow.__init__, (self, ) + args)
        self.setWindowTitle('EEG Analyzer') 


        self.host = socket.gethostbyname(socket.gethostname())

        self.mainWidget = QtGui.QWidget(self)

        self.setCentralWidget (self.mainWidget)
        
        
 
        self.undoAct = QtGui.QAction("&Undo", self,
                shortcut=QtGui.QKeySequence.Undo,
                statusTip="Undo the last operation", triggered=self.undo)
 
        self.redoAct = QtGui.QAction("&Redo", self,
                shortcut=QtGui.QKeySequence.Redo,
                statusTip="Redo the last operation", triggered=self.redo)
 
        self.cutAct = QtGui.QAction("Cu&t", self,
                shortcut=QtGui.QKeySequence.Cut,
                statusTip="Cut the current selection's contents to the clipboard",
                triggered=self.cut)
 
        self.copyAct = QtGui.QAction("&Copy", self,
                shortcut=QtGui.QKeySequence.Copy,
                statusTip="Copy the current selection's contents to the clipboard",
                triggered=self.copy)
 
        self.pasteAct = QtGui.QAction("&Paste", self,
                shortcut=QtGui.QKeySequence.Paste,
                statusTip="Paste the clipboard's contents into the current selection",
                triggered=self.paste)        
        
        
 
        self.mainLayout     = QtGui.QVBoxLayout()
        
        self.databaseWidget = DatabaseWidget(self) 
        self.schemaWidget   = SchemaWidget(self)
        self.pyroNSWidget   = PyroNSWidget(self)
        self.pyperWidget    = PyperWidget(self)
        self.nodesWidget    = ProcessingNodeWidget(self)
        self.consumerWidget = ComConsumerWidget(self)
    
        self.docks =  {"Pyro":QtGui.QDockWidget("Pyro properties", self),
                       "Pypers":QtGui.QDockWidget("Pypers", self),
                       "Nodes":QtGui.QDockWidget("Processing nodes", self) }
        
        self.docks["Pyro"].setWidget(self.pyroNSWidget)        
        self.docks["Pypers"].setWidget(self.pyperWidget)       
        self.docks["Nodes"].setWidget(self.nodesWidget)        
        
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, self.docks["Pyro"])
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, self.docks["Pypers"])
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, self.docks["Nodes"])
        
        self.mainLayout.addWidget(self.databaseWidget)
        self.mainLayout.addWidget(self.schemaWidget)
        #self.mainLayout.addWidget(self.pyroNSWidget)
        #self.mainLayout.addWidget(self.pyperWidget)
        self.mainLayout.addWidget(self.consumerWidget)

        self.mainWidget.setLayout(self.mainLayout)

        self.showMaximized()





    def undo(self):
        QtGui.QApplication.focusWidget().undo()
 
    def redo(self):
        QtGui.QApplication.focusWidget().redo()
 
    def cut(self):
        QtGui.QApplication.focusWidget().cut()
 
    def copy(self):
        QtGui.QApplication.focusWidget().copy()
 
    def paste(self):
        QtGui.QApplication.focusWidget().paste()



    def checkNameServer(self):
        self.pyroNSWidget.checkNameServer()

            




def main(args): 
    global pickleFile
    global persistReg
    
    pickleFile = "persist.reg"
    try:
        persistReg = pickle.load(open(pickleFile))
    except IOError:
        persistReg = PersistenceRegister()
    
    
    
    app = QtGui.QApplication(args)
    win = MainWindow()
    win.show()  
    sys.exit(app.exec_())



def startAnalyzer():
    main([])



if __name__ == '__main__':
    arg = sys.argv
    main(arg)

#import cProfile
#if __name__ == '__main__':   
#    cProfile.run('main(sys.argv)', 'profileRepport')


