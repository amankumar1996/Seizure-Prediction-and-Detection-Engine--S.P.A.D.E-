__version__ = "0.1.0"

import client
from client import ProcessingClient
from widgets.processingNodeWidget import ProcessingNodeWidget
from Analyzer import startAnalyzer
