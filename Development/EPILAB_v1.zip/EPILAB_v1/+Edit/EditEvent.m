function EditEvent (study, panel)

global edit;

% display new panel
edit.ModulesPanel = panel;%uipanel('Parent', panel, 'Title', 'Add Events' ,'Units','Normalized','Position', [0.05 0.05 0.9 0.9]);

%edit.EventTypePopupmenu = uicontrol('Parent',edit.ModulesPanel,'style','popupmenu',...
%    'HandleVisibility','callback','Units','Normalized', 'Position',[0.45 0.9 0.25 0.05],'String',{'Seizure','Spike','Other'},'Callback', {@EventTypePopupmenuCallback}); 

%aux = (get (edit.EventTypePopupmenu, 'String'));
%aux1 = aux(get (edit.EventTypePopupmenu, 'Value'));
%edit.eventType= aux1{1};

%edit.EventTypeText = uicontrol('Parent', edit.ModulesPanel,'style','text',...
%    'HandleVisibility','callback','Units','Normalized', 'Position',[0.1 0.9 0.15 0.05],'String','Type of Event '); 

%edit.CommentsEdit = uicontrol('Parent',edit.ModulesPanel,'style','edit',...
%    'HandleVisibility','callback','Units','Normalized', 'Position',[0.45 0.8 0.45 0.05],'String',''); 
%edit.CommentsText = uicontrol('Parent', edit.ModulesPanel,'style','text',...
%    'HandleVisibility','callback','Units','Normalized', 'Position',[0.1 0.8 0.1 0.05],'String','Comments'); 


%edit.StartEdit = uicontrol('Parent',edit.ModulesPanel,'style','edit',...
%    'HandleVisibility','callback','Units','Normalized', 'Position',[0.225 0.7 0.175 0.05],'String','', 'Visible', 'on'); 
%edit.StartText = uicontrol('Parent', edit.ModulesPanel,'style','text',...
%    'HandleVisibility','callback','Units','Normalized', 'Position',[0.1 0.7 0.1 0.05],'String','Start', 'Visible', 'on'); 

%edit.StopEdit = uicontrol('Parent',edit.ModulesPanel,'style','edit',...
%    'HandleVisibility','callback','Units','Normalized', 'Position',[0.725 0.7 0.175 0.05],'String','','Visible', 'on');
%edit.StopText = uicontrol('Parent', edit.ModulesPanel,'style','text',...
%    'HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.7 0.1 0.05],'String','Stop','Visible', 'on'); 


edit.EventOcurrenceEdit = uicontrol('Parent',edit.ModulesPanel,'style','edit',...
    'HandleVisibility','callback','Units','Normalized', 'Position',[0.45 0.7 0.25 0.05],'String','', 'Visible', 'off'); 
edit.EventOcurrenceText = uicontrol('Parent', edit.ModulesPanel,'style','text',...
    'HandleVisibility','callback','Units','Normalized', 'Position',[0.1 0.7 0.25 0.05],'String','Event ocurrence (sample)', 'Visible', 'off');

UpdateTable();

edit.HelpButton = uicontrol('Parent', edit.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.5 0.2 0.1 0.05],...
    'String','Help','Callback', @HelpButtonCallback, 'enable', 'off'); % Button for help
edit.RemoveButton = uicontrol('Parent', edit.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.65 0.2 0.1 0.05],...
    'String','Remove','Callback', @RemoveButtonCallback, 'enable', 'on'); % Button for remove
%edit.AddButton = uicontrol('Parent', edit.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.8 0.2 0.1 0.05],...
%    'String','Add','Callback', @AddButtonCallback); % Button for add
%edit.FromFileButton = uicontrol('Parent', edit.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',...
%    [0.1 0.2 0.15 0.05],'String','Add From File','Callback', @FromFileButtonCallback); % Button for add events from file

%edit.PredictionEdit = uicontrol('Parent',edit.ModulesPanel,'style','edit',...
%    'HandleVisibility','callback','Units','Normalized', 'Position',[0.45 0.075 0.25 0.05],'String','', 'Visible', 'on'); 
%edit.PredictionText = uicontrol('Parent', edit.ModulesPanel,'style','text',...
%    'HandleVisibility','callback','Units','Normalized', 'Position',[0.1 0.075 0.25 0.05],'String','Prediction Horizon (minutes)', 'Visible', 'on');
%edit.SetButton = uicontrol('Parent', edit.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.8 0.075 0.1 0.05],...
%    'String','Set','Callback', @SetButtonCallback);

    function EventTypePopupmenuCallback(hObject, eventdata)
        aux = (get (edit.EventTypePopupmenu, 'String'));
        aux1 = aux(get (edit.EventTypePopupmenu, 'Value'));
        edit.eventType= aux1{1};
        set (edit.StartEdit, 'Visible', 'off');set (edit.StartText, 'Visible', 'off');
        set (edit.StopEdit, 'Visible', 'off');set (edit.StopText, 'Visible', 'off');
        set (edit.EventOcurrenceEdit,  'Visible', 'off');set (edit.EventOcurrenceText,  'Visible', 'off');
        
        switch edit.eventType
            case 'Seizure'
                set (edit.StartEdit, 'Visible', 'on');
                set (edit.StartText, 'Visible', 'on');
                set (edit.StopEdit, 'Visible', 'on');
                set (edit.StopText, 'Visible', 'on');
            case 'Spike'
                set (edit.EventOcurrenceEdit,  'Visible', 'on');
                set (edit.EventOcurrenceText,  'Visible', 'on');
            case 'Other'
                set (edit.EventOcurrenceEdit,  'Visible', 'on');
                set (edit.EventOcurrenceText,  'Visible', 'on');
        end
    end

    function AddButtonCallback (hObject, eventdata) 
        edit.eventType
        
        switch edit.eventType
            case 'Seizure'
                
                if ((~isempty(get(edit.StartEdit, 'String')))&&(~isempty(get(edit.StopEdit, 'String'))))
                    if (isempty(study.dataset(study.dataset_selected).file.data.eeg_events))
                        study.dataset(study.dataset_selected).file.data.eeg_events = Epilab_Event (edit.eventType,...
                            str2double(get(edit.StartEdit, 'String')),str2double(get(edit.StopEdit, 'String')),...
                            get(edit.CommentsEdit, 'String'));
                    else
                        edit.eventType
                        get(edit.StartEdit, 'String')
                        get(edit.StopEdit, 'String')
                        get(edit.CommentsEdit, 'String')
                        study.dataset(study.dataset_selected).file.data.eeg_events(end+1) = Epilab_Event (edit.eventType,...
                            str2double(get(edit.StartEdit, 'String')),str2double(get(edit.StopEdit, 'String')),...
                            get(edit.CommentsEdit, 'String'));
                    end
                    UpdateTable();
                else
                    warndlg('Required fields were left empty','Error!!!')
                end
                
            case 'Spike'
                if (~isempty(get(edit.EventOcurrenceEdit, 'String')))
                    if (isempty(study.dataset(study.dataset_selected).file.data.eeg_events))
                        study.dataset(study.dataset_selected).file.data.eeg_events = Epilab_Event (edit.eventType,...
                            str2double(get(edit.EventOcurrenceEdit, 'String')),str2double(get(edit.EventOcurrenceEdit,...
                            'String')), get(edit.CommentsEdit, 'String'));
                    else
                        edit.eventType
                        get(edit.EventOcurrenceEdit, 'String')
                        get(edit.EventOcurrenceEdit, 'String')
                        get(edit.CommentsEdit, 'String')
                        study.dataset(study.dataset_selected).file.data.eeg_events(end+1) = Epilab_Event (edit.eventType,...
                            str2double(get(edit.EventOcurrenceEdit, 'String')),str2double(get(edit.EventOcurrenceEdit,...
                            'String')), get(edit.CommentsEdit, 'String'));
                    end
                    UpdateTable();
                else
                    warndlg('Required Event Ocurrence Time empty','Error!!!')
                end
                
            case 'Other'                
                disp ('Not Available');
                warndlg('Not Available','Error!!!')
        end
            set(edit.StartEdit, 'String', '');
            set(edit.StopEdit, 'String', '');
            set(edit.CommentsEdit, 'String', '');
    end
%Callback function of the Add From File Button
    function FromFileButtonCallback (hObject, eventdata)
        [fname, path] = uigetfile({'*.nts',  'All Files (*.nts)'},'Select file');
        get_events_from_file([path,fname])
    end
%=========================End Callback Add From File===========================
%=========================Function to get info from the Micromed generated note files (nts)
    function get_events_from_file(note_file)
        td=fopen(note_file,'r');

        start_seiz_samp=[];
        end_seiz_samp=[];
        no_end_flagg=0;
        while 1
            line=fgetl(td);
            pos_sep=findstr(line,':');
            sample=str2num(line(1:pos_sep-1));
            
            comment=line(pos_sep+1:end);
            ixc = isstrprop(comment, 'graphic');
            ixc=find(ixc);
            if size(ixc,2)~=0
                ixc=ixc(end);
                comment=comment(1:ixc);
            end
            if sample==0
                break
            elseif (strcmpi(comment,'seizure') || strcmpi(comment,'SubClinical Seiz. Onset'))
                disp('crise')
                start_seiz_samp = [start_seiz_samp, sample];
                if no_end_flagg==1%If end of last seizure is not anotated then update end_seiz_samp with a zero
                   end_seiz_samp=[end_seiz_samp,0]; 
                end
                no_end_flagg=1;
            elseif (strcmpi(comment,'end') || strcmpi(comment,'SubClinical Seiz. Onset Termination'))
                end_seiz_samp=[end_seiz_samp,sample];
                no_end_flagg=0;
            else
                if (isempty(study.dataset(study.dataset_selected).file.data.eeg_events))
                    study.dataset(study.dataset_selected).file.data.eeg_events = Epilab_Event ('Other',  sample,sample, comment);
                else
                    study.dataset(study.dataset_selected).file.data.eeg_events(end+1) = Epilab_Event ('Other', sample,sample,comment);
                end
            end
        end
        
        if size(start_seiz_samp,2)~=size(end_seiz_samp,2)
            end_seiz_samp=[end_seiz_samp,0];
        end
        
        for i=1:size(start_seiz_samp,2)
            s=start_seiz_samp(i);
            e=end_seiz_samp(i);
            if (isempty(study.dataset(study.dataset_selected).file.data.eeg_events))
                study.dataset(study.dataset_selected).file.data.eeg_events = Epilab_Event ('Seizure', s,e,'Seizure');
            else
                study.dataset(study.dataset_selected).file.data.eeg_events(end+1) = Epilab_Event ('Seizure', s,e,'Seizure');
            end
        end
        fclose(td)
        UpdateTable();
    end
    %====================================Get from file END=================================
    function UpdateTable()
        
        events_number = 0;
        
        for k = 1:size(study.dataset(study.dataset_selected).file,2)
            events_number_aux =  length(study.dataset(study.dataset_selected).file(k).data.eeg_events);
            events_number = events_number + events_number_aux;
        end

        EventTableDat=cell(events_number,4);
        
        if events_number ~= 0
            %i=1;
            EventTableAux = [];
            e=1;
            for k = 1:size(study.dataset(study.dataset_selected).file,2)
                EventTableAux = study.dataset(study.dataset_selected).file(k).data.eeg_events;
                n_curr_evts=size(EventTableAux,2);
                
                start_ts=study.dataset(study.dataset_selected).file(k).data.start_ts;
                if k==1
                    first_ts=datevec(start_ts);
                end
                vs=datenum(start_ts);
                for i=1:n_curr_evts
                    secs=EventTableAux(i).started./study.dataset(study.dataset_selected).file(k).data.sampling_rate;
                    vd=datenum([0 0 0 0 0 secs]);
                    ts=datestr(vs+vd,'yyyy-mm-dd HH:MM:SS.FFF')
                    tsv=datevec(ts)
                    EventTableDat{e,1} =EventTableAux(i).type;
                    EventTableDat{e,2} =num2str(etime(tsv,first_ts))
                    EventTableDat{e,3} =ts;
                    EventTableDat{e,4} =EventTableAux(i).comments;
                    e=e+1;
                    
                end
            end

             
        else
            EventTableDat = [];
        end
        cnames = {'Event type','Onset Time (s)','Onset Timestamp','Comments'};

        edit.EventsUiTable = uitable('Data',EventTableDat,'ColumnName', cnames,'Units','Normalized','CellSelectionCallback',@UpdateEvent,...
            'Parent',edit.ModulesPanel,'RearrangeableColumn','on','Position',[0 0.3 1 0.7]);

        set (edit.EventsUiTable,  'Units', 'pixels');
        get (edit.EventsUiTable, 'position');
        PanelWidth = get (edit.EventsUiTable, 'position');

        set (edit.EventsUiTable, 'ColumnWidth',{PanelWidth(3)/5,PanelWidth(3)/5,PanelWidth(3)/5,1.705*PanelWidth(3)/5})
    end

    function  UpdateEvent (source, event)
        edit.row=event.Indices(:,1);
    end

    function RemoveButtonCallback (hObject, eventdata) 
        EventTableAux = study.dataset(study.dataset_selected).file.data.eeg_events;
        EventTableAux(edit.row) = [];
        study.dataset(study.dataset_selected).file.data.eeg_events = EventTableAux;
        UpdateTable();
    end

    function SetButtonCallback (hObject, eventdata)
        if ~isempty(str2num(get(edit.PredictionEdit, 'String')))
            study.dataset(study.dataset_selected).results.predictionHorizon = str2num(get(edit.PredictionEdit, 'String'));
            set(hObject, 'enable','off');
            
            set (edit.PredictionEdit, 'visible', 'off');
            set (edit.PredictionText, 'string', [(get(edit.PredictionText,'string')) '   ' get(edit.PredictionEdit, 'string')]);
        else
            warndlg('no prediction horizon selected','Error!!!')
        end
    end
        
end