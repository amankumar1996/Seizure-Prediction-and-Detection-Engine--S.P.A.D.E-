%Inside this class one must code all the properties that will store all the data that you need.
%This class allows to save the sub-module and to load it in the future without any change.
classdef ECGuniv_Data < handle
   %======================================================================
    %ECGuniv_Data
    %
    %Data of ECGuniv
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
   %Properties needed for the submodule
   properties
       
        parameter_acquisition;
        
        % algorithm output
        time;
        
        c_ = struct([]);       
       
       s_hrv;
       s_rr;
       s_NN;
       ApEn;
       relpow;
       powspec;
       v_freq;
       
   end
   
   methods
       %Constructor
       function obj = ECGuniv_Data()
           
       end
       
       function study = SaveData(obj, study, results, features_check)
         
            for x=1:length(study.dataset_selected)

                selected_chans = study.dataset(study.dataset_selected(x)).results.chansSelected;
                chans_ind = study.dataset(study.dataset_selected(x)).results.ECGchansSelectedInd;
                chans=study.dataset(study.dataset_selected(x)).results.chansSelected{chans_ind};
                study.dataset(study.dataset_selected(x)).results.chansEcg={chans};
                chans_ind = reshape(chans_ind, 1, []);
                dataset = study.dataset_selected(x);
                for k = 1:length(chans_ind)

                    if length(results.RRMean_results) >= dataset
                        eval(['obj.c_(1).RRMean_channel_' selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).RRMean_channel_' selected_chans{chans_ind(k)} ' = results.RRMean_results{dataset}(k,:);']);
                    end

                    if length(results.RRVar_results) >= dataset
                        eval(['obj.c_(1).RRVar_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).RRVar_channel_' selected_chans{chans_ind(k)} ' = results.RRVar_results{dataset}(k,:);']);
                    end

                    if length(results.RRMin_results) >= dataset
                        eval(['obj.c_(1).RRMin_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).RRMin_channel_' selected_chans{chans_ind(k)} ' = results.RRMin_results{dataset}(k,:);']);
                    end

                    if length(results.RRMax_results) >= dataset
                        eval(['obj.c_(1).RRMax_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).RRMax_channel_' selected_chans{chans_ind(k)} ' = results.RRMax_results{dataset}(k,:);']);
                    end
                    
                    if length(results.BPMMean_results) >= dataset
                        eval(['obj.c_(1).BPMMean_channel_' selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).BPMMean_channel_' selected_chans{chans_ind(k)} ' = results.BPMMean_results{dataset}(k,:);']);
                    end

                    if length(results.BPMVar_results) >= dataset
                        eval(['obj.c_(1).BPMVar_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).BPMVar_channel_' selected_chans{chans_ind(k)} ' = results.BPMVar_results{dataset}(k,:);']);
                    end

                    if length(results.BPMMin_results) >= dataset
                        eval(['obj.c_(1).BPMMin_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).BPMMin_channel_' selected_chans{chans_ind(k)} ' = results.BPMMin_results{dataset}(k,:);']);
                    end
                    
                    if length(results.BPMMax_results) >= dataset
                        eval(['obj.c_(1).BPMMax_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).BPMMax_channel_' selected_chans{chans_ind(k)} ' = results.BPMMax_results{dataset}(k,:);']);
                    end
                    
                    if length(results.VLF_results) >= dataset
                        eval(['obj.c_(1).VLF_channel_' selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).VLF_channel_' selected_chans{chans_ind(k)} ' = results.VLF_results{dataset}(k,:);']);
                    end
                    
                    if length(results.LF_results) >= dataset
                        eval(['obj.c_(1).LF_channel_' selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).LF_channel_' selected_chans{chans_ind(k)} ' = results.LF_results{dataset}(k,:);']);
                    end
                    
                    if length(results.HF_results) >= dataset
                        eval(['obj.c_(1).HF_channel_' selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).HF_channel_' selected_chans{chans_ind(k)} ' = results.HF_results{dataset}(k,:);']);
                    end
                    
                    if length(results.AppEn_results) >= dataset
                        eval(['obj.c_(1).ECGAppEn_channel_' selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).ECGAppEn_channel_' selected_chans{chans_ind(k)} ' = results.AppEn_results{dataset}(k,:);']);
                    end
                    
                    if length(results.SamEn_results) >= dataset
                        eval(['obj.c_(1).ECGSamEn_channel_' selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).ECGSamEn_channel_' selected_chans{chans_ind(k)} ' = results.SamEn_results{dataset}(k,:);']);
                    end
                    
                    if k > 1
                        continue;
                    end
                    
                    if features_check(1)
                        study.dataset(study.dataset_selected(x)).results.featureNames_ecg = ...
                            strcat(study.dataset(study.dataset_selected(x)).results.featureNames_ecg, ...
                            'RRMean,RRVar,RRMin,RRMax,');
                    end                    
                    if features_check(2)
                        study.dataset(study.dataset_selected(x)).results.featureNames_ecg = ...
                            strcat(study.dataset(study.dataset_selected(x)).results.featureNames_ecg, ...
                            'BPMMean,BPMVar,BPMMin,BPMMax,');
                    end                    
                    if features_check(3)
                        study.dataset(study.dataset_selected(x)).results.featureNames_ecg = ...
                            strcat(study.dataset(study.dataset_selected(x)).results.featureNames_ecg, ...
                            'VLF,LF,HF,');
                    end                    
                    if features_check(4)
                        study.dataset(study.dataset_selected(x)).results.featureNames_ecg = ...
                            strcat(study.dataset(study.dataset_selected(x)).results.featureNames_ecg, ...
                            'ECGAppEn,');
                    end                    
                    if features_check(5)
                        study.dataset(study.dataset_selected(x)).results.featureNames_ecg = ...
                            strcat(study.dataset(study.dataset_selected(x)).results.featureNames_ecg, ...
                            'ECGSamEn,');
                    end                    
                end
                
                obj.parameter_acquisition = results.parameter_acquisition;
                obj.time = results.time;
                study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.ECGuniv = obj;
                obj = FeatureExtraction.ECG.ECGuniv.ECGuniv_Data();
            end
       end
   end
end
