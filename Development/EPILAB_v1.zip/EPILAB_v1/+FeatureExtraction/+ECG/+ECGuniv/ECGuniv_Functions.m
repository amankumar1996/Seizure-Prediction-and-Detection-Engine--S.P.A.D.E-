%This Class must have all the functions needed for the algorithm.
%Code related with the interface or with the data should not be mixed with this class.
%It receives a reference for the object data.
classdef ECGuniv_Functions < handle
    %======================================================================
    %ECGuniv_Functions
    %
    %Functions of ECGuniv
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
   
   properties
       
        parameter_acquisition;
        data;
        
        study;
        
        acq_window;
        acq_step;    
        acq_window_sam;
        acq_step_sam;    
        a_curr_first_sam;
        a_curr_last_sam;
        a_invert_factor;
        a_total_sam;
        st_hrv;
        
        time;
        RRMean_results;
        RRVar_results;
        RRMin_results;
        RRMax_results;
        BPMMean_results;
        BPMVar_results;
        BPMMin_results;
        BPMMax_results;    
        VLF_results;
        LF_results;
        HF_results;
        AppEn_results;
        SamEn_results;
        
        m_FreqBandsHz ;
        ARCoeff;
        relpow;
        powspec;
        v_freq;
        s_SamRate;
        s_InterSamRate;
        s_hrv;
        s_rr;
        s_RRInter;
        s_NN;
        ApEn;
        mean_RR;
        std_RR;
        max_RR;
        min_RR;
        diff_RR;
        mean_BMP;
        std_BMP;
        max_BMP 
        min_BMP 
        diff_BMP
        std_NN;
        RMS_NN;
        v_NN50;
        v_NN50Per;
        
   end
    
   methods
       
      %Constructor
      function obj = ECGuniv_Functions(study)
          addpath(fullfile('utils','ecg'));
          
          obj.st_hrv = struct('rrsam', []);
          
          obj.time = [];
          obj.RRMean_results = [];
          obj.RRVar_results = [];
          obj.RRMin_results = [];
          obj.RRMax_results = [];
          
          obj.BPMMean_results = [];
          obj.BPMVar_results = [];
          obj.BPMMin_results = [];
          obj.BPMMax_results = [];
          
          obj.VLF_results = [];
          obj.LF_results = [];
          obj.HF_results = [];
          
          obj.AppEn_results = [];
          obj.SamEn_results = [];

          obj.study = study;
          obj.s_SamRate = study.dataset(study.dataset_selected(1)).file(1).data.sampling_rate;
          obj.s_InterSamRate = 4;
          obj.m_FreqBandsHz =  [0 0.04; 0.04 0.15; 0.15 0.4];
      end
      
      function obj = SetInitParams(obj, p_window, p_step)
          obj.acq_window = p_window;
          obj.acq_step = p_step;
          obj.acq_window_sam = obj.s_SamRate * obj.acq_window;
          obj.acq_step_sam = obj.s_SamRate * obj.acq_step;
      end
      
      function obj = InitRRSignal(obj, study, p_segment, p_samp_rate, ...
              p_invert_factor)
          
          clear obj.a_invert_factor
          
          obj.a_invert_factor = p_invert_factor;
          obj.st_hrv(1:size(p_segment, 1)) = struct('rrsam', []);
          
          obj.a_total_sam = 0;
          
          GetRRSignal(obj, study, p_segment, p_samp_rate);
          
          obj.a_curr_first_sam = 1;
          obj.a_curr_last_sam = obj.acq_window_sam;
      end
      
      function obj = GetRRSignal(obj, study, p_segment, p_samp_rate)
          
          for s_Counter = 1:size(p_segment, 1)
              clear v_RSamples
              v_RSamples = f_RWaveDet(obj.a_invert_factor(s_Counter).* p_segment(s_Counter, :), ...
                  p_samp_rate);
              obj.st_hrv(s_Counter).rrsam = f_AddHorElems(obj.st_hrv(s_Counter).rrsam, ...
                  obj.a_total_sam + v_RSamples);
              clear v_RSamples
          end
          
          obj.a_total_sam = obj.a_total_sam + size(p_segment, 2);
      end
      
      function last_samp = GetCurrLastSamp(obj)
          last_samp = obj.a_curr_last_sam;
      end

      function obj = RunSingleSegment(obj, study, p_samp_rate, features_check)

          clear v_RRStats v_BPMStats v_RelPow v_AppEn v_SamEn
          v_RRStats = [];
          v_BPMStats = [];
          v_RelPow = [];
          v_AppEn = [];
          v_SamEn = [];
          
          for s_Counter = 1:length(obj.st_hrv)
              
              clear v_RSamples
              v_RSamples = find(obj.st_hrv(s_Counter).rrsam >= obj.a_curr_first_sam & ...
                  obj.st_hrv(s_Counter).rrsam <= obj.a_curr_last_sam);
              if ~isempty(v_RSamples)
                  v_RSamples = obj.st_hrv(s_Counter).rrsam(v_RSamples);
              end
              
              clear v_RRSignal v_RRTime v_RRInter
              if length(v_RSamples) > 3
                  % R-R signal
                  [v_RRSignal v_RRTime v_RRInter] = ...
                      f_HRVSignals(v_RSamples, p_samp_rate);
              else
                  v_RRSignal = [];
                  v_RRInter = [];
              end

              if features_check(1)
                  if length(v_RRSignal) > 2
                      % R-R signal in milliseconds
                      v_RRSigMilli = f_Sec2MilliSec(v_RRSignal);
                      [s_Max s_Min] = f_RRMaxMin(v_RRSigMilli);
                      v_RRStats = f_AddVerElems(v_RRStats, [mean(v_RRSigMilli) ...
                          var(v_RRSigMilli) s_Min s_Max]);
                  else
                      v_RRStats = f_AddVerElems(v_RRStats, [-1 -1 -1 -1]);
                  end
              end
              
              if features_check(2)
                  if length(v_RRSignal) > 2
                      clear v_BPMSignal
                      v_BPMSignal = f_RR2BPM(v_RRSignal);
                      [s_Max s_Min] = f_RRMaxMin(v_BPMSignal);
                      v_BPMStats = f_AddVerElems(v_BPMStats, [mean(v_BPMSignal) ...
                          var(v_BPMSignal) s_Min s_Max]);
                  else
                      v_BPMStats = f_AddVerElems(v_BPMStats, [-1 -1 -1 -1]);
                  end
              end

              if features_check(3)
                  if length(v_RRInter) >= 10
                      v_RelPow = f_AddVerElems(v_RelPow, ...
                          f_RelPow(v_RRInter, obj.s_InterSamRate, obj.m_FreqBandsHz, 1)');
                  else
                      v_RelPow = f_AddVerElems(v_RelPow, -1.* ones(1, length(obj.m_FreqBandsHz)));
                  end
              end

              if features_check(4)
                  if length(v_RRSignal) > 10
                      v_AppEn = f_AddVerElems(v_AppEn, f_apen_est(v_RRSignal));
                  else
                      v_AppEn = f_AddVerElems(v_AppEn, -1);
                  end
              end
              
              if features_check(5)
                  if length(v_RRSignal) > 10
                      v_SamEn = f_AddVerElems(v_SamEn, f_sampen(v_RRSignal, 3, [], [], 0));
                  else
                      v_SamEn = f_AddVerElems(v_SamEn, -1);
                  end
              end              
          end
          
          obj.a_curr_first_sam = obj.a_curr_first_sam + obj.acq_step_sam;
          obj.a_curr_last_sam = obj.a_curr_first_sam + obj.acq_window_sam - 1;

          if study.dataset(study.dataset_selected).results.saveFileHandle_ecg > 0
              if ~isempty(v_RRStats)
                  fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_ecg, ...
                      v_RRStats(:), 'double');
              end
              
              if ~isempty(v_BPMStats)
                  fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_ecg, ...
                      v_BPMStats(:), 'double');
              end              
              
              if ~isempty(v_RelPow)
                  fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_ecg, ...
                      v_RelPow(:), 'double');
              end         
              
              if ~isempty(v_AppEn)
                  fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_ecg, ...
                      v_AppEn(:), 'double');
              end         
              
              if ~isempty(v_SamEn)
                  fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_ecg, ...
                      v_SamEn(:), 'double');
              end                  
          else
              if ~isempty(v_RRStats)
                  if ~isempty(obj.RRMean_results)
                      obj.RRMean_results = obj.RRMean_results{1};
                  end
                  obj.RRMean_results = f_AddHorElems(obj.RRMean_results, ...
                      v_RRStats(:, 1));
                  obj.RRMean_results = {obj.RRMean_results};

                  if ~isempty(obj.RRVar_results)
                      obj.RRVar_results = obj.RRVar_results{1};
                  end
                  obj.RRVar_results = f_AddHorElems(obj.RRVar_results, ...
                      v_RRStats(:, 2));
                  obj.RRVar_results = {obj.RRVar_results};

                  if ~isempty(obj.RRMin_results)
                      obj.RRMin_results = obj.RRMin_results{1};
                  end
                  obj.RRMin_results = f_AddHorElems(obj.RRMin_results, ...
                      v_RRStats(:, 3));
                  obj.RRMin_results = {obj.RRMin_results};

                  if ~isempty(obj.RRMax_results)
                      obj.RRMax_results = obj.RRMax_results{1};
                  end
                  obj.RRMax_results = f_AddHorElems(obj.RRMax_results, ...
                      v_RRStats(:, 4));
                  obj.RRMax_results = {obj.RRMax_results};
              end

              if ~isempty(v_BPMStats)
                  if ~isempty(obj.BPMMean_results)
                      obj.BPMMean_results = obj.BPMMean_results{1};
                  end
                  obj.BPMMean_results = f_AddHorElems(obj.BPMMean_results, ...
                      v_BPMStats(:, 1));
                  obj.BPMMean_results = {obj.BPMMean_results};

                  if ~isempty(obj.BPMVar_results)
                      obj.BPMVar_results = obj.BPMVar_results{1};
                  end
                  obj.BPMVar_results = f_AddHorElems(obj.BPMVar_results, ...
                      v_BPMStats(:, 2));
                  obj.BPMVar_results = {obj.BPMVar_results};

                  if ~isempty(obj.BPMMin_results)
                      obj.BPMMin_results = obj.BPMMin_results{1};
                  end
                  obj.BPMMin_results = f_AddHorElems(obj.BPMMin_results, ...
                      v_BPMStats(:, 3));
                  obj.BPMMin_results = {obj.BPMMin_results};

                  if ~isempty(obj.BPMMax_results)
                      obj.BPMMax_results = obj.BPMMax_results{1};
                  end
                  obj.BPMMax_results = f_AddHorElems(obj.BPMMax_results, ...
                      v_BPMStats(:, 4));
                  obj.BPMMax_results = {obj.BPMMax_results};
              end

              if ~isempty(v_RelPow)
                  if ~isempty(obj.VLF_results)
                      obj.VLF_results = obj.VLF_results{1};
                  end
                  obj.VLF_results = f_AddHorElems(obj.VLF_results, ...
                      v_RelPow(:, 1));
                  obj.VLF_results = {obj.VLF_results};

                  if ~isempty(obj.LF_results)
                      obj.LF_results = obj.LF_results{1};
                  end
                  obj.LF_results = f_AddHorElems(obj.LF_results, ...
                      v_RelPow(:, 2));
                  obj.LF_results = {obj.LF_results};

                  if ~isempty(obj.HF_results)
                      obj.HF_results = obj.HF_results{1};
                  end
                  obj.HF_results = f_AddHorElems(obj.HF_results, ...
                      v_RelPow(:, 3));
                  obj.HF_results = {obj.HF_results};
              end

              if ~isempty(v_AppEn)
                  if ~isempty(obj.AppEn_results)
                      obj.AppEn_results = obj.AppEn_results{1};
                  end
                  obj.AppEn_results = f_AddHorElems(obj.AppEn_results, ...
                      v_AppEn(:, 1));
                  obj.AppEn_results = {obj.AppEn_results};
              end
              
              if ~isempty(v_SamEn)
                  if ~isempty(obj.SamEn_results)
                      obj.SamEn_results = obj.SamEn_results{1};
                  end
                  obj.SamEn_results = f_AddHorElems(obj.SamEn_results, ...
                      v_SamEn(:, 1));
                  obj.SamEn_results = {obj.SamEn_results};
              end              
          end
      end;


      
      
      function obj  = run_RR_statistics(obj, study)
         
         obj.mean_RR = f_Mean(obj.s_rr);
         obj.std_RR = f_StDev(obj.s_rr);
         [obj.max_RR obj.min_RR obj.diff_RR] = f_RRMaxMin(obj.s_rr);
         
      end
      
      function obj  = run_BMP_statistics(obj, study)
         obj.mean_BMP = f_Mean(obj.s_hrv);
         obj.std_BMP = f_StDev(obj.s_hrv);
         [obj.max_BMP obj.min_BMP obj.diff_BMP] = f_RRMaxMin(obj.s_hrv);
         
      end
      
      function obj  = run_NN_statistics(obj, study)
         obj.std_NN = f_StDev(obj.s_NN);
         obj.RMS_NN = f_RMS(obj.s_NN);
         [obj.v_NN50,  obj.v_NN50Per] = f_NN50(obj.s_NN);
               
      end
      
      
      function obj  = run_relpow(obj, study, AR)
          
         %eeg = study.dataset.file.data.eeg;
         [obj.relpow obj.powspec obj.v_freq] = f_RelPow(obj.s_RRInter, obj.s_InterSamRate,...
             obj.m_FreqBandsHz, AR);
      end
      
      
      
      function obj  = run_ARcoeff(obj, study)
         %eeg = study.dataset.file.data.eeg;
         obj.ARCoeff = f_ARModelCoeff(obj.s_RRInter);
      end
      
      function obj  = run_apen(obj, study)
          obj.ApEn = f_AppEn(obj.s_rr);
      end
      
      
      
   end
      
   methods (Access = public)
        [s_Mean s_Var s_Skew s_Kurt] = f_Moment(v_EEGSignal);
        [v_RelPow1 v_PowSpec1 v_Freq1] = f_RelPow(v_EEGSignal, s_SamRate, m_FreqBandsHz);
        [s_SEF s_EdgePow] = f_SpecEdgeFreq(v_EEGSignal, s_SamRate,...
            ps_FreqRef, ps_Per, ps_MinFreq, ps_ARMethod);
        v_ARCoeff = f_ARModelCoeff(pv_Sig,ps_AROrder, ps_ARMethod);
        
        
        [v_RSamples v_ECGSignal] = f_RWaveDet(v_ECGSignal, s_SamRate);
        
        [v_RRSignal v_RRTime v_RRInter v_RRInterTime] = f_HRVSignals(v_RSamples, s_SamRate);
        v_RRSigMilli = f_Sec2MilliSec(v_RRSignal);
        v_NNDiffMilli = f_NN2NNDiff(v_RRSigMilli);
        v_BPMSignal = f_RR2BPM(v_RRSignal);
        f_Mean(v_RRSigMilli);
        f_StDev(v_RRSigMilli);
        [s_Max s_Min s_MaxMinDiff] = f_RRMaxMin(v_RRSigMilli);
        [s_NN50 s_NN50Per] = f_NN50(v_NNDiffMilli);
   end
    
end