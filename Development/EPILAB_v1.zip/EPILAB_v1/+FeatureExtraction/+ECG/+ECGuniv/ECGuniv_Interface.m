classdef ECGuniv_Interface < handle
    %======================================================================
    %ECGuniv_Interface
    %
    %Interface to ECGuniv
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================

   %Properties needed to the interface
   properties
      panel_title = 'ECG univariate';
      
      ecguniv_i;
      ecguniv_d;
      ecguniv_f;
      study;
      AR;
      
      acq_window;
      acq_step;
     
   end
    
   methods(Static)
       
      %Constructor
      function obj = ECGuniv_Interface(study)
          %import MODULE.BE.*;
		  
          obj.study = study;
		  obj.ecguniv_d = FeatureExtraction.ECG.ECGuniv.ECGuniv_Data();
		  obj.ecguniv_f = FeatureExtraction.ECG.ECGuniv.ECGuniv_Functions(study);
          
          obj.acq_window = 5;
          obj.acq_step = obj.acq_window;
      end
      
      
      %Draws the content of the sub-module panel
      %REQUIRED FUNCTION
      function draw(obj, panel)
          % set(panel, 'Title',obj.panel_title, 'TitlePosition','centertop');
 
          obj.ecguniv_i.ModulesPanel = uipanel('Parent', panel, 'Title',...
              'ECG Univariate Measures' ,'Units','Normalized',...
              'Position', [0.05 0.05 0.9 0.9]);
          
          obj.ecguniv_i.AcquisitionIntervalEdit = uicontrol('Parent',obj.ecguniv_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.9 0.2 0.05],...
              'String',num2str(obj.acq_window)); % Edit box for data path
          obj.ecguniv_i.AcquisitionIntervalText = uicontrol('Parent', obj.ecguniv_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.9 0.5 0.05],...
              'String','Feature computation - acquisition interval (minutes)'); % Text for data path
          
          s_CurrVer = 0.7;
          s_VerSpace = s_CurrVer / 4;
          
          obj.ecguniv_i.RRStatistics = uicontrol('Parent',obj.ecguniv_i.ModulesPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.1 s_CurrVer 0.7 s_VerSpace],...
              'String','R-R Statistics', 'enable','on', 'value', 1); % Edit box for data path

          s_CurrVer = s_CurrVer - s_VerSpace;
          obj.ecguniv_i.BPMStatistics = uicontrol('Parent',obj.ecguniv_i.ModulesPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.1 s_CurrVer 0.7 s_VerSpace],...
              'String','BPM Statistics', 'enable','on', 'value', 1); % Edit box for data path
          
          s_CurrVer = s_CurrVer - s_VerSpace;
          obj.ecguniv_i.Spectral = uicontrol('Parent',obj.ecguniv_i.ModulesPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.1 s_CurrVer 0.7 s_VerSpace],...
              'String','Spectral analysis', 'enable','on', 'value', 1); % Edit box for data path
          
          s_CurrVer = s_CurrVer - s_VerSpace;
          obj.ecguniv_i.AppEn = uicontrol('Parent',obj.ecguniv_i.ModulesPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.1 s_CurrVer 0.7 s_VerSpace],...
              'String','App. Entropy', 'enable','on', 'value', 1); % Edit box for data path

          obj.ecguniv_i.CancelButton = uicontrol('Parent', obj.ecguniv_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.45 0.1 0.1 0.075],...
              'String','Cancel','Callback', {@CancelButtonCallback, obj}); % Button for cancel
          obj.ecguniv_i.HelpButton = uicontrol('Parent', obj.ecguniv_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.60 0.1 0.1 0.075],...
              'String','Help','Callback', @HelpButtonCallback); % Button for help
          obj.ecguniv_i.OkButton = uicontrol('Parent', obj.ecguniv_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.75 0.1 0.1 0.075],...
              'String','Ok','Callback', {@OkButtonCallback, obj, obj.study}); % Button for ok
          
          function OkButtonCallback (hObject, eventdata, obj, study)

              if isempty(get(obj.ecguniv_i.AcquisitionIntervalEdit, 'String'))
                  return;
              end

              results = obj.ecguniv_f.Run (study, obj.acq_window * 60, obj.acq_step * 60);
              
              obj.ecguniv_d.SaveData(study, results);
              
              close(gcf);
          end
          
          function CancelButtonCallback (hObject, eventdata, obj)
              obj.clear (obj.ecguniv_i);
              close(gcf);
          end          
           
      end
      
      function SetInitParams(obj, p_window, p_step)
          obj.acq_window = p_window;
          obj.acq_step = p_step;
          obj.ecguniv_f.SetInitParams(obj.acq_window, obj.acq_step);
      end        
      
      function ClearChildClasses(obj)
          delete(obj.ecguniv_f);
          clear obj.ecguniv_f
          delete(obj.ecguniv_d);
          clear obj.ecguniv_d
		  obj.ecguniv_d = FeatureExtraction.ECG.ECGuniv.ECGuniv_Data();
		  obj.ecguniv_f = FeatureExtraction.ECG.ECGuniv.ECGuniv_Functions(obj.study);
          obj.ecguniv_f.SetInitParams(obj.acq_window, obj.acq_step);
      end      
      
      function RunSingleSegment(obj, study, p_samp_rate, p_ecg_features)
          obj.ecguniv_f.RunSingleSegment(study, p_samp_rate, p_ecg_features);
      end
      
      function InitRRSignal(obj, study, p_segment, p_samp_rate, p_invert_factor)
          obj.ecguniv_f.InitRRSignal(study, p_segment, p_samp_rate, ...
              p_invert_factor);
      end      
      
      function GetRRSignal(obj, study, p_segment, p_samp_rate)
          obj.ecguniv_f.GetRRSignal(study, p_segment, p_samp_rate);
      end        
      
      function last_samp = GetCurrLastSamp(obj)
          last_samp = obj.ecguniv_f.GetCurrLastSamp();
      end      

      function SaveResults(obj, study, features_check)
          obj.ecguniv_d.SaveData(study, obj.ecguniv_f, features_check);
      end      
	  
	  %Clear the content of the sub-module panel
	  %This function is called by the module when the user want to change to another sub-module
	  %This is important to avoid memory problems
      %REQUIRED FUNCTION
      function clear(obj)
      end
	  
   end
end