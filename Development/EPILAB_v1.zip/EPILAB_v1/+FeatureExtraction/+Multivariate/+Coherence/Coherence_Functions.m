classdef Coherence_Functions < handle
    %======================================================================
    %Coherence_Functions
    %
    %Functions of Coherence
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    % The following properties can be set only by class methods
    properties
        parameter_acquisition;
        % Algorithm output
        time;
        Coherence = {};
        labels;
    end
    methods
        % Constructor
        function obj= Coherence_Functions()
        end
        
        
        function obj = RunSingleSegment(obj, study, p_segment, p_samp_rate,Coherencefrq)
            %======================================================================
            %Adaptation to work in multifeature mode
            %EU FP7 Grant 211713 (EPILEPSIAE)
            %
            %Cesar A. D. Teixeira
            %CISUC, FCTUC, University of Coimbra
            %July 2010
            %==============================================================
            %========
            
            addpath(fullfile('Toolbox','code_Freiburg'));
            addpath(fullfile('Toolbox','BCT'));
            %for s_Counter = 1:size(p_segment, 1)
            
            eeg_length = length(p_segment);
            num_total = 0;%floor(((eeg_length - window_MeanPhaseCoherence)/window_shift));
            
            BMVresults= BiMultiVariateFeatures_Functions(p_segment', p_samp_rate,size(p_segment, 1),eeg_length, num_total, 'COH', eeg_length,Coherencefrq);
            
            %end
            
            obj.labels = BMVresults.labels;
            
            if study.dataset(study.dataset_selected).results.saveFileHandle_mlt > 0
                fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_mlt, ...
                    BMVresults.IM(1:nchoosek(size(p_segment,1),2),1), 'double');
            else
                if ~isempty(obj.Coherence)
                    obj.Coherence = obj.Coherence{1};
                end
                obj.Coherence = f_AddHorElems(obj.Coherence,BMVresults.IM(:,1));
                obj.Coherence = {obj.Coherence};
            end
        end;
        
        
    end%methods
end%classdef
