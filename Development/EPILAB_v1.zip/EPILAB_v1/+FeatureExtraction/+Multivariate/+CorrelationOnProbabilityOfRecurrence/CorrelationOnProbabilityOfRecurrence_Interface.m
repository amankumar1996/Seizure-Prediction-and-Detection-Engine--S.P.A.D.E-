classdef CorrelationOnProbabilityOfRecurrence_Interface < handle
    %======================================================================
    %CorrelationOnProbabilityOfRecurrence_Interface
    %
    %Interface to CorrelationOnProbabilityOfRecurrence
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
% The following properties can be set only by class methods
   properties
      e_i;
      e_d;
      e_f;
% data
      study;
   end%properties
   methods
% Constructor
      function obj= CorrelationOnProbabilityOfRecurrence_Interface(study)
% Create and then hide the GUI as it is being constructed.
         obj.study= study;         
         obj.e_f= FeatureExtraction.Multivariate.CorrelationOnProbabilityOfRecurrence.CorrelationOnProbabilityOfRecurrence_Functions();
         obj.e_d= FeatureExtraction.Multivariate.CorrelationOnProbabilityOfRecurrence.CorrelationOnProbabilityOfRecurrence_Data();
      end%function obj= CorrelationOnProbabilityOfRecurrence_Interface(study)
   end%methods
   methods(Static)
% Draw the panel and its contents
      function draw(obj, panel)
% display new panel
         obj.e_i.ModulesPanel= uipanel('Parent', panel, 'Title', 'Corr. btw. Prob. of Recurrence features' ,'Units', 'Normalized', 'Position', [0.05 0.05 0.9 0.9]);

         obj.e_i.AcquisitionIntervalEdit= uicontrol('Parent', obj.e_i.ModulesPanel, 'style', 'edit', 'HandleVisibility', 'callback', 'Units', 'Normalized', 'Position', [0.600 0.800 0.200 0.050], 'String', ''); % Edit box for data path
         obj.e_i.AcquisitionIntervalText= uicontrol('Parent', obj.e_i.ModulesPanel, 'style', 'text', 'HandleVisibility', 'callback', 'Units', 'Normalized', 'Position', [0.050 0.800 0.500 0.050], 'String', 'Feature computation - acquisition interval (seconds)'); % Text for data path


         obj.e_i.CPREdit= uicontrol('Parent', obj.e_i.ModulesPanel, 'style', 'edit', 'HandleVisibility', 'callback', 'Units', 'Normalized', 'Position', [0.60 0.40 0.10 0.05], 'String', ''); % Edit box for data path
         obj.e_i.CPRText= uicontrol('Parent', obj.e_i.ModulesPanel, 'style', 'text', 'HandleVisibility', 'callback', 'Units', 'Normalized', 'Position', [0.05 0.40 0.45 0.05], 'String', 'CorrelationOnProbabilityOfRecurrence window size, seconds'); % Edit box for data path
         obj.e_i.CancelButton= uicontrol('Parent', obj.e_i.ModulesPanel, 'style', 'pushbutton', 'HandleVisibility', 'callback', 'Units', 'Normalized', 'Position', [0.55 0.05 0.1 0.05], 'String', 'Cancel', 'Callback', {@CancelButtonCallback, obj}); % Button for cancel
         obj.e_i.HelpButton  = uicontrol('Parent', obj.e_i.ModulesPanel, 'style', 'pushbutton', 'HandleVisibility', 'callback', 'Units', 'Normalized', 'Position', [0.70 0.05 0.1 0.05], 'String', 'Help',   'Callback', @HelpButtonCallback); % Button for help
         obj.e_i.OkButton    = uicontrol('Parent', obj.e_i.ModulesPanel, 'style', 'pushbutton', 'HandleVisibility', 'callback', 'Units', 'Normalized', 'Position', [0.85 0.05 0.1 0.05], 'String', 'Ok',     'Callback', {@OkButtonCallback, obj, obj.study}); % Button for ok
      
         function OkButtonCallback(hObject, eventdata, obj, study)
% Input parameters (eeg, parameter acquisition, ste, lte)
            if((~isempty(get(obj.e_i.AcquisitionIntervalEdit, 'String')))  && ((~isempty(get(obj.e_i.CPREdit, 'String')))));
               parameter_acquisition= str2double(get(obj.e_i.AcquisitionIntervalEdit, 'String'));
               results= [];
               
               CorrelationOnProbabilityOfRecurrencewin= str2double(get(obj.e_i.CPREdit, 'String'));
%               CorrelationOnProbabilityOfRecurrencefrq= str2double(get(obj.e_i.CPREdit, 'String'));
               results= obj.e_f.Run(study, parameter_acquisition, CorrelationOnProbabilityOfRecurrencewin);
               
% Save results
               selection= questdlg('Do you want to save results?', 'Save Request', 'Yes','No','Yes');
               switch selection,
                  case 'Yes',
                     obj.study= obj.e_d.SaveData (obj.study, results);
                  case 'No'
                     return
               end
            else
               warndlg('Required fields were left empty', 'Error!!!')
            end
         end
         function CancelButtonCallback(hObject, eventdata, obj)
            obj.clear(obj.e_i);
         end
      end
% Clear the panel and its contents
      function clear(C)
         delete(C.ModulesPanel);
      end
      
      function RunSingleSegment(obj, study, p_segment, p_samp_rate)
          obj.e_f.RunSingleSegment(study, p_segment, p_samp_rate);
      end
      
      function SaveResults(obj, study)
          obj.e_d.SaveData(study, obj.e_f);
      end 
      
      
   end%methods(Static)
end%classdef
