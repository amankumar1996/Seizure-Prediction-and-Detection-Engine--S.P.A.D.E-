classdef MutualInformation_Interface < handle
    %======================================================================
    %MutualInformation_Interface
    %
    %Interface to MutualInformation
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    % The following properties can be set only by class methods
    properties
        e_i;
        e_d;
        e_f;
        % data
        study;
    end%properties
    methods
        % Constructor
        function obj= MutualInformation_Interface(study)
            % Create and then hide the GUI as it is being constructed.
            obj.study= study;
            obj.e_f= FeatureExtraction.Multivariate.MutualInformation.MutualInformation_Functions();
            obj.e_d= FeatureExtraction.Multivariate.MutualInformation.MutualInformation_Data();
        end%function obj= MutualInformation_Interface(study)
    end%methods
    methods(Static)
        % Draw the panel and its contents
        function draw(obj, panel)
            % display new panel
            obj.e_i.ModulesPanel= uipanel('Parent', panel, 'Title', 'MutualInformation features' ,'Units', 'Normalized', 'Position', [0.05 0.05 0.9 0.9]);
            
            
            obj.e_i.MIEdit= uicontrol('Parent', obj.e_i.ModulesPanel, 'style', 'edit', 'HandleVisibility', 'callback', 'Units', 'Normalized', 'Position', [0.60 0.30 0.10 0.15], 'String',num2str(obj.e_d.MutualInformationDelay)); % Edit box for data path
            obj.e_i.MIText= uicontrol('Parent', obj.e_i.ModulesPanel, 'style', 'text', 'HandleVisibility', 'callback', 'Units', 'Normalized', 'Position', [0.05 0.30 0.45 0.15], 'String', 'MutualInformation evaluation delay, seconds'); % Edit box for data path
            
            obj.e_i.CancelButton= uicontrol('Parent', obj.e_i.ModulesPanel, 'style', 'pushbutton', 'HandleVisibility', 'callback', 'Units', 'Normalized', 'Position', [0.55 0.05 0.1 0.15], 'String', 'Cancel', 'Callback', {@CancelButtonCallback, obj}); % Button for cancel
            obj.e_i.HelpButton  = uicontrol('Parent', obj.e_i.ModulesPanel, 'style', 'pushbutton', 'HandleVisibility', 'callback', 'Units', 'Normalized', 'Position', [0.70 0.05 0.1 0.15], 'String', 'Help',   'Callback', @HelpButtonCallback); % Button for help
            obj.e_i.OkButton    = uicontrol('Parent', obj.e_i.ModulesPanel, 'style', 'pushbutton', 'HandleVisibility', 'callback', 'Units', 'Normalized', 'Position', [0.85 0.05 0.1 0.15], 'String', 'Ok',     'Callback', {@OkButtonCallback, obj, obj.study}); % Button for ok
            
            function OkButtonCallback(hObject, eventdata, obj, study)
                % Input parameters (eeg, parameter acquisition, ste, lte)
                if(~isempty(get(obj.e_i.MIEdit, 'String')));
                    
                    obj.e_d.MutualInformationDelay= str2double(get(obj.e_i.MIEdit, 'String'));
                    
                    
                    close(gcf);
                else
                    warndlg('Required fields were left empty', 'Error!!!')
                end
            end
            function CancelButtonCallback(hObject, eventdata, obj)
                obj.clear(obj.e_i);
            end
        end
        % Clear the panel and its contents
        function clear(C)
            delete(C.ModulesPanel);
        end
        
        function RunSingleSegment(obj, study, p_segment, p_samp_rate)
            obj.e_f.RunSingleSegment(study, p_segment, p_samp_rate,obj.e_d.MutualInformationDelay);
        end
        
        function SaveResults(obj, study)
            obj.e_d.SaveData(study, obj.e_f);
        end
        
    end%methods(Static)
end%classdef
