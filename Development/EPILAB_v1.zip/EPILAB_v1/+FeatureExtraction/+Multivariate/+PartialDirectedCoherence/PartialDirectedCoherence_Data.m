classdef PartialDirectedCoherence_Data < handle
    %======================================================================
    %PartialDirectedCoherence_Data
    %
    %Data of PartialDirectedCoherence
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    % The following properties can be set as public
    properties
        parameter_acquisition;
        % Algorithm output
        time;
        c_= struct([]);
        PartialDirectedCoherencefrq=40;
    end%properties
    methods
        
        % Constructor
        function obj= PartialDirectedCoherence_Data()
        end
        
        function study = SaveData(obj, study, results)
            
            for x=1:length(study.dataset_selected)
                
                selected_chans = study.dataset(study.dataset_selected(x)).results.chansSelected;
                chans_ind = study.dataset(study.dataset_selected(x)).results.EEGchansSelectedInd;
                chans_ind = reshape(chans_ind, 1, []);
                dataset = study.dataset_selected(x);
                
                %study.dataset(study.dataset_selected).results.chansSelected={};
                for k = 1:nchoosek(size(chans_ind,2),2)
                    st=results.labels{k};
                    
                    idx1=findstr(st,'chan');
                    idx2=findstr(st,'_d_');
                    ch1_idx=str2num(st(idx1+4:idx2-1))
                    ch2_idx=str2num(st(idx2+3:end))
                    
                    ch1=selected_chans{ch1_idx,1}
                    ch2=selected_chans{ch2_idx,1}
                    
                    
                if (sum(strcmpi(study.dataset(study.dataset_selected).results.mltChanComb,[ch1,'-',ch2]))==0) && (sum(strcmpi(study.dataset(study.dataset_selected).results.mltChanComb,[ch2,'-',ch1]))==0)
                        study.dataset(study.dataset_selected).results.mltChanComb={study.dataset(study.dataset_selected).results.mltChanComb{:},[ch1,'-',ch2]}';
                    end
                    
                    
                    if ~isempty(results.PartialDirectedCoherence)
                        eval(['obj.c_(1).PDC_channel_',ch1,'_',ch2,'=[];']);
                        eval(['obj.c_(1).PDC_channel_',ch1,'_',ch2,'= results.PartialDirectedCoherence{x}(k,:);']);
                        
                        
                        
                        if isfield(study.dataset(study.dataset_selected(x)).results.featureExtractionMethods,'MultiVariate')
                            ss=study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.MultiVariate.c_;
                            ss.(['PDC_channel_',ch1,'_',ch2])=results.PartialDirectedCoherence{x}(k,:);
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.MultiVariate.c_=ss;
                        else
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.('MultiVariate').('c_').(['PDC_channel_',ch1,'_',ch2])=results.PartialDirectedCoherence{x}(k,:);
                        end
                        
                    end
                    if k > 1
                        continue;
                    end
                    
                    study.dataset(study.dataset_selected(x)).results.featureNames_mlt = ...
                        strcat(study.dataset(study.dataset_selected(x)).results.featureNames_mlt, ...
                        'PDC,');
                    
                end
                
                
                
                
                
                
                
                
                obj.parameter_acquisition = results.parameter_acquisition;
                obj.time = results.time;
                %study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.MultiVariate = obj;
                
                obj = FeatureExtraction.Multivariate.PartialDirectedCoherence.PartialDirectedCoherence_Data();
                
            end
        end
        
        
    end%methods
end%classdef
