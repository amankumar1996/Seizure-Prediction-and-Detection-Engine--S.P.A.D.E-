classdef MultiFeature_Functions < handle
    %======================================================================
    %MultiFeature_Functions
    %
    %Functions of ARModCoeff
    %CISUC/FCTUC
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    
    % The following properties can be set only by class methods
    properties
        
        acq_window;
        acq_step;
        e_d;
        % algorithm output
        time;
        s_MultiFeature_results
        is_canceled=0;
        
    end
    
    methods
        
        %Constructor
        function obj = MultiFeature_Functions()
            
        end
        
        function obj = Run (obj, study, acq_window, acq_step,notch_check,notch_freq,low_check,low_cut,low_ord,high_check,high_cut,high_ord, ...
                uni_check, uni_interfaces, multi_check, multi_interfaces, ...
                ecg_check, ecg_interface,description_obj)
            
            
            
            
            
            study.dataset(study.dataset_selected).results.parameterAcq=acq_step;
            study.dataset(study.dataset_selected).results.feat_events=[];
            
            global g_MAT_TYPE g_TRC_TYPE g_BIN_TYPE g_NIC_TYPE
            
            function [file, f_type, samp_rate, n_chans, n_pnts, sel_chan,evts] = ...
                    FileInfo(study, file_num)
                % returns information about the file being processed
                
                file = fullfile(study.dataset(study.dataset_selected).file(file_num).path,...
                    study.dataset(study.dataset_selected).file(file_num).filename);
                f_type=study.dataset(study.dataset_selected).file(file_num).type;
                samp_rate = study.dataset(study.dataset_selected).file(file_num).data.sampling_rate;
                n_chans = length(study.dataset(study.dataset_selected).file(file_num).data.electrodes);
                n_pnts =  study.dataset(study.dataset_selected).file(file_num).data.n_pnts;
                sel_chan = study.dataset(study.dataset_selected).results.chansSelected;
                
                evts =  study.dataset(study.dataset_selected).file(file_num).data.eeg_events;
                
            end
            
            function global_sec = get_curr_global_secs(p_glb_start_ts, p_curr_start_ts, ...
                    p_curr_first_samp, p_samp_rate)
                global_sec = etime(datevec(p_curr_start_ts, 'yyyy-mm-dd HH:MM:SS'), ...
                    datevec(p_glb_start_ts, 'yyyy-mm-dd HH:MM:SS'));
                global_sec = global_sec + (p_curr_first_samp - 1) / p_samp_rate;
            end
            
            function ClearAllFeatures(p_uni_check, p_uni_interfaces, p_multi_check, ...
                    p_multi_interfaces, p_ecg_interface)
                
                for s_Counter = 1:length(p_uni_check)
                    if ~get(p_uni_check(s_Counter), 'value')
                        continue;
                    end
                    
                    p_uni_interfaces{s_Counter}.ClearChildClasses( ...
                        p_uni_interfaces{s_Counter});
                end
                
                if ~isempty(p_ecg_interface{1})
                    p_ecg_interface{1}.ClearChildClasses(p_ecg_interface{1});
                end
                
            end
            
            function ProcessSegment(p_eeg_segment, p_samp_rate, p_curr_sec, ...
                    p_uni_check, p_uni_interfaces, p_multi_check, p_multi_interfaces, ...
                    p_ecg_interface, ps_make_ecg, pv_ecg_features)
                
                if ~isempty(study.dataset(study.dataset_selected).results.saveFileName)
                    if ~isempty([p_uni_interfaces{:}])
                    fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_uni, ...
                        p_curr_sec, 'double');
                    end
                    
                    if ~isempty([p_multi_interfaces{:}])
                    fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_mlt, ...
                        p_curr_sec, 'double');
                    end
                    
                    if ps_make_ecg~=0
                    fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_ecg, ...
                        p_curr_sec, 'double');
                    end
                    
                else
                    study.dataset(study.dataset_selected).results.glbTime = ...
                        f_AddHorElems(study.dataset(study.dataset_selected).results.glbTime, ...
                        p_curr_sec);
                    study.from_raw=2;
                    
                    
                end
                
                if ~isempty(p_eeg_segment)
                    %s_filtered = 0;
                    
                    
                    
                    if (notch_check)%If the notch filter check button is pressed
                        
                        %Apply a notch filter centered at 50 Hz and with a pass band of 2 Hz
                        p_eeg_segment=notch_filter(p_eeg_segment',notch_freq,2,4,p_samp_rate)';
                        
                        
                    end
                    
                    if (low_check)%If the low-pass filter check button is pressed
                        
                        if low_cut>0.5 && low_cut<(p_samp_rate/2)%Verify if the cut-off value defined is appropriate
                            %Apply a low-pass filter with the acquired cut-off frequency and with
                            %order 5
                            p_eeg_segment=low_pass_filter(p_eeg_segment',low_cut,low_ord,p_samp_rate)';
                            
                        end
                    end
                    
                    if (high_check)%If the high-pass filter check button is pressed
                        
                        if high_cut>0.1 && high_cut<(p_samp_rate/2)%Verify if the cut-off value defined is appropriate
                            %Apply a high-pass filter with the acquired cut-off frequency and with
                            %order 2
                            p_eeg_segment=high_pass_filter(p_eeg_segment',high_cut,high_ord,p_samp_rate)';
                        end
                    end
                    
                    
                    
                    
                    for s_Counter = 1:length(p_uni_check)
                        if ~get(p_uni_check(s_Counter), 'value')
                            continue;
                        end
                        
                        if size(p_eeg_segment, 1) < max(eeg_chann_ind)
                            break;
                        end
                        
                        
                        
                        p_uni_interfaces{s_Counter}.RunSingleSegment(p_uni_interfaces{s_Counter}, ...
                            study, p_eeg_segment, p_samp_rate);
                        
                        
                    end
                    
                    
                    %Code for multivariate features
                    
                    
                    
                    for s_Counter = 1:length(p_multi_check)
                        if ~get(p_multi_check(s_Counter), 'value')
                            continue;
                        end
                        
                        if size(p_eeg_segment, 1) < max(eeg_chann_ind)
                            break;
                        end
                        
                        
                        
                                             
                        
                        p_multi_interfaces{s_Counter}.RunSingleSegment(p_multi_interfaces{s_Counter}, ...
                            study, p_eeg_segment, p_samp_rate);
                        
                        
                        
                        
                    end
                    
                    
                    
                    
                    
                end
                
                while ps_make_ecg
                    p_ecg_interface{1}.RunSingleSegment(p_ecg_interface{1}, study, ...
                        p_samp_rate, pv_ecg_features);
                    break;
                end
                
            end
            
            function data_filtered = filter_data(p_eeg_segment)
                
                data_filtered = p_eeg_segment;
                
                s_firstind = s_NotchFiltPadd;
                if s_firstind > size(data_filtered, 2);
                    s_firstind = size(data_filtered, 2);
                end
                s_lastind = s_firstind + size(data_filtered, 2) - 1;
                s_firstaux = size(data_filtered, 2) - (s_NotchFiltPadd - 1);
                if s_firstaux < 1
                    s_firstaux = 1;
                end
                clear m_temp
                m_temp = fliplr(data_filtered(:, 2:s_firstind));
                m_temp = f_AddHorElems(m_temp, data_filtered);
                m_temp = f_AddHorElems(m_temp, fliplr(data_filtered(:, ...
                    s_firstaux:(end - 1))));
                
                m_temp = f_IIRBiFilter(m_temp', s_NotchFilt)';
                
                clear data_filtered
                data_filtered = m_temp(:, s_firstind:s_lastind);
                clear m_temp
            end
            
            function [data file_count] = get_extra_segment(p_study, p_curr_seg, p_sel_chan, ...
                    p_window_samp, p_file_num, p_files_tot)
                
                data = p_curr_seg;
                size_hole = p_window_samp - size(data, 2);
                file_count = p_file_num;
                while 1
                    if file_count < p_files_tot
                        gap_secs = p_study.dataset(p_study.dataset_selected).gap{file_count}.seconds;
                        gap_size = round(gap_secs * samp_rate);
                        if gap_size > size_hole
                            gap_size = size_hole;
                        end
                    else
                        gap_size = size_hole;
                    end
                    
                    if gap_size > 0
                        clear v_Ind
                        v_Ind = zeros(1, gap_size);
                        s_Ind = size(data, 2);
                        s_Dir = -1;
                        for s_IndCounter = 1:gap_size
                            v_Ind(s_IndCounter) = s_Ind;
                            if size(data, 2) < 2
                                continue;
                            end
                            s_Ind = s_Ind + s_Dir;
                            if s_Ind < 1
                                s_Ind = 2;
                                s_Dir = 1;
                            end
                            if s_Ind > size(data, 2)
                                s_Ind = size(data, 2) - 1;
                                s_Dir = -1;
                            end
                        end
                        data = f_AddHorElems(data, ...
                            data(:, v_Ind));
                        clear v_Ind s_Ind s_Dir s_IndCounter
                    end
                    
                    if size(data, 2) >= p_window_samp
                        break;
                    end
                    
                    size_hole = p_window_samp - size(data, 2);
                    
                    file_count = file_count + 1;
                    
                    [file, f_type, samp_rate, n_chans, n_pnts, sel_chan,evts] = ...
                        FileInfo(study, file_count);
                    
                    clear data_obj_aux
                    data_obj_aux = gen_epilab_reader(file, f_type, n_pnts, ...
                        samp_rate);
                    
                    clear segment_trace_aux
                    segment_trace_aux = data_obj_aux.init_data_access(...
                        p_sel_chan, size_hole / samp_rate, size_hole / samp_rate);
                    
                    data_obj_aux.delete();
                    clear data_obj_aux
                    
                    data = f_AddHorElems(data, segment_trace_aux);
                    
                    if size(data, 2) >= p_window_samp
                        break;
                    end
                    
                    size_hole = p_window_samp - size(data, 2);
                end
                
                data = data(:, 1:p_window_samp);
            end
            
            function put_log_line(str_line)
                fprintf(s_logfile, '%s - %s\n', datestr(clock, 'yyyy_mm_dd_HH:MM:SS.FFF'), ...
                    str_line);
            end
            
            %s_usenotchfilter = 1;
            s_uselogfile = 1;
            obj.acq_window = acq_window;
            obj.acq_step = acq_step;
            if obj.acq_step <= 0
                obj.acq_step = obj.acq_window;
            end
            s_offset = 0;
            s_start_ts = [];
            
            sel_chan = study.dataset(study.dataset_selected).results.chansSelected;
            
            eeg_chann_ind = study.dataset(study.dataset_selected).results.EEGchansSelectedInd;
            ecg_chann_ind = study.dataset(study.dataset_selected).results.ECGchansSelectedInd;
            
            if isempty(ecg_chann_ind)
                s_make_ecg = 0;
                v_ecg_features = [];
                v_ecg_invert_factor = [];
            else
                s_make_ecg = 1;
                v_ecg_features = cell2mat(get(ecg_check, 'Value'));
                v_ecg_invert_factor = ones(1, length(ecg_chann_ind));
                ecg_interface{1}.SetInitParams(ecg_interface{1}, obj.acq_window, obj.acq_step);
                study.dataset(study.dataset_selected).results.featureNames_ecg = 'TimeOffset,';
            end
            
            files_tot = length(study.dataset(study.dataset_selected).file); %total number of files in dataset
            
            
            
            study.dataset(study.dataset_selected).results.glbTime = [];
            
            
            if sum(uni_check)>0
                study.dataset(study.dataset_selected).results.featureNames = 'TimeOffset,';
            end
            
            if sum(multi_check)>0
                study.dataset(study.dataset_selected).results.featureNames_mlt = 'TimeOffset,';
            end
            
                          
            
            s_logfile = -1;
            if s_uselogfile
                
                s_logfile = fopen(fullfile(pwd,'tmp',sprintf('%s_multifeat.txt', ...
                    datestr(clock, 'yyyymmdd_HHMMSS'))), 'wt');
                if s_logfile == -1
                    display(sprintf('[MultiFeature_Functions] - ERROR creating log file: %s', ...
                        s_logfile));
                end
            end
            
            ClearAllFeatures(uni_check, uni_interfaces, multi_check, ...
                multi_interfaces, ecg_interface);
            
            clear data_obj
            data_obj = [];
            
            file_num = 0;
            
            
            tot_points=[];
            
            for f=1:files_tot
                [file, f_type, samp_rate, n_chans, n_pnts, sel_chan,evts] = ...
                    FileInfo(study, f);
                tot_points=[tot_points,n_pnts];
            end
            
            gstart=tic;
            
            while file_num < files_tot
                
                
                
                
                file_num = file_num + 1;
                
                %% information about the file
                [file, f_type, samp_rate, n_chans, n_pnts, sel_chan,evt] = ...
                    FileInfo(study, file_num);
                
                
                %Insert valid seizure events in the results.feat_events struct
                
                
                vs=datenum(study.dataset(study.dataset_selected).file(file_num).data.start_ts);
                ov_start=datevec(study.dataset(study.dataset_selected).file(1).data.start_ts,'yyyy-mm-dd HH:MM:SS');
                
                
                
                on_fl=0;
                
                feat_evt=study.dataset(study.dataset_selected).results.feat_events;
                for ev=1:numel(evt)
                    if (~isempty(strfind(lower(evt(ev).type),'eeg-on')) || ~isempty(strfind(lower(evt(ev).type),'clin-on')))&&on_fl==0
                        secs_on=   evt(ev).started/samp_rate;
                        
                        
                        vd=datenum([0 0 0 0 0 secs_on]);
                        ts_on=datestr(vs+vd,'yyyy-mm-dd HH:MM:SS.FFF');
                        ts_on_sec=etime(datevec(ts_on,'yyyy-mm-dd HH:MM:SS.FFF'),ov_start);
                        
                        on_fl=1;
                        
                        
                    elseif (~isempty(strfind(lower(evt(ev).type),'eeg-off')) || ~isempty(strfind(lower(evt(ev).type),'clin-off'))) && on_fl==1
                        
                        secs_off=evt(ev).started/samp_rate;
                        on_fl=0;
                        
                        
                        vd=datenum([0 0 0 0 0 secs_off]);
                        
                        ts_off=datestr(vs+vd,'yyyy-mm-dd HH:MM:SS.FFF');
                        ts_off_sec=etime(datevec(ts_off,'yyyy-mm-dd HH:MM:SS.FFF'),ov_start);
                        
                        
                        feat_evt = horzcat(feat_evt,Epilab_Event('seizure',ts_on_sec,ts_off_sec,evt(ev).comments,ts_on,ts_off));
                        
                        if ~isempty(study.dataset(study.dataset_selected).results.saveFileName)
                            
                            fprintf(study.dataset(study.dataset_selected).results.saveFileHandle_evt,'seizure\t%s\t%d\t%s\t%d\t%s\t%d\t%s\t%s\t%s\n',ts_on,floor(ts_on_sec),'NA',NaN,ts_off,floor(ts_off_sec),'NA','NA','NA');
                        end
                        
                        
                        
                    end
                    
                end
                
                
                study.dataset(study.dataset_selected).results.feat_events=feat_evt;
                
                if s_logfile ~= -1
                    put_log_line(sprintf('Processing file (%d / %d): %s', file_num, ...
                        files_tot, file));
                end
                display(sprintf('[MultiFeature_Functions] - Processing file: %s', file));
                
                w_request = obj.acq_window * samp_rate;
                step_sam = obj.acq_step * samp_rate;
                
                if ~isempty(data_obj)
                    data_obj.delete();
                    clear data_obj
                end
                data_obj = gen_epilab_reader(file, f_type, n_pnts, samp_rate);%Create a data access object
                
                if isempty(s_start_ts)
                    s_start_ts = data_obj.start_ts;
                end
                
                clear segment_trace
                if ~isempty(ecg_chann_ind)
                    
                    segment_trace = data_obj.init_data_access(sel_chan(ecg_chann_ind),...
                        data_obj.file_obj.a_n_data_secs, data_obj.file_obj.a_n_data_secs, ...
                        s_offset);%read complete first segment
                    ecg_interface{1}.InitRRSignal(ecg_interface{1}, study, ...
                        segment_trace, samp_rate, v_ecg_invert_factor);
                end
                
                clear segment_trace
                segment_trace = [];
                if ~isempty(eeg_chann_ind)
                    segment_trace = data_obj.init_data_access(sel_chan(eeg_chann_ind),...
                        obj.acq_window, obj.acq_step, s_offset);%read complete first segment
                end
                
                curr_sec = get_curr_global_secs(s_start_ts, data_obj.start_ts, ...
                    data_obj.curr_first_samp, samp_rate) + obj.acq_window;
                
                s_lastsamp = s_offset + w_request;
                
                s_offset = 0;
                
                
                while ~obj.is_canceled
                    
                    
                    lstart=tic;
                    if s_lastsamp < n_pnts
                        ProcessSegment(segment_trace, samp_rate, curr_sec, ...
                            uni_check, uni_interfaces, multi_check, multi_interfaces, ...
                            ecg_interface, s_make_ecg, v_ecg_features);
                        if ~isempty(eeg_chann_ind)
                            segment_trace = data_obj.get_next_data_window();
                        end
                        curr_sec = curr_sec + obj.acq_step;
                        s_lastsamp = s_lastsamp + step_sam;
                    else
                        s_firstlocal = n_pnts - w_request;
                        if s_firstlocal < 0
                            s_firstlocal = 0;
                        end
                        clear segment_trace
                        segment_trace = data_obj.init_data_access(sel_chan, ...
                            w_request + 1, w_request + 1, s_firstlocal);
                        
                        s_firstlocal = n_pnts - (s_lastsamp - w_request + 1);
                        s_lastlocal = size(segment_trace, 2);
                        s_firstlocal = size(segment_trace, 2) - s_firstlocal;
                        
                        segment_trace = get_extra_segment(study, segment_trace, ...
                            sel_chan, 2 * (w_request + 1), file_num, files_tot);
                        
                        if s_make_ecg
                            ecg_interface{1}.GetRRSignal(ecg_interface{1}, study, ...
                                segment_trace(ecg_chann_ind, s_lastlocal + 1:end), ...
                                samp_rate);
                        end
                        
                        while s_firstlocal <= s_lastlocal
                            
                            ProcessSegment(segment_trace(eeg_chann_ind, ...
                                s_firstlocal:(s_firstlocal + w_request - 1)), ...
                                samp_rate, curr_sec, uni_check, uni_interfaces, ...
                                multi_check, multi_interfaces, ecg_interface, ...
                                s_make_ecg, v_ecg_features);
                            
                            curr_sec = curr_sec + obj.acq_step;
                            s_firstlocal = s_firstlocal + step_sam;
                        end
                        s_offset = s_firstlocal - s_lastlocal + 1;
                        break;
                    end
                    tm=toc(lstart);
                    if s_lastsamp==(s_offset + w_request + (2*step_sam)) %Compute statistics
                        
                        
                        
                        Est_time=((sum(tot_points(file_num:end))*tm)/w_request);
                        
                        disp(sprintf('Estimated Processing Time:%s',datestr(datenum([0 0 0 0 0 Est_time]),'dd HH:MM:SS')));
                        set(description_obj,'string',sprintf('Estimated Proc. Time=%s\nFile %d of %d',datestr(datenum([0 0 0 0 0 Est_time]),'dd HH:MM:SS'),file_num,files_tot),'ForegroundColor','red');
                        drawnow
                        
                    end
                    drawnow
                    if obj.is_canceled
                        break
                    end
                    
                    
                end
                
                gap_size = 0;
                file_count = file_num;
                while file_count < files_tot
                    gap_secs = study.dataset(study.dataset_selected).gap{file_count}.seconds;
                    gap_size = gap_size + round(gap_secs * samp_rate);
                    if gap_size >= s_offset
                        break;
                    end
                    file_count = file_count + 1;
                    [file, f_type, samp_rate, n_chans, n_pnts, sel_chan,evts] = ...
                        FileInfo(study, file_count);
                    gap_size = gap_size + n_pnts;
                    if gap_size >= s_offset
                        break;
                    end
                end
                if file_count == file_num
                    s_offset = 0;
                else
                    s_offset = n_pnts - (gap_size - (s_offset - 1));
                    file_num = file_count - 1;
                end
                
                
                
            end
            
            
            disp(sprintf('Computation lasted:%s',datestr(datenum([0 0 0 0 0 toc(gstart)]),'dd HH:MM:SS')));
            set(description_obj,'string',sprintf('Computation Lasted=%s',datestr(datenum([0 0 0 0 0 toc(gstart)]),'dd HH:MM:SS')),'ForegroundColor','black');
            drawnow
            
            
            if s_logfile ~= -1
                put_log_line(sprintf('Processing %d files done!', files_tot));
                fclose(s_logfile);
            end
            
            if ~isempty(data_obj)
                data_obj.delete();
                clear data_obj
            end
            
        end
        
        function obj = CreateHeaderFile (obj, study,typ)
            
            
            str_head_name = strcat(study.dataset(study.dataset_selected).results.saveFileName,'_',typ,'.dat.head');
            
            s_file = fopen(str_head_name, 'wt');
            if s_file < 0
                display(sprintf('[MultiFeature_Functions] - ERROR creating header file: %s', ...
                    str_head_name));
                return;
            end
            
            
            if strcmpi(typ,'mlt')
                elec=f_GetSignalStrFromCells(study.dataset(study.dataset_selected).results.mltChanComb);
                feat=study.dataset(study.dataset_selected).results.featureNames_mlt;
            elseif strcmpi(typ,'eeg')
                feat=study.dataset(study.dataset_selected).results.featureNames;
                elec=f_GetSignalStrFromCells(study.dataset(study.dataset_selected).results.chansSelected);
            else
                feat=study.dataset(study.dataset_selected).results.featureNames_ecg;
                elec=f_GetSignalStrFromCells(study.dataset(study.dataset_selected).results.chansEcg);
            end
            
            
            
            
            
            
            files_tot = length(study.dataset(study.dataset_selected).file);
            
            fprintf(s_file, 'window_size=%s\n', num2str(obj.acq_window));
            fprintf(s_file, 'step=%s\n', num2str(obj.acq_step));
            fprintf(s_file, 'electrode_names=%s\n',elec);
            fprintf(s_file, 'feauture_names=%s\n',feat);
            fprintf(s_file, 'notch_parms=\n');
            fprintf(s_file, 'low_parms=\n');
            fprintf(s_file, 'high_parms=\n');
            fprintf(s_file, 'band_parms=\n');
            
            fprintf(s_file, 'total_files=%d\n', files_tot);
            
            for file_num = 1:files_tot
                file = fullfile(study.dataset(study.dataset_selected).file(file_num).path,...
                    study.dataset(study.dataset_selected).file(file_num).filename);
                fprintf(s_file, '%s\t%s\n', ...
                    study.dataset(study.dataset_selected).file(file_num).data.start_ts, file);
            end
            
            fclose(s_file);
            
        end
    end
    
    methods (Access=public)
        s_MultiFeature = f_MultiFeature(obj,eeg_segment, ps_SamRate);
    end
    
    
end
