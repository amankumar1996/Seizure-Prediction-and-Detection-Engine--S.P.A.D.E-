
classdef MultiFeature_Interface < handle
    %======================================================================
    %MultiFeature_Interface
    %
    %Functions of ARModCoeff
    %CISUC/FCTUC
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    % The following properties can be set only by class methods
    properties
        e_i;
        e_d;
        e_f;
        
        acq_window;
        acq_step;
        low_cut=60;
        high_cut=0.5;
        low_check;
        low_ord;
        low_ord_pop;
        high_ord_pop;
        high_ord;
        high_check;
        notch_check;
        notch_freq;
        notch_freq_pop;
        % data
        un_with_opt=[1 1 0 0 0 1 0 1 1 0 1];%Define wich univariate features have aditional parameters
        mv_with_opt=[1 0 1 0 1 1];%Define wich multivariate features have aditional parameters
        study;
        Description;
        stop_sig=0;
    end
    
    methods
        %Constructor
        function obj = MultiFeature_Interface(study)
            %  Create and then hide the GUI as it is being constructed.
            obj.study = study;
            
            obj.e_f = FeatureExtraction.Tools.MultiFeature.MultiFeature_Functions();
            obj.acq_window = 5;
            obj.acq_step = obj.acq_window;
        end
    end
    
    methods(Static)
        %Draw the panel and its contents
        function draw(obj,panel)
            
            global h DIRECTORY_UNI DIRECTORY_MUL DIRECTORY_ECG SEPARATOR
            
            % display new panel
            obj.e_i.ModulesPanel = uipanel('Parent', panel, 'Title', 'MultiFeature process' ,'Units','Normalized','Position', [0.05 0.05 0.9 0.9]);
            
            
            obj.e_i.WindowSizeEdit = uicontrol('Parent',obj.e_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.35 0.925 0.1 0.05],...
                'String',num2str(obj.acq_window));
            obj.e_i.WindowSizeText = uicontrol('Parent', obj.e_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.92 0.3 0.05],...
                'String','Window size (seconds):');
            
            obj.e_i.StepSizeEdit = uicontrol('Parent',obj.e_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.35 0.87 0.1 0.05],...
                'String',num2str(obj.acq_step));
            obj.e_i.StepSizeText = uicontrol('Parent', obj.e_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.865 0.3 0.05],...
                'String','Step size (seconds):');
            
            
            
            %Define filters check buttons, labels and input boxes
            obj.e_i.notchCheck=uicontrol('Parent',obj.e_i.ModulesPanel,'Style','checkbox','units','Normalized','Position',[0.5 0.95 0.3 0.07],'String','Notch Filter','Value',1);
            obj.e_i.notch_freq_pop=uicontrol('Parent',obj.e_i.ModulesPanel,'Style','popupmenu','String',{'50 Hz','60 Hz'},'units','Normalized','Position',[0.68 0.95 0.15 0.06]');
            
            
            obj.e_i.lowpassCheck=uicontrol('Parent',obj.e_i.ModulesPanel,'Style','checkbox','units','Normalized','Position',[0.5 0.895 0.3 0.07],'String','Low-pass Filter; Cut-Off:');
            
            obj.e_i.lowcutEdit = uicontrol('Parent',obj.e_i.ModulesPanel,'style','edit','Units', 'Normalized','Position', [0.785 0.901 0.085 0.06],'String',num2str(obj.low_cut));
            obj.e_i.low_ord_pop=uicontrol('Parent',obj.e_i.ModulesPanel,'Style','popupmenu','String',{'Ord. 1','Ord. 2','Ord. 3','Ord. 4','Ord. 5','Ord. 6','Ord. 7','Ord. 8','Ord. 9','Ord. 10'},...
                'Value',5,'units','Normalized','Position',[0.855 0.895 0.15 0.06]');
            
            
            
            obj.e_i.highpassCheck=uicontrol('Parent',obj.e_i.ModulesPanel,'Style','checkbox','units','Normalized','Position',[0.5 0.84 0.3 0.07],'String','High-pass Filter; Cut-Off:');
            
            
            obj.e_i.highcutEdit = uicontrol('Parent',obj.e_i.ModulesPanel,'style','edit','Units', 'Normalized','Position', [0.785 0.844 0.085 0.06],'String',num2str(obj.high_cut));
            obj.e_i.high_ord_pop=uicontrol('Parent',obj.e_i.ModulesPanel,'Style','popupmenu','String',{'Ord. 1','Ord. 2','Ord. 3','Ord. 4','Ord. 5'},...
                'Value',2,'units','Normalized','Position',[0.855 0.84 0.15 0.06]');
            
            
            % univariate panel
            obj.e_i.UnivariatePanel = uipanel('Parent', obj.e_i.ModulesPanel, 'Title', 'Univariate features' ,'Units','Normalized','Position', [0.05 0.01 0.3 0.8]);
            
            h.FeatureExtraction.cpaths = getFeatureExtractionMethods(DIRECTORY_UNI);
            
            s_VerMar = 0.2;
            s_VerSpace = 1 / (length(h.FeatureExtraction.cpaths) + s_VerMar);
            s_CurrVer = 1;
            
            obj.e_i.UnivariateSel = zeros(1, length(h.FeatureExtraction.cpaths));
            obj.e_i.UnivariateButton = zeros(1, length(h.FeatureExtraction.cpaths));
            obj.e_i.UnivariateFig = zeros(1, length(h.FeatureExtraction.cpaths));
            obj.e_i.UnivariateInterfaces = cell(1, length(h.FeatureExtraction.cpaths));
            for i=1:length(h.FeatureExtraction.cpaths)
                c = h.FeatureExtraction.cpaths{i};
                c_name = c;
                c_name(c == SEPARATOR) = ' '; % Remove separators
                c_name = c_name(2:end); % Remove +
                s_CurrVer = s_CurrVer - s_VerSpace;
                obj.e_i.UnivariateSel(i) = uicontrol('Parent',obj.e_i.UnivariatePanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.1 s_CurrVer 0.7 s_VerSpace],...
                    'String',c_name, 'enable','on', 'value', 0, 'callback', {@UnivariateCheckCallBack, obj, obj.study, c_name, i}); % Edit box for data path
                
                if obj.un_with_opt(i)
                    obj.e_i.UnivariateButton(i) = uicontrol('Parent', obj.e_i.UnivariatePanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.8 s_CurrVer 0.1 s_VerSpace],...
                        'String','...', 'enable','off','Callback', {@UnivariateButtonCallback, obj, c_name, i}); % Button for ok
                end
            end
            
            % multivariate new panel
            obj.e_i.MultivariatePanel = uipanel('Parent', obj.e_i.ModulesPanel, 'Title', 'Multivariate features' ,'Units','Normalized','Position', [0.375 0.21 0.3 0.6]);
            
            h.FeatureExtraction.cpaths = getFeatureExtractionMethods(DIRECTORY_MUL);
            
            s_VerSpace = 1 / (length(h.FeatureExtraction.cpaths) + s_VerMar);
            s_CurrVer = 1;
            
            obj.e_i.MultivariateSel = zeros(1, length(h.FeatureExtraction.cpaths));
            obj.e_i.MultivariateButton = zeros(1, length(h.FeatureExtraction.cpaths));
            obj.e_i.MultivariateFig = zeros(1, length(h.FeatureExtraction.cpaths));
            obj.e_i.MultivariateInterfaces = cell(1, length(h.FeatureExtraction.cpaths));
            for i = 1:length(h.FeatureExtraction.cpaths)
                c = h.FeatureExtraction.cpaths{i};
                c_name = c;
                c_name(c == SEPARATOR) = ' '; % Remove separators
                c_name = c_name(2:end); % Remove +
                s_CurrVer = s_CurrVer - s_VerSpace;
                obj.e_i.MultivariateSel(i) = uicontrol('Parent',obj.e_i.MultivariatePanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.1 s_CurrVer 0.7 s_VerSpace],...
                    'String',c_name, 'enable','on', 'value', 0, 'callback', {@MultivariateCheckCallBack, obj, obj.study, c_name, i}); % Edit box for data path
                
                if obj.mv_with_opt(i)
                    obj.e_i.MultivariateButton(i) = uicontrol('Parent', obj.e_i.MultivariatePanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.8 s_CurrVer 0.1 s_VerSpace],...
                        'String','...','enable','off','Callback', {@MultivariateButtonCallback, obj, c_name, i}); % Button for ok
                end
            end
            
            % ECG new panel
            obj.e_i.ECGPanel = uipanel('Parent', obj.e_i.ModulesPanel, 'Title', 'ECG features' ,'Units','Normalized','Position', [0.7 0.21 0.25 0.6]);
            
            s_ECGFeatNum = 5;
            s_VerMar = 0;
            s_CurrVer = 0.775;
            s_VerSpace = s_CurrVer / (s_ECGFeatNum + s_VerMar);
            
            obj.e_i.ECGSel = zeros(1, s_ECGFeatNum);
            
            obj.e_i.ECGInterfaces = cell(1, 1);
            
            sel_chan = h.study.dataset(h.study.dataset_selected).results.chansSelected;
            ecg_chann_ind = f_CheckForECGChanns(sel_chan);
            
            eeg_chann_ind = ones(length(sel_chan), 1);
            
            if ~isempty(ecg_chann_ind)
                eeg_chann_ind(ecg_chann_ind) = 0;
            end
            
            obj.study.dataset(obj.study.dataset_selected).results.EEGchansSelectedInd = find(eeg_chann_ind);
            obj.study.dataset(obj.study.dataset_selected).results.ECGchansSelectedInd = ecg_chann_ind;
            
            if isempty(ecg_chann_ind)
                s_EnableECG = 'off';
            else
                s_EnableECG = 'on';
                h.FeatureExtraction.cpaths = getFeatureExtractionMethods(DIRECTORY_ECG);
                cpath = h.FeatureExtraction.cpaths{1};
                cpath(cpath == SEPARATOR) = ' '; % Remove separators
                cpath = cpath(2:end); % Remove +
                obj.e_i.ECGInterfaces{1} = eval(strcat('FeatureExtraction.ECG.', ...
                    cpath, '.', cpath, '_Interface(obj.study);'));
            end
            
            i = 1;
            obj.e_i.ECGSel(i) = uicontrol('Parent',obj.e_i.ECGPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.1 s_CurrVer 0.9 s_VerSpace],...
                'String','R-R Statistics', 'enable',s_EnableECG, 'value', 0); % Edit box for data path
            
            i = i + 1;
            s_CurrVer = s_CurrVer - s_VerSpace;
            obj.e_i.ECGSel(i) = uicontrol('Parent',obj.e_i.ECGPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.1 s_CurrVer 0.9 s_VerSpace],...
                'String','BPM Statistics', 'enable',s_EnableECG, 'value', 0); % Edit box for data path
            
            i = i + 1;
            s_CurrVer = s_CurrVer - s_VerSpace;
            obj.e_i.ECGSel(i) = uicontrol('Parent',obj.e_i.ECGPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.1 s_CurrVer 0.9 s_VerSpace],...
                'String','Spectral analysis', 'enable',s_EnableECG, 'value', 0); % Edit box for data path
            
            obj.e_i.Description = uicontrol('Parent',obj.e_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.4 .09 0.5 0.1],...
                'String','', 'enable','on','fontsize',12); %
            
            i = i + 1;
            s_CurrVer = s_CurrVer - s_VerSpace;
            obj.e_i.ECGSel(i) = uicontrol('Parent',obj.e_i.ECGPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.1 s_CurrVer 0.9 s_VerSpace],...
                'String','App. Entropy', 'enable',s_EnableECG, 'value', 0); % Edit box for data path
            
            i = i + 1;
            s_CurrVer = s_CurrVer - s_VerSpace;
            obj.e_i.ECGSel(i) = uicontrol('Parent',obj.e_i.ECGPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.1 s_CurrVer 0.9 s_VerSpace],...
                'String','Sample Entropy', 'enable',s_EnableECG, 'value', 0); % Edit box for data path
            
            
            obj.e_i.CancelButton = uicontrol('Parent', obj.e_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.55 0.05 0.1 0.05],...
                'String','Cancel','Callback', {@CancelButtonCallback, obj}); % Button for cancel
            obj.e_i.HelpButton = uicontrol('Parent', obj.e_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.70 0.05 0.1 0.05],...
                'String','Help','Callback', @HelpButtonCallback); % Button for help
            obj.e_i.OkButton = uicontrol('Parent', obj.e_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.85 0.05 0.1 0.05],...
                'String','Ok','Callback', {@OkButtonCallback, obj, obj.study}); % Button for ok
            
            function OkButtonCallback (hObject, eventdata, obj, study)
                
                if isempty(get(obj.e_i.WindowSizeEdit, 'String'))
                    return;
                end
                obj.e_f.is_canceled=0;
                obj.acq_window = str2num(get(obj.e_i.WindowSizeEdit, 'String'));
                obj.acq_step = get(obj.e_i.StepSizeEdit, 'String');
                
                obj.notch_check=(get(obj.e_i.notchCheck,'Value') == get(obj.e_i.notchCheck,'Max'));
                obj.low_check=(get(obj.e_i.lowpassCheck,'Value') == get(obj.e_i.lowpassCheck,'Max'));
                if(obj.low_check)
                    obj.low_cut = str2num(get(obj.e_i.lowcutEdit, 'String'));
                end
                obj.high_check=(get(obj.e_i.highpassCheck,'Value') == get(obj.e_i.highpassCheck,'Max'));
                if(obj.high_check)
                    obj.high_cut = str2num(get(obj.e_i.highcutEdit, 'String'));
                end
                
                notch_freq_idx=get(obj.e_i.notch_freq_pop, 'value');
                
                
                if(notch_freq_idx==1)
                    obj.notch_freq=50;
                else
                    obj.notch_freq=60;
                end
                
                obj.low_ord=get(obj.e_i.low_ord_pop, 'value')
                obj.high_ord=get(obj.e_i.high_ord_pop, 'value');
                
                disp(['Low Ord:',num2str(obj.low_ord)])
                
                
                if isempty(obj.acq_step)
                    obj.acq_step = obj.acq_window;
                else
                    obj.acq_step = str2num(obj.acq_step);
                end
                
                if ~isempty(study.dataset(study.dataset_selected).results.saveFileName)
                    
                    
                    
                    
                    
                    flg_univ=0;
                    for s_Counter = 1:length(obj.e_i.UnivariateSel)
                    
                    if ~get(obj.e_i.UnivariateSel(s_Counter), 'value')
                        continue;
                    end
                    
                    flg_univ=1;
                    break;
                    end
                
                    flg_multi=0;
                    for s_Counter = 1:length(obj.e_i.MultivariateSel)
                    
                    if ~get(obj.e_i.MultivariateSel(s_Counter), 'value')
                        continue;
                    end
                    
                    flg_multi=1;
                    break;
                    end
                    
                    
                    
                    evt_name=[study.dataset(study.dataset_selected).results.saveFileName,'.evts'];
                    
                    study.dataset(study.dataset_selected).results.saveFileHandle_evt =fopen(evt_name,'w+');
                    
                    
                    
                    if study.dataset(study.dataset_selected).results.saveFileHandle_evt == -1
                            warndlg(sprintf('ERROR creating file for events: %s. Results will not be saved to file!', ...
                                uvt_name));
                            study.dataset(study.dataset_selected).results.saveFileHandle_evt = [];
                    else
                    fprintf(study.dataset(study.dataset_selected).results.saveFileHandle_evt,'evt_type\teeg_onset\teeg_onset_sec\tfirst_eeg_change\tfirst_eeg_change_sec\teeg_offset\teeg_offset_sec\t pattern\tclassification\tvigilance\n');

                    end
                    
                    if flg_univ
                        
                        uni_name=[study.dataset(study.dataset_selected).results.saveFileName,'_eeg.dat'];
                        
                        study.dataset(study.dataset_selected).results.saveFileHandle_uni = ...
                            fopen(uni_name, 'w');
                        if study.dataset(study.dataset_selected).results.saveFileHandle_uni == -1
                            warndlg(sprintf('ERROR creating file for univariate features: %s. Results will not be saved to file!', ...
                                uni_name));
                            study.dataset(study.dataset_selected).results.saveFileHandle_uni = [];
                        end
                    end
                    
                    
                    if flg_multi
                        
                        mlt_name=[study.dataset(study.dataset_selected).results.saveFileName,'_mlt.dat'];
                        
                        study.dataset(study.dataset_selected).results.saveFileHandle_mlt = ...
                            fopen(mlt_name, 'w');
                        if study.dataset(study.dataset_selected).results.saveFileHandle_mlt == -1
                            warndlg(sprintf('ERROR creating file for multivariate features: %s. Results will not be saved to file!', ...
                                mlt_name));
                            study.dataset(study.dataset_selected).results.saveFileHandle_mlt = [];
                        end
                    end
                    
                    
                    if ~isempty(obj.e_i.ECGInterfaces{1})
                        
                        ecg_name=[study.dataset(study.dataset_selected).results.saveFileName,'_ecg.dat'];
                        
                        study.dataset(study.dataset_selected).results.saveFileHandle_ecg = ...
                            fopen(ecg_name, 'w');
                        if study.dataset(study.dataset_selected).results.saveFileHandle_ecg == -1
                            warndlg(sprintf('ERROR creating file for ECG features: %s. Results will not be saved to file!', ...
                                ecg_name));
                            study.dataset(study.dataset_selected).results.saveFileHandle_ecg = [];
                        end
                    end
                    
                    
                    
                end
                
                results = obj.e_f.Run (study, obj.acq_window, obj.acq_step, obj.notch_check,obj.notch_freq,obj.low_check,obj.low_cut,obj.low_ord,obj.high_check,obj.high_cut,obj.high_ord,...
                    obj.e_i.UnivariateSel, obj.e_i.UnivariateInterfaces, ...
                    obj.e_i.MultivariateSel, obj.e_i.MultivariateInterfaces, ...
                    obj.e_i.ECGSel, obj.e_i.ECGInterfaces,obj.e_i.Description);
                
                for s_Counter = 1:length(obj.e_i.UnivariateSel)
                    
                    if ~get(obj.e_i.UnivariateSel(s_Counter), 'value')
                        continue;
                    end
                    
                    obj.e_i.UnivariateInterfaces{s_Counter}.SaveResults( ...
                        obj.e_i.UnivariateInterfaces{s_Counter}, study);
                end
                
                
                for s_Counter = 1:length(obj.e_i.MultivariateSel)
                    if ~get(obj.e_i.MultivariateSel(s_Counter), 'value')
                        continue;
                    end
                    
                    obj.e_i.MultivariateInterfaces{s_Counter}.SaveResults( ...
                        obj.e_i.MultivariateInterfaces{s_Counter}, study);
                end
                
                
                if ~isempty(obj.e_i.ECGInterfaces{1})
                    obj.e_i.ECGInterfaces{1}.SaveResults(obj.e_i.ECGInterfaces{1}, study, ...
                        cell2mat(get(obj.e_i.ECGSel, 'Value')));
                end
                
                if ~isempty(study.dataset(study.dataset_selected).results.saveFileName)
                    
                    if flg_univ
                        fclose(study.dataset(study.dataset_selected).results.saveFileHandle_uni);
                        obj.e_f.CreateHeaderFile(study,'eeg');
                    end
                    if flg_multi
                        fclose(study.dataset(study.dataset_selected).results.saveFileHandle_mlt);
                        obj.e_f.CreateHeaderFile(study,'mlt');
                    end
                    if ~isempty(obj.e_i.ECGInterfaces{1})
                        fclose(study.dataset(study.dataset_selected).results.saveFileHandle_ecg);
                        obj.e_f.CreateHeaderFile(study,'ecg');
                    end
                end
                if study.dataset(study.dataset_selected).results.saveFileHandle_evt ~= -1
                    fclose(study.dataset(study.dataset_selected).results.saveFileHandle_evt);
                end
                
                
                
            end
            
            function CancelButtonCallback (hObject, eventdata, obj)
                disp('Cancel Button pressed')
                obj.e_f.is_canceled=1;
                
            end
            
            
            
            function HelpButtonCallback(hObject, eventdata, obj)
                
                helpdlg(sprintf('Feature Extraction Module.\n\nSelect the feature groups to compute and then press OK.\n\n\n\n EU FP7 Grant 211713 (EPILEPSIAE)'),'EPILAB');
                uiwait
                
            end
            
            function UnivariateCheckCallBack (hObject, eventdata, obj, study, cpath, ind)
                if (get(obj.e_i.UnivariateSel(ind), 'value'))
                    if isempty(obj.e_i.UnivariateInterfaces{ind})
                        obj.e_i.UnivariateInterfaces{ind} = eval(strcat('FeatureExtraction.Univariate.', cpath, '.', cpath, '_Interface(study);'));
                    end
                    if obj.un_with_opt(ind)
                        set(obj.e_i.UnivariateButton(ind), 'enable', 'on');
                    end
                else
                    if obj.un_with_opt(ind)
                        set(obj.e_i.UnivariateButton(ind), 'enable', 'off');
                    end
                end
            end
            
            function MultivariateCheckCallBack (hObject, eventdata, obj, study, cpath, ind)
                if (get(obj.e_i.MultivariateSel(ind), 'value'))
                    if isempty(obj.e_i.MultivariateInterfaces{ind})
                        obj.e_i.MultivariateInterfaces{ind} = eval(strcat('FeatureExtraction.Multivariate.', cpath, '.', cpath, '_Interface(study);'));
                    end
                    if obj.mv_with_opt(ind)
                        set(obj.e_i.MultivariateButton(ind), 'enable', 'on');
                    end
                else
                    if obj.mv_with_opt(ind)
                        set(obj.e_i.MultivariateButton(ind), 'enable', 'off');
                    end
                end
            end
            
            function UnivariateButtonCallback (hObject, eventdata, obj, cpath, ind)
                addpath(pwd);
                
                
                obj.e_i.UnivariateFig(ind) = figure ('NumberTitle','off','position', [250 150 700 200], 'MenuBar', 'none', 'name', ['EpiLab : ', cpath, ' Module']);
                obj.e_i.UnivariateInterfaces{ind}.acq_window = str2num(get(obj.e_i.WindowSizeEdit, 'String'));
                obj.e_i.UnivariateInterfaces{ind}.draw(obj.e_i.UnivariateInterfaces{ind}, obj.e_i.UnivariateFig(ind));
                
            end
            
            function MultivariateButtonCallback (hObject, eventdata, obj, cpath, ind)
                addpath(pwd);
                
                
                obj.e_i.MultivariateFig(ind) = figure ('NumberTitle','off','position', [250 150 700 200], 'MenuBar', 'none', 'name', ['EpiLab : ', cpath, ' Module']);
                obj.e_i.MultivariateInterfaces{ind}.draw(obj.e_i.MultivariateInterfaces{ind}, obj.e_i.MultivariateFig(ind));
                
            end
            
            function c=getFeatureExtractionMethods(DIRECTORY)
                %Read Feature extraction methods directory
                dirs=dir(DIRECTORY);
                c = {};
                for i=1:length(dirs)
                    n = dirs(i).name;
                    if n(1) == '+'
                        c{i} = dirs(i).name;
                    end
                end
            end
        end
        
        %Clear the panel and its contents
        function clear(C)
            delete(C.ModulesPanel);
        end
    end
end