classdef ARModCoeff_Data < handle
    %======================================================================
    %ARModCoeff_Data
    %
    %Data related to ARModCoeff
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    % The following properties can be set as public
    properties
        parameter_acquisition;
        overlap;
        
        AROrder;
        ARMethod;
        
        AROrder_results;
        ARMethod_results;
        
        % algorithm output
        time;

        c_ = struct([]);
    end

    methods
        % constructor
        function obj = ARModCoeff_Data()

        end

        function study = SaveData(obj, study, results)
            obj.AROrder_results = results.AROrder_val;
            obj.ARMethod_results = results.ARMethod_val;

            for x=1:length(study.dataset_selected)
                selected_chans = study.dataset(study.dataset_selected(x)).results.chansSelected;
                chans_ind = study.dataset(study.dataset_selected(x)).results.EEGchansSelectedInd;
                chans_ind = reshape(chans_ind, 1, []);
                dataset = study.dataset_selected(x);
                for k = 1:length(chans_ind)
                    if length(results.ARCoeff_results) >= dataset
                        eval(['obj.c_(1).ARCoeff_channel_' selected_chans{chans_ind(k)} '=[];']);
                        eval(['obj.c_(1).ARCoeff_channel_' selected_chans{chans_ind(k)} ' = results.ARCoeff_results{dataset}(k,:);']);
                    
                    
                    
                    
                    if isfield(study.dataset(study.dataset_selected(x)).results.featureExtractionMethods,'ARModCoeff')
                        ss=study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.ARModCoeff.c_;
                        ss.(['ARCoeff_channel_' selected_chans{chans_ind(k)}])=results.ARCoeff_results{dataset}(k,:);
                        study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.ARModCoeff.c_=ss;
                    else
                        study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.('ARModCoeff').('c_').(['ARCoeff_channel_' selected_chans{chans_ind(k)}])=results.ARCoeff_results{dataset}(k,:);
                    end
                    
                    end
                    
                    if k > 1
                        continue;
                    end
                    
                    study.dataset(study.dataset_selected(x)).results.featureNames = ...
                        strcat(study.dataset(study.dataset_selected(x)).results.featureNames, ...
                        'ARCoeff,');
                end
            end

            obj.parameter_acquisition = results.parameter_acquisition;
            obj.time = results.time;
            %study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.ARModCoeff = obj;

            obj = FeatureExtraction.Univariate.ARModCoeff.ARModCoeff_Data();
        end

    end

end
