classdef ARModCoeff_Functions < handle
    %======================================================================
    %ARModCoeff_Functions
    %
    %Functions of ARModCoeff
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    % The following properties can be set only by class methods
    properties

        parameter_acquisition;
        overlap;

        % algorithm output
        time;
        ARCoeff_results = {};
        AROrder_val = 0;
        ARMethod_val = 0;
        
    end

    methods

        %Constructor
        function obj = ARModCoeff_Functions()

        end
        
        function obj = RunSingleSegment(obj, study, p_segment, p_samp_rate, ...
                p_ar_order, p_ar_method)
            v_fiterror = [];
            for s_Counter = 1:size(p_segment, 1)
                p_segment(s_Counter, :) = p_segment(s_Counter, :) - ...
                    mean(p_segment(s_Counter, :));
                clear s_error
                s_error = obj.f_ARModelCoeff(p_segment(s_Counter, :), p_ar_order, ...
                    p_ar_method);
                s_error = p_segment(s_Counter, :) - filter(s_error, 1, ...
                    p_segment(s_Counter, :));
                s_error = sqrt(sum(s_error.^ 2) / length(s_error));
                
                v_fiterror = f_AddVerElems(v_fiterror, s_error);
                clear s_error
            end
            if study.dataset(study.dataset_selected).results.saveFileHandle_uni > 0
                fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_uni, ...
                    v_fiterror(:), 'double');
            end
                if ~isempty(obj.ARCoeff_results)
                    obj.ARCoeff_results = obj.ARCoeff_results{1};
                end
                obj.ARCoeff_results = f_AddHorElems(obj.ARCoeff_results, ...
                    v_fiterror);
                obj.ARCoeff_results = {obj.ARCoeff_results};
            
        end;        

        
        function v_ARCoeff = ...
    f_ARModelCoeff(obj,...
    pv_Sig, ...
    ps_AROrder, ...
    ps_ARMethod)
% 
% Function: f_ARModelCoeff.m
% 
% Description: 
% This function computes the coefficients of an AR (autoregressive) model
% for an input signal.
% 
% Inputs:
% pv_Sig: input signal
% ps_AROrder (optional): AR model order. Default: 100
% ps_ARMethod (optional): set to 'burg' (default) to compute the
% coefficients using the burg method, 'cov' to use the covariance method,
% 'mcov' to use the modified covariance method, 'yule' to use the
% Yule-Walker method, 'lpc' to use the Linear prediction filter
% coefficients
% 
% Outputs:
% v_ARCoeff: array containing the AR model coefficients
% 
% MATLAB Version: R2007b
% 
% Team: LENA
% Author: Mario Valderrama
%
    
    v_ARCoeff = [];
    s_AROrder = 10;
    s_ARMethod = 'burg';
    if nargin >= 2 && ~isempty(ps_AROrder)
        s_AROrder = ps_AROrder;
    end
    if nargin >= 3 && ~isempty(ps_ARMethod)
        s_ARMethod = ps_ARMethod;
    end
    
    if length(pv_Sig) < s_AROrder * 5
        s_AROrder = round(length(pv_Sig) / 5);
    end
    
    switch s_ARMethod,
        case 'burg',
            v_ARCoeff = arburg(pv_Sig, s_AROrder);
            
        case 'cov',
            v_ARCoeff = arcov(pv_Sig, s_AROrder);

        case 'mcov',
            v_ARCoeff = armcov(pv_Sig, s_AROrder);
            
        case 'yule',
            v_ARCoeff = aryule(pv_Sig, s_AROrder);

        case 'lpc',
            v_ARCoeff = lpc(pv_Sig, s_AROrder);
            
        otherwise,
            return;
            
    end


        
        
        end
    end
%         
%     methods (Access=public)
%         
%         
%         v_ARCoeff = f_ARModelCoeff(obj, eeg_segment, AROrder, ARMethod);
%     end


end
