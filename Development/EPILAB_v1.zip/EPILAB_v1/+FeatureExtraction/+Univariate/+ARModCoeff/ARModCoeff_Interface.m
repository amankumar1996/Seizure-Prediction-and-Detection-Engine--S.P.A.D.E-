classdef ARModCoeff_Interface < handle
    %======================================================================
    %ARModCoeff_Interface
    %
    %Interface to ARModCoeff
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    properties
        par_acquisition;
        
        study;
        
        ar_i;
        ar_f;
        ar_d;
        
        acq_window;
        acq_step;        
        ar_order;
        ar_method;
    end
    
    methods
      %Constructor
      function obj = ARModCoeff_Interface(study)
         %  Create and then hide the GUI as it is being constructed.
         obj.study = study;
         
         obj.ar_f = FeatureExtraction.Univariate.ARModCoeff.ARModCoeff_Functions();
         obj.ar_d = FeatureExtraction.Univariate.ARModCoeff.ARModCoeff_Data();
         
         obj.acq_window = 5;
         obj.acq_step = obj.acq_window;   
         obj.ar_order = 10;
         obj.ar_method = 'burg';
      end
    end
    

    methods(Static)
      %Draw the panel and its contents
      function draw(obj,panel)
          
          
          % display new panel
          obj.ar_i.ModulesPanel = uipanel('Parent', panel, 'Title', 'AR Model Coefficients' ,'Units','Normalized','Position', [0.05 0.05 0.9 0.9]);

         
          obj.ar_i.AROrderText = uicontrol('Parent', obj.ar_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.65 0.3 0.13],...
              'String','AR order'); 
          obj.ar_i.AROrderEdit = uicontrol('Parent',obj.ar_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.65 0.2 0.13],...
              'String',num2str(obj.ar_order),'enable','on'); 
          
          obj.ar_i.ARMethodText = uicontrol('Parent', obj.ar_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.50 0.3 0.13],...
              'String','AR method'); 
          obj.ar_i.ARMethodCombobox = uicontrol('Parent',obj.ar_i.ModulesPanel,'style','popupmenu','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.50 0.2 0.13],...
              'String',{'burg', 'cov', 'mcov', 'yule', 'lpc'},'value',1, 'enable','on'); 
          

          obj.ar_i.CancelButton = uicontrol('Parent', obj.ar_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.55 0.05 0.1 0.13],...
              'String','Cancel','Callback', {@CancelButtonCallback, obj}); % Button for cancel
          obj.ar_i.HelpButton = uicontrol('Parent', obj.ar_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.70 0.05 0.1 0.13],...
              'String','Help','Callback', @HelpButtonCallback); % Button for help
          obj.ar_i.OkButton = uicontrol('Parent', obj.ar_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.85 0.05 0.1 0.13],...
              'String','Ok','Callback', {@OkButtonCallback, obj, obj.study}); % Button for ok
      
          function OkButtonCallback (hObject, eventdata, obj, study)
              
             
              if ~isempty(get(obj.ar_i.AROrderEdit, 'String'))
                  obj.ar_order = str2num(get(obj.ar_i.AROrderEdit, 'String'));
              end                  
              
              obj.ar_method = get(obj.ar_i.ARMethodCombobox, 'String');
              obj.ar_method = obj.ar_method{get(obj.ar_i.ARMethodCombobox, 'Value')};
              
              close(gcf);              
          end
          
          function CancelButtonCallback (hObject, eventdata, obj)
              obj.clear (obj.ar_i);
              close(gcf);
          end
      end
      
      function ClearChildClasses(obj)
          delete(obj.ar_f);
          clear obj.ar_f
          delete(obj.ar_d);
          clear obj.ar_d
          obj.ar_f = FeatureExtraction.Univariate.ARModCoeff.ARModCoeff_Functions();
          obj.ar_d = FeatureExtraction.Univariate.ARModCoeff.ARModCoeff_Data();
      end
      
      function RunSingleSegment(obj, study, p_segment, p_samp_rate)
          obj.ar_f.RunSingleSegment(study, p_segment, p_samp_rate, ...
              obj.ar_order, obj.ar_method);
      end

      function SaveResults(obj, study)
          obj.ar_d.SaveData(study, obj.ar_f);
      end      

      %Clear the panel and its contents
      function clear(C)
          delete(C.ModulesPanel);
      end
    end
end


