function [v_RelPow v_PowSpec v_Freq] = ...
    CrossFreqCoupl(obj,...
    pv_Sig, ...
    ps_SamRate, ...
    pm_FreqRanges, ...
    ps_ARMethod)
%
% Function: f_CrossFreqCoupling.m
%
% Description:
% This function computes the cross frequency coupling of the input signal: 
% Histogram of the High-frequency (gamma) envelope vs delta and theta phases. 
%
% Inputs:
% pv_Sig: input signal
% ps_SamRate: sample rate in Hz
% pm_FreqRangesHz: nx2 matrix containing the ranges of desired frequency
% bands to compute the relative power. n  is the number of frequency bands.
% Example: [0.1 4;4 8], computes the relative power for bands between 0.1
% to 4 Hz and between 4 and 8 Hz
% ps_ARMethod (optional): set to 1 to compute the power spectral density
% via an AR (Autoregressive) model estimator. Default: 0 (FFT squared
% modulus estimator)
%
% Outputs:
% v_RelPow: array of length n containing the relative power for each
% frequency band
% v_PowSpec: array containing the power spectrum for frequencies from 0 to
% the half of the sample rate
% v_Freq: array containing the frequency values from 0 to the half of the
% sample rate
%
% MATLAB Version: R2007b
%
% Team: LENA
% Author: Mario Valderrama
%

    [v_RelPow v_PowSpec v_Freq] = CrossFreqCoupl(pv_Sig, ps_SamRate, pm_FreqRanges, ps_ARMethod);

