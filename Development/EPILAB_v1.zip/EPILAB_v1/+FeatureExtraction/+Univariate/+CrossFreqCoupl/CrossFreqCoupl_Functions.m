classdef CrossFreqCoupl_Functions < handle
    %======================================================================
    %CrossFreqCoupl_Functions
    %
    %Functions of CrossFreqCoupl
    %Catalina Alvarado
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %2011
    %======================================================================

    % The following properties can be set only by class methods
    properties

        parameter_acquisition;
        overlap;

        % algorithm output
        time;
        gammadelta_results = {};
        gammatheta_results = {};                
        ps_CrossFreqCoupl_results = 0;
        
    end

    methods

        %Constructor
        function obj = CrossFreqCoupl_Functions()

        end
        
        function obj = RunSingleSegment(obj, study, p_segment, p_samp_rate, p_filterFreq, p_HistBins)
            
            [v_CFC, v_GammaEnvel] = obj.CrossFreqCoupl(p_segment, p_samp_rate, p_filterFreq, p_HistBins);

            if study.dataset(study.dataset_selected).results.saveFileHandle_uni > 0

                fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_uni, ...
                    v_CFC(:), 'double');
            else
                if ~isempty(obj.gammadelta_results)
                    obj.gammadelta_results = obj.gammadelta_results{1};
                end
                obj.gammadelta_results = f_AddHorElems(obj.gammadelta_results, ...
                    v_CFC(:, 1));
                obj.gammadelta_results = {obj.gammadelta_results};

                if ~isempty(obj.gammatheta_results)
                    obj.gammatheta_results = obj.gammatheta_results{1};
                end
                obj.gammatheta_results = f_AddHorElems(obj.gammatheta_results, ...
                    v_CFC(:, 2));
                obj.gammatheta_results = {obj.gammatheta_results};


            end
        end;            

        
        function [v_CFC, v_GammaEnvel] = CrossFreqCoupl(obj, pv_Sig, ...
             ps_SamRate, p_filterFreq, p_HistBins)
%
% Function: f_RelPow.m
%
% Description:
% This function computes the relative power of particular spectral bands
% for the input signal.
%
% Inputs:
% pv_Sig: input signal
% ps_SamRate: sample rate in Hz
% pm_FreqRangesHz: nx2 matrix containing the ranges of desired frequency
% bands to compute the relative power. n  is the number of frequency bands.
% Example: [0.1 4;4 8], computes the relative power for bands between 0.1
% to 4 Hz and between 4 and 8 Hz
% ps_ARMethod (optional): set to 1 to compute the power spectral density
% via an AR (Autoregressive) model estimator. Default: 0 (FFT squared
% modulus estimator)
%
% Outputs:
% v_RelPow: array of length n containing the relative power for each
% frequency band
% v_PowSpec: array containing the power spectrum for frequencies from 0 to
% the half of the sample rate
% v_Freq: array containing the frequency values from 0 to the half of the
% sample rate
%
% MATLAB Version: R2007b
%
% Team: LENA
% Author: Mario Valderrama
%

            [v_CFC, v_GammaEnvel] = f_CrossFreqCoupl(pv_Sig, ps_SamRate, p_filterFreq, p_HistBins);
    
        end
    end
        
%     methods (Access=public)
%         [v_RelPow v_PowSpec v_Freq] = RelPow(obj,eeg_segment, ps_SamRate, pm_FreqRanges, ps_ARMethod);
% 
%     end


end
