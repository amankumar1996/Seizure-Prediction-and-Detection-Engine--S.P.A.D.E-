classdef CrossFreqCoupl_Interface < handle
    %======================================================================
    %CrossFreqCoupl_Interface
    %
    %Interface to CrossFreqCoupl
    %Catalina Alvarado
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %2011
    %======================================================================
    properties

        study;       
        
        cfc_i; % Figure handle        
        cfc_f; % Data handle
        cfc_d; % Data handle
        
        acq_window;
        acq_step;  
        delta_lowfreq;
        delta_highfreq;
        theta_lowfreq;
        theta_highfreq;
        gamma_lowfreq;
        gamma_highfreq;
        hist_bins;
    end
    
    methods
      %Constructor
      function obj = CrossFreqCoupl_Interface(study)
         %  Create and then hide the GUI as it is being constructed.
         obj.study = study;         
         obj.cfc_f = FeatureExtraction.Univariate.CrossFreqCoupl.CrossFreqCoupl_Functions();
         obj.cfc_d = FeatureExtraction.Univariate.CrossFreqCoupl.CrossFreqCoupl_Data();         
         obj.acq_window = 5;
         obj.acq_step = obj.acq_window; 
         obj.delta_lowfreq = 1;
         obj.delta_highfreq = 3;
         obj.theta_lowfreq = 3;
         obj.theta_highfreq = 8;
         obj.gamma_lowfreq = 70;
         obj.gamma_highfreq = 120;
         obj.hist_bins = 40;
      end
    end

    methods(Static)
      %Draw the panel and its contents
      function draw(obj,panel)
    
          % display new panel
          obj.cfc_i.ModulesPanel = uipanel('Parent', panel, 'Title', 'Cross-frequency coupling' ,'Units','Normalized','Position', [0.05 0.05 0.9 0.9]);

          obj.cfc_i.AcquisitionIntervalEdit = uicontrol('Parent',obj.cfc_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.5 0.8 0.1 0.1],...
              'String',num2str(obj.acq_window));
          obj.cfc_i.AcquisitionIntervalText = uicontrol('Parent', obj.cfc_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.8 0.4 0.1],...
              'String','Feature computation - acquisition interval (seconds)'); 

          %Filtering parameters
          obj.cfc_i.DeltaLFEdit = uicontrol('Parent',obj.cfc_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.5 0.7 0.1 0.1],...
              'String',num2str(obj.delta_lowfreq));
          obj.cfc_i.DeltaLFText = uicontrol('Parent', obj.cfc_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.7 0.4 0.1],...
              'String','Delta frequency: Low - High Frequency (Hz)');
          obj.cfc_i.DeltaHFEdit = uicontrol('Parent',obj.cfc_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.7 0.7 0.1 0.1],...
              'String',num2str(obj.delta_highfreq));
          obj.cfc_i.DeltaHFText = uicontrol('Parent', obj.cfc_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.64 0.7 0.02 0.1],...
              'String','-');
          
          obj.cfc_i.ThetaLFEdit = uicontrol('Parent',obj.cfc_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.5 0.6 0.1 0.1],...
              'String',num2str(obj.theta_lowfreq));
          obj.cfc_i.ThetaLFText = uicontrol('Parent', obj.cfc_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.6 0.4 0.1],...
              'String','Theta frequency: Low - High Frequency (Hz)');
          obj.cfc_i.ThetaHFEdit = uicontrol('Parent',obj.cfc_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.7 0.6 0.1 0.1],...
              'String',num2str(obj.theta_highfreq));
          obj.cfc_i.ThetaHFText = uicontrol('Parent', obj.cfc_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.64 0.6 0.02 0.1],...
              'String','-');          
          
          obj.cfc_i.GammaLFEdit = uicontrol('Parent',obj.cfc_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.5 0.5 0.1 0.1],...
              'String',num2str(obj.gamma_lowfreq));
          obj.cfc_i.GammaLFText = uicontrol('Parent', obj.cfc_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.5 0.4 0.1],...
              'String','Gamma frequency: Low - High Frequency (Hz)');
          obj.cfc_i.GammaHFEdit = uicontrol('Parent',obj.cfc_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.7 0.5 0.1 0.1],...
              'String',num2str(obj.gamma_highfreq));
          obj.cfc_i.GammaHFText = uicontrol('Parent', obj.cfc_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.64 0.5 0.02 0.1],...
              'String','-'); 
          
          obj.cfc_i.HistBinEdit = uicontrol('Parent',obj.cfc_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.5 0.3 0.1 0.1],...
              'String',num2str(obj.hist_bins));
          obj.cfc_i.HistBinText = uicontrol('Parent', obj.cfc_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.3 0.4 0.1],...
              'String','Histogram: Number of bins');
          


          
          obj.cfc_i.CancelButton = uicontrol('Parent', obj.cfc_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.55 0.05 0.1 0.1],...
              'String','Cancel','Callback', {@CancelButtonCallback, obj}); % Button for cancel
          obj.cfc_i.HelpButton = uicontrol('Parent', obj.cfc_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.70 0.05 0.1 0.1],...
              'String','Help','Callback', @HelpButtonCallback); % Button for help
          obj.cfc_i.OkButton = uicontrol('Parent', obj.cfc_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.85 0.05 0.1 0.1],...
              'String','Ok','Callback', {@OkButtonCallback, obj, obj.study}); % Button for ok
      
          function OkButtonCallback (hObject, eventdata, obj, study)
              
              if ~isempty(get(obj.cfc_i.AcquisitionIntervalEdit, 'String'))
                  obj.acq_window = str2num(get(obj.cfc_i.AcquisitionIntervalEdit, 'String'));
              end
              

              
      
              if ~isempty(get(obj.cfc_i.DeltaLFEdit, 'String'))
                  obj.delta_lowfreq = str2num(get(obj.cfc_i.DeltaLFEdit, 'String'));
              end              
              if ~isempty(get(obj.cfc_i.DeltaHFEdit, 'String'))
                  obj.delta_highfreq = str2num(get(obj.cfc_i.DeltaHFEdit, 'String'));
              end
              if ~isempty(get(obj.cfc_i.ThetaLFEdit, 'String'))
                  obj.theta_lowfreq = str2num(get(obj.cfc_i.ThetaLFEdit, 'String'));
              end
              if ~isempty(get(obj.cfc_i.ThetaHFEdit, 'String'))
                  obj.theta_highfreq = str2num(get(obj.cfc_i.ThetaHFEdit, 'String'));
              end
              if ~isempty(get(obj.cfc_i.GammaLFEdit, 'String'))
                  obj.gamma_lowfreq = str2num(get(obj.cfc_i.GammaLFEdit, 'String'));
              end
              if ~isempty(get(obj.cfc_i.GammaHFEdit, 'String'))
                  obj.gamma_highfreq = str2num(get(obj.cfc_i.GammaHFEdit, 'String'));
              end
              if ~isempty(get(obj.cfc_i.HistBinEdit, 'String'))
                  obj.hist_bins = str2num(get(obj.cfc_i.HistBinEdit, 'String'));
              end
%               
              
              close(gcf);
          end
          function CancelButtonCallback (hObject, eventdata, obj)
              close(gcf);
              return;              
              
          end
      end
      
      function ClearChildClasses(obj)
          delete(obj.cfc_f);
          clear obj.cfc_f
          delete(obj.cfc_d);
          clear obj.cfc_d
          obj.cfc_f = FeatureExtraction.Univariate.CrossFreqCoupl.CrossFreqCoupl_Functions();
          obj.cfc_d = FeatureExtraction.Univariate.CrossFreqCoupl.CrossFreqCoupl_Data();
      end      
      
      function RunSingleSegment(obj, study, p_segment, p_samp_rate)
          p_filterFreq = [obj.delta_lowfreq, obj.delta_highfreq;obj.theta_lowfreq, ...
              obj.theta_highfreq;obj.gamma_lowfreq,obj.gamma_highfreq];                
          p_HistBins = obj.hist_bins;
          obj.cfc_f.RunSingleSegment(study, p_segment, p_samp_rate, p_filterFreq, p_HistBins);
      end

      function SaveResults(obj, study)
          obj.cfc_d.SaveData(study, obj.cfc_f);
      end          

      %Clear the panel and its contents
      function clear(C)
          delete(C.ModulesPanel);
      end
    end
end