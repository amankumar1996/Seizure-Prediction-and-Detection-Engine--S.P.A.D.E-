classdef DecorrTime_Functions < handle
    %======================================================================
    %DecorrTime_Functions
    %
    %Functions of DecorrTime
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================

    % The following properties can be set only by class methods
    properties

        parameter_acquisition;
        overlap;

        % algorithm output
        time;
        DecorrTime_results; 
        
    end

    methods

        %Constructor
        function obj = DecorrTime_Functions()
            
            obj.DecorrTime_results = [];
            obj.time = [];

        end
        
        function obj = RunSingleSegment(obj, study, p_segment, p_samp_rate)
            v_decorrtime = [];
            for s_Counter = 1:size(p_segment, 1)
                v_decorrtime = f_AddVerElems(v_decorrtime, ...
                    obj.f_DecorrTime(p_segment(s_Counter, :), p_samp_rate));
            end
            if study.dataset(study.dataset_selected).results.saveFileHandle_uni > 0
                fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_uni, ...
                    v_decorrtime(:), 'double');
            else
                if ~isempty(obj.DecorrTime_results)
                    obj.DecorrTime_results = obj.DecorrTime_results{1};
                end
                obj.DecorrTime_results = f_AddHorElems(obj.DecorrTime_results, ...
                    v_decorrtime);
                obj.DecorrTime_results = {obj.DecorrTime_results};
            end
        end;

        
        function s_DecorrTime = ...
    f_DecorrTime(obj,...
    pv_Sig, ...
    ps_SamRate)
% 
% Function: f_DecorrTime.m
% 
% Description: 
% This function computes the decorrelation time which is an estimator of
% the range of linear correlations of a signal. The decorrelation time can
% be defined using the first zero crossing of the autocorrelation function.
% For more information see Mormann et al., 2005.
% 
% Inputs:
% pv_Sig: input signal
% ps_SamRate (optional): sample rate in Hz. Default: 1 Hz
% 
% Outputs:
% s_DecorrTime: the decorrelation time in seconds
% 
% MATLAB Version: R2007b
% 
% Team: LENA
% Author: Mario Valderrama
%
    
    s_DecorrTime = [];
    
    if nargin < 1
        error('[s_DecorrTime] - ERROR: bad number of inputs!');
    end    
    
    s_SamRate = 1;
    if nargin >= 2 && ~isempty(ps_SamRate)
        s_SamRate = ps_SamRate;
    end
    
    s_DecorrTime = xcorr(double(pv_Sig), 'unbiased');
    s_DecorrTime = find(s_DecorrTime(length(pv_Sig):end) <= 0, 1);
    if isempty(s_DecorrTime)
        s_DecorrTime = -1;
    else
        s_DecorrTime = s_DecorrTime - 1;
        s_DecorrTime = s_DecorrTime./ s_SamRate;
    end
        
        
    end
    end  
%     methods (Access=public)
%         s_DecorrTime = f_DecorrTime(obj, eeg_segment, ps_SamRate);
%     end
end
