classdef DecorrTime_Interface < handle
    %======================================================================
    %DecorrTime_Interface
    %
    %Interface to DecorrTime
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    properties
        
        par_acquisition;
        
        study;
        
        % class objects
        dt_i;
        dt_f;
        dt_d;
        
        acq_window;
        acq_step;
    end
    
    methods
      %Constructor
      function obj = DecorrTime_Interface(study)
         %  Create and then hide the GUI as it is being constructed.
         obj.study = study;
         
         obj.dt_f = FeatureExtraction.Univariate.DecorrTime.DecorrTime_Functions();
         obj.dt_d = FeatureExtraction.Univariate.DecorrTime.DecorrTime_Data();
         
         obj.acq_window = 5;
         obj.acq_step = obj.acq_window;
      end
    end

    methods(Static)
      %Draw the panel and its contents
      function draw(obj,panel)
          
          % display new panel
          obj.dt_i.ModulesPanel = uipanel('Parent', panel, 'Title', 'Decorrelation Time' ,'Units','Normalized','Position', [0.05 0.05 0.9 0.9]);

          obj.dt_i.AcquisitionIntervalEdit = uicontrol('Parent',obj.dt_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.8 0.2 0.05],...
              'String',num2str(obj.acq_window));
          obj.dt_i.AcquisitionIntervalText = uicontrol('Parent', obj.dt_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.8 0.5 0.05],...
              'String','Feature computation - acquisition interval (seconds)'); 

          obj.dt_i.OverlapEdit = uicontrol('Parent',obj.dt_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.7 0.2 0.05],...
              'String',num2str(obj.acq_step));
          obj.dt_i.OverlapText = uicontrol('Parent', obj.dt_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.7 0.5 0.05],...
              'String','Feature computation - step (seconds)'); 

          obj.dt_i.CancelButton = uicontrol('Parent', obj.dt_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.55 0.05 0.1 0.05],...
              'String','Cancel','Callback', {@CancelButtonCallback, obj}); % Button for cancel
          obj.dt_i.HelpButton = uicontrol('Parent', obj.dt_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.70 0.05 0.1 0.05],...
              'String','Help','Callback', @HelpButtonCallback); % Button for help
          obj.dt_i.OkButton = uicontrol('Parent', obj.dt_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.85 0.05 0.1 0.05],...
              'String','Ok','Callback', {@OkButtonCallback, obj, obj.study}); % Button for ok
      
          function OkButtonCallback (hObject, eventdata, obj, study)
              
              if ~isempty(get(obj.dt_i.AcquisitionIntervalEdit, 'String'))
                  obj.acq_window = str2num(get(obj.dt_i.AcquisitionIntervalEdit, 'String'));
              end
              
              if ~isempty(get(obj.dt_i.OverlapEdit, 'String'))
                  obj.acq_step = str2num(get(obj.dt_i.OverlapEdit, 'String'));
              end              
              
              close(gcf);
          end
          function CancelButtonCallback (hObject, eventdata, obj)
              close(gcf);
              return;              
%               obj.clear (obj.dt_i);
          end
      end
      
      function ClearChildClasses(obj)
          delete(obj.dt_f);
          clear obj.dt_f
          delete(obj.dt_d);
          clear obj.dt_d
          obj.dt_f = FeatureExtraction.Univariate.DecorrTime.DecorrTime_Functions();
          obj.dt_d = FeatureExtraction.Univariate.DecorrTime.DecorrTime_Data();
      end
      
      function RunSingleSegment(obj, study, p_segment, p_samp_rate)
          obj.dt_f.RunSingleSegment(study, p_segment, p_samp_rate);
      end

      function SaveResults(obj, study)
          obj.dt_d.SaveData(study, obj.dt_f);
      end
      
      %Clear the panel and its contents
      function clear(C)
          delete(C.ModulesPanel);
      end
    end
end


