classdef Energy_Functions < handle
    %======================================================================
    %Energy_Functions
    %
    %Functions of Energy features
    %Bruno Direito/Rui Costa
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %2008/2009
    %======================================================================
    % The following properties can be set only by class methods
    properties
        parameter_acquisition;
        % algorithm output
        time;
        short_term_energy = {};
        long_term_energy = {};
        en_accumulated = {};
        en_derivate = {};
        %file_data_obj;
    end

    methods
        %% Constructor
        function obj = Energy_Functions()

        end
        %% Functions
        
        function obj = RunSingleSegment(obj, study, p_segment, p_samp_rate)
            v_en = [];
            for s_Counter = 1:size(p_segment, 1)
                v_en = f_AddVerElems(v_en, ...
                    sum(p_segment(s_Counter, :).^ 2) / size(p_segment, 2));
            end
            if study.dataset(study.dataset_selected).results.saveFileHandle_uni > 0
                fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_uni, ...
                    v_en(:), 'double');
            else
                if ~isempty(obj.long_term_energy)
                    obj.long_term_energy = obj.long_term_energy{1};
                end
                obj.long_term_energy = f_AddHorElems(obj.long_term_energy, ...
                    v_en(:, 1));
                obj.long_term_energy = {obj.long_term_energy};
            end
        end;    
        
        
    end
end



