%Defines the main class and Function of Energy evaluation
classdef Energy_Functions < handle
    % The following properties can be set only by class methods
    properties

        parameter_acquisition;

        % algorithm output
        time;
        short_term_energy = {};
        long_term_energy = {};

        en_accumulated = {};
        en_derivate = {};
        %file_data_obj;

    end

    methods

        %Constructor
        function obj = Energy_Functions()

        end

        function obj = Run(obj, study, parameter_acquisition, short_term_energy_, long_term_energy_, average_energy_)

            files_tot = length(study.dataset(study.dataset_selected).file);


            for file_num=1:files_tot

                disp (['file ' num2str(file_num)]);

                tic;
                %% information about the file
                
                file = fullfile(study.dataset(study.dataset_selected).file(file_num).path,...
                    study.dataset(study.dataset_selected).file(file_num).filename);
                
                f_type=study.dataset(study.dataset_selected).file(file_num).type;
                
                sr = study.dataset(study.dataset_selected).file(file_num).data.sampling_rate;

                n_chans = length(study.dataset(study.dataset_selected).file(file_num).data.electrodes);

                n_pnts =  study.dataset(study.dataset_selected).file(file_num).data.n_pnts;

                selected_chans = study.dataset(study.dataset_selected).results.chansSelected;
                
                data_obj=gen_epilab_reader(file,f_type,n_pnts,192,sr,parameter_acquisition,...
                    long_term_energy_);%Create a data access object
                
                %% Average energy / Accumulated energy
                if ~isnan(average_energy_)
                    [sampleTime, STE, LTE, en_accumulated, en_derivate] = AccumulatedEnergy (file,...
                        parameter_acquisition, sr, n_pnts, n_chans, selected_chans(k), short_term_energy_, long_term_energy_, average_energy_);
                    obj.en_accumulated{x}(k,:) = en_accumulated(2:end);
                    obj.en_derivate{x}(k,:) = en_derivate(2:end);
                else
                    [sampleTime, STE, LTE] = EnergyVariation_readFile(parameter_acquisition,sr,...
                        selected_chans,short_term_energy_,long_term_energy_,data_obj);
                end

                for k=1:size(selected_chans,2)
                    obj.long_term_energy{file_num}(k,:) = LTE(k,:);
                    obj.short_term_energy{file_num}(k,:) = STE(k,:);
%                     obj.time{file_num,:} = sampleTime;
                end

                obj.parameter_acquisition = parameter_acquisition;
            end

            toc;


            %% calculation routines

            function [pred_time,en_ste,en_lte,en_accumulated, en_derivate] = AccumulatedEnergy (file,...
                    pAcquisition,sRate,n_pnts,n_chans, selected_chan,ste,lte, wSize)


                % dois arrays: size - long term window

                % segmentTrace = zeros (lte*sRate);  % long term - parametro (andar para tras com o indice) e acrescentar a nova leitura -size (parametro)

                epiread = Epilab_Reader (file, n_pnts);

                [segmentTrace, offset, lastSegment] = memMapFile2chanSegments (file,n_pnts,lte*sRate,selected_chan,192);

                EEG_en_variation = segmentTrace';

                %                 num_pnts = length (segmentTrace);

                window_shift = pAcquisition * sRate;

                window_lte = lte * sRate;
                window_ste = ste * sRate;

                % number of samples processed by window (window length * sampling rate)
                window = wSize * sRate;

                aux = ceil(lte/pAcquisition);
                lastSample = aux * window_shift;
                unread_block = lastSample-window;
                %                 offset = unread_block * 8;

                %number of samples processed by each window (window duration * sampling rate; 300 sec and 15 sec)

                signal_en = EEG_en_variation.^2;
                %signal energy (^2) pointxpoint

                number=1;
                i = 1;
                
                en_lte = 0;
                en_ste = 0;

                en_accumulated = 0;
                en_level = 0;


                % CALCULAR MOMENTO ANTES PARA ENERGIA ACUMULADA


                while (~lastSegment)
                    %data = window_lte + (i-1)*window_shift;

                    en_lte(i) = (sum(signal_en)/window_lte);

                    en_ste(i) = (sum(signal_en(window_lte-window_ste:window_lte))/window_ste);



                    aux = (signal_en(window_lte-window:window_lte));
                    en_level (i+1) = ((sum(aux)) / window);
                    en_accumulated (i+1) = en_accumulated(i)+en_level(i+1);
                    en_derivate (i+1) = (en_level(i+1) - en_level(i));

                    %processing of STE and LTE values

                    % remove first x samples
                    signal_en (1:window_shift) = [];
                    %                   [segmentTrace, lastSample, lastSegment] = readFile2segments (file, lastSample, pAcquisition * sRate);
                    [segmentTrace, lastSegment, offset] = epiread.Read_MATfile (window_shift, offset, selected_chan);
                    segmentTrace = (segmentTrace.^2)';
                    signal_en = vertcat(signal_en, segmentTrace);

                    %                     offset;
                    i = i+1;
                end

                pred_time =  (window_lte/sRate):pAcquisition:((window_lte + (window_shift*(i-2)))/sRate);
            end




            function [pred_time,en_ste,en_lte] = EnergyVariation_readFile (pAcquisition,sRate,selected_chans,ste,lte,file_data_obj)

                if nargin == 1,
                    pAcquisition = 5;
                    sRate = 256;
                    ste = 15;
                    lte = 300;
                end,



                window_shift = pAcquisition * sRate;

                window_lte = lte * sRate;
                window_ste = ste * sRate;




                [segmentTrace, lastSegment]=file_data_obj.init_data_access(selected_chans);


                EEG_en_variation = segmentTrace';

                n_chan2proc=length(selected_chans);


                signal_en = EEG_en_variation.^2;

                %signal energy (^2) pointxpoint
                %signal_en(end-10:end)
                i = 1;
                en_lte = 0;
                en_ste = 0;

                en_lte=[];
                en_ste=[];

                while (~lastSegment)


                    en_lte= [en_lte;(sum(signal_en)./window_lte)];

                    en_ste = [en_ste;(sum(signal_en(window_lte-window_ste:window_lte,:))./window_ste)];


                    [segmentTrace, lastSegment]=file_data_obj.get_next_data_segment();

                    signal_en (1:window_shift,:) = [];
                    segmentTrace = (segmentTrace.^2)';
                    signal_en = vertcat(signal_en, segmentTrace);

                    i = i+1;
                end

                en_ste=en_ste';
                en_lte=en_lte';

                pred_time =  (window_lte/sRate):pAcquisition:((window_lte + (window_shift*(i-2)))/sRate);

            end
        end
    end
end
