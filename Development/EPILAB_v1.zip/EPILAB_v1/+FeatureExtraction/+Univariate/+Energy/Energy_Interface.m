classdef Energy_Interface < handle
    %======================================================================
    %Energy_Interface
    %
    %Interface to Energy features
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
   % The following properties can be set only by class methods
   properties
      e_i;
      e_d;
      e_f;
      
      % data
      study;
      
      acq_window;
      acq_step;
   end
    
   methods
      %Constructor
      function obj = Energy_Interface(study)
         %  Create and then hide the GUI as it is being constructed.
         obj.study = study;
         
         obj.e_f = FeatureExtraction.Univariate.Energy.Energy_Functions();
         obj.e_d = FeatureExtraction.Univariate.Energy.Energy_Data();
         
         obj.acq_window = 5;
         obj.acq_step = obj.acq_window;         
      end
   end
   
   methods(Static)
      %Draw the panel and its contents
      function draw(obj,panel)
          
          
          % display new panel
          obj.e_i.ModulesPanel = uipanel('Parent', panel, 'Title', 'Energy-based features' ,'Units','Normalized','Position', [0.05 0.05 0.9 0.9]);

          obj.e_i.AcquisitionIntervalEdit = uicontrol('Parent',obj.e_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.8 0.2 0.05],...
              'String',num2str(obj.acq_window)); % Edit box for data path
          obj.e_i.AcquisitionIntervalText = uicontrol('Parent', obj.e_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.8 0.5 0.05],...
              'String','Feature computation - acquisition interval (seconds)'); % Text for data path

          obj.e_i.AverageEnergySel = uicontrol('Parent',obj.e_i.ModulesPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.65 0.4 0.05],...
              'String','Accumulated & derivate energy', 'enable','on', 'value', 0, 'callback', {@AverageEnergySelCallback, obj}); % Edit box for data path
          

          obj.e_i.AverageEnergyEdit = uicontrol('Parent',obj.e_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.55 0.1 0.05],...
              'String','', 'enable','off'); % Edit box for data path
          obj.e_i.AverageEnergyText = uicontrol('Parent', obj.e_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.55 0.45 0.05],...
              'String','Average Energy Window Size (seconds)', 'enable','off'); % Edit box for data path

          obj.e_i.LTEEdit = uicontrol('Parent',obj.e_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.4 0.1 0.05],...
              'String',num2str(obj.acq_window)); % Edit box for data path
          obj.e_i.LTEText = uicontrol('Parent', obj.e_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.4 0.45 0.05],...
              'String','Long Term Energy (window size, seconds)'); % Edit box for data path

          obj.e_i.STEEdit = uicontrol('Parent',obj.e_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.3 0.1 0.05],...
              'String',num2str(obj.acq_window * 0.5)); % Edit box for data path
          obj.e_i.STEText = uicontrol('Parent', obj.e_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.3 0.45 0.05],...
              'String','Short Term Energy (window size, seconds)'); % Edit box for data path

          obj.e_i.CancelButton = uicontrol('Parent', obj.e_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.55 0.05 0.1 0.05],...
              'String','Cancel','Callback', {@CancelButtonCallback, obj}); % Button for cancel
          obj.e_i.HelpButton = uicontrol('Parent', obj.e_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.70 0.05 0.1 0.05],...
              'String','Help','Callback', @HelpButtonCallback); % Button for help
          obj.e_i.OkButton = uicontrol('Parent', obj.e_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.85 0.05 0.1 0.05],...
              'String','Ok','Callback', {@OkButtonCallback, obj, obj.study}); % Button for ok
      
          function OkButtonCallback (hObject, eventdata, obj, study)
              
              if ~isempty(get(obj.e_i.AcquisitionIntervalEdit, 'String'))
                  obj.acq_window = str2num(get(obj.e_i.AcquisitionIntervalEdit, 'String'));
              end
              
              close(gcf);
                    
          end
          
          function CancelButtonCallback (hObject, eventdata, obj)
              obj.clear (obj.e_i);
              close(gcf);
          end
          
          function AverageEnergySelCallback (hObject, eventdata, obj)
              if (get(obj.e_i.AverageEnergySel, 'value'))
                  set(obj.e_i.AverageEnergyEdit, 'enable', 'on');
                  set(obj.e_i.AverageEnergyText, 'enable', 'on');
              else
                  set(obj.e_i.AverageEnergyEdit, 'enable', 'off');
                  set(obj.e_i.AverageEnergyText, 'enable', 'off');
              end
          end
      end
      
      function ClearChildClasses(obj)
          delete(obj.e_f);
          clear obj.e_f
          delete(obj.e_d);
          clear obj.e_d
          obj.e_f = FeatureExtraction.Univariate.Energy.Energy_Functions();
          obj.e_d = FeatureExtraction.Univariate.Energy.Energy_Data();
      end      
      
      function RunSingleSegment(obj, study, p_segment, p_samp_rate)
          obj.e_f.RunSingleSegment(study, p_segment, p_samp_rate);
      end

      function SaveResults(obj, study)
          obj.e_d.SaveData(study, obj.e_f);
      end           

      %Clear the panel and its contents
      function clear(C)
        delete(C.ModulesPanel);
      end
    end
end