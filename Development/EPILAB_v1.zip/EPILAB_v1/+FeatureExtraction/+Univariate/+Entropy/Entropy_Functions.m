classdef Entropy_Functions < handle
    %======================================================================
    %Entropy_Functions
    %
    %Functions of Entropy features
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================

    % The following properties can be set only by class methods
    properties

        parameter_acquisition;
        overlap;

        % algorithm output
        time;
        AppEntropy_results;
        SamEntropy_results;        
        
    end

    methods

        %Constructor
        function obj = Entropy_Functions()
            addpath(fullfile('utils','ecg'));
            
            obj.AppEntropy_results = [];
            obj.SamEntropy_results = [];
            obj.time = [];

        end
        
        function obj = RunSingleSegment(obj, study, p_segment, p_samp_rate)
            
            v_AppEn = [];
            v_SamEn = [];
            for s_Counter = 1:size(p_segment, 1)
                if length(p_segment(s_Counter, :)) > 10
                    v_AppEn = f_AddVerElems(v_AppEn, ...
                        f_apen_est(p_segment(s_Counter, :)));
                    v_SamEn = f_AddVerElems(v_SamEn, ...
                        f_sampen(p_segment(s_Counter, :), 3, [], [], 0));
                else
                    v_AppEn = f_AddVerElems(v_AppEn, -1);
                    v_SamEn = f_AddVerElems(v_SamEn, -1);
                end
            end
            if study.dataset(study.dataset_selected).results.saveFileHandle_uni > 0
                fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_uni, ...
                    v_AppEn(:), 'double');
                fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_uni, ...
                    v_SamEn(:), 'double');
            else
                if ~isempty(obj.AppEntropy_results)
                    obj.AppEntropy_results = obj.AppEntropy_results{1};
                end
                obj.AppEntropy_results = f_AddHorElems(obj.AppEntropy_results, ...
                    v_AppEn(:, 1));
                obj.AppEntropy_results = {obj.AppEntropy_results};

                if ~isempty(obj.SamEntropy_results)
                    obj.SamEntropy_results = obj.SamEntropy_results{1};
                end
                obj.SamEntropy_results = f_AddHorElems(obj.SamEntropy_results, ...
                    v_SamEn(:, 1));
                obj.SamEntropy_results = {obj.SamEntropy_results};
            end
        end;
    end
        
    methods (Access=public)
        
    end
end
