classdef Entropy_Interface < handle
    %======================================================================
    %Entropy_Interface
    %
    %Interface to Entropy features
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    properties
        
        par_acquisition;
        
        study;
        
        % class objects
        en_i;
        en_f;
        en_d;
        
        acq_window;
        acq_step;
    end
    
    methods
      %Constructor
      function obj = Entropy_Interface(study)
         %  Create and then hide the GUI as it is being constructed.
         obj.study = study;
         
         obj.en_f = FeatureExtraction.Univariate.Entropy.Entropy_Functions();
         obj.en_d = FeatureExtraction.Univariate.Entropy.Entropy_Data();
         
         obj.acq_window = 5;
         obj.acq_step = obj.acq_window;
      end
    end

    methods(Static)
      %Draw the panel and its contents
      function draw(obj,panel)
          
          % display new panel
          obj.en_i.ModulesPanel = uipanel('Parent', panel, 'Title', 'Decorrelation Time' ,'Units','Normalized','Position', [0.05 0.05 0.9 0.9]);

          obj.en_i.AcquisitionIntervalEdit = uicontrol('Parent',obj.en_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.8 0.2 0.05],...
              'String',num2str(obj.acq_window));
          obj.en_i.AcquisitionIntervalText = uicontrol('Parent', obj.en_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.8 0.5 0.05],...
              'String','Feature computation - acquisition interval (seconds)'); 

          obj.en_i.OverlapEdit = uicontrol('Parent',obj.en_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.7 0.2 0.05],...
              'String',num2str(obj.acq_step));
          obj.en_i.OverlapText = uicontrol('Parent', obj.en_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.7 0.5 0.05],...
              'String','Feature computation - step (seconds)'); 

          obj.en_i.CancelButton = uicontrol('Parent', obj.en_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.55 0.05 0.1 0.05],...
              'String','Cancel','Callback', {@CancelButtonCallback, obj}); % Button for cancel
          obj.en_i.HelpButton = uicontrol('Parent', obj.en_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.70 0.05 0.1 0.05],...
              'String','Help','Callback', @HelpButtonCallback); % Button for help
          obj.en_i.OkButton = uicontrol('Parent', obj.en_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.85 0.05 0.1 0.05],...
              'String','Ok','Callback', {@OkButtonCallback, obj, obj.study}); % Button for ok
      
          function OkButtonCallback (hObject, eventdata, obj, study)
              
              if ~isempty(get(obj.en_i.AcquisitionIntervalEdit, 'String'))
                  obj.acq_window = str2num(get(obj.en_i.AcquisitionIntervalEdit, 'String'));
              end
              
              if ~isempty(get(obj.en_i.OverlapEdit, 'String'))
                  obj.acq_step = str2num(get(obj.en_i.OverlapEdit, 'String'));
              end              
              
              close(gcf);
          end
          function CancelButtonCallback (hObject, eventdata, obj)
              close(gcf);
              return;              
%               obj.clear (obj.en_i);
          end
      end
      
      function ClearChildClasses(obj)
          delete(obj.en_f);
          clear obj.en_f
          delete(obj.en_d);
          clear obj.en_d
          obj.en_f = FeatureExtraction.Univariate.Entropy.Entropy_Functions();
          obj.en_d = FeatureExtraction.Univariate.Entropy.Entropy_Data();
      end      
      
      function RunSingleSegment(obj, study, p_segment, p_samp_rate)
          obj.en_f.RunSingleSegment(study, p_segment, p_samp_rate);
      end

      function SaveResults(obj, study)
          obj.en_d.SaveData(study, obj.en_f);
      end
      
      %Clear the panel and its contents
      function clear(C)
          delete(C.ModulesPanel);
      end
    end
end


