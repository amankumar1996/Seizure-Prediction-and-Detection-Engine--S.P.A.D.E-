classdef Hjorth_Functions < handle
%======================================================================
    %Hjorth_Interface
    %
    %Functions for Hjorth features
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================

    % The following properties can be set only by class methods
    properties

        parameter_acquisition;
        overlap;

        time;
        
        HjorthM_results={};
        HjorthC_results={};
        
        ARMethod_val %(optional): set to 1 to compute the power spectral density
        % via an AR (Autoregressive) model estimator. Default: 0 (FFT squared
        % modulus estimator)

    end

    methods

        %Constructor
        function obj = Hjorth_Functions()
            obj.time = [];
            obj.HjorthM_results = [];
            obj.HjorthC_results = [];
        end
        
        function obj = RunSingleSegment(obj, study, p_segment, p_samp_rate, ARMethod)
            v_hjorth = [];
            for s_Counter = 1:size(p_segment, 1)
                clear s_hm s_hc
                [s_hm s_hc] = obj.f_Hjorth(p_segment(s_Counter, :), p_samp_rate, ...
                    ARMethod);
                v_hjorth = f_AddVerElems(v_hjorth, [s_hm s_hc]);
            end
            if study.dataset(study.dataset_selected).results.saveFileHandle_uni > 0
                fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_uni, ...
                    v_hjorth(:), 'double');
            else
                if ~isempty(obj.HjorthM_results)
                    obj.HjorthM_results = obj.HjorthM_results{1};
                end
                obj.HjorthM_results = f_AddHorElems(obj.HjorthM_results, ...
                    v_hjorth(:, 1));
                obj.HjorthM_results = {obj.HjorthM_results};

                if ~isempty(obj.HjorthC_results)
                    obj.HjorthC_results = obj.HjorthC_results{1};
                end
                obj.HjorthC_results = f_AddHorElems(obj.HjorthC_results, ...
                    v_hjorth(:, 2));
                obj.HjorthC_results = {obj.HjorthC_results};
            end
        end;        

        
        
        function [s_HM s_HC] = ...
    f_Hjorth(obj,...
    pv_Sig, ...
    ps_SamRate, ...
    ps_ARMethod)
% 
% Function: f_Hjorth.m
% 
% Description: 
% This function computes the Hjorth mobility and complexity as defined in
% Mormann et al., 2005.
% 
% Inputs:
% pv_Sig: input signal
% ps_SamRate: sample rate in Hz
% ps_ARMethod (optional): set to 1 to compute the power spectral density
% via an AR (Autoregressive) model estimator. Default: 0 (FFT squared
% modulus estimator) 
% 
% Outputs:
% s_HM: Hjorth mobility
% s_HC: Hjorth complexity
% 
% MATLAB Version: R2007b
% 
% Team: LENA
% Author: Mario Valderrama
%

if nargin < 1
    error('[f_Hjorth] - ERROR: bad number of inputs!');
end

s_ARMethod = 0;
if exist('ps_ARMethod', 'var') && ~isempty(ps_ARMethod)
    s_ARMethod = ps_ARMethod;
end

clear v_PowSpec v_Freq s_TotalPow
[v_PowSpec v_Freq s_TotalPow] = ...
    f_PowSpec(pv_Sig, ps_SamRate, s_ARMethod);

v_Freq = v_Freq.* v_Freq;
s_HM = sum(v_PowSpec(:).* v_Freq(:))./ s_TotalPow;
v_Freq = v_Freq.* v_Freq;
s_HC = sum(v_PowSpec(:).* v_Freq(:))./ s_TotalPow;

clear v_Freq
        
        end
    end
        
%     methods (Access=public)
%         [s_HM s_HC] = f_Hjorth(obj, eeg_segment, ps_SamRate, ps_ARMethod);
%     end


end
