function [ed] = CalcDistBPoints(y,tau,ed_algorithm)
%   CALCDISTBPOINTS Calculate the distance between alll points in a 3D matrix
%   
%   [ED] = CALCDISTBPOINTS(Y,TAU,ED_ALGORITHM)
%
%   Input parameters:
%   y: 3D matrix containing the phase space reconstruction
%   tau: Tima delay
%   ed_algorithm: Algorithm 
%
%   Output parameters:
%   ed: 3D matrix with distances between all points of y

if nargin<3
   ed_algorithm = 'euclidean'; 
end
if nargin<2
    error('Parameter tau is missing.')
end
if nargin==0,
    display('Parameter y is missing.');
end

if strcmp(ed_algorithm,'maximumNorm')==0 && strcmp(ed_algorithm,'euclidean')==0,
    error('ed_algorithm must be "maximum_norm" or "euclidean"');
end

ndim = size(y,3);
N=size(y,1);

ed=zeros(N,N,ndim);

% display('*** Calculating nearest neighbours of y ***')

%Calc of Maximum Norm
if strcmp(ed_algorithm,'maximum_norm')==1,

    for m=1:ndim
        a_aux=y(1:N-(m-1)*tau,1:m,m);
        for l=1:size(a_aux,1)
            for k=l:size(a_aux,1)

                ed(l,k,m)=maximumNorm(l,k,m,x,tau);
                ed(k,l,m)=ed(l,k,m);
            end
        end
        clear a_aux;
    end

elseif strcmp(ed_algorithm,'euclidean')==1,

    for m=1:ndim
        a_aux=y(1:N-(m-1)*tau,1:m,m);

        ed(1:size(a_aux,1),1:size(a_aux,1),m)=squareform (pdist(a_aux));

        clear a_aux;
    end

end

function [ed] = maximumNorm (l,k,m,x,tau)

mn_aux=zeros(m,1);
for j=0:m-1
    mn_aux(j+1,1)=abs(x(l+j*tau)-x(k+j*tau));
end

ed=max(mn_aux);