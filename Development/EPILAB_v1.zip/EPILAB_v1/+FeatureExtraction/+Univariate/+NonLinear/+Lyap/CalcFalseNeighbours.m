function [E] = CalcFalseNeighbours(y,tau,ed)
%   CALCFALSENEIGHBOURS Calculate the false neighbours between points of y
%   
%   [E] = CALCFALSENEIGHBOURS(Y,ED,N,TAU,NDIM)
%
%   Input parameters:
%   y: 3D matrix containing the phase space reconstruction for ndim
%   ed: 3D matrix with distances between all points of y
%   tau: Tima delay
%
%   Output parameters:
%   E: 

if nargin==2,
    [ed] = CalcDistBPoints(y,tau);
end
if nargin<2
   error('Parameter tau is missing.'); 
end
if nargin==0
   error('Parameter y is missing.') 
end

N=size(y,1);
ndim=size(y,3);

% display('*** Calculating false neighbours ***')

a = zeros(N-tau,ndim-1);
n = zeros(N-tau,ndim-1);

E=zeros(ndim-1,1);

for d=1:ndim-1
    for i=1:N-d*tau
        [n_aux,ind]=sort(ed(i,1:N-d*tau,d));
        n(i,d)=ind(find(n_aux,1,'first'));

        %             display(['i = ' num2str(i) ', d = ' num2str(d) ', n(i,d) = ' num2str(n(i,d)) ]);
        a(i,d)=ed(i,n(i,d),d+1)/ed(i,n(i,d),d);
    end

    E(d,1)=(1/(N-d*tau))*sum(a(1:N-d*tau,d));
end
