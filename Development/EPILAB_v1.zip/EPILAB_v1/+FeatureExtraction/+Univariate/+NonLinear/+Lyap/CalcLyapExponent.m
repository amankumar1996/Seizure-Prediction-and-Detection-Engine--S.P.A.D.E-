function [exponent_est, min_emb_dim] = CalcLyapExponent(x)
%   CALCLYAPEXPONENT Function to calculate the Lyapunov exponents of a time
%   series segment. The algorithm is based on the fixed [1].
%
%   References:
%   [1] Determining 
%   Detailed explanation goes here

N=length(x);

[tau] = CalcTimeDelay(x);

[y] = RecPhaseSpace(x,tau);

[min_emb_dim,ed] = CalcMinEmbDimension(x,y,tau);

attractor = y(1:N-(min_emb_dim-1)*tau,1:min_emb_dim,min_emb_dim); 

% dist_matrix = squareform(pdist (attractor,'euclidean'));

% total_matrix = cmdscale(dist_matrix);

% %--------------------------------------------------------------------------
% figure(1)
% hold on;
% if size(total_matrix,2)>=3
%     p1 = plot3(total_matrix(:,1),total_matrix(:,2),total_matrix(:,3),'-b');
% elseif size(total_matrix,2)==2
%     p1 = plot(total_matrix(:,1),total_matrix(:,2),'-b');
% end
% pause;
% %--------------------------------------------------------------------------

s1 = size(attractor,1);

% find the NN of the fiducial point

ind = 1; %indice da trajectoria referencia

ind2 = 0; %indice trajectoria candidata

exponent_est = 0; %valor da estimativa do expoente

its = 0; % numero de iterac��es

evolv = 4; % parametro de evolu��o do attractor

att_size = s1 - evolv -1; % tamanho do ficheiro util

sumAux = 0;

while (ind<att_size)
    if its==0
        % distance between fiducial point and closer point
        [distOrd, indOrd] = sort (ed(1:s1-evolv,ind,min_emb_dim));
        initDist = find (distOrd,1,'first');
        ind2 = indOrd (initDist);
    else
        initDist = ed(ind2,ind,min_emb_dim);
    end
    
    
% %--------------------------------------------------------------------------
% %coordinates and graphical representation of both points    
% figure(1)
% p2 = plot3 (total_matrix(ind,1),total_matrix (ind,2),total_matrix (ind,3),'-or');
% p3 = plot3 (total_matrix(ind2,1),total_matrix (ind2,2),total_matrix (ind2,3),'-or');
% pause;
% %--------------------------------------------------------------------------

    % determination of the distance between the 2 points after evolv time smaples
    finalDist = (ed(ind2+evolv,ind+evolv,min_emb_dim));

% %--------------------------------------------------------------------------    
% %graphical representation of evolved points
% p4 = plot3 ([(total_matrix (ind2+evolv, 1));(total_matrix (ind+evolv, 1))],...
% [(total_matrix (ind2+evolv, 2));(total_matrix (ind+evolv, 2))],...
% [(total_matrix (ind2+evolv, 3));(total_matrix (ind+evolv, 3))],'-or');
% pause;
% %--------------------------------------------------------------------------


    % add 1 iteration
    its = its+1;

    % Auxiliar computation for Lyapunov exponent estimative
    sumAux = sumAux + log2(finalDist/initDist)/evolv;

    % Lyapunov exponent estimative
    exponent_est = sumAux/its;

    no_points_found = true;

    indOld = ind2;
    anglmx = 0.3;
    distmx = 0.4;

    % look for new points
    while (no_points_found)
        % avoid closest point to the reference point
        % avoid points too far
               
        indAux = find (ed (1:s1-evolv,ind+evolv,min_emb_dim)< (distmx* mean(ed(1:s1-evolv,ind+evolv,min_emb_dim))));

        indAux2 = find(indAux>10);


        if ~isempty(indAux2)
            for i = 1:length (indAux2)
                indCandidate = indAux(indAux2(i));
                dnew = ed (indCandidate,ind+evolv,min_emb_dim);

                if (indCandidate ~= ind+evolv) %%&& indCandidate

% %--------------------------------------------------------------------------                    
% % graphical representation of ref point and candidates - angle
% p5 = plot3 ([(total_matrix (indCandidate, 1));(total_matrix (ind+evolv, 1))],...
% [(total_matrix (indCandidate, 2));(total_matrix (ind+evolv, 2))],...
% [(total_matrix (indCandidate, 3));(total_matrix (ind+evolv, 3))],'-g');
% pause;
% set(p5,'Visible','off')
% %--------------------------------------------------------------------------

                    % computation of the angle between vector
                    vector1 = attractor (ind+evolv,:) - attractor(indCandidate,:);
                    vector2 = attractor (ind+evolv,:) - attractor(ind2+evolv,:);
                    angldot = dot(vector1,vector2);

                    cth = abs(angldot/(finalDist*dnew));
                    angl = acos (cth);
                    if imag(angl) ~= 0
                        %
                        %                             break;
                    elseif angl<anglmx
                        no_points_found = false;
                        ind2 = indCandidate;
                        ind = ind+evolv;
                        break;
                    end
                end
            end
        end

        if distmx < 1
            distmx = distmx + 0.2;
            %                 disp ('maior distancia');
        elseif anglmx <= 0.9
            anglmx = anglmx+0.3;
            %                 disp ('maior angulo');
        else
            ind = ind+evolv;
            ind2 = indOld+evolv;
            no_points_found = false;
        end
        
        if ind+evolv>s1 || ind2+evolv>s1
            break;
        end
    end
% %--------------------------------------------------------------------------    
% set(p2,'Visible','off')
% set(p3,'Visible','off')
% set(p4,'Visible','off')
% %--------------------------------------------------------------------------    
    
end
display(['*** Lyapunov Exponent = ' num2str(exponent_est) '. Embedding Dimension = ' num2str(min_emb_dim) ' ***']);
