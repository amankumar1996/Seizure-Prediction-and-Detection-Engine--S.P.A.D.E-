function [min_emb_dim,ed,y] = CalcMinEmbDimension(x,y,tau,ed_algorithm,DISPLAY)
%   CALCMINEMBDIMENSION Function to calculate the embedding dimension based on [1].
%
%   [ED] = CALCMINEMBDIMENSION(X,Y,TAU,ED_ALGORITHM,DISPLAY)
%
%   References:
%   [1] Pratical Method for determining the minimum embedding dimension of a
%   scalar time series, Liangyue Cao
%
%   Input parameters:
%   x: segmentof the time series signal
%   y: 3D matrix containing the phase space reconstruction for ndim
%   dimensions
%   tau: time delay
%   ed_algorithm: algorithm used to calculate the distance between a point and
%   its neighbours. It can be "maximum_norm" or "euclidean";
%   DISPLAY: 0 or 1 to display or not to display the delay time graphic
%
%   Output parameteres:
%   min_emb_dim - minimum embedding dimension

if nargin<5,
    DISPLAY=0;
    if DISPLAY,
        display(['Parameter DISPLAY = ' num2str(DISPLAY) '.']);
    end
end
if nargin<4,
    ed_algorithm='euclidean';
    if DISPLAY,
        display(['Parameter eu_algorithm = "' ed_algorithm '".']);
    end
end
if nargin<3 || isempty(tau)==1,
    tau=delayTime(x);
    if DISPLAY,
        display(['Parameter tau = ' num2str(tau) '.']);
    end
end
if nargin<2,
    y = RecPhaseSpace(x,tau);
    if DISPLAY,
        display('Parameter y has been calculated.');
    end
end
if nargin==0,
    display('Parameter x is missing.');
end
if size(x,2)~=1
    x=x';
    display('Parameter x was transposed .');
end
if strcmp(ed_algorithm,'maximumNorm')==0 && strcmp(ed_algorithm,'euclidean')==0,
    error('ed_algorithm must be "maximum_norm" or "euclidean"');
end

[ed] = CalcDistBPoints(y,tau);

[E] = CalcFalseNeighbours(y,tau,ed);

% [min_emb_value, min_emb_dim] = min (E);
% min_emb_dim_aux = find(E/sum(E)<0.01,1,'first');
% if min_emb_dim_aux<min_emb_dim, min_emb_dim=min_emb_dim_aux; end
diff_E=abs(diff(E));
[min_emb_value, min_emb_dim] = min (diff_E);



if DISPLAY,
    display(['*** Minimum embeding dimension ' num2str(min_emb_dim) ' ***'])
end

if DISPLAY,
    figure
    hold on;
    plot(E)
    plot(min_emb_dim,min_emb_value,'*r')
    plot(diff_E,'m')
    pause;
end




