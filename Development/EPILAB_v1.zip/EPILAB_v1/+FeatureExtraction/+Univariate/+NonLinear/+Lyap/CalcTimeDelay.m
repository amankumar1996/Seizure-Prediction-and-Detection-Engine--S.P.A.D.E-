function [tau] = CalcTimeDelay(x,n_T,DISPLAY )
%   CALCTIMEDELAY Function to find the delay time based on the maximization odf
%   the mutual prediciton error [1].
%
%   [TAU] = DELAYTIME(X,N_T,DISPLAY)
%
%   References:
%   [1] Aplications of the nearest neighbours statistics, Jorg D. Wichard
%
%   Input parameters:
%   x: segmentof the time series signal
%   n_T: maximum delay time possible
%   DISPLAY: 0 or 1 to display or not to display the delay time graphic
%
%   Output parameteres:
%   tau: optimum delay time

if nargin<3,
    DISPLAY=0;
    if DISPLAY,
        display(['Parameter DISPLAY = ' num2str(DISPLAY) '.']);
    end
end
if nargin<2,
    n_T=50; %Number of possible values for time delay
    if DISPLAY,
        display(['Parameter n_T = ' num2str(n_T) '.']);
    end
end
if nargin==0,
    display('Parameter x is missing.');
end
if size(x,2)~=1
    x=x';
    display('Parameter x was transposed .');
end

if n_T>length(x)-2
    n_T=length(x)-2;
    display(['Parameter n_T = ' num2str(n_T) '.']);
end

if DISPLAY,
    display('*** Calculating delay time. ***');
end

N=length(x);

F=zeros(n_T,1);

for T=1:n_T

    F_aux=0;
    for i=1:N-T
        [xnn_aux,ind] = sort(abs(x(1:N-T)-x(i)));
        %         [xnn_aux,ind] = sort(sqrt(((x(1:N-T)-x(i)).^2)+((1:N-T)'-i).^2));
        nn = ind(find(xnn_aux,1,'first'));

        aux=abs(x(i)-x(nn));
        if aux~=0, F_aux = F_aux + abs(x(i+T)-x(nn+T))/aux; end

    end
    F(T)=(1/(N-T))*F_aux;
end

[tau_v, tau] = localMax(F,1,'first');

if DISPLAY,
    display(['*** Delay time = ' num2str(tau) '. ***']);
end

if DISPLAY,
    figure;
    hold on;
    plot(F)
    plot(tau,F(tau),'*r');
end

