function [y] = RecPhaseSpace(x,tau,ndim,DISPLAY)
%   RECPHASESPACE Function to reconstruc the phase space of a time series
%   segment.
%
%   [Y] = RECPHASESPACE(X,TAU,NDIM,DISPLAY)
%
%   References:
%   [1] Phase Space Analysis for Cardiovascular Signals, S.M.Krihnan
%
%   Input parameters:
%   x: segmentof the time series signal
%   tau: optimum delay time
%   ndim: maximum number of dimensions used to reconstruct the phase space
%
%   Output parameters:
%   y: 3D matrix containing the phase space reconstruction for ndim
%   dimensions

if nargin<4,
    DISPLAY=0;
    if DISPLAY,
    display(['Parameter DISPLAY = ' num2str(DISPLAY) '.']);
    end
end
if nargin<3,
    ndim=10;
    if DISPLAY,
    display(['Parameter ndim = ' num2str(ndim) '.']);
    end
end
if nargin<2 || isempty(tau)==1,
    tau=CalcTimeDelay(x);  %Most suitable value when studing ECG signals is tau=7. [1] 
    if DISPLAY,
    display(['Parameter tau = ' num2str(tau) '.']);
    end
end
if nargin==0,
    display('Parameter x is missing.');
end
if size(x,2)~=1
    x=x';
    display('Parameter x was transposed .');
end
if ndim>round(length(x)/tau),
    ndim=round(length(x)/tau);
    display(['Parameter ndim = ' num2str(ndim) '.']);
end

N = length(x);
y = zeros(N,ndim,ndim);


%Vector Reconstruction

if DISPLAY,
    display('*** Reconstructing vector y ***'); 
end

for i=1:N
    y(i,1,1)=x(i);
    for d=2:ndim
        if (i>N-(d-1)*tau), break; end
        y(i,1:d,d) = [y(i,1:d-1,d-1) x(i+(d-1)*tau)];
%         display([num2str(size(y(i,1:d,d)))]);
    end
end
