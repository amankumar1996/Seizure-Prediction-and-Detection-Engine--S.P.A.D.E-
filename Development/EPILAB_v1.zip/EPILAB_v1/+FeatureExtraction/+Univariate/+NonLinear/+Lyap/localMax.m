% LOCALMAX Function find local maximums.
%
% Input parameters:
% x: time series signal
% scale: sensitivity of the local maximums search
% option:
%  'first': first maximum
%  'last': last maximum
%  'all': all maximums
%
% Output parameteres:
% lmv: localmax values
% lmi: localmax indexes

function [lmv,lmi] = localMax(x,scale,option)

if nargin<3,
    option='all';
    display(['Parameter option = "' option '".']);
end
if nargin<2,
    scale=1;
    display(['Parameter scale = ' num2str(scale) '.']);
end
if nargin<1
    error('time series not found.');
end


localmax=[];

n_signal = length(x);

l = 0;
for j=scale+1:n_signal-scale
   y = x(j-scale:j+scale);
   [ymax,imax] = max(y);
   if imax == scale+1
      l = l+1;
      localmax(l,1) = j;
      localmax(l,2) = ymax;     
   end
end

if isempty(localmax)~=1
    if (strcmp(option,'first'))
        localmax=localmax(1,:);
    elseif (strcmp(option,'last'))
        localmax=localmax(end,:);
    end
end

lmi = localmax(:,1);
lmv = localmax(:,2);


