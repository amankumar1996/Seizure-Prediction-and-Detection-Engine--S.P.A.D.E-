function [exponent_est, min_emb_dim] = CalcLyapExponent(obj, x)
%   CALCLYAPEXPONENT Function to calculate the Lyapunov exponents of a time
%   series segment. The algorithm is based on the fixed [1].
%
%   References:
%   [1] Determining
%   Detailed explanation goes here

tic
N=length(x);

% [tau] = CalcTimeDelay(x);

tau = 10;

[y] = RecPhaseSpace(x,tau);

[min_emb_dim,ed] = CalcMinEmbDimension(x,y,tau);

attractor = y(1:N-(min_emb_dim-1)*tau,1:min_emb_dim,min_emb_dim);

% dist_matrix = squareform(pdist (attractor,'euclidean'));

% total_matrix = cmdscale(dist_matrix);

% %--------------------------------------------------------------------------
% figure(1)
% hold on;
% if size(total_matrix,2)>=3
%     p1 = plot3(total_matrix(:,1),total_matrix(:,2),total_matrix(:,3),'-b');
% elseif size(total_matrix,2)==2
%     p1 = plot(total_matrix(:,1),total_matrix(:,2),'-b');
% end
% pause;
% %--------------------------------------------------------------------------

s1 = size(attractor,1);

% find the NN of the fiducial point

ind = 1; % reference trajectory point index

ind2 = 0; % candidate trajectory point index

exponent_est = 0; % Lyapunov Exponent estimative during the algorithm

its = 0; % number of iterations

evolv = 4; % attractor's evolution

att_size = s1 - evolv -1; % usable file size

sumAux = 0;

while (ind<att_size)
    if its==0
        % distance between fiducial point and closer point
        [distOrd, indOrd] = sort (ed(1:s1-evolv,ind,min_emb_dim));
        initDist = find (distOrd,1,'first');
        ind2 = indOrd (initDist);
    else
        initDist = ed(ind2,ind,min_emb_dim);
    end


    % %--------------------------------------------------------------------------
    % %coordinates and graphical representation of both points
    % figure(1)
    % p2 = plot3 (total_matrix(ind,1),total_matrix (ind,2),total_matrix (ind,3),'-or');
    % p3 = plot3 (total_matrix(ind2,1),total_matrix (ind2,2),total_matrix (ind2,3),'-or');
    % pause;
    % %--------------------------------------------------------------------------

    % determination of the distance between the 2 points after evolv time smaples
    finalDist = (ed(ind2+evolv,ind+evolv,min_emb_dim));

    % %--------------------------------------------------------------------------
    % %graphical representation of evolved points
    % p4 = plot3 ([(total_matrix (ind2+evolv, 1));(total_matrix (ind+evolv, 1))],...
    % [(total_matrix (ind2+evolv, 2));(total_matrix (ind+evolv, 2))],...
    % [(total_matrix (ind2+evolv, 3));(total_matrix (ind+evolv, 3))],'-or');
    % pause;
    % %--------------------------------------------------------------------------


    % add 1 iteration
    its = its+1;

    % Auxiliar computation for Lyapunov exponent estimative
    sumAux = sumAux + log2(finalDist/initDist)/evolv;

    % Lyapunov exponent estimative
    exponent_est = sumAux/its;

    no_points_found = true;

    indOld = ind2;
    anglmx = 0.3;
    distmx = 0.4;

    % look for new points
    while (no_points_found)
        % avoid closest point to the reference point
        % avoid points too far

        indAux = find (ed (1:s1-evolv,ind+evolv,min_emb_dim)< (distmx* mean(ed(1:s1-evolv,ind+evolv,min_emb_dim))));

        indAux2 = find(indAux>10);


        if ~isempty(indAux2)
            for i = 1:length (indAux2)
                indCandidate = indAux(indAux2(i));
                dnew = ed (indCandidate,ind+evolv,min_emb_dim);

                if (indCandidate ~= ind+evolv) %%&& indCandidate

                    % %--------------------------------------------------------------------------
                    % % graphical representation of ref point and candidates - angle
                    % p5 = plot3 ([(total_matrix (indCandidate, 1));(total_matrix (ind+evolv, 1))],...
                    % [(total_matrix (indCandidate, 2));(total_matrix (ind+evolv, 2))],...
                    % [(total_matrix (indCandidate, 3));(total_matrix (ind+evolv, 3))],'-g');
                    % pause;
                    % set(p5,'Visible','off')
                    % %--------------------------------------------------------------------------

                    % computation of the angle between vector
                    vector1 = attractor (ind+evolv,:) - attractor(indCandidate,:);
                    vector2 = attractor (ind+evolv,:) - attractor(ind2+evolv,:);
                    angldot = dot(vector1,vector2);

                    cth = abs(angldot/(finalDist*dnew));
                    angl = acos (cth);
                    if imag(angl) ~= 0
                        %
                        %                             break;
                    elseif angl<anglmx
                        no_points_found = false;
                        ind2 = indCandidate;
                        ind = ind+evolv;
                        break;
                    end
                end
            end
        end

        if distmx < 1
            distmx = distmx + 0.2;
            %                 disp ('maior distancia');
        elseif anglmx <= 0.9
            anglmx = anglmx+0.3;
            %                 disp ('maior angulo');
        else
            ind = ind+evolv;
            ind2 = indOld+evolv;
            no_points_found = false;
        end

        if ind+evolv>s1 || ind2+evolv>s1
            break;
        end
    end
    % %--------------------------------------------------------------------------
    % set(p2,'Visible','off')
    % set(p3,'Visible','off')
    % set(p4,'Visible','off')
    % %--------------------------------------------------------------------------

end

display(['*** Lyapunov Exponent = ' num2str(exponent_est) '. Embedding Dimension = ' num2str(min_emb_dim) ' ***']);


    function [tau] = CalcTimeDelay(x,n_T,DISPLAY )
        %   CALCTIMEDELAY Function to find the delay time based on the maximization odf
        %   the mutual prediciton error [1].
        %
        %   [TAU] = DELAYTIME(X,N_T,DISPLAY)
        %
        %   References:
        %   [1] Aplications of the nearest neighbours statistics, Jorg D. Wichard
        %
        %   Input parameters:
        %   x: segmentof the time series signal
        %   n_T: maximum delay time possible
        %   DISPLAY: 0 or 1 to display or not to display the delay time graphic
        %
        %   Output parameteres:
        %   tau: optimum delay time

        if nargin<3,
            DISPLAY=0;
            if DISPLAY,
                display(['Parameter DISPLAY = ' num2str(DISPLAY) '.']);
            end
        end
        if nargin<2,
            n_T=50; %Number of possible values for time delay
            if DISPLAY,
                display(['Parameter n_T = ' num2str(n_T) '.']);
            end
        end
        if nargin==0,
            display('Parameter x is missing.');
        end
        if size(x,2)~=1
            x=x';
            display('Parameter x was transposed .');
        end

        if n_T>length(x)-2
            n_T=length(x)-2;
            display(['Parameter n_T = ' num2str(n_T) '.']);
        end

        if DISPLAY,
            display('*** Calculating delay time. ***');
        end

        N=length(x);

        F=zeros(n_T,1);

        for T=1:n_T

            F_aux=0;
            for i=1:N-T
                [xnn_aux,ind] = sort(abs(x(1:N-T)-x(i)));
                %         [xnn_aux,ind] = sort(sqrt(((x(1:N-T)-x(i)).^2)+((1:N-T)'-i).^2));
                nn = ind(find(xnn_aux,1,'first'));

                aux=abs(x(i)-x(nn));
                if aux~=0, F_aux = F_aux + abs(x(i+T)-x(nn+T))/aux; end

            end
            F(T)=(1/(N-T))*F_aux;
        end

        [tau_v, tau] = localMax(F,1,'first');

        if DISPLAY,
            display(['*** Delay time = ' num2str(tau) '. ***']);
        end

        if DISPLAY,
            figure;
            hold on;
            plot(F)
            plot(tau,F(tau),'*r');
        end
    end

    function [y] = RecPhaseSpace(x,tau,ndim,DISPLAY)
        %   RECPHASESPACE Function to reconstruc the phase space of a time series
        %   segment.
        %
        %   [Y] = RECPHASESPACE(X,TAU,NDIM,DISPLAY)
        %
        %   References:
        %   [1] Phase Space Analysis for Cardiovascular Signals, S.M.Krihnan
        %
        %   Input parameters:
        %   x: segmentof the time series signal
        %   tau: optimum delay time
        %   ndim: maximum number of dimensions used to reconstruct the phase space
        %
        %   Output parameters:
        %   y: 3D matrix containing the phase space reconstruction for ndim
        %   dimensions

        if nargin<4,
            DISPLAY=0;
            if DISPLAY,
                display(['Parameter DISPLAY = ' num2str(DISPLAY) '.']);
            end
        end
        if nargin<3,
            ndim=10;
            if DISPLAY,
                display(['Parameter ndim = ' num2str(ndim) '.']);
            end
        end
        if nargin<2 || isempty(tau)==1,
            tau=CalcTimeDelay(x);  %Most suitable value when studing ECG signals is tau=7. [1]
            if DISPLAY,
                display(['Parameter tau = ' num2str(tau) '.']);
            end
        end
        if nargin==0,
            display('Parameter x is missing.');
        end
        if size(x,2)~=1
            x=x';
            display('Parameter x was transposed .');
        end
        if ndim>round(length(x)/tau),
            ndim=round(length(x)/tau);
            display(['Parameter ndim = ' num2str(ndim) '.']);
        end

        N = length(x);
        y = zeros(N,ndim,ndim);


        %Vector Reconstruction

        if DISPLAY,
            display('*** Reconstructing vector y ***');
        end

        for i=1:N
            y(i,1,1)=x(i);
            for d=2:ndim
                if (i>N-(d-1)*tau), break; end
                y(i,1:d,d) = [y(i,1:d-1,d-1) x(i+(d-1)*tau)];
                %         display([num2str(size(y(i,1:d,d)))]);
            end
        end
    end

    function [min_emb_dim,ed,y] = CalcMinEmbDimension(x,y,tau,ed_algorithm,DISPLAY)
        %   CALCMINEMBDIMENSION Function to calculate the embedding dimension based on [1].
        %
        %   [ED] = CALCMINEMBDIMENSION(X,Y,TAU,ED_ALGORITHM,DISPLAY)
        %
        %   References:
        %   [1] Pratical Method for determining the minimum embedding dimension of a
        %   scalar time series, Liangyue Cao
        %
        %   Input parameters:
        %   x: segmentof the time series signal
        %   y: 3D matrix containing the phase space reconstruction for ndim
        %   dimensions
        %   tau: time delay
        %   ed_algorithm: algorithm used to calculate the distance between a point and
        %   its neighbours. It can be "maximum_norm" or "euclidean";
        %   DISPLAY: 0 or 1 to display or not to display the delay time graphic
        %
        %   Output parameteres:
        %   min_emb_dim - minimum embedding dimension

        if nargin<5,
            DISPLAY=0;
            if DISPLAY,
                display(['Parameter DISPLAY = ' num2str(DISPLAY) '.']);
            end
        end
        if nargin<4,
            ed_algorithm='euclidean';
            if DISPLAY,
                display(['Parameter eu_algorithm = "' ed_algorithm '".']);
            end
        end
        if nargin<3 || isempty(tau)==1,
            tau=delayTime(x);
            if DISPLAY,
                display(['Parameter tau = ' num2str(tau) '.']);
            end
        end
        if nargin<2,
            y = RecPhaseSpace(x,tau);
            if DISPLAY,
                display('Parameter y has been calculated.');
            end
        end
        if nargin==0,
            display('Parameter x is missing.');
        end
        if size(x,2)~=1
            x=x';
            display('Parameter x was transposed .');
        end
        if strcmp(ed_algorithm,'maximumNorm')==0 && strcmp(ed_algorithm,'euclidean')==0,
            error('ed_algorithm must be "maximum_norm" or "euclidean"');
        end

        [ed] = CalcDistBPoints(y,tau);

        [E] = CalcFalseNeighbours(y,tau,ed);

        % [min_emb_value, min_emb_dim] = min (E);
        % min_emb_dim_aux = find(E/sum(E)<0.01,1,'first');
        % if min_emb_dim_aux<min_emb_dim, min_emb_dim=min_emb_dim_aux; end
        diff_E=abs(diff(E));
        [min_emb_value, min_emb_dim] = min (diff_E);



        if DISPLAY,
            display(['*** Minimum embeding dimension ' num2str(min_emb_dim) ' ***'])
        end

        if DISPLAY,
            figure
            hold on;
            plot(E)
            plot(min_emb_dim,min_emb_value,'*r')
            plot(diff_E,'m')
            pause;
        end
    end


    function [ed] = CalcDistBPoints(y,tau,ed_algorithm)
        %   CALCDISTBPOINTS Calculate the distance between alll points in a 3D matrix
        %
        %   [ED] = CALCDISTBPOINTS(Y,TAU,ED_ALGORITHM)
        %
        %   Input parameters:
        %   y: 3D matrix containing the phase space reconstruction
        %   tau: Tima delay
        %   ed_algorithm: Algorithm
        %
        %   Output parameters:
        %   ed: 3D matrix with distances between all points of y

        if nargin<3
            ed_algorithm = 'euclidean';
        end
        if nargin<2
            error('Parameter tau is missing.')
        end
        if nargin==0,
            display('Parameter y is missing.');
        end

        if strcmp(ed_algorithm,'maximumNorm')==0 && strcmp(ed_algorithm,'euclidean')==0,
            error('ed_algorithm must be "maximum_norm" or "euclidean"');
        end

        ndim = size(y,3);
        N=size(y,1);

        ed=zeros(N,N,ndim);

        % display('*** Calculating nearest neighbours of y ***')

        %Calc of Maximum Norm
        if strcmp(ed_algorithm,'maximum_norm')==1,

            for m=1:ndim
                a_aux=y(1:N-(m-1)*tau,1:m,m);
                for l=1:size(a_aux,1)
                    for k=l:size(a_aux,1)

                        ed(l,k,m)=maximumNorm(l,k,m,x,tau);
                        ed(k,l,m)=ed(l,k,m);
                    end
                end
                clear a_aux;
            end

        elseif strcmp(ed_algorithm,'euclidean')==1,

            for m=1:ndim
                a_aux=y(1:N-(m-1)*tau,1:m,m);

                ed(1:size(a_aux,1),1:size(a_aux,1),m)=squareform (pdist(a_aux));

                clear a_aux;
            end

        end
    end

    function [ed] = maximumNorm (l,k,m,x,tau)

        mn_aux=zeros(m,1);
        for j=0:m-1
            mn_aux(j+1,1)=abs(x(l+j*tau)-x(k+j*tau));
        end

        ed=max(mn_aux);
    end
    function [E] = CalcFalseNeighbours(y,tau,ed)
        %   CALCFALSENEIGHBOURS Calculate the false neighbours between points of y
        %
        %   [E] = CALCFALSENEIGHBOURS(Y,ED,N,TAU,NDIM)
        %
        %   Input parameters:
        %   y: 3D matrix containing the phase space reconstruction for ndim
        %   ed: 3D matrix with distances between all points of y
        %   tau: Tima delay
        %
        %   Output parameters:
        %   E:

        if nargin==2,
            [ed] = CalcDistBPoints(y,tau);
        end
        if nargin<2
            error('Parameter tau is missing.');
        end
        if nargin==0
            error('Parameter y is missing.')
        end

        N=size(y,1);
        ndim=size(y,3);

        % display('*** Calculating false neighbours ***')

        a = zeros(N-tau,ndim-1);
        n = zeros(N-tau,ndim-1);

        E=zeros(ndim-1,1);

        for d=1:ndim-1
            for i=1:N-d*tau
                [n_aux,ind]=sort(ed(i,1:N-d*tau,d));
                n(i,d)=ind(find(n_aux,1,'first'));

                %             display(['i = ' num2str(i) ', d = ' num2str(d) ', n(i,d) = ' num2str(n(i,d)) ]);
                a(i,d)=ed(i,n(i,d),d+1)/ed(i,n(i,d),d);
            end

            E(d,1)=(1/(N-d*tau))*sum(a(1:N-d*tau,d));
        end

        % LOCALMAX Function find local maximums.
        %
        % Input parameters:
        % x: time series signal
        % scale: sensitivity of the local maximums search
        % option:
        %  'first': first maximum
        %  'last': last maximum
        %  'all': all maximums
        %
        % Output parameteres:
        % lmv: localmax values
        % lmi: localmax indexes
    end

    function [lmv,lmi] = localMax(x,scale,option)

        if nargin<3,
            option='all';
            display(['Parameter option = "' option '".']);
        end
        if nargin<2,
            scale=1;
            display(['Parameter scale = ' num2str(scale) '.']);
        end
        if nargin<1
            error('time series not found.');
        end


        localmax=[];

        n_signal = length(x);

        l = 0;
        for j=scale+1:n_signal-scale
            y = x(j-scale:j+scale);
            [ymax,imax] = max(y);
            if imax == scale+1
                l = l+1;
                localmax(l,1) = j;
                localmax(l,2) = ymax;
            end
        end

        if isempty(localmax)~=1
            if (strcmp(option,'first'))
                localmax=localmax(1,:);
            elseif (strcmp(option,'last'))
                localmax=localmax(end,:);
            end
        end

        lmi = localmax(:,1);
        lmv = localmax(:,2);

    end

    % LOCALMIN Function find local minimums.
    %
    % Input parameters:
    % x: time series signal
    % scale: sensitivity of the local minimums search
    % option:
    %  'first': first minimum
    %  'last': last minimum
    %  'all': all minimums
    %
    % Output parameteres:
    % lmv: localmin values
    % lmi: localmin indexes

    function [lmv,lmi] = localMin(x,scale,option)

        if nargin<3,
            option='all';
            display(['Parameter option = "' option '".']);
        end
        if nargin<2,
            scale=1;
            display(['Parameter scale = ' num2str(scale) '.']);
        end
        if nargin<1
            error('time series not found.');
        end


        localmin=[];

        n_signal = length(x);

        l = 0;
        for j=scale+1:n_signal-scale
            y = x(j-scale:j+scale);
            [ymin,imin] = min(y);
            if imin == scale+1
                l = l+1;
                localmin(l,1) = j;
                localmin(l,2) = ymin;
            end
        end

        if isempty(localmin)~=1
            if (strcmp(option,'first'))
                localmin=localmin(1,:);
            elseif (strcmp(option,'last'))
                localmin=localmin(end,:);
            end
        end

        lmi = localmin(:,1);
        lmv = localmin(:,2);

    end


end
