classdef NonLinear_Functions < handle
    %======================================================================
    %NonLinear_Functions
    %
    %Functions for non-linear features
    %Bruno Direito
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %2008/2009
    %======================================================================
    % The following properties can be set only by class methods
    properties
        
        %         parameter_acquisition;
        %         window_size;
        
        % algorithm output
        % %         time = {};
        %         path_update=0;
        
        lyapunov_estimative = {};
        corr_dimension = {};
        
    end
    
    methods
        %Constructor
        function obj = NonLinear_Functions()
            %  Create class to process the function
            
            % update path #include opentstool toolbox
            addpath (fullfile('Toolbox', 'OpenTSTOOL'))
            settspath (fullfile('Toolbox', 'OpenTSTOOL'))
        end
        
        function obj = RunSingleSegment(obj, study, p_segment, p_samp_rate)
            v_nl = [];
            
            for s_Counter = 1:size(p_segment, 1)
                
                [lyap_r,embed_dim] = lyap_compu(p_segment(s_Counter,:));
                
                v_nl = f_AddVerElems(v_nl, [lyap_r,embed_dim]);
            end
            if study.dataset(study.dataset_selected).results.saveFileHandle_uni > 0
                fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_uni, ...
                    v_nl(:), 'double');
            else
                if ~isempty(obj.lyapunov_estimative)
                    obj.lyapunov_estimative = obj.lyapunov_estimative{1};
                end
                obj.lyapunov_estimative = f_AddHorElems(obj.lyapunov_estimative, ...
                    v_nl(:, 1));
                obj.lyapunov_estimative = {obj.lyapunov_estimative};
                
                
                if ~isempty(obj.corr_dimension)
                    obj.corr_dimension = obj.corr_dimension{1};
                end
                obj.corr_dimension = f_AddHorElems(obj.corr_dimension, ...
                    v_nl(:,2));
                obj.corr_dimension = {obj.corr_dimension};
            end
            
            function [lyap_r,corr_dim] = lyap_compu(p_segment)
                
                t = ((p_segment + abs(min(p_segment))))/max(p_segment + abs(min(p_segment)));
                
                s = signal(t');
                
                %% obtain automutual information | time delay of the atractor reconstruction
                a = amutual (s,32,32); %amutual(signal, maxtau, bins) | maxtau = 32 and number of bins 128
                % view (a)
                
                try
                    % first minimum from ammutual information
                    firstmin_amutual =  round(firstmin(a));
                catch
                    %                     figure, view(s)
                    firstmin_amutual = 10;
                end
                
                %% Cao's algorithm (embedding dimension)
                max_dim = 8;
                c = cao (s,max_dim,firstmin_amutual,5,-1); %cao(signal, maxdim, tau, NNR, Nref)
                % | maxdim accepted = 10 | tau = first minimum of amutual information
                % method |NNR = number of nearest neighbors = 5
                
                % derivative of cao's method plot (if under 0.1 => x = embedding dimension)
                embed_dim = diff(data(c),1);
                embed_dim = reverse(signal(embed_dim));
                offset = 0.1;
                embed_dim = minus (embed_dim,offset); %returns the 'kink in the cao's graph'
                
                %Define embbeding dimension according to Cao's method
                if ((min(embed_dim)<0) && (max(embed_dim)>0))
                    f_zero = round(firstzero(embed_dim));
                    embed_dim = (max_dim-f_zero);
                else
                    f_zero = max_dim;
                    embed_dim = 6;
                end
                
                
                
                %% e = embbeded time series | attractor
                %                 embed_dim
                
                e = embed (s,embed_dim,firstmin_amutual); %embed(signal,
                % dimension, delay|tau, windowtype)
                
                %% Lyapunov exponent
                l = largelyap(e,-1,10,10,5); %largelyap (signal, number of reference points,
                % stepsahead, past | number of poiunts excluded in same trajectory, nnr | number of nearest points)
                
                
                corr_dim= takens_estimator (e,-1,0.05,40);%Compute correlation dimension
                
                
                
                % largest lyapunov exponent | slope of linear segment of the largelyap plot
                [x_l y_l] = size (data(l));
                
                counter = 0;
                lyap_data = data (l);
                
                error_time = 10;
                
                for j = 2:x_l
                    if (lyap_data(j) - lyap_data(j-1) < 0.05)
                        counter = counter + 1;
                    else
                        counter = 0;
                    end
                    
                    if (counter == 3)
                        error_time = j;
                        break;
                    end
                end
                
                %  l = slope of the linear section
                lyap_r = lyap_data (error_time)/error_time;
                
            end
            
        end;
        
        
        
        
        
    end
    
    methods (Access = public)
        [output1 output2] = CalcLyapExponent (obj, eeg_segment);
    end
    
    
end
