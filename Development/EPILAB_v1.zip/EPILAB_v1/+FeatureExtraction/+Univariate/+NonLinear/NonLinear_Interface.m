classdef NonLinear_Interface < handle
    %======================================================================
    %NonLinear_Interface
    %
    %Interface to non-linear features
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    properties
        
        nl_i;
        
        nl_f;
        nl_d;
        
        % data
        study;
        
        acq_window;
        acq_step;
    end
    
    methods
        %Constructor
        function obj = NonLinear_Interface(study)
            %  Create and then hide the GUI as it is being constructed.
            obj.study = study;
            
            obj.nl_f = FeatureExtraction.Univariate.NonLinear.NonLinear_Functions();
            obj.nl_d = FeatureExtraction.Univariate.NonLinear.NonLinear_Data();
            
            obj.acq_window = 5;
            obj.acq_step = obj.acq_window;
        end
    end
    
    methods(Static)
        %Draw the panel and its contents
        function draw(obj,panel)
            
            
            % display new panel
            obj.nl_i.ModulesPanel = uipanel('Parent', panel, 'Title', 'Non Linear Features extraction' ,'Units','Normalized','Position', [0.05 0.05 0.9 0.9]);
            
            obj.nl_i.nonlinearInfoText = uicontrol('Parent', obj.nl_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.85 0.75 0.05],...
                'String','Maximum Lyapunov Exponent and embedding dimension (According to Cao Algorithm) '); % Text information about algorithm and acquired features
            
            obj.nl_i.AcquisitionIntervalEdit = uicontrol('Parent',obj.nl_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.7 0.2 0.05],...
                'String',num2str(obj.acq_window)); % Edit box for acquisition interval
            obj.nl_i.AcquisitionIntervalText = uicontrol('Parent', obj.nl_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.7 0.45 0.05],...
                'String','Feature computation - acquisition interval (seconds)'); % Text for acquisition interval
            
            obj.nl_i.OverlapEdit = uicontrol('Parent',obj.nl_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.5 0.2 0.05],...
                'String',num2str(obj.acq_step)); % Edit box for window size
            obj.nl_i.OverlapText = uicontrol('Parent', obj.nl_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.5 0.45 0.05],...
                'String','Feature extraction window length (seconds)'); % Text for window size
            
            
            
            obj.nl_i.CancelButton = uicontrol('Parent', obj.nl_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.55 0.05 0.1 0.05],...
                'String','Cancel','Callback', {@CancelButtonCallback, obj}); % Button for cancel
            obj.nl_i.HelpButton = uicontrol('Parent', obj.nl_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.70 0.05 0.1 0.05],...
                'String','Help','Enable', 'off','Callback', @HelpButtonCallback); % Button for help
            obj.nl_i.OkButton = uicontrol('Parent', obj.nl_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.85 0.05 0.1 0.05],...
                'String','Ok','Callback', {@OkButtonCallback, obj, obj.study}); % Button for ok
            
            
            function OkButtonCallback (hObject, eventdata, obj, study)
                
                if ~isempty(get(obj.nl_i.AcquisitionIntervalEdit, 'String'))
                    obj.acq_window = str2num(get(obj.nl_i.AcquisitionIntervalEdit, 'String'));
                end
                
                if ~isempty(get(obj.nl_i.OverlapEdit, 'String'))
                    obj.acq_step = str2num(get(obj.nl_i.OverlapEdit, 'String'));
                end
                
                close(gcf);
                
                
            end
            
            function CancelButtonCallback (hObject, eventdata, obj)
                obj.clear (obj.nl_i);
                close(gcf);
            end
            
            
        end
        
        %Clear the panel and its contents
        
        function ClearChildClasses(obj)
            delete(obj.nl_f);
            clear obj.nl_f
            delete(obj.nl_d);
            clear obj.nl_d
            obj.nl_f = FeatureExtraction.Univariate.NonLinear.NonLinear_Functions();
            obj.nl_d = FeatureExtraction.Univariate.NonLinear.NonLinear_Data();
        end
        
        function RunSingleSegment(obj, study, p_segment, p_samp_rate)
            obj.nl_f.RunSingleSegment(study, p_segment, p_samp_rate);
        end
        
        function SaveResults(obj, study)
            obj.nl_d.SaveData(study, obj.nl_f);
        end
        
        function clear(C)
            delete(C.ModulesPanel);
        end
    end
    
end

