classdef RelPow_Data < handle
    %======================================================================
    %RelPow_Data
    %
    %Data related to Relative Power features
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    properties
        
        parameter_acquisition;
        overlap;
        
        ps_ARMethod_results;
        
        % algorithm output
        time;
        
        c_ = struct([]);
    end
    
    methods
        % constructor
        function obj = RelPow_Data()
            
        end
        
        function study = SaveData(obj, study, results)
            
            for x=1:length(study.dataset_selected)
                
                selected_chans = study.dataset(study.dataset_selected(x)).results.chansSelected;
                chans_ind = study.dataset(study.dataset_selected(x)).results.EEGchansSelectedInd;
                chans_ind = reshape(chans_ind, 1, []);
                dataset = study.dataset_selected(x);
                for k = 1:length(chans_ind)
                    if length(results.delta_results) >= dataset
                        eval(['obj.c_(1).delta_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).delta_channel_' selected_chans{chans_ind(k)} ' = results.delta_results{dataset}(k,:);']);
                        
                        eval(['obj.c_(1).theta_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).theta_channel_' selected_chans{chans_ind(k)} ' = results.theta_results{dataset}(k,:);']);
                        
                        eval(['obj.c_(1).alpha_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).alpha_channel_' selected_chans{chans_ind(k)} ' = results.alpha_results{dataset}(k,:);']);
                        
                        eval(['obj.c_(1).beta_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).beta_channel_' selected_chans{chans_ind(k)} ' = results.beta_results{dataset}(k,:);']);
                        
                        eval(['obj.c_(1).gamma_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).gamma_channel_' selected_chans{chans_ind(k)} ' = results.gamma_results{dataset}(k,:);']);
                        
                        
                        
                        if isfield(study.dataset(study.dataset_selected(x)).results.featureExtractionMethods,'RelPow')
                            ss=study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.RelPow.c_;
                            
                            ss.(['delta_channel_' selected_chans{chans_ind(k)}])=results.delta_results{dataset}(k,:);
                            
                            ss.(['theta_channel_' selected_chans{chans_ind(k)}])=results.theta_results{dataset}(k,:);
                            
                            ss.(['alpha_channel_' selected_chans{chans_ind(k)}])=results.alpha_results{dataset}(k,:);
                            
                            ss.(['beta_channel_' selected_chans{chans_ind(k)}])=results.beta_results{dataset}(k,:);
                            
                            ss.(['gamma_channel_' selected_chans{chans_ind(k)}])=results.gamma_results{dataset}(k,:);
                            
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.RelPow.c_=ss;
                        else
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.('RelPow').('c_').(['delta_channel_' selected_chans{chans_ind(k)}])=results.delta_results{dataset}(k,:);
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.('RelPow').('c_').(['theta_channel_' selected_chans{chans_ind(k)}])=results.theta_results{dataset}(k,:);
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.('RelPow').('c_').(['alpha_channel_' selected_chans{chans_ind(k)}])=results.alpha_results{dataset}(k,:);
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.('RelPow').('c_').(['beta_channel_' selected_chans{chans_ind(k)}])=results.beta_results{dataset}(k,:);
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.('RelPow').('c_').(['gamma_channel_' selected_chans{chans_ind(k)}])=results.gamma_results{dataset}(k,:);
                        end
                    end
                    
                    if k > 1
                        continue;
                    end
                    
                    study.dataset(study.dataset_selected(x)).results.featureNames = ...
                        strcat(study.dataset(study.dataset_selected(x)).results.featureNames, ...
                        'RelPowDelta,RelPowTheta,RelPowAlpha,RelPowBeta,RelPowGamma,');
                end
                
                obj.parameter_acquisition = results.parameter_acquisition;
                obj.time = results.time;
                obj.ps_ARMethod_results = results.ps_ARMethod_results;
                %study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.RelPow = obj;
                
                obj = FeatureExtraction.Univariate.RelPow.RelPow_Data();
            end
        end
    end
end
