classdef RelPow_Functions < handle
    %======================================================================
    %RelPow_Functions
    %
    %Functions for Relative Power features
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    properties
        
        parameter_acquisition;
        overlap;
        
        % algorithm output
        time;
        delta_results = {};
        theta_results = {};
        alpha_results = {};
        beta_results = {};
        gamma_results = {};
        ps_ARMethod_results = 0;
        
    end
    
    methods
        
        %Constructor
        function obj = RelPow_Functions()
            
        end
        
        function obj = RunSingleSegment(obj, study, p_segment, p_samp_rate, ARMethod)
            v_FreqBandsHz =  [0.1 4;4 8;8 15;15 30;30 round(p_samp_rate / 2)];
            
            v_RelPow = [];
            for s_Counter = 1:size(p_segment, 1)
                v_RelPowTemp = obj.RelPow(p_segment(s_Counter, :), p_samp_rate, ...
                    v_FreqBandsHz, ARMethod);
                v_RelPow = f_AddVerElems(v_RelPow, v_RelPowTemp');
            end
            if study.dataset(study.dataset_selected).results.saveFileHandle_uni > 0
                fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_uni, ...
                    v_RelPow(:), 'double');
            else
                if ~isempty(obj.delta_results)
                    obj.delta_results = obj.delta_results{1};
                end
                obj.delta_results = f_AddHorElems(obj.delta_results, ...
                    v_RelPow(:, 1));
                obj.delta_results = {obj.delta_results};
                
                if ~isempty(obj.theta_results)
                    obj.theta_results = obj.theta_results{1};
                end
                obj.theta_results = f_AddHorElems(obj.theta_results, ...
                    v_RelPow(:, 2));
                obj.theta_results = {obj.theta_results};
                
                if ~isempty(obj.alpha_results)
                    obj.alpha_results = obj.alpha_results{1};
                end
                obj.alpha_results = f_AddHorElems(obj.alpha_results, ...
                    v_RelPow(:, 3));
                obj.alpha_results = {obj.alpha_results};
                
                if ~isempty(obj.beta_results)
                    obj.beta_results = obj.beta_results{1};
                end
                obj.beta_results = f_AddHorElems(obj.beta_results, ...
                    v_RelPow(:, 4));
                obj.beta_results = {obj.beta_results};
                
                if ~isempty(obj.gamma_results)
                    obj.gamma_results = obj.gamma_results{1};
                end
                obj.gamma_results = f_AddHorElems(obj.gamma_results, ...
                    v_RelPow(:, 5));
                obj.gamma_results = {obj.gamma_results};
            end
        end;
        
        
        function [v_RelPow v_PowSpec v_Freq] = ...
                RelPow(obj,...
                pv_Sig, ...
                ps_SamRate, ...
                pm_FreqRanges, ...
                ps_ARMethod)
            %
            % Function: f_RelPow.m
            %
            % Description:
            % This function computes the relative power of particular spectral bands
            % for the input signal.
            %
            % Inputs:
            % pv_Sig: input signal
            % ps_SamRate: sample rate in Hz
            % pm_FreqRangesHz: nx2 matrix containing the ranges of desired frequency
            % bands to compute the relative power. n  is the number of frequency bands.
            % Example: [0.1 4;4 8], computes the relative power for bands between 0.1
            % to 4 Hz and between 4 and 8 Hz
            % ps_ARMethod (optional): set to 1 to compute the power spectral density
            % via an AR (Autoregressive) model estimator. Default: 0 (FFT squared
            % modulus estimator)
            %
            % Outputs:
            % v_RelPow: array of length n containing the relative power for each
            % frequency band
            % v_PowSpec: array containing the power spectrum for frequencies from 0 to
            % the half of the sample rate
            % v_Freq: array containing the frequency values from 0 to the half of the
            % sample rate
            %
            % MATLAB Version: R2007b
            %
            % Team: LENA
            % Author: Mario Valderrama
            %
            
            [v_RelPow v_PowSpec v_Freq] = f_RelPow(pv_Sig, ps_SamRate, pm_FreqRanges, ps_ARMethod);
        end
    end
    
       
    
end
