classdef RelPow_Interface < handle
%======================================================================
%RelPow_Interface
%
%Interface to Relative Power features
%
%EU FP7 Grant 211713 (EPILEPSIAE)
%
%======================================================================
    
    properties
        ARMethod;
        par_acquisition;

        study;

        rp_i;
        rp_f;
        rp_d;
        
        acq_window;
        acq_step;        
    end
    
    methods
      %Constructor
      function obj = RelPow_Interface(study)
         %  Create and then hide the GUI as it is being constructed.
         obj.study = study;
         
         obj.rp_f = FeatureExtraction.Univariate.RelPow.RelPow_Functions();
         obj.rp_d = FeatureExtraction.Univariate.RelPow.RelPow_Data();
         
         obj.ARMethod = 1;
         obj.acq_window = 5;
         obj.acq_step = obj.acq_window;         
      end
    end

    methods(Static)
      %Draw the panel and its contents
      function draw(obj,panel)
    
          % display new panel
          obj.rp_i.ModulesPanel = uipanel('Parent', panel, 'Title', 'Relative Power' ,'Units','Normalized','Position', [0.05 0.05 0.9 0.9]);
          
          obj.rp_i.ARMethodText = uicontrol('Parent', obj.rp_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.60 0.3 0.15],...
              'String','AR Method'); 
          obj.rp_i.ARMethodCheckbox = uicontrol('Parent',obj.rp_i.ModulesPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.60 0.2 0.15],...
              'value',1,'enable','on');           
          obj.rp_i.CancelButton = uicontrol('Parent', obj.rp_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.55 0.05 0.1 0.15],...
              'String','Cancel','Callback', {@CancelButtonCallback, obj}); % Button for cancel
          obj.rp_i.HelpButton = uicontrol('Parent', obj.rp_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.70 0.05 0.1 0.15],...
              'String','Help','Callback', @HelpButtonCallback); % Button for help
          obj.rp_i.OkButton = uicontrol('Parent', obj.rp_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.85 0.05 0.1 0.15],...
              'String','Ok','Callback', {@OkButtonCallback, obj, obj.study}); % Button for ok
      
          function OkButtonCallback (hObject, eventdata, obj, study)
                            
              obj.ARMethod = get(obj.rp_i.ARMethodCheckbox, 'value');
              
              close(gcf);
          end
          function CancelButtonCallback (hObject, eventdata, obj)
              close(gcf);
              return;              
              obj.clear (obj.rp_i);
          end
      end
      
      function ClearChildClasses(obj)
          delete(obj.rp_f);
          clear obj.rp_f
          delete(obj.rp_d);
          clear obj.rp_d
          obj.rp_f = FeatureExtraction.Univariate.RelPow.RelPow_Functions();
          obj.rp_d = FeatureExtraction.Univariate.RelPow.RelPow_Data();
      end      
      
      function RunSingleSegment(obj, study, p_segment, p_samp_rate)
          obj.rp_f.RunSingleSegment(study, p_segment, p_samp_rate, obj.ARMethod);
      end

      function SaveResults(obj, study)
          obj.rp_d.SaveData(study, obj.rp_f);
      end          

      %Clear the panel and its contents
      function clear(C)
          delete(C.ModulesPanel);
      end
    end
end


