classdef SpectrEdge_Data < handle
    %======================================================================
    %SpectrEdge_Data
    %Data related to Spectral Edge feature extraction
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    % The following properties can be set as public
    properties
        
        parameter_acquisition;
        overlap;
        
        FreqRef;
        Per;
        MinFreq;
        ARMethod;
        
        
        % algorithm output
        time;
        
        c_ = struct([]);
    end
    
    methods
        % constructor
        function obj = SpectrEdge_Data()
            
        end
        
        function study = SaveData(obj, study, results)
            
            for x=1:length(study.dataset_selected)
                
                selected_chans = study.dataset(study.dataset_selected(x)).results.chansSelected;
                chans_ind = study.dataset(study.dataset_selected(x)).results.EEGchansSelectedInd;
                chans_ind = reshape(chans_ind, 1, []);
                dataset = study.dataset_selected(x);
                for k = 1:length(chans_ind)
                    if length(results.SEF_results) >= dataset
                        eval(['obj.c_(1).SpectrEdgeFreq_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).SpectrEdgeFreq_channel_' selected_chans{chans_ind(k)} ' = results.SEF_results{dataset}(k,:);']);
                        
                        eval(['obj.c_(1).SpectrEdgePow_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).SpectrEdgePow_channel_' selected_chans{chans_ind(k)} ' = results.EdgePow_results{dataset}(k,:);']);
                        
                        if isfield(study.dataset(study.dataset_selected(x)).results.featureExtractionMethods,'SpectrEdge_Data')
                            ss=study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.SpectrEdge_Data.c_;
                            
                            ss.(['SpectrEdgeFreq_channel_' selected_chans{chans_ind(k)}])=results.SEF_results{dataset}(k,:);
                            
                            ss.(['SpectrEdgePow_channel_' selected_chans{chans_ind(k)}])=results.EdgePow_results{dataset}(k,:);
                            
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.SpectrEdge_Data.c_=ss;
                        else
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.('SpectrEdge_Data').('c_').(['SpectrEdgeFreq_channel_' selected_chans{chans_ind(k)}])=results.SEF_results{dataset}(k,:);
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.('SpectrEdge_Data').('c_').(['SpectrEdgePow_channel_' selected_chans{chans_ind(k)}])=results.EdgePow_results{dataset}(k,:);
                        end
                    end
                    
                    if k > 1
                        continue;
                    end
                    
                    study.dataset(study.dataset_selected(x)).results.featureNames = ...
                        strcat(study.dataset(study.dataset_selected(x)).results.featureNames, ...
                        'SpectrEdgeFreq,SpectrEdgePow,');
                end
            end
            
            obj.parameter_acquisition = results.parameter_acquisition;
            obj.time = results.time;
            %study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.SpectrEdge_Data = obj;
            
            obj = FeatureExtraction.Univariate.SpectrEdge.SpectrEdge_Data();
        end
        
    end
    
end
