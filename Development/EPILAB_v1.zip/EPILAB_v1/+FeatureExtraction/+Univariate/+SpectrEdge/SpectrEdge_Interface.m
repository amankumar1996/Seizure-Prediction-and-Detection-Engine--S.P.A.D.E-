classdef SpectrEdge_Interface < handle
%======================================================================
%SpectrEdge_Interface
%
%Interface to Spectral Edge features
%
%EU FP7 Grant 211713 (EPILEPSIAE)
%
%======================================================================
    properties

        ARMethod;
        par_acquisition;

        study;

        se_i;
        se_f;
        se_d;

        acq_window;
        acq_step;
        freq_ref;
        pow_per;
        min_freq;
    end
    
    methods
      %Constructor
      function obj = SpectrEdge_Interface(study)
         %  Create and then hide the GUI as it is being constructed.
         obj.study = study;
         
         obj.se_f = FeatureExtraction.Univariate.SpectrEdge.SpectrEdge_Functions();
         obj.se_d = FeatureExtraction.Univariate.SpectrEdge.SpectrEdge_Data();
         
         obj.ARMethod = 1;
         obj.acq_window = 5;
         obj.acq_step = obj.acq_window;   
         obj.freq_ref = 20;
         obj.pow_per = 50;
         obj.min_freq = 0.1;
      end
    end
    
    methods(Static)
      %Draw the panel and its contents
      function draw(obj,panel)
          
          
          % display new panel
          obj.se_i.ModulesPanel = uipanel('Parent', panel, 'Title', 'Spectral Edge features' ,'Units','Normalized','Position', [0.05 0.05 0.9 0.9]);

          
          obj.se_i.FreqRefText = uicontrol('Parent', obj.se_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.60 0.3 0.15],...
              'String','Freq Ref'); 
          obj.se_i.FreqRefEdit = uicontrol('Parent',obj.se_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.60 0.35 0.15],...
              'String',num2str(obj.freq_ref),'enable','on'); 
          
          obj.se_i.PerText = uicontrol('Parent', obj.se_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.50 0.3 0.15],...
              'String','Percentage'); 
          obj.se_i.PerEdit = uicontrol('Parent',obj.se_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.50 0.35 0.15],...
              'String',num2str(obj.pow_per),'enable','on'); 
          
          obj.se_i.MinFreqText = uicontrol('Parent', obj.se_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.40 0.3 0.15],...
              'String','Min Freq'); 
          obj.se_i.MinFreqEdit = uicontrol('Parent',obj.se_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.40 0.35 0.15],...
              'String',num2str(obj.min_freq),'enable','on'); 
          
          obj.se_i.ARMethodText = uicontrol('Parent', obj.se_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.30 0.3 0.15],...
              'String','AR method'); 
          obj.se_i.ARMethodCheckbox = uicontrol('Parent',obj.se_i.ModulesPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.30 0.2 0.15],...
               'value',1,'enable','on'); 
           
          obj.se_i.CancelButton = uicontrol('Parent', obj.se_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.55 0.05 0.1 0.15],...
              'String','Cancel','Callback', {@CancelButtonCallback, obj}); % Button for cancel
          obj.se_i.HelpButton = uicontrol('Parent', obj.se_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.70 0.05 0.1 0.15],...
              'String','Help','Callback', @HelpButtonCallback); % Button for help
          obj.se_i.OkButton = uicontrol('Parent', obj.se_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.85 0.05 0.1 0.15],...
              'String','Ok','Callback', {@OkButtonCallback, obj, obj.study}); % Button for ok
      
          function OkButtonCallback (hObject, eventdata, obj, study)
              

              
              if ~isempty(get(obj.se_i.FreqRefEdit, 'String'))
                  obj.freq_ref = str2num(get(obj.se_i.FreqRefEdit, 'String'));
              end  
              
              if ~isempty(get(obj.se_i.PerEdit, 'String'))
                  obj.pow_per = str2num(get(obj.se_i.PerEdit, 'String'));
              end  
              
              if ~isempty(get(obj.se_i.MinFreqEdit, 'String'))
                  obj.min_freq = str2num(get(obj.se_i.MinFreqEdit, 'String'));
              end                
              
              obj.ARMethod = get(obj.se_i.ARMethodCheckbox, 'value');
              
              close(gcf);
          end
          
          function CancelButtonCallback (hObject, eventdata, obj)
              close(gcf);
              return;              
              obj.clear (obj.se_i);
          end
      end
      
      function ClearChildClasses(obj)
          delete(obj.se_f);
          clear obj.se_f
          delete(obj.se_d);
          clear obj.se_d
          obj.se_f = FeatureExtraction.Univariate.SpectrEdge.SpectrEdge_Functions();
          obj.se_d = FeatureExtraction.Univariate.SpectrEdge.SpectrEdge_Data();
      end      
      
      function RunSingleSegment(obj, study, p_segment, p_samp_rate)
          obj.se_f.RunSingleSegment(study, p_segment, p_samp_rate, ...
              obj.freq_ref, obj.pow_per, obj.min_freq, obj.ARMethod);
      end

      function SaveResults(obj, study)
          obj.se_d.SaveData(study, obj.se_f);
      end          

      %Clear the panel and its contents
      function clear(C)
          delete(C.ModulesPanel);
      end
    end
end
