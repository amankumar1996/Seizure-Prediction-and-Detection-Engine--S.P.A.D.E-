

classdef Statistic_Data < handle
    %======================================================================
    %Statistic_Data
    %Data related to Statistic feature extraction
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
    
    % The following properties can be set as public
    properties
        parameter_acquisition;
        
        % algorithm output
        time;
        
        c_ = struct([]);
        
    end
    
    methods
        % constructor
        function obj = Statistics_Data()
            
        end
        
        function study = SaveData(obj, study, results)
            
            for x=1:length(study.dataset_selected)
                
                selected_chans = study.dataset(study.dataset_selected(x)).results.chansSelected;
                chans_ind = study.dataset(study.dataset_selected(x)).results.EEGchansSelectedInd;
                chans_ind = reshape(chans_ind, 1, []);
                dataset = study.dataset_selected(x);
                for k = 1:length(chans_ind)
                    
                    if length(results.mean_value) >= dataset
                        eval(['obj.c_(1).mean_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).mean_channel_' selected_chans{chans_ind(k)} ' = results.mean_value{dataset}(k,:);']);
                        
                        eval(['obj.c_(1).variance_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).variance_channel_' selected_chans{chans_ind(k)} ' = results.variance_value{dataset}(k,:);']);
                        
                        eval(['obj.c_(1).skewness_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).skewness_channel_' selected_chans{chans_ind(k)} ' = results.skewness_value{dataset}(k,:);']);
                        
                        eval(['obj.c_(1).kurt_channel_'  selected_chans{chans_ind(k)}  '=[];']);
                        eval(['obj.c_(1).kurt_channel_' selected_chans{chans_ind(k)} ' = results.kurt_value{dataset}(k,:);']);
                        
                        
                        
                        if isfield(study.dataset(study.dataset_selected(x)).results.featureExtractionMethods,'Statistic')
                            ss=study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.Statistic.c_;
                            
                            ss.(['mean_channel_' selected_chans{chans_ind(k)}])=results.mean_value{dataset}(k,:);
                            
                            ss.(['variance_channel_' selected_chans{chans_ind(k)}])=results.variance_value{dataset}(k,:);
                            
                            ss.(['skewness_channel_' selected_chans{chans_ind(k)}])=results.skewness_value{dataset}(k,:);
                            
                            ss.(['kurt_channel_' selected_chans{chans_ind(k)}])=results.kurt_value{dataset}(k,:);
                            
                            
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.Statistic.c_=ss;
                        else
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.('Statistic').('c_').(['mean_channel_' selected_chans{chans_ind(k)}])=results.mean_value{dataset}(k,:);
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.('Statistic').('c_').(['variance_channel_' selected_chans{chans_ind(k)}])=results.variance_value{dataset}(k,:);
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.('Statistic').('c_').(['skewness_channel_' selected_chans{chans_ind(k)}])=results.skewness_value{dataset}(k,:);
                            study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.('Statistic').('c_').(['kurt_channel_' selected_chans{chans_ind(k)}])=results.kurt_value{dataset}(k,:);
                        end
                    end
                    
                    if k > 1
                        continue;
                    end
                    
                    study.dataset(study.dataset_selected(x)).results.featureNames = ...
                        strcat(study.dataset(study.dataset_selected(x)).results.featureNames, ...
                        'Mean,Variance,Skewness,Kurtosis,');
                end
                
                obj.parameter_acquisition = results.parameter_acquisition;
                obj.time = results.time;
                %study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.Statistic = obj;
                obj = FeatureExtraction.Univariate.Statistic.Statistic_Data();
            end
            
        end
    end
end