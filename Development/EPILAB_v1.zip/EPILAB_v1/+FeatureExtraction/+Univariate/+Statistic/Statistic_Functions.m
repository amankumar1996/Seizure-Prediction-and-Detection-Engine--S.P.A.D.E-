classdef Statistic_Functions < handle
%======================================================================
%Statistic_Functions
%
%Functions to Statistics features
%
%EU FP7 Grant 211713 (EPILEPSIAE)
%
%Bruno Direito/Rui Costa
%CISUC, FCTUC, University of Coimbra
%2008/2009
%======================================================================
    properties

        parameter_acquisition;

        % algorithm output
        time;
        mean_value = {};
        variance_value = {};
        skewness_value = {};
        kurt_value = {};
    end

    methods

        %Constructor
        function obj = Statistic_Functions()
            obj.time = [];
        end
        
        function obj = RunSingleSegment(obj, study, p_segment)
            v_stats = [];
            for s_Counter = 1:size(p_segment, 1)
                 v_stats = f_AddVerElems(v_stats, [mean(p_segment(s_Counter, :)) ...
                     var(p_segment(s_Counter, :)) skewness(p_segment(s_Counter, :)) ...
                     kurtosis(p_segment(s_Counter, :))]);
            end
            if study.dataset(study.dataset_selected).results.saveFileHandle_uni > 0
                fwrite(study.dataset(study.dataset_selected).results.saveFileHandle_uni, ...
                    v_stats(:), 'double');
            else
                if ~isempty(obj.mean_value)
                    obj.mean_value = obj.mean_value{1};
                end
                obj.mean_value = f_AddHorElems(obj.mean_value, ...
                    v_stats(:, 1));
                obj.mean_value = {obj.mean_value};

                if ~isempty(obj.variance_value)
                    obj.variance_value = obj.variance_value{1};
                end
                obj.variance_value = f_AddHorElems(obj.variance_value, ...
                    v_stats(:, 2));
                obj.variance_value = {obj.variance_value};

                if ~isempty(obj.skewness_value)
                    obj.skewness_value = obj.skewness_value{1};
                end
                obj.skewness_value = f_AddHorElems(obj.skewness_value, ...
                    v_stats(:, 3));
                obj.skewness_value = {obj.skewness_value};

                if ~isempty(obj.kurt_value)
                    obj.kurt_value = obj.kurt_value{1};
                end
                obj.kurt_value = f_AddHorElems(obj.kurt_value, ...
                    v_stats(:, 4));
                obj.kurt_value = {obj.kurt_value};
            end
        end;           
    end
end
