classdef Statistic_Interface < handle
%======================================================================
%Statistic_Interface
%
%Interface to Statistics features
%
%EU FP7 Grant 211713 (EPILEPSIAE)
%
%Bruno Direito/Rui Costa
%CISUC, FCTUC, University of Coimbra
%2008/2009
%======================================================================
   properties
       s_i;

       s_d;
       s_f;

       % data
       study;

       acq_window;
       acq_step;
   end
    
   methods
      %Constructor
      function obj = Statistic_Interface(study)
         %  Create and then hide the GUI as it is being constructed.
         obj.study = study;
         
         obj.s_f = FeatureExtraction.Univariate.Statistic.Statistic_Functions();
         obj.s_d = FeatureExtraction.Univariate.Statistic.Statistic_Data();
         
         obj.acq_window = 5;
         obj.acq_step = obj.acq_window;         
      end
   end
   
   methods(Static)
      %Draw the panel and its contents
      function draw(obj,panel)
          
          
          % display new panel
          obj.s_i.ModulesPanel = uipanel('Parent', panel, 'Title', 'Segment statistics features' ,'Units','Normalized','Position', [0.05 0.05 0.9 0.9]);

          obj.s_i.AcquisitionIntervalEdit = uicontrol('Parent',obj.s_i.ModulesPanel,'style','edit','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.8 0.2 0.05],...
              'String',num2str(obj.acq_window));
          obj.s_i.AcquisitionIntervalText = uicontrol('Parent', obj.s_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.8 0.5 0.05],...
              'String','Feature computation - acquisition interval (seconds)'); 


          obj.s_i.MeanText = uicontrol('Parent', obj.s_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.65 0.3 0.05],...
              'String','Segment mean value'); 
          obj.s_i.MeanCheckbox = uicontrol('Parent',obj.s_i.ModulesPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.65 0.2 0.05],...
              'value',1,'enable','off'); 
          
          obj.s_i.VarianceText = uicontrol('Parent', obj.s_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.55 0.3 0.05],...
              'String','Segment variance value'); 
          obj.s_i.VarianceCheckbox = uicontrol('Parent',obj.s_i.ModulesPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.55 0.2 0.05],...
              'value', 1, 'enable','off'); 
          

          obj.s_i.SkewnessText = uicontrol('Parent', obj.s_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.45 0.3 0.05],...
              'String','Segment skewness value'); 
          obj.s_i.SkewnessCheckbox = uicontrol('Parent',obj.s_i.ModulesPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.45 0.1 0.05],...
              'value', 1, 'enable', 'off'); 
          
        
          obj.s_i.KurtosisText = uicontrol('Parent', obj.s_i.ModulesPanel,'style','text','HandleVisibility','callback','Units','Normalized', 'Position',[0.05 0.35 0.3 0.05],...
              'String','Segment kurtosis value');
          obj.s_i.KurtosisCheckbox = uicontrol('Parent',obj.s_i.ModulesPanel,'style','checkbox','HandleVisibility','callback','Units','Normalized', 'Position',[0.6 0.35 0.1 0.05],...
              'value', 1, 'enable', 'off');
          

          obj.s_i.CancelButton = uicontrol('Parent', obj.s_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.55 0.05 0.1 0.05],...
              'String','Cancel','Callback', {@CancelButtonCallback, obj}); % Button for cancel
          obj.s_i.HelpButton = uicontrol('Parent', obj.s_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.70 0.05 0.1 0.05],...
              'String','Help','Callback', @HelpButtonCallback); % Button for help
          obj.s_i.OkButton = uicontrol('Parent', obj.s_i.ModulesPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.85 0.05 0.1 0.05],...
              'String','Ok','Callback', {@OkButtonCallback, obj, obj.study}); % Button for ok
      
          function OkButtonCallback (hObject, eventdata, obj, study)
              
              if ~isempty(get(obj.s_i.AcquisitionIntervalEdit, 'String'))
                  obj.acq_window = str2num(get(obj.s_i.AcquisitionIntervalEdit, 'String'));
              end
              
              close(gcf);
          end
          
          function CancelButtonCallback (hObject, eventdata, obj)
              obj.clear(obj.s_i);
              close(gcf);
          end
      end
      
      function ClearChildClasses(obj)
          delete(obj.s_f);
          clear obj.s_f
          delete(obj.s_d);
          clear obj.s_d
          obj.s_f = FeatureExtraction.Univariate.Statistic.Statistic_Functions();
          obj.s_d = FeatureExtraction.Univariate.Statistic.Statistic_Data();
      end      
      
      function RunSingleSegment(obj, study, p_segment, p_samp_rate)
          obj.s_f.RunSingleSegment(study, p_segment);
      end

      function SaveResults(obj, study)
          obj.s_d.SaveData(study, obj.s_f);
      end        

      %Clear the panel and its contents
      function clear(C)
        delete(C.ModulesPanel);
      end
    end
end