classdef WaveletCoefficientEnergy_Data < handle
    %======================================================================
    %WaveletCoefficientEnergy_Data
    %
    %Data for Wavelet Coef. Extraction
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %Bruno Direito
    %CISUC, FCTUC, University of Coimbra
    %2008/2009
    %======================================================================
    properties
        % Feature extraction method parameters
        parameter_acquisition;
        mother_wavelet;
        decomposition_level;
        short_term_window;
        long_term_window;
        
        % wavelet coefficients extracted
        wavelet_coefficients;
        
        % algorithm output
        time;
        
        c_ = struct([]);
    end
    
    methods
        % constructor
        function obj = WaveletCoefficientEnergy_Data()
            
        end
        
        function study = SaveData(obj, study, results)
            
            
            obj.mother_wavelet = results.mother_wavelet;
            obj.decomposition_level = results.decomposition_level;
            
            
            for x=1:length(study.dataset_selected)
                
                selected_chans = study.dataset(study.dataset_selected(x)).results.chansSelected;
                chans_ind = study.dataset(study.dataset_selected(x)).results.EEGchansSelectedInd;
                chans_ind = reshape(chans_ind, 1, []);
                dataset = study.dataset_selected(x);
                for k = 1:length(chans_ind)
                    if length(results.wav_coef_results) >= dataset
                        clear v_wav
                        v_wav = cell2mat(results.wav_coef_results{dataset});
                        v_wav = v_wav(k, :);
                        v_wav = reshape(v_wav, obj.decomposition_level, []);
                        for b = 1:obj.decomposition_level
                            eval(['obj.c_(1).wav_' obj.mother_wavelet '_energy_band_' num2str(b) '_channel_' ...
                                num2str(cell2mat(selected_chans(chans_ind(k)))) ' = [];']);
                            eval(['obj.c_(1).wav_' obj.mother_wavelet '_energy_band_' num2str(b) '_channel_' num2str(cell2mat(selected_chans(chans_ind(k)))) '(1,:)= v_wav(b, :);']);
                            
                            
                            if isfield(study.dataset(study.dataset_selected(x)).results.featureExtractionMethods,'WaveletCoefficientEnergy')
                                ss=study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.WaveletCoefficientEnergy.c_;
                                ss.(['wav_' obj.mother_wavelet '_energy_band_' num2str(b) '_channel_' selected_chans{chans_ind(k)}])=v_wav(b, :);
                                study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.WaveletCoefficientEnergy.c_=ss;
                            else
                                study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.('WaveletCoefficientEnergy').('c_').(['wav_' obj.mother_wavelet '_energy_band_' num2str(b) '_channel_' selected_chans{chans_ind(k)}])=v_wav(b, :);
                            end
                            
                            
                            
                            
                            
                        end
                        clear v_wav
                    end
                    
                    if k > 1
                        continue;
                    end
                    
                    for b = 1:obj.decomposition_level
                        study.dataset(study.dataset_selected(x)).results.featureNames = ...
                            strcat(study.dataset(study.dataset_selected(x)).results.featureNames, ...
                            'Wavelet_', obj.mother_wavelet, '_EnergyBand_', num2str(b), ',');
                    end
                end
                
                %study.dataset(study.dataset_selected(x)).results.featureExtractionMethods.WaveletCoefficientEnergy = obj;
                obj = FeatureExtraction.Univariate.WaveletCoefficientEnergy.WaveletCoefficientEnergy_Data();
                obj.time = study.dataset(study.dataset_selected(x)).results.glbTime;
            end
            
            return;
            
        end
        
    end
end