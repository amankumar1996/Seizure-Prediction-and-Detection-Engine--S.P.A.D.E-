classdef WaveletCoefficientEnergy_Interface < handle
%======================================================================
%WaveletCoefficientEnergy_Interface
%
%Interface to Wavelet Coef. Extraction
%
%EU FP7 Grant 211713 (EPILEPSIAE)
%
%Bruno Direito
%CISUC, FCTUC, University of Coimbra
%2008/2009
%======================================================================
   properties
     
      % figure handles
      wce_i;
      % data handle
      wce_d;
      wce_f;
      
      % data
      study;
      
      acq_window;
      acq_step;
      
      mother_wav;
      dec_level;
      
   end
    
   methods
      %Constructor
      function obj = WaveletCoefficientEnergy_Interface(study)
         %  Create and then hide the GUI as it is being constructed.
         obj.study = study;
         
         obj.wce_f = FeatureExtraction.Univariate.WaveletCoefficientEnergy.WaveletCoefficientEnergy_Functions();
         obj.wce_d = FeatureExtraction.Univariate.WaveletCoefficientEnergy.WaveletCoefficientEnergy_Data();
         
         obj.acq_window = 5;
         obj.acq_step = obj.acq_window;            
         obj.mother_wav = 'db4';
         obj.dec_level = 6;
      end

   end
   
   methods(Static)
      %Draw the panel and its contents
      function draw(obj, panel)
         
          % display new panel

          obj.wce_i.WSelectionPanel = uipanel('Parent', panel, 'Title', 'Wavelet Selection' ,'Units','Normalized','Position', [0.05 0.05 0.9 0.9]);

          obj.wce_i.WaveletMotherEdit = uicontrol('Parent',obj.wce_i.WSelectionPanel,'style','popup','HandleVisibility','callback',...
              'Units','Normalized', 'Position',[0.55 0.6 0.2 0.2],'String','Haar|Daubechies|Biothorgonal|Coiflets|Symlets|Morlet|Mexican Hat|Meyer','Callback', @WaveletMotherEditCallback); % Edit box for data path
          obj.wce_i.WaveletMotherText = uicontrol('Parent', obj.wce_i.WSelectionPanel,'style','text','HandleVisibility','callback', ...
              'Units','Normalized','Position',[0.15 0.6 0.35 0.2],'String','Wavelet Decomposition Mother Wavelet'); % Edit box for data path
          obj.wce_i.WaveletMotherTypeEdit = uicontrol('Parent',obj.wce_i.WSelectionPanel,'style','popupmenu','HandleVisibility','callback',...
              'Units','Normalized', 'Position',[0.8 0.6 0.15 0.2],'String',{''}); % Edit box for data path
          
          obj.wce_i.WaveletDecEdit = uicontrol('Parent',obj.wce_i.WSelectionPanel,'style','popupmenu','HandleVisibility','callback',...
              'Units','Normalized', 'Position',[0.55 0.3 0.2 0.2],'String','2|3|4|5|6'); % Edit box for data path
          obj.wce_i.WaveletDecText = uicontrol('Parent', obj.wce_i.WSelectionPanel,'style','text','HandleVisibility','callback', ...
              'Units','Normalized','Position',[0.15 0.3 0.35 0.2],'String','Wavelet Decomposition Level'); % Edit box for data path
          
          obj.wce_i.CancelButton = uicontrol('Parent', obj.wce_i.WSelectionPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.55 0.075 0.1 0.075],...
              'String','Cancel','Callback', {@CancelButtonCallback, obj}); % Button for cancel
          obj.wce_i.HelpButton = uicontrol('Parent', obj.wce_i.WSelectionPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.7 0.075 0.1 0.075],...
              'String','Help','Callback', @HelpButtonCallback); % Button for help
          obj.wce_i.OkButton = uicontrol('Parent', obj.wce_i.WSelectionPanel,'style','pushbutton', 'HandleVisibility','callback','Units','Normalized', 'Position',[0.85 0.075 0.1 0.075],...
              'String','Ok','Callback', {@OkButtonCallback, obj, obj.study}); % Button for ok
          

          function mother_wavelet = WaveletMotherEditCallback (hObject, eventdata)
              
              mother_wavelet_val = (get(obj.wce_i.WaveletMotherEdit,'Value'));
              
              switch (mother_wavelet_val)
                  case 1
                      disp ('Haar')
                      mother_wavelet = 'haar'; 
                      set (obj.wce_i.WaveletMotherTypeEdit, 'String', {''});
                  case 2
                      disp ('Daubechies')
                      mother_wavelet = 'db';
                      set (obj.wce_i.WaveletMotherTypeEdit, 'String', '2|3|4|5|6|7|8|9|10');
                  case 3
                      disp ('Biorthogonal')
                      mother_wavelet = 'bior';
                      set (obj.wce_i.WaveletMotherTypeEdit, 'String', '1.3|1.5|2.2|2.4|2.6|2.8|3.1|3.3|3.5|3.7|3.9|4.4|5.5|6.8');
                  case 4
                      disp ('Coiflets')   
                      mother_wavelet = 'coif';
                      set (obj.wce_i.WaveletMotherTypeEdit, 'String', '1|2|3|4|5');
                  case 5
                      disp ('Symlets')
                      mother_wavelet = 'sym';
                      set (obj.wce_i.WaveletMotherTypeEdit, 'String', '2|3|4|5|6|7|8');
                  case 6
                      disp ('Morlet')
                      mother_wavelet = 'morl';
                      set (obj.wce_i.WaveletMotherTypeEdit, 'String', {''});
                  case 7
                      disp ('Mexican Hat')       
                      mother_wavelet = 'mexh';
                      set(obj.wce_i.WaveletMotherTypeEdit, 'String', {''});
                  case 8
                      disp ('Meyer')
                      mother_wavelet = 'meyer';
                      set(obj.wce_i.WaveletMotherTypeEdit, 'String', {''});
              end
          end
          
          function OkButtonCallback (hObject, eventdata, obj, study)
              
              
              combo_val = get(obj.wce_i.WaveletMotherTypeEdit, 'String');

              if iscell(combo_val)
                  mother_wavelet_id = '';
              else
                  types = str2num(get (obj.wce_i.WaveletMotherTypeEdit, 'String'));
                  type = (get(obj.wce_i.WaveletMotherTypeEdit,'Value'));
                  mother_wavelet_id = types (type);
              end
                   
              obj.mother_wav = WaveletMotherEditCallback;
              obj.mother_wav = [obj.mother_wav '' num2str(mother_wavelet_id)];
              
              combo_val = str2num(get(obj.wce_i.WaveletDecEdit,'String'));
              decomposition_level_val = get(obj.wce_i.WaveletDecEdit,'Value');
              obj.dec_level = combo_val(decomposition_level_val);

                   
              close(gcf);  
              

          end
          function CancelButtonCallback (hObject, eventdata, obj)
              obj.clear (obj.wce_i);
              close(gcf);
          end

      end
      
      function ClearChildClasses(obj)
          delete(obj.wce_f);
          clear obj.wce_f
          delete(obj.wce_d);
          clear obj.wce_d
          obj.wce_f = FeatureExtraction.Univariate.WaveletCoefficientEnergy.WaveletCoefficientEnergy_Functions();
          obj.wce_d = FeatureExtraction.Univariate.WaveletCoefficientEnergy.WaveletCoefficientEnergy_Data();
      end      
      
      function RunSingleSegment(obj, study, p_segment, p_samp_rate)
          obj.wce_f.RunSingleSegment(study, p_segment, p_samp_rate,...
              obj.mother_wav, obj.dec_level);
      end

      function SaveResults(obj, study)
          obj.wce_d.SaveData(study, obj.wce_f);
      end        

      %Clear the panel and its contents
      %TODO: Also clean new menus
      function clear(C)
        delete(C.WSelectionPanel);
        delete(C.WDataPanel);
      end
    end
end