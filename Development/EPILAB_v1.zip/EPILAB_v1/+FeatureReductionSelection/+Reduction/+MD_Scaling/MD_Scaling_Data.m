classdef MD_Scaling_Data < handle
    %======================================================================
    %MD_Scaling_Data
    %
    %Data of MDS
    %CISUC/FCTUC
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
   % The following properties can be set only by class methods
   properties
      
     %BEGIN: DO NOT REMOVE THESE PROPERTIES
          STUDY;
          
          %USED BY RESULTS LIST (SHOULD BE UPDATED IN INTERFACE CLASS)
          sub_module_name = 'MD_Scaling';
          saveinfo_datasets;
          saveinfo_features;
          saveinfo_other;
          saveinfo_name = '';
          MenuitemCallback;
          loading = 0;
          EPILAB_DS_FLAG = '_study';
          FEATURES_TAG = 'c_';

      %END: DO NOT REMOVE THESE PROPERTIES      
      
      %New dimensional space
      DIM = 2;
      CRIT={'stress','sstress','metricstress','metricsstress','sammon','strain'};
      VAL_PU = 1;
      
      %DATA SETS
      DATA_SETS_PATHS = {};
      PATHNAME = '';
      DATA_SETS = {};
      DATA_SETS_SEL = [];
      DATA_SETS_LAST_POS = 1;
      FEATURES = {};
      FEATURES_LIST = {};
%##########################################################################
      NORMAL_STATE = 1;
      PRE_ICTAL_STATE = 2;
      ICTAL_STATE = 3;
      POS_ICTAL_STATE = 4;
      PRE_ICTAL_TIME = 100;
      POS_ICTAL_TIME = 100;
%##########################################################################      
      
      %Results
      A = [];
      T2 = [];
      M=[];
   end
   
   methods
      %Constructor
      function obj = MD_Scaling_Data()
        
      end
   end   
end