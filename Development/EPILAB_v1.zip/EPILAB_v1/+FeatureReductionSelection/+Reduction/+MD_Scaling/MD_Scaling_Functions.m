classdef MD_Scaling_Functions
    %======================================================================
    %MD_Scaling_Functions
    %
    %Functions of MDS
    %CISUC/FCTUC
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
   % The following properties can be set only by class methods
   properties
        DATA;
   end
    
   methods
       
      %Constructor
      function obj = MD_Scaling_Functions(data)
          obj.DATA = data;
      end
      
      function m=reduce(obj, dim, val_pu)
          global h;
          
          val=get(h.MD_Scaling.datasets_list,'Value');

          disp(obj.DATA.DATA_SETS_PATHS(val));
          
          %BEGIN - Datasets protection
              f = '';
              a = obj.DATA.FEATURES(val);
              aux = zeros(1,length(a));

              for i=1:length(a)
                  aux(i) = sum(a{i});
              end                  


              if length(a)>1 %If the datasets hasn't the same number of features
                  for i=1:length(aux)
                      f = strcat(f,'aux(',num2str(i),'),');
                  end

                  e = strcat('isequal(',f(1:end-1),')');

                  if ~eval(e) 
                      errordlg('Select in all datasets choosen the same number of features.');
                      SP = 0; SS = 0; AC = 0;
                      return;
                  end   
              end

              if sum(aux(i))==0 %If none feature was selected
                  errordlg('Select at least one feature/dataset.');
                  SP = 0; SS = 0; AC = 0;
                  return;                  
              end
          %END - Datasets protection          
          
          [P T]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'iii');

          %###############################################################


          diss_matrix=pdist(P');
          
          switch val_pu
              case 1
                  crit = 'stress';
              case 2
                  crit = 'sstress';
              case 3
                  crit = 'metricstress';
              case 4
                  crit = 'metricsstress';
              case 5
                  crit = 'sammon';
              case 6
                  crit = 'strain';
          end
          m=mdscale(diss_matrix,dim,'criterion',crit);
          %###############################################################
          
      end
      
        
        function [P T Test T2] = readEpi(obj, path, type)    
            path
            type
            switch(type)
                case 'i' 

                        %0. Read and normalize
                        m=readNorm(obj, path);
                        
                        

                        %1. Create Test matrix (Test)
                        Test=m(1:3:end,:);
                        m(1:3:end,:)=[];      
                        
                        %2. Create the target matrix (T)
                        T=m(:,1);

                        %3. Create the target for Test (T2)
                        T2=Test(:,1); 

                        %4. Create and transpose P
                        P=m(:,2:end);
                        P=P';

                        %5. Clean and transpose Test
                        Test=Test(:,2:end);
                        Test=Test';


                case 'ii'                     
                            %0. Read and normalize
                            m=readNorm(obj, path(1:(end-1)));
                            Test=readNorm(obj, path(end));

                            %1. Create the target matrix (T)
                            T=m(:,1);

                            %2. Create the target for Test (T2)
                            T2=Test(:,1); 

                            %3. Create and transpose P
                            P=m(:,2:end);
                            P=P';

                            %4. Clean and transpose Test
                            Test=Test(:,2:end);
                            Test=Test';

                case 'iii'                    
                            %0. Read and normalize
                            m=readNorm(obj, path);
                            Test=readNorm(obj, path(end));

                            %1. Create the target matrix (T)
                            T=m(:,1);

                            %2. Create the target for Test (T2)
                            T2=Test(:,1); 

                            %3. Create and transpose P
                            P=m(:,2:end);
                            P=P';

                            %4. Clean and transpose Test
                            Test=Test(:,2:end);
                            Test=Test';
                            
                 case 'iv'                    
                            %0. Read and normalize
                            m=readNorm(obj, path);
                            Test=readNorm(obj, path(end));

                            %1. Create the target matrix (T)
                            T=m(:,1);

                            %2. Create the target for Test (T2)
                            T2=Test(:,1); 

                            %3. Create and transpose P
                            P=m(:,2:end);
                            P=P';

                            %4. Clean and transpose Test
                            Test=Test(:,2:end);
                            Test=Test';           
            end   
            
            function m=readNorm(obj, path)
                m=[];
                global h;
                
                %1. Read from the Excel file
                for i=1:length(path),
                    
                    p=path{i}
                    if length(p)>5
                        if isequal(p(1:6),obj.DATA.EPILAB_DS_FLAG)
                            mAux=features2Matrix(obj,str2double(p(7:end)));
                            %TODO: Add study dataset support
                        else
                            mAux=xlsread(char(path(i)));
                            h.SVM.LoadingError = 0;
                        end
                    else
                        mAux=xlsread(char(path(i)));
                        h.SVM.LoadingError = 0;
                    end

                    %1.1 Normalize matrix by column
                    aux=mAux(:,1);
                    aux2=mAux(:,2:end);
                    
%                     aux2=scalestd(aux2')';
                    
                    for j=1:length(aux2(1,:))
                        aux2(:,j)=aux2(:,j)/max(max(aux2(:,j)));
                    end    
                    
                    mAux=horzcat(aux,aux2);   

                    m=vertcat(m,mAux);
                end 
            end
            
            function m=features2Matrix(obj, dataset_number)
                parameter_acquisition=obj.DATA.STUDY.dataset(dataset_number).results.parameterAcq;
                  %1� Read features
                  obj.DATA.STUDY
                      types = fieldnames(obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods);

                      
                      oth_idx=~strcmp('MDS',types);
                      types=types(oth_idx)
                      
                      oth_idx=~strcmp('PCA',types);
                      types=types(oth_idx)
                      
                      final_matrix = {};
                      count = 2;
                      for j=length(types):-1:1  % 2.2 For each feature type
                          e = cell2mat(strcat('isempty(','obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),')'));
                          a = cell2mat(strcat('fieldnames(','obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),')'));

                          if ~eval(e)
                            features = eval(a);

                            for x=length(features):-1:1  % 2.3 For each feature
                              feat = cell2mat(features(x));
                              e2 = strcat(e(1:end-1),'.',feat,')');

                              if or(eval(e2), feat(1:2) ~= obj.DATA.FEATURES_TAG)
                                  if strcmp(feat, 'parameter_acquisition')%Data Aquisition (For T matrix)
                                      if eval(strcat('~isempty(obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',features{x},')'))
                                        parameter_acquisition = eval(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',features{x}));
                                      end  
                                      features(x) = [];
                                  else    
                                      disp(feat)
                                      features(x) = [];
                                  end    
                              end
                            end 
                            m = [];
                            f = features(1);
                            features=fieldnames(eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),'.',f))))
                            min = 999999999;
                            for x=1:length(features)  % 2.3 Seek for the sortest feature
                                aux = eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',f,'.',features{x})));
                                length(aux)
                                if length(aux)<min;
                                    min = length(aux);
                                end    
                            end
                            disp(['min = ' num2str(min)]);
                            for x=1:length(features)  % 2.4 Add new features to final matrix
                                aux = eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',f,'.',features{x})));
                                aux = aux((length(aux)-min)+1:end);
                                m(:,count) = aux';
                                count = count + 1;
                            end  

                          end  
                      end
                      
                      m(:,1) = 1;
                        return;
                      

              end
    
        end
      
        
        function [SP SS AC NERRORS] = calcPerformance(obj, A, T2) 
        %Classes:
        %1 - Normal state
        %2 - Pre-ictal 
        %3 - Ictal
        %4 - Pos-ictal
        %T2 - Must have 1 column and n rows with the classes
            NORMAL=1;
            PREICTAL=2;
            ICTAL=3;
            POSICTAL=4;        

            %0 Calc the total number of errors and corrects
            NERRORS=zeros(4);
            CORRECTS=zeros(4,1);
            for i=1:length(A)
                aux=A(i);
                NERRORS(T2(i),aux(1))=NERRORS(T2(i),aux(1))+(T2(i)~=aux(1));
                CORRECTS(T2(i))=CORRECTS(T2(i))+(T2(i)==aux(1)); %Add the correct situations
            end

            %1 Calc TP, TN, FP, FN
            %1.1 True Negatives
            TN_NORMAL=(CORRECTS(NORMAL)+NERRORS(ICTAL,NORMAL)+NERRORS(POSICTAL,NORMAL));
            TN_ICTAL=(NERRORS(NORMAL,ICTAL)+CORRECTS(ICTAL)+NERRORS(POSICTAL,ICTAL));
            TN_POSICTAL=(NERRORS(NORMAL,POSICTAL)+NERRORS(ICTAL,POSICTAL)+CORRECTS(POSICTAL));
            TN=TN_NORMAL+TN_ICTAL+TN_POSICTAL;
            disp({'Neg Verdadeiros=' TN});

            %1.2 False Negatives
            FN=NERRORS(PREICTAL,NORMAL)+NERRORS(PREICTAL,ICTAL)+NERRORS(PREICTAL,POSICTAL);
            disp({'Neg Falsos=' FN});

            %1.3 True Positives
            TP=CORRECTS(PREICTAL);
            disp({'Pos Verdadeiros=' TP});

            %1.4 False Positives
            FP=NERRORS(NORMAL,PREICTAL)+NERRORS(ICTAL,PREICTAL)+NERRORS(POSICTAL,PREICTAL);
            disp({'Pos Falsos=' FP});


            %2. Metrics
            %2.1 Calc the sensitivity (TP/TP+FN)
            SS = (TP/(TP+FN))*100; 

            %2.2 Calc the specificity (TN/TN+FP)
            SP = (TN/(TN+FP))*100;  

            %2.3 Calc the classifier precision (CORRECT/TOTAL)
            CORRECT=sum(CORRECTS);
            TOTAL=length(T2);
            AC = (CORRECT/TOTAL)*100;


            SS;
            SP;
            AC;
            NERRORS;
            CORRECTS;
            end
   end    
end