classdef MD_Scaling_Interface < handle
    %======================================================================
    %MD_Scaling_Interface
    %
    %Interface to MDS
    %CISUC/FCTUC
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
   properties
      panel_title = 'Nonclassical Multidimensional Scaling';
      
      %Graphical User Interface auxiliar variables (normalized)
      DEFAULT_EDIT_WIDTH = 0.075;
      DEFAULT_EDIT_HEIGHT = 0.10;
      
      DEFAULT_TEXT_HEIGHT = 0.10;
      DEFAULT_TEXT_WIDTH = 0.30;
      
      DEFAULT_POPUP_HEIGHT = 0.10;
      DEFAULT_POPUP_WIDTH = 0.20; 
      
      DEFAULT_SEPARATION = 0.03;
      
      MD_Scaling_PANEL_WIDTH = 0.98;
      MD_Scaling_PANEL_HEIGHT = 0.6;
      MD_Scaling_PANEL_X = 0.01;
      MD_Scaling_PANEL_Y = 0.01;
      
      DATA_PANEL_HEIGHT = 0.2;
      
      STUDY;
      DATA;
      FUNCTIONS;
   end
    
   methods
       
      %Constructor
      %REQUIRED FUNCTION
      function obj = MD_Scaling_Interface(study)
          obj.STUDY = study;
          obj.DATA = FeatureReductionSelection.Reduction.MD_Scaling.MD_Scaling_Data();
          obj.DATA.STUDY = study;
          obj.FUNCTIONS = FeatureReductionSelection.Reduction.MD_Scaling.MD_Scaling_Functions(obj.DATA);
      end
      
      %Method that builds the Graphical User Interface Components
      %params: panel (uipanel where all the uicomponents are drawn)
      function draw(obj, panel)
      
           global h;
           
           set(panel,'Title',obj.panel_title, 'TitlePosition','centertop');
           
           data_panel = uipanel('Parent',panel,'Title','Select Data','ForegroundColor',[4/255 166/255 146/255],'FontWeight','bold','Units','Normalized','FontSize',10,'Position',[0,0.8,0.6,obj.DATA_PANEL_HEIGHT]);
           drawDataPanel(data_panel);           
           
           reduction_panel = uipanel('Parent',panel,'Title','Parameters','ForegroundColor',[4/255 166/255 146/255],'FontWeight','bold','Units','Normalized','FontSize',10,'Position',[0,0,1,0.8]);
           
           create_MD_ScalingPanel(reduction_panel); 

           %Draw the data panel
           function drawDataPanel(data_panel)  

              h.MD_Scaling.open_dataset_button = uicontrol('Parent',data_panel,'Style','pushbutton','Units','Normalized','String','Open','FontSize',8,'Callback',{@OpenDataSet_Button},...
                   'Position',[0.03,0.01,0.1,0.25]);

              h.MD_Scaling.delete_button = uicontrol('Parent',data_panel,'Style','pushbutton','Units','Normalized','String','Del','FontSize',8,'Enable','Off','Callback',{@Delete_Button},...
                   'Position',[0.03+0.1,0.01,0.07,0.25]); 
              
              h.MD_Scaling.refresh_button = uicontrol('Parent',data_panel,'Style','pushbutton','Units','Normalized','String','Refresh','FontSize',8,'Enable','On','Callback',{@LoadStudyDatasets},...
                   'Position',[0.13+0.07,0.01,0.13,0.25]); 

              h.MD_Scaling.datasets_list = uicontrol('Parent',data_panel,'Style','listbox','Units','Normalized','String',obj.DATA.DATA_SETS,'BackgroundColor','white','Max',20,'Min',2,'Callback',{@LoadFeatures},...
                   'Position',[0.03,0.25,0.3,0.7]);  

              h.MD_Scaling.features_list = uicontrol('Parent',data_panel,'Style','listbox','Units','Normalized','BackgroundColor','white','Max',20,'Min',2,'Callback',{@SetFeatures},...
                   'Position',[0.07+0.3,0.02,0.62,0.95]);
              
              
              if obj.DATA.loading %Set the datasets when loading saved data
                set(h.MD_Scaling.datasets_list,'Value',obj.DATA.DATA_SETS_SEL);
                LoadFeatures(1, []);
                set(h.MD_Scaling.delete_button, 'Enable', 'on');
              else
                  LoadStudyDatasets;
              end    
              
              %Load datasets from xls files
              function OpenDataSet_Button(source,eventdata)
                  
                       if(length(obj.DATA.PATHNAME)>1)
                           [ filename , pathname ] = uigetfile (  {'*.xls'} , 'Choose a xls dataset file','MultiSelect','on',obj.DATA.PATHNAME);
                       else
                           [ filename , pathname ] = uigetfile (  {'*.xls'} , 'Choose a xls dataset file','MultiSelect','on');
                       end
                        
                        current_path = pwd;
                        obj.DATA.PATHNAME = pathname(length(current_path)+2:end);
                        if isequal(filename,0)
                            disp('You must select a file!');
                        elseif ischar(filename)
                            [pathname filename];
                            obj.DATA.DATA_SETS_PATHS(obj.DATA.DATA_SETS_LAST_POS) = {[pathname filename]};
                            obj.DATA.DATA_SETS(obj.DATA.DATA_SETS_LAST_POS) = {filename};
                            obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS + 1;

                            obj.DATA.DATA_SETS;
                            set(h.MD_Scaling.datasets_list,'String',obj.DATA.DATA_SETS);
                            set(h.MD_Scaling.datasets_list,'Value',obj.DATA.DATA_SETS_LAST_POS-1);
                            LoadFeatures([],[]);

                            set(h.MD_Scaling.delete_button, 'Enable', 'on');
                        else    
                            disp('FILENAMES:');
                            strcat(pathname,char(filename));
                            aux = obj.DATA.DATA_SETS_LAST_POS;
                            for i = 1:length(filename)
                                obj.DATA.DATA_SETS_PATHS(obj.DATA.DATA_SETS_LAST_POS) = {[pathname char(filename(i))]};
                                obj.DATA.DATA_SETS(obj.DATA.DATA_SETS_LAST_POS) = {char(filename(i))};
                                obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS + 1;
                            end
                            obj.DATA.DATA_SETS;
                            obj.DATA.DATA_SETS_PATHS;
                            set(h.MD_Scaling.datasets_list,'String',obj.DATA.DATA_SETS);
                            set(h.MD_Scaling.datasets_list,'Value',aux:obj.DATA.DATA_SETS_LAST_POS-1);
                            LoadFeatures([],[]);

                            set(h.MD_Scaling.delete_button, 'Enable', 'on');
                        end
              end

              %Delete datasets from the datasets list
              function Delete_Button(source, eventdata)
                  val=get(h.MD_Scaling.datasets_list,'Value');
                  str=get(h.MD_Scaling.datasets_list,'String');
                  for i=length(val):-1:1
                      obj.DATA.FEATURES_LIST(val(i)) = [];
                      obj.DATA.FEATURES(val(i)) = [];

                      obj.DATA.DATA_SETS_PATHS(val(i)) = [];
                      obj.DATA.DATA_SETS(val(i)) = [];
                      obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS - 1;

                      set(h.MD_Scaling.datasets_list, 'Value', []);
                      set(h.MD_Scaling.datasets_list, 'String', obj.DATA.DATA_SETS);
                      set(h.MD_Scaling.features_list, 'Value', []);
                      set(h.MD_Scaling.features_list, 'String', []);
                  end   

                  str=get(h.MD_Scaling.datasets_list,'String');

                  if isempty(str)
                      set(h.MD_Scaling.delete_button, 'Enable', 'off');
                  end
              end
              
              %Load the features of datasets into the data object
              function LoadFeatures(source, eventdata)
                  val=get(h.MD_Scaling.datasets_list,'Value');
                  if ~isempty(val)                              
                      if isempty(source)
                          [num,txt] = xlsread(char(obj.DATA.DATA_SETS_PATHS(val(1))));
                          num(:,1) = [];
                          txt = txt(1,3:end);
                          set(h.MD_Scaling.features_list,'String',txt);
                          for i=1:length(val)
                              obj.DATA.FEATURES_LIST{val(i)} = txt;
                              obj.DATA.FEATURES{val(i)} = ones(1,length(txt));
                          end
                          set(h.MD_Scaling.features_list,'Value',1:length(txt));
                      else    
                          a = obj.DATA.FEATURES{val(1)};
                          %b = obj.DATA.FEATURES_LIST{val(1)};

                          h.list = obj.DATA.FEATURES_LIST;
                          h.feat = obj.DATA.FEATURES;

                          set(h.MD_Scaling.features_list,'String',obj.DATA.FEATURES_LIST{val(1)});
                          set(h.MD_Scaling.features_list,'Value',find(a==1));
                      end 

                  end
              end 

              %Update the features selected by the user in the data object
              function SetFeatures(source, eventdata)
                  
                  val=get(source,'Value');
                  str=get(source,'String');
                  pos=get(h.MD_Scaling.datasets_list,'Value');
                  
                  if ~isempty(val)
                      fea = zeros(1,length(str));
                      for i=1:length(val)
                          fea(val(i)) = 1;
                      end    

                      for i=1:length(pos) %TODO: Test these conditions
                          if length(obj.DATA.FEATURES{pos(i)}) == length(fea) %If the dest matrix is equal
                              obj.DATA.FEATURES{pos(i)} = fea;
                          elseif length(obj.DATA.FEATURES{pos(i)}) > length(fea) %If the dest matrix is bigger
                              aux = zeros(1,length(obj.DATA.FEATURES{pos(i)}));
                              aux(1:length(fea)) = fea;
                              obj.DATA.FEATURES{pos(i)} = aux;
                          else          %If the dest matrix is smaller
                              aux = fea(1,length(obj.DATA.FEATURES{pos(i)}));
                              obj.DATA.FEATURES{pos(i)} = aux;
                          end    
                      end    
                  end
              end 

              %Fill the dataset list with results from the other modules
              function LoadStudyDatasets(source, eventdata)
                  

                  %1� Insert the datasets to the list
                  ds_name = strcat(obj.STUDY.name,'.');
                  aux = obj.DATA.DATA_SETS_LAST_POS;
                  for i=1:length(obj.STUDY.dataset)
                      ds_name2 = strcat(ds_name,obj.STUDY.dataset(i).name);
                      h.DATA_SETS = obj.DATA.DATA_SETS;
                      h.ds_name2 = ds_name2;
                      
                      if isempty(obj.DATA.DATA_SETS)
                          obj.DATA.DATA_SETS(obj.DATA.DATA_SETS_LAST_POS) = {ds_name2};
                          
                          %Add position of dataset, useful for the train
                          %function to capture the right features, e.g.
                          %study1, study2, etc.
                          obj.DATA.DATA_SETS_PATHS(obj.DATA.DATA_SETS_LAST_POS) = {[obj.DATA.EPILAB_DS_FLAG num2str(i)]};
                          obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS + 1;
                          break;
                      end    
                      
                      for j=1:length(obj.DATA.DATA_SETS)
                         if strcmp(obj.DATA.DATA_SETS{j}, ds_name2)
                              obj.DATA.DATA_SETS(j) = [];
                              obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS - 1;
                              aux = aux - 1; %Update auxiliar var
                              break;
                         end
                      end  
                      
                      obj.DATA.DATA_SETS(obj.DATA.DATA_SETS_LAST_POS) = {ds_name2};
                      obj.DATA.DATA_SETS_PATHS(obj.DATA.DATA_SETS_LAST_POS) = {[obj.DATA.EPILAB_DS_FLAG num2str(i)]}; %Add reference to the paths data structure
                      obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS + 1;
                      
                  end


                  %2� Load features
                  for i=1:length(obj.STUDY.dataset) % 2.1 For each dataset

                      types = fieldnames(obj.STUDY.dataset(i).results.featureExtractionMethods);

                      final_matrix = {};
                      count = 1;
                      for j=length(types):-1:1  % 2.2 For each feature type
                          e = cell2mat(strcat('isempty(','obj.STUDY.dataset(i).results.featureExtractionMethods.',types(j),')'));
                          a = cell2mat(strcat('fieldnames(','obj.STUDY.dataset(i).results.featureExtractionMethods.',types(j),')'));

                          if ~eval(e)
                            features = eval(a);

                            for x=length(features):-1:1  % 2.3 For each feature
                              feat = cell2mat(features(x));
                              e2 = strcat(e(1:end-1),'.',feat,')');

                              if or(eval(e2), feat(1:2) ~= obj.DATA.FEATURES_TAG)
                                  disp(feat)
                                  features(x) = [];                                          
                              end
                            end 
                            f = features(1);
                            features=fieldnames(eval(cell2mat(strcat('obj.STUDY.dataset(i).results.featureExtractionMethods.',types(j),'.',f))));
                            for x=1:length(features)  % 2.4 Add new features to final matrix
                                final_matrix(count) = strcat(types(j),'.',features(x));
                                count = count + 1;
                            end  

                          end
                      end    

                      obj.DATA.FEATURES_LIST{aux} = final_matrix;
                      obj.DATA.FEATURES_LIST
                      obj.DATA.FEATURES{aux} = ones(1,length(final_matrix));
                      aux = aux + 1;

                  end

                  % 3� Apply changes to the handles
                  set(h.MD_Scaling.features_list,'String',{});
                  set(h.MD_Scaling.features_list,'String',{});

                  set(h.MD_Scaling.datasets_list,'Value',[]);
                  set(h.MD_Scaling.datasets_list,'String',obj.DATA.DATA_SETS);

                  set(h.MD_Scaling.delete_button, 'Enable', 'on');
              end    
           end

           function create_MD_ScalingPanel(fpanel)
                % Set current data to the selected data set.
                % TODO: Analyse the memory of constantly creating
                % uipanels
                
               %Draw MD_Scaling parameters
               npanel = uipanel('Parent',fpanel,'BorderType','none','BorderWidth',0,'Units','Normalized','Visible','on','Position',[obj.MD_Scaling_PANEL_X,obj.MD_Scaling_PANEL_Y,obj.MD_Scaling_PANEL_WIDTH,obj.MD_Scaling_PANEL_HEIGHT]);

               IPOS = 0.7;
               %NOTE: The uicontrols are drawn in a
               %bottom-up fashion

               IPOS = IPOS + 0.2;
%                CRIT={'stress','sstress','metricstress','metricsstress','sammon','strain'};

               h.MD_Scaling.crit_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Goodness-of-fit criterion:','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
%                h.MD_Scaling.crit_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',CRIT,'BackgroundColor','white',...
%                    'Max',20,'Min',2,'Value',1,'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH+0.1,obj.DEFAULT_EDIT_HEIGHT]);
               
                 h.MD_Scaling.crit_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.DATA.CRIT,'BackgroundColor','white',...
                   'Max',20,'Min',2,'Value',1,'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH+0.1,obj.DEFAULT_EDIT_HEIGHT]);

%                h.MD_Scaling.crit_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String','stress|sstress|metricstress|metricsstress|sammon|strain',...
%                    'BackgroundColor','white','Max',20,'Min',2,'Callback',{@(src,event)SelectCriterion(obj,src,event)},'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH+0.1,obj.DEFAULT_EDIT_HEIGHT]);
               
                         
               IPOS = IPOS + 0.2;
               
               h.MD_Scaling.dim_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Reduced dimension:','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.MD_Scaling.dim_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.DIM),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_EDIT_HEIGHT]);              

               
                  
               %Reduce Button
               h.MD_Scaling.Select_button = uicontrol('Parent',npanel,'Style','pushbutton','Units','Normalized','String','Reduce','FontSize',10,'Callback',{@(src,event)Reduce_Button(obj,src,event)},...
                'Position',[0.21,0.1,0.1,0.1]);

               %Save Button
               h.MD_Scaling.save_button = uicontrol('Parent',npanel,'Style','pushbutton','Units','Normalized','String','Save','FontSize',10,'Enable','off','Callback',{@(src,event)Save_Button(obj,src,event)},...
                'Position',[0.21+0.11,0.1,0.1,0.1]);
            
              
              
              
              
              %Reduce the features space
              function Reduce_Button(obj, source, evendata)
                   
                   updateData(obj);
                   dim = str2double(get(h.MD_Scaling.dim_edit,'String'));
                   
                   
                   %Select the goodness-of-fit criterion
                   val_pu = get(h.MD_Scaling.crit_popup,'Value');
%                    str_pu = get(h.MD_Scaling.crit_popup,'String');
%                    crit = str_pu(val_pu);
                   
                   obj.DATA.M = obj.FUNCTIONS.reduce(dim,val_pu)
                   if size(obj.DATA.M,1) > 0 && size(obj.DATA.M,2) > 0
                        set(h.MD_Scaling.save_button,'Enable','on');
                   end
                   
              end
              
              function updateData(obj)
                  obj.DATA.DIM = str2double(get(h.MD_Scaling.dim_edit,'String'));
                  
                  obj.DATA.VAL_PU = get(h.MD_Scaling.crit_popup,'Value');

              end
              
              %Save into the EpiLab data structure the classifier

              
              
              function Save_Button(obj, source, evendata)
                  
                  datasets = get(h.MD_Scaling.datasets_list,'Value');
                  
                  newdataset_name = '';
                  
                  for i=1:length(datasets)
                    newdataset_name = strcat(newdataset_name, obj.DATA.STUDY.dataset(i).name,'_');
                  end  
                  
                  %TODO: If already exist a dataset with that name, ask to
                  %replace
                  
                  
                  
                  dim = str2double(get(h.MD_Scaling.dim_edit,'String'));
                  
                  for i=1:dim
                    eval(strcat('obj.DATA.STUDY.dataset(1).results.featureExtractionMethods.MDS.c_.MDS_dim_',num2str(i),' = obj.DATA.M(:,',num2str(i),')'';'));
                  end
                  
                  %TODO: Capture the time for the new features with a new
                      %dimension                      
                  
                  
                  %Copy the data structure
                  %obj.DATA.STUDY.dataset(end).file.data = obj.DATA.STUDY.dataset(val(1)).file.data;                 
                  
                  set(h.MD_Scaling.save_button,'Enable','off');
                
              end
               
           end
             
      end
         
      %Copy all the properties
      %REQUIRED FUNCTION
      function copyAllProperties(obj, src, dest)
          prop = fieldnames(src);
          for i=1:length(prop)    
             if ~strcmp(prop{i},'STUDY')
                eval(strcat('dest.',prop{i},'=src.',prop{i},';'));
             end   
          end    
      end     
           
   end
end