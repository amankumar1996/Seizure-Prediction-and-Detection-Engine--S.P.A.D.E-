classdef PCA_Data < handle
    %======================================================================
    %PCA_Data
    %
    %Data of PCA
    %CISUC/FCTUC
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %======================================================================
   % The following properties can be set only by class methods
   properties
      
     %BEGIN: DO NOT REMOVE THESE PROPERTIES
          STUDY;
          
          %USED BY RESULTS LIST (SHOULD BE UPDATED IN INTERFACE CLASS)
          sub_module_name = 'PCA';
          module_name = 'Red';
          saveinfo_datasets;
          saveinfo_features;
          saveinfo_other;
          saveinfo_name = '';
          MenuitemCallback;
          loading = 0;
          EPILAB_DS_FLAG = '_study';
          FEATURES_TAG = 'c_';

      %END: DO NOT REMOVE THESE PROPERTIES      
      
      %New dimensional space
      DIM = 2;
      M = []; %Matrix where the new feature are stored
      time = [];
      
      %DATA SETS
      DATA_SETS_PATHS = {};
      PATHNAME = '';
      DATA_SETS = {};
      DATA_SETS_SEL = [];
      DATA_SETS_LAST_POS = 1;
      FEATURES = {};
      FEATURES_LIST = {};
      
      %Results
      A = [];
      T2 = [];
   end
   
   methods
      %Constructor
      function obj = PCA_Data()
        
      end
   end   
end