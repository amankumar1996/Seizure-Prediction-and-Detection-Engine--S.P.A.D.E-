%Defines the main class and interface of classifiers
classdef Artificial_Neural_Networks_COMP < handle
   % The following properties can be set only by class methods
   properties
       INTERFACE;
       DATA;
   end
    
   methods
      %Constructor
      function NN = Artificial_Neural_Networks_COMP(d,UI)
        NN.INTERFACE = UI;
        NN.DATA = d;
      end
      
      function npanel=draw(obj,fpanel)
           global h;
           
           npanel = uipanel('Parent',fpanel,'BorderType','none','BorderWidth',0,'Units','Normalized','Visible','on','Position',[obj.INTERFACE.NNET_PANEL_X,obj.INTERFACE.NNET_PANEL_Y,obj.INTERFACE.NNET_PANEL_WIDTH,obj.INTERFACE.NNET_PANEL_HEIGHT]);
                   
           %training_function_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Training Function:','FontSize',10,'Position',[0,0.4,0.25,0.2]);
           %training_function_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',{'TRAINLM','TRAINGDM','TRAINBFG'},'Position',[0.25,0.4,0.15,0.2]);

           IPOS = 0.35;
           %NOTE: The uicontrols are drawn in a
           %bottom-up fashion

           IPOS = IPOS + 0.2;
           
           h.ANN.conscience_learning_rate_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Conscience learning rate:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.conscience_learning_rate_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.NNET_COMP_conscience),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_EDIT_HEIGHT]);
           
           IPOS = IPOS + obj.INTERFACE.DEFAULT_EDIT_HEIGHT;
           
           h.ANN.kohonen_learning_rate_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Kohonen learning rate:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.kohonen_learning_rate_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.NNET_COMP_kohonen),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_EDIT_HEIGHT]);
           
           IPOS = IPOS + obj.INTERFACE.DEFAULT_EDIT_HEIGHT;

           h.ANN.number_of_neurons_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Number of neurons:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.number_of_neurons_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','BackgroundColor','white','String','','Enable','off',...,
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_EDIT_HEIGHT]);
           
           
           h.ANN.epochs_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Epochs:','FontSize',10,...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION*2+obj.INTERFACE.DEFAULT_POPUP_WIDTH,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.epochs_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.INTERFACE.DATA.EPOCHS),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION+obj.INTERFACE.DEFAULT_POPUP_WIDTH+obj.INTERFACE.DEFAULT_TEXT_WIDTH/2+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');
           
      end

      function [SP SS AC A] = train(obj,P,T,Test,T2)
          
          maxmin = [];
          for i=1:length(P(:,1))
              maxmin(i,:) = [0 1];
          end
          net = newc(maxmin,length(T(:,1)),obj.DATA.NNET_COMP_kohonen,obj.DATA.NNET_COMP_conscience);
          %net.trainFcn=cell2mat(obj.DATA.TRAINING_FUNCTIONS(obj.DATA.TRAINING_FUNCTIONS_POS));
          net.trainParam.epochs = obj.DATA.EPOCHS;
          %net = train(net,P);          
          %net.trainParam.goal = obj.DATA.GOAL;
          %net.divideParam.trainRatio=1;
          %net.divideParam.testRatio=0;
          %net.divideParam.valRatio=0;
          net = train(net,P);

          A = sim(net,Test);
          [SP SS AC]=PredictionAlgorithms.calcPerformance(A,T2)
      end
      
      function updateData(obj)
          global h;
          
          obj.DATA.EPOCHS = str2num(get(h.ANN.epochs_edit, 'String'));
          obj.DATA.NNET_COMP_conscience = str2num(get(h.ANN.conscience_learning_rate_edit, 'String'));
          obj.DATA.NNET_COMP_kohonen = str2num(get(h.ANN.kohonen_learning_rate_edit, 'String'));

          %obj.DATA.GOAL = str2num(get(h.ANN.goal_edit, 'String'));
          %obj.DATA.SPREAD_CONSTANT = str2num(get(h.ANN.spread_constant_edit, 'String'));
          
      end
   end
end