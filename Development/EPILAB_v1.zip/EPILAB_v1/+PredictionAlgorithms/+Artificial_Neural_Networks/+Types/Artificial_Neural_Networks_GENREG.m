%Defines the main class and interface of classifiers
classdef Artificial_Neural_Networks_GENREG < handle
   % The following properties can be set only by class methods
   properties
       INTERFACE;
       DATA;
   end
    
   methods
      %Constructor
      function NN = Artificial_Neural_Networks_GENREG(d,UI)
        NN.INTERFACE = UI;
        NN.DATA = d;
      end
      
      function npanel=draw(obj,fpanel)
           global h;
           
           
           npanel=uipanel('Parent',fpanel,'BorderType','none','BorderWidth',0,'Units','Normalized','Visible','on','Position',[0.01,0.01,0.98,0.6]);

           IPOS = 0.55;
           %NOTE: The uicontrols are drawn in a
           %bottom-up fashion

           IPOS = IPOS + 0.2;

           h.ANN.spread_constant_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Spread Constant:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.spread_constant_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.NNET_GENREG_SPREAD),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_EDIT_HEIGHT]);
      end

      function [SP SS AC A] = train(obj,P,T,Test,T2)
          net = newgrnn(P, T, obj.DATA.NNET_GENREG_SPREAD);
          net.trainFcn='trainlm';
          %net.trainParam.epochs = obj.DATA.EPOCHS;
          %net.trainParam.goal = obj.DATA.GOAL;
          %net.divideParam.trainRatio=1;
          %net.divideParam.testRatio=0;
          %net.divideParam.valRatio=0;
          net = train(net,P,T);

          A = sim(net,Test);
          [SP SS AC]=PredictionAlgorithms.calcPerformance(A,T2)
      end
      
      function updateData(obj)
          global h;
          
          %obj.DATA.EPOCHS = str2num(get(h.ANN.epochs_edit, 'String'));
          %obj.DATA.GOAL = str2num(get(h.ANN.goal_edit, 'String'));
          obj.DATA.NNET_GENREG_SPREAD = str2num(get(h.ANN.spread_constant_edit, 'String'));
          
      end
   end
end