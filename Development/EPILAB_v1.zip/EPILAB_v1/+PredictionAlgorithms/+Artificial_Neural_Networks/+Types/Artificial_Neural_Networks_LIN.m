%Defines the main class and interface of classifiers
classdef Artificial_Neural_Networks_LIN < handle
   % The following properties can be set only by class methods
   properties
       INTERFACE;
       DATA;
   end
    
   methods
      %Constructor
      function NN = Artificial_Neural_Networks_LIN(d,UI)
        NN.INTERFACE = UI;
        NN.DATA = d;
      end
      
      function npanel=draw(obj,fpanel)
           global h;
           
           npanel = uipanel('Parent',fpanel,'BorderType','none','BorderWidth',0,'Units','Normalized','Visible','on','Position',[obj.INTERFACE.NNET_PANEL_X,obj.INTERFACE.NNET_PANEL_Y,obj.INTERFACE.NNET_PANEL_WIDTH,obj.INTERFACE.NNET_PANEL_HEIGHT]);

           IPOS = 0.4;
           %NOTE: The uicontrols are drawn in a
           %bottom-up fashion

           IPOS = IPOS + 0.2;
           
           h.ANN.inputdelay_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Input delay vector:','FontSize',10,...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION*2+obj.INTERFACE.DEFAULT_POPUP_WIDTH,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH+0.05,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.inputdelay_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',mat2str(obj.DATA.NNET_LIN_INPUTDELAY),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION+obj.INTERFACE.DEFAULT_POPUP_WIDTH+obj.INTERFACE.DEFAULT_TEXT_WIDTH/2+obj.INTERFACE.DEFAULT_SEPARATION+0.05,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

           h.ANN.performance_function_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Performance function:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.performance_function_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.DATA.PERFORMANCE_FUNCTIONS,'Value',obj.DATA.NNET_LIN_PERFORMANCE_FUNCTIONS_POS,'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_POPUP_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT]);

           IPOS = IPOS + obj.INTERFACE.DEFAULT_POPUP_HEIGHT;

           h.ANN.goal_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Goal:','FontSize',10,...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION*2+obj.INTERFACE.DEFAULT_POPUP_WIDTH,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.goal_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.INTERFACE.DATA.NNET_LIN_GOAL),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION+obj.INTERFACE.DEFAULT_POPUP_WIDTH+obj.INTERFACE.DEFAULT_TEXT_WIDTH/2+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

           h.ANN.learning_rate_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Learning rate:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.learning_rate_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.NNET_LIN_LEARNINGRATE),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_EDIT_HEIGHT]);

           IPOS = IPOS + obj.INTERFACE.DEFAULT_EDIT_HEIGHT;

           h.ANN.epochs_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Epochs:','FontSize',10,...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION*2+obj.INTERFACE.DEFAULT_POPUP_WIDTH,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.epochs_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.NNET_LIN_EPOCHS),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION+obj.INTERFACE.DEFAULT_POPUP_WIDTH+obj.INTERFACE.DEFAULT_TEXT_WIDTH/2+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

           h.ANN.training_function_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Training Function:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.training_function_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.DATA.TRAINING_FUNCTIONS,'Value',obj.DATA.NNET_LIN_TRAINING_FUNCTIONS_POS,'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_POPUP_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT]);
      end

      function [SP SS AC A] = train(obj,P,T,Test,T2)

          net = newlin(P, T, obj.DATA.NNET_LIN_INPUTDELAY, obj.DATA.NNET_LIN.LEARNINGRATE);
          net.trainFcn = cell2mat(obj.DATA.TRAINING_FUNCTIONS(obj.DATA.NNET_LIN_TRAINING_FUNCTIONS_POS));
          net.performFcn = cell2mat(obj.DATA.PERFORMANCE_FUNCTIONS(obj.DATA.NNET_LIN_PERFORMANCE_FUNCTIONS_POS));
          net.trainParam.epochs = obj.DATA.NNET_LIN_EPOCHS;
          net.trainParam.goal = obj.DATA.NNET_LIN_GOAL;
          net = train(net,P,T);

          A = sim(net,Test);
          [SP SS AC]=PredictionAlgorithms.calcPerformance(A,T2)
      end
      
      function updateData(obj)
          global h;
          
          obj.DATA.NNET_LIN_EPOCHS = str2num(get(h.ANN.epochs_edit, 'String'));
          obj.DATA.NNET_LIN_GOAL = str2num(get(h.ANN.goal_edit, 'String'));
          obj.DATA.NNET_LIN_INPUTDELAY = [str2num(get(h.ANN.inputdelay_edit, 'String'))];
          obj.DATA.NNET_LIN_TRAINING_FUNCTIONS_POS = get(h.ANN.training_function_popup, 'Value');
          obj.DATA.NNET_LIN_PERFORMANCE_FUNCTIONS_POS = get(h.ANN.performance_function_popup, 'Value');
          obj.DATA.NNET_LIN_LEARNINGRATE = str2num(get(h.ANN.learning_rate_edit, 'String'));
          
      end
   end
end