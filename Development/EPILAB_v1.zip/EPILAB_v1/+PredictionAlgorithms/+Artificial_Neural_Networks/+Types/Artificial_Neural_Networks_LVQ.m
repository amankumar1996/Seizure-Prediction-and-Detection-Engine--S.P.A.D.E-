%Defines the main class and interface of classifiers
classdef Artificial_Neural_Networks_LVQ < handle
   % The following properties can be set only by class methods
   properties
       INTERFACE;
       DATA;
   end
    
   methods
      %Constructor
      function NN = Artificial_Neural_Networks_LVQ(d,UI)
        NN.INTERFACE = UI;
        NN.DATA = d;
      end
      
      function npanel=draw(obj,fpanel)
           global h;
           
           npanel = uipanel('Parent',fpanel,'BorderType','none','BorderWidth',0,'Units','Normalized','Visible','on','Position',[obj.INTERFACE.NNET_PANEL_X,obj.INTERFACE.NNET_PANEL_Y,obj.INTERFACE.NNET_PANEL_WIDTH,obj.INTERFACE.NNET_PANEL_HEIGHT]);

           IPOS = 0.3;
           %NOTE: The uicontrols are drawn in a
           %bottom-up fashion

           IPOS = IPOS + 0.2;
           
           h.ANN.output_perc_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Output class percentages:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH+0.05,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.output_perc_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',mat2str(obj.DATA.NNET_LVQ_OUTPUT_CLASS),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH+0.1,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');
           
           IPOS = IPOS + obj.INTERFACE.DEFAULT_EDIT_HEIGHT;
           
           h.ANN.hidden_neurons_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Number of hidden neurons:','FontSize',10,...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION*2+obj.INTERFACE.DEFAULT_POPUP_WIDTH,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH+0.05,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.hidden_neurons_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.NNET_LVQ_HIDDENNEURONS),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION+obj.INTERFACE.DEFAULT_POPUP_WIDTH+obj.INTERFACE.DEFAULT_TEXT_WIDTH/2+obj.INTERFACE.DEFAULT_SEPARATION+0.11,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

           h.ANN.performance_function_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Performance function:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.performance_function_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.DATA.PERFORMANCE_FUNCTIONS,'Value',obj.DATA.NNET_LVQ_PERFORMANCE_FUNCTIONS_POS,'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_POPUP_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT]);

           IPOS = IPOS + obj.INTERFACE.DEFAULT_POPUP_HEIGHT;

           h.ANN.goal_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Goal:','FontSize',10,...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION*2+obj.INTERFACE.DEFAULT_POPUP_WIDTH,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.goal_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.INTERFACE.DATA.NNET_LVQ_GOAL),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION+obj.INTERFACE.DEFAULT_POPUP_WIDTH+obj.INTERFACE.DEFAULT_TEXT_WIDTH/2+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

           h.ANN.learning_rate_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Learning rate:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.learning_rate_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.NNET_LVQ_LEARNINGRATE),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_EDIT_HEIGHT]);

           IPOS = IPOS + obj.INTERFACE.DEFAULT_EDIT_HEIGHT;

           h.ANN.epochs_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Epochs:','FontSize',10,...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION*2+obj.INTERFACE.DEFAULT_POPUP_WIDTH,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.epochs_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.NNET_LVQ_EPOCHS),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION+obj.INTERFACE.DEFAULT_POPUP_WIDTH+obj.INTERFACE.DEFAULT_TEXT_WIDTH/2+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

           h.ANN.learning_function_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Learning Function:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.learning_function_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.DATA.NNET_LVQ_LEARNING_FUNCTIONS,'Value',obj.DATA.NNET_LVQ_LEARNING_FUNCTIONS_POS,'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_POPUP_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT]);
      end

      function [SP SS AC A] = train(obj,P,T,Test,T2)

          net = newlvq(P, obj.DATA.NNET_LVQ_HIDDENNEURONS, obj.DATA.NNET_LVQ_OUTPUT_CLASS, obj.DATA.NNET_LVQ_LEARNINGRATE, cell2mat(obj.DATA.LEARNING_FUNCTIONS(obj.DATA.NNET_LVQ_LEARNING_FUNCTIONS_POS)));
          net.performFcn = cell2mat(obj.DATA.PERFORMANCE_FUNCTIONS(obj.DATA.NNET_LVQ_PERFORMANCE_FUNCTIONS_POS));
          net.trainParam.epochs = obj.DATA.NNET_LVQ_EPOCHS;
          net.trainParam.goal = obj.DATA.NNET_LVQ_GOAL;
          net = train(net,P,T);

          A = sim(net,Test);
          [SP SS AC]=PredictionAlgorithms.calcPerformance(A,T2)
      end
      
      function updateData(obj)
          global h;
          
          obj.DATA.NNET_LVQ_EPOCHS = str2num(get(h.ANN.epochs_edit, 'String'));
          obj.DATA.NNET_LVQ_GOAL = str2num(get(h.ANN.goal_edit, 'String'));
          obj.DATA.NNET_LVQ_HIDDENNEURONS = str2num(get(h.ANN.hidden_neurons_edit, 'String'));
          obj.DATA.NNET_LVQ_LEARNING_FUNCTIONS_POS = get(h.ANN.learning_function_popup, 'Value');
          obj.DATA.NNET_LVQ_PERFORMANCE_FUNCTIONS_POS = get(h.ANN.performance_function_popup, 'Value');
          obj.DATA.NNET_LVQ_LEARNINGRATE = str2num(get(h.ANN.learning_rate_edit, 'String'));
          obj.DATA.NNET_LVQ_OUTPUT_CLASS = [str2num(get(h.ANN.output_perc_edit, 'String'))]
          
      end
   end
end