%Defines the main class and interface of classifiers
classdef Artificial_Neural_Networks_PERCEPTRON < handle
   % The following properties can be set only by class methods
   properties
       INTERFACE;
       DATA;
   end
    
   methods
      %Constructor
      function NN = Artificial_Neural_Networks_PERCEPTRON(d,UI)
        NN.INTERFACE = UI;
        NN.DATA = d;
      end
      
      function npanel=draw(obj,fpanel)
           global h;           
           
           npanel = uipanel('Parent',fpanel,'BorderType','none','BorderWidth',0,'Units','Normalized','Visible','on','Position',[obj.INTERFACE.NNET_PANEL_X,obj.INTERFACE.NNET_PANEL_Y,obj.INTERFACE.NNET_PANEL_WIDTH,obj.INTERFACE.NNET_PANEL_HEIGHT]);

           IPOS = 0.5;
           %NOTE: The uicontrols are drawn in a
           %bottom-up fashion

           IPOS = IPOS + 0.2;


           h.ANN.goal_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Goal:','FontSize',10,...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION*2+obj.INTERFACE.DEFAULT_POPUP_WIDTH,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.goal_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.INTERFACE.DATA.GOAL),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION+obj.INTERFACE.DEFAULT_POPUP_WIDTH+obj.INTERFACE.DEFAULT_TEXT_WIDTH/2+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

           h.ANN.learning_function_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Learning function:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.learning_function_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.DATA.LEARNING_FUNCTIONS_PERCP,'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_POPUP_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT]);

           IPOS = IPOS + obj.INTERFACE.DEFAULT_POPUP_HEIGHT;

           h.ANN.epochs_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Epochs:','FontSize',10,...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION*2+obj.INTERFACE.DEFAULT_POPUP_WIDTH,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.epochs_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.INTERFACE.DATA.EPOCHS),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION+obj.INTERFACE.DEFAULT_POPUP_WIDTH+obj.INTERFACE.DEFAULT_TEXT_WIDTH/2+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

           h.ANN.transfer_function_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Training Function:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.transfer_function_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.DATA.TRANSFER_FUNCTIONS_PERCP,'Value',obj.DATA.TRANSFER_FUNCTIONS_POS,'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_POPUP_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT]);
      end

      function [SP SS AC A] = train(obj,P,T,Test,T2)          
          
          maxmin = [];
          for i=1:length(P(:,1))
              maxmin(i,:) = [0 1];
          end
          
          net = newp(maxmin, length(T(:,1)), cell2mat(obj.DATA.TRANSFER_FUNCTIONS_PERCP(obj.DATA.TRANSFER_FUNCTIONS_POS)),cell2mat(obj.DATA.LEARNING_FUNCTIONS_PERCP(obj.DATA.LEARNING_FUNCTIONS_POS)));
          %net.trainFcn=cell2mat(obj.DATA.TRAINING_FUNCTIONS(obj.DATA.TRAINING_FUNCTIONS_POS));
          %net.adaptFcn=cell2mat(obj.DATA.LEARNING_FUNCTIONS(obj.DATA.LEARN
          %ING_FUNCTIONS_POS));           %default = 'learngdm' aparentemente esta fun��o nao produz nenhum diferen�a porque s� � usada com o m�todo de treino adapt         
          net.trainParam.epochs = obj.DATA.EPOCHS;
          net.trainParam.goal = obj.DATA.GOAL;
          net = train(net,P,T);

          A = sim(net,Test);
          [SP SS AC]=PredictionAlgorithms.calcPerformance(A,T2)
      end
      
      function updateData(obj)
          global h;
          
          obj.DATA.EPOCHS = str2num(get(h.ANN.epochs_edit, 'String'));
          obj.DATA.GOAL = str2num(get(h.ANN.goal_edit, 'String'));
          obj.DATA.TRANSFER_FUNCTIONS_POS = get(h.ANN.transfer_function_popup, 'Value');
          obj.DATA.LEARNING_FUNCTIONS_POS = get(h.ANN.learning_function_popup, 'Value');
          
      end
   end
end