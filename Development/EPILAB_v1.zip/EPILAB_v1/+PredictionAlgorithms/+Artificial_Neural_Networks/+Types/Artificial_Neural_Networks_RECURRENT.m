%Defines the main class and interface of classifiers
classdef Artificial_Neural_Networks_RECURRENT < handle
   % The following properties can be set only by class methods
   properties
       INTERFACE;
       DATA;
   end
    
   methods
      %Constructor
      function NN = Artificial_Neural_Networks_RECURRENT(d,UI)
        NN.INTERFACE = UI;
        NN.DATA = d;
      end
      
      function npanel=draw(obj,fpanel)
           global h;          
           
           npanel = uipanel('Parent',fpanel,'BorderType','none','BorderWidth',0,'Units','Normalized','Visible','on','Position',[obj.INTERFACE.NNET_PANEL_X,obj.INTERFACE.NNET_PANEL_Y,obj.INTERFACE.NNET_PANEL_WIDTH,obj.INTERFACE.NNET_PANEL_HEIGHT]);

           IPOS = 0.15;
           %NOTE: The uicontrols are drawn in a
           %bottom-up fashion

           IPOS = IPOS + 0.2;

           layers_panel_size = 0.4;
           layers_panel = uipanel('Parent',npanel,'Title','Properties for: ','Units','Normalized','FontSize',10,...
               'Position',[0,IPOS,0.8,layers_panel_size]);

           IPOS2 = 0.2;

           %BEGIN: layers_panel

                h.ANN.transfer_function_text = uicontrol('Parent',layers_panel,'Style','text','Units','Normalized','String','Transfer function:','FontSize',10,...
                   'Position',[0,IPOS2,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT/layers_panel_size]);
                h.ANN.transfer_function_popup = uicontrol('Parent',layers_panel,'Style','popupmenu','Units','Normalized','String',obj.INTERFACE.DATA.TRANSFER_FUNCTIONS,'BackgroundColor','white','Callback',{@(src,event)obj.INTERFACE.layerX_Callback(src,event)},...
                   'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS2,obj.INTERFACE.DEFAULT_POPUP_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT/layers_panel_size]);

                IPOS2 = IPOS2 + obj.INTERFACE.DEFAULT_POPUP_HEIGHT/layers_panel_size;

                h.ANN.number_neurons_text = uicontrol('Parent',layers_panel,'Style','text','Units','Normalized','String','Number of Neurons:','FontSize',10,...
                   'Position',[0,IPOS2,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT/layers_panel_size]);
                h.ANN.number_neurons_edit = uicontrol('Parent',layers_panel,'Style','edit','Units','Normalized','String',num2str(obj.INTERFACE.DATA.layers(1,1)),'BackgroundColor','white','Callback',{@(src,event)obj.INTERFACE.layerX_Callback(src,event)},...
                   'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS2,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_EDIT_HEIGHT/layers_panel_size]);                                

               IPOS2 = IPOS2 + obj.INTERFACE.DEFAULT_EDIT_HEIGHT/layers_panel_size + 0.1;

               h.ANN.layer_x_popup = uicontrol('Parent',layers_panel,'Style','popupmenu','Units','Normalized','String',{'Layer 1','Layer 2'},'BackgroundColor','white','Callback',{@(src,event)obj.INTERFACE.layerSelection_Callback(src,event)},...
                'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS2,obj.INTERFACE.DEFAULT_POPUP_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT/layers_panel_size]);
           %END: layers_panel

           IPOS = IPOS + layers_panel_size+0.05;

           h.ANN.number_layers_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Number of Layers:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.number_layers_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.NUMBER_LAYERS),'BackgroundColor','white','Callback',{@(src,event)obj.INTERFACE.layersDefinition_Callback(src,event)},...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_EDIT_HEIGHT]); 

           IPOS = IPOS + obj.INTERFACE.DEFAULT_EDIT_HEIGHT;

           h.ANN.performance_function_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Performance function:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.performance_function_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',{'MSE', 'MSEREG', 'SSE'},'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_POPUP_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT]);

           IPOS = IPOS + obj.INTERFACE.DEFAULT_POPUP_HEIGHT;

           h.ANN.goal_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Goal:','FontSize',10,...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION*2+obj.INTERFACE.DEFAULT_POPUP_WIDTH,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.goal_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.INTERFACE.DATA.GOAL),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION+obj.INTERFACE.DEFAULT_POPUP_WIDTH+obj.INTERFACE.DEFAULT_TEXT_WIDTH/2+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

           h.ANN.learning_function_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Learning function:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.learning_function_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.DATA.LEARNING_FUNCTIONS,'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_POPUP_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT]);

           IPOS = IPOS + obj.INTERFACE.DEFAULT_POPUP_HEIGHT;

           h.ANN.epochs_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Epochs:','FontSize',10,...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION*2+obj.INTERFACE.DEFAULT_POPUP_WIDTH,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.epochs_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.INTERFACE.DATA.EPOCHS),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION+obj.INTERFACE.DEFAULT_POPUP_WIDTH+obj.INTERFACE.DEFAULT_TEXT_WIDTH/2+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

           h.ANN.training_function_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Training Function:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.training_function_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.INTERFACE.DATA.TRAINING_FUNCTIONS,'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_POPUP_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT]);
      end

      function [SP SS AC A] = train(obj,P,T,Test,T2)
          net = newlrn(P, T, obj.DATA.layers(1:end-1,1)',obj.DATA.TRANSFER_FUNCTIONS(obj.DATA.layers(1:end-1,2)'));
          net.trainFcn=cell2mat(obj.DATA.TRAINING_FUNCTIONS(obj.DATA.TRAINING_FUNCTIONS_POS));
          net.adaptFcn=cell2mat(obj.DATA.LEARNING_FUNCTIONS(obj.DATA.LEARNING_FUNCTIONS_POS));           %default = 'learngdm' aparentemente esta fun��o nao produz nenhum diferen�a porque s� � usada com o m�todo de treino adapt         
          net.trainParam.epochs = obj.DATA.EPOCHS;
          net.trainParam.goal = obj.DATA.GOAL;
          net.divideParam.trainRatio=1;
          net.divideParam.testRatio=0;
          net.divideParam.valRatio=0;
          net = train(net,P,T);

          A = sim(net,Test);
          [SP SS AC]=PredictionAlgorithms.calcPerformance(A,T2)
      end
      
      function updateData(obj)
          global h;
          
          obj.DATA.EPOCHS = str2num(get(h.ANN.epochs_edit, 'String'));
          obj.DATA.GOAL = str2num(get(h.ANN.goal_edit, 'String'));
          obj.DATA.TRAINING_FUNCTIONS_POS = get(h.ANN.training_function_popup, 'Value');
          obj.DATA.LEARNING_FUNCTIONS_POS = get(h.ANN.learning_function_popup, 'Value');
          
      end
   end
end