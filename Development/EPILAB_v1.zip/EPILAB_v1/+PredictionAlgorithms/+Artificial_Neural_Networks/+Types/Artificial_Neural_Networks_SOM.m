%Defines the main class and interface of classifiers
classdef Artificial_Neural_Networks_SOM < handle
   % The following properties can be set only by class methods
   properties
       INTERFACE;
       DATA;
   end
    
   methods
      %Constructor
      function NN = Artificial_Neural_Networks_SOM(d,UI)
        NN.INTERFACE = UI;
        NN.DATA = d;
      end
      
      function npanel=draw(obj,fpanel)
           global h;
           
           npanel = uipanel('Parent',fpanel,'BorderType','none','BorderWidth',0,'Units','Normalized','Visible','on','Position',[obj.INTERFACE.NNET_PANEL_X,obj.INTERFACE.NNET_PANEL_Y,obj.INTERFACE.NNET_PANEL_WIDTH,obj.INTERFACE.NNET_PANEL_HEIGHT]);

           IPOS = 0.35;
           %NOTE: The uicontrols are drawn in a
           %bottom-up fashion

           IPOS = IPOS + 0.2;

           h.ANN.ordering_phase_learning_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Ordering phase learning rate:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.ordering_phase_learning_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.ORD_PHASE_LEARNING),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_EDIT_HEIGHT]); 

           IPOS = IPOS + obj.INTERFACE.DEFAULT_EDIT_HEIGHT;
           
           h.ANN.dimensionsmap_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Dimensions of map:','FontSize',10,...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION*2+obj.INTERFACE.DEFAULT_POPUP_WIDTH,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH+0.05,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.dimensionsmap_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',mat2str(obj.DATA.DIMENSIONS_MAP),'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION+obj.INTERFACE.DEFAULT_POPUP_WIDTH+obj.INTERFACE.DEFAULT_TEXT_WIDTH/2+obj.INTERFACE.DEFAULT_SEPARATION+0.05,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

           h.ANN.neighborhood_distance_function_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Neighborhood distance:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.neighborhood_distance_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',obj.DATA.NEIGH_DISTANCE,'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_EDIT_HEIGHT]);

           IPOS = IPOS + obj.INTERFACE.DEFAULT_POPUP_HEIGHT;

           h.ANN.tuning_phase_learning_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Tuning phase learning rate:','FontSize',10,...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION*2+obj.INTERFACE.DEFAULT_POPUP_WIDTH,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.tuning_phase_learning_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.TUNING_PHASE_LEARNING),'BackgroundColor','white',...
               'Position',[0.12+obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION+obj.INTERFACE.DEFAULT_POPUP_WIDTH+obj.INTERFACE.DEFAULT_TEXT_WIDTH/2+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

           h.ANN.topology_function_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Topology Function:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.topology_function_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.DATA.TOPOLOGY_FUNCTIONS,'Value',obj.DATA.TOPOLOGY_FUNCTIONS_POS,'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_POPUP_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT]);

           IPOS = IPOS + obj.INTERFACE.DEFAULT_POPUP_HEIGHT;

           h.ANN.ordering_phase_steps_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Ordering phase steps:','FontSize',10,...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION*2+obj.INTERFACE.DEFAULT_POPUP_WIDTH,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
           h.ANN.ordering_phase_steps_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.INTERFACE.DATA.ORD_PHASE_STEPS),'BackgroundColor','white',...
               'Position',[0.12+obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION+obj.INTERFACE.DEFAULT_POPUP_WIDTH+obj.INTERFACE.DEFAULT_TEXT_WIDTH/2+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_EDIT_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

           h.ANN.distance_function_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Distance function:','FontSize',10,...
               'Position',[0,IPOS,obj.INTERFACE.DEFAULT_TEXT_WIDTH,obj.INTERFACE.DEFAULT_TEXT_HEIGHT]);
           h.ANN.distance_function_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.INTERFACE.DATA.DISTANCE_FUNCTIONS,'Value',obj.INTERFACE.DATA.DISTANCE_FUNCTIONS_POS,'BackgroundColor','white',...
               'Position',[obj.INTERFACE.DEFAULT_TEXT_WIDTH+obj.INTERFACE.DEFAULT_SEPARATION,IPOS,obj.INTERFACE.DEFAULT_POPUP_WIDTH,obj.INTERFACE.DEFAULT_POPUP_HEIGHT]);
      end

      function [SP SS AC A] = train(obj,P,T,Test,T2)
          
          net = newsom(P, obj.DATA.DIMENSIONS_MAP, cell2mat(obj.DATA.TOPOLOGY_FUNCTIONS(obj.DATA.TOPOLOGY_FUNCTIONS_POS)), ...
              cell2mat(obj.DATA.DISTANCE_FUNCTIONS(obj.DATA.DISTANCE_FUNCTIONS_POS)), obj.DATA.ORD_PHASE_LEARNING, obj.DATA.ORD_PHASE_STEPS, obj.DATA.TUNING_PHASE_LEARNING, obj.DATA.NEIGH_DISTANCE);
          
          %net.trainParam.epochs = 5;
          
          net = train(net,P);

          A = sim(net,Test);
          
          [SP SS AC]=PredictionAlgorithms.calcPerformance(A,T2)
      end
      
      function updateData(obj)
          global h;
          
          obj.DATA.ORD_PHASE_LEARNING = str2double(get(h.ANN.ordering_phase_learning_edit, 'String'));
          obj.DATA.ORD_PHASE_STEPS = str2double(get(h.ANN.ordering_phase_steps_edit, 'String'));
          obj.DATA.TUNING_PHASE_LEARNING = str2double(get(h.ANN.tuning_phase_learning_edit, 'String'));
          obj.DATA.NEIGH_DISTANCE = str2double(get(h.ANN.neighborhood_distance_edit, 'String'));
          obj.DATA.DIMENSIONS_MAP = [str2double(get(h.ANN.dimensionsmap_edit, 'String'))];
          obj.DATA.DISTANCE_FUNCTIONS_POS = get(h.ANN.distance_function_popup, 'Value');
          obj.DATA.TOPOLOGY_FUNCTIONS_POS = get(h.ANN.topology_function_popup, 'Value');
          
      end
   end
end