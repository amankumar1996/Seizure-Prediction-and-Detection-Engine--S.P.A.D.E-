%This class contains the functions necessary to train the artificial neural networks
classdef Artificial_Neural_Networks_Functions
    % The following properties can be set only by class methods
    properties
        DATA;
    end
    
    methods
        %Constructor
        function obj = Artificial_Neural_Networks_Functions(data)
            obj.DATA = data;
        end
        
        function [SP SS AC A T2]=train(obj, net, train_type)
            global h;
            
            val=get(h.ANN.datasets_list,'Value');
            
            disp(obj.DATA.DATA_SETS_PATHS(val));
            
            %BEGIN - Datasets protection
            f = '';
            a = obj.DATA.FEATURES(val);
            
            aux = zeros(1,length(a));
            
            for i=1:length(a)
                aux(i) = sum(a{i});
            end
            
            
            if length(a)>1 %If the datasets hasn't the same number of features
                for i=1:length(aux)
                    f = strcat(f,'aux(',num2str(i),'),');
                end
                
                e = strcat('isequal(',f(1:end-1),')');
                
                if ~eval(e)
                    errordlg('Select in all datasets choosen the same number of features.');
                    SP = 0; SS = 0; AC = 0;
                    return;
                end
            end
            
            if sum(aux(i))==0 %If none feature was selected
                errordlg('Select at least one feature/dataset.');
                SP = 0; SS = 0; AC = 0;
                return;
            end
            %END - Datasets protection
            
            obj.DATA.DATA_SETS_PATHS(val)
            train_type
            switch char(train_type) %TODO: Alterar o readEpi para que funcione com o study
%                 case obj.DATA.TRAIN_TYPE_MERGE7030
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'i');
%                 case obj.DATA.TRAIN_TYPE_MERGE_1
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'ii');
%                 case obj.DATA.TRAIN_TYPE_MERGE
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'iii');
                case obj.DATA.TRAIN_TYPE_MANUAL
                    [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'i');
%                 case obj.DATA.TRAIN_TYPE_MANUAL_PREV
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'v');
                case obj.DATA.TRAIN_TYPE_FROM_FILE
                    [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'ii');
%                 case obj.DATA.TRAIN_TYPE_EQUAL
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'vii');
            end
            
            %if(h.ANN.LoadingError==0)
            
            %Train only with the selected features
           
            %P=P(a{1}==1,:);
            %Test=Test(a{1}==1,:);
            
            [SP SS AC A] = net.train(P,T,Test,T2);
            
%             size(A)
%             
%             A=real2th(A',[obj.DATA.NORMAL_STATE obj.DATA.PRE_ICTAL_STATE obj.DATA.ICTAL_STATE obj.DATA.POS_ICTAL_STATE]);
%             
%             
%             [SP SS AC]=calcPerformance(obj,A,T2)
%             obj.DATA.SP=SP;
%             obj.DATA.SS=SS;
%             obj.DATA.AC=AC;
%             A=A';
%             obj.DATA.A=A;
%             obj.DATA.T2=T2;
%             
%             
%             
%             %obj.DATA.firing_power_alarm=0.5;
%             
%             
%             
% %                A2 = zeros(length(T2),1);
% %                for i=1:length(T2) % Convert the A into a 1,2,3,4 format
% %                     aux=max(A(:,i));
% %                     A2(i) = find(A(:,i)==max(A(:,i)));
% % 
% %                     if(aux > 0) %Allow a more detailed plot
% %                       A2(i) = A2(i) + (aux-1);
% %                     else
% %                       A2(i) = A2(i) + (aux+1);
% %                     end    
% %                end
%                
%                A2=real2th(A',[obj.DATA.NORMAL_STATE obj.DATA.PRE_ICTAL_STATE obj.DATA.ICTAL_STATE obj.DATA.POS_ICTAL_STATE]);
%                
%                
%                
%                
%                
%                [out,tint,time_out,tar]=class2alarm(obj.DATA.test_time_vec,A2,T2,obj.DATA.pictal_delta,obj.DATA.PRE_ICTAL_STATE,obj.DATA.pAcq,obj.DATA.firing_power_alarm);
%                [SS_AL,FPR,hours_estim,nseiz]=eval_results_alarm(out,tar);
%                
%                
%                
%                obj.DATA.SS_AL=SS_AL;
%                obj.DATA.FPR=FPR;
%                obj.DATA.TIME_AL=time_out;
%                obj.DATA.OUT_AL=out;
%                obj.DATA.TAR_AL=tar;
               
            
            
            
            %            else
            %                SS = NaN; SP = NaN; AC = NaN; A = 0; T2 = 0;
            %            end
        end
        
        %function [P T Test T2] = readEpi( path, type)
        %
        %Example: [P T Test T2] = readEpi({'../data/pac2.xls','../data/pac10.xls'},'ii');
        %
        %Read n xls files, this read depend on type:
        %
        %   type = 'i' > Merge all the files in a single matrix, in each 3 one is
        %   for test (P = 70%, Test=30%).
        %
        %   type = 'ii' > Merge all the files in a single matrix (P), excepting the last
        %   that is the Test matrix.
        %
        %   type = 'iii' > Merge all the files in a single matrix (P), the last one
        %   is the Test matrix
        %
        %   type = 'iv' > The last seizure is for testing the reamining ones for
        %   training
        %
        
        
        function [P T Test T2] = readEpi(obj, path, type)
            global h;
            switch(type)
                
%                 case 'i'
%                     
%                     %0. Read and normalize
%                     m=readNorm(obj, path);
%                     
%                     %1. Create Test matrix (Test)
%                     Test=m(1:3:end,:);
%                     m(1:3:end,:)=[];
%                     
%                     %2. Create the target matrix (T)
%                     T=zeros(4,length(m));
%                     for i = 1:length(m),
%                         n = m(i,1);
%                         T(n,i)=1;
%                     end
%                     
%                     %3. Create the target for Test (T2)
%                     T2=Test(:,1);
%                     
%                     %4. Create and transpose P
%                     P=m(:,2:end);
%                     P=P';
%                     
%                     %5. Clean and transpose Test
%                     Test=Test(:,2:end);
%                     Test=Test';
%                     
%                     
%                 case 'ii'
%                     %0. Read and normalize
%                     m=readNorm(obj, path(1:(end-1)));
%                     Test=readNorm(obj, path(end));
%                     
%                     %1. Create the target matrix (T)
%                     T=zeros(4,length(m));
%                     for i = 1:length(m),
%                         n = m(i,1);
%                         T(n,i)=1;
%                     end
%                     
%                     %2. Create the target for Test (T2)
%                     T2=Test(:,1);
%                     
%                     %3. Create and transpose P
%                     P=m(:,2:end);
%                     P=P';
%                     
%                     %4. Clean and transpose Test
%                     Test=Test(:,2:end);
%                     Test=Test';
%                     
%                 case 'iii'
%                     %0. Read and normalize
%                     m=readNorm(obj, path);
%                     Test=readNorm(obj, path(end));
%                     
%                     %1. Create the target matrix (T)
%                     T=zeros(4,length(m));
%                     for i = 1:length(m),
%                         n = m(i,1);
%                         T(n,i)=1;
%                     end
%                     
%                     %2. Create the target for Test (T2)
%                     T2=Test(:,1);
%                     
%                     %3. Create and transpose P
%                     P=m(:,2:end);
%                     P=P';
%                     
%                     %4. Clean and transpose Test
%                     Test=Test(:,2:end);
%                     Test=Test';
                    
                case 'i'
                    %select data by visual inspection of the features | create feature interface
                    
                    
                    
                    par_file=fullfile(obj.DATA.STUDY.workspace_path,'train_cache','last_man_data_sets.mat');
                    pictal_delta=obj.DATA.PRE_ICTAL_TIME;
                    if exist(par_file,'file')
                        disp('last man exists')
                        dl=load(par_file)
                        sel_feat=dl.sel_feat
                        low_pass_stat=dl.low_pass_stat;
                        low_cut_off=dl.low_cut_off;
                        %prev_pictal=dl.pictal_delta;
                        %equal_class=dl.equal_class;
                        
                        %prev_pictal=dl.i;
                    else
                        disp('last man do not exists')
                        sel_feat=1;
                        low_pass_stat=0;
                        equal_class=0;
                        low_cut_off=0.1;
                        %prev_pictal=obj.DATA.PRE_ICTAL_TIME;
                    end
                    d_selection = MultiFeatPlot(obj.DATA.STUDY);
                    d_selection.get_data_sets_idx(sel_feat,low_pass_stat,low_cut_off,pictal_delta);
                    
                    uiwait();
                    
                    %dataset selection 
                    try
                        [dat_train_time_start] = d_selection.data_sets.train.start*60; %time stamp minutes - seconds                    
                        [dat_train_time_end] = d_selection.data_sets.train.end*60; %time stamp minutes - seconds
                    catch
                        dat_train_time_start=dl.dat_train_time_start;
                        dat_train_time_end=dl.dat_train_time_end;
                    end
                    
                    try
                        [dat_test_time_start] = d_selection.data_sets.test.start*60; %time stamp minutes - seconds
                        [dat_test_time_end] = d_selection.data_sets.test.end*60; %time stamp minutes - seconds
                     catch
                        dat_test_time_start=dl.dat_test_time_start;
                        dat_test_time_end=dl.dat_test_time_end;
                    end
                    
                    
%                     try
%                          [pictal_delta] = d_selection.data_sets.preictal*60 %time stamp minutes - seconds
%                     
%                          %[pictal_time_end] = d_selection.data_sets.preictal.end*60; %time stamp minutes - seconds
%                      
%                          %pictal_delta=pictal_time_end-pictal_time_start;
%                          obj.DATA.PRE_ICTAL_TIME=pictal_delta;
%                      catch
%                          obj.DATA.PRE_ICTAL_TIME=dl.pictal_delta;
%                          pictal_delta=dl.pictal_delta;
%                     end
%                      obj.DATA.pictal_delta=pictal_delta;
                     
                    
                    
                    try
                          equal_class=d_selection.equal_class; 
                    
                         
                     catch
                         equal_class=dl.equal_class; 
                    end
                    
                    try
                          low_pass_stat=d_selection.low_pass_stat; 
                    
                         
                     catch
                         low_pass_stat=dl.low_pass_stat;
                     end
                     
                    
                    
%                      if pictal_delta<obj.DATA.PRE_ICTAL_TIME
%                        pictal_delta=obj.DATA.PRE_ICTAL_TIME;
%                      end
                    
                    
                    p_acq = obj.DATA.STUDY.dataset.results.parameterAcq;
                    obj.DATA.pAcq=p_acq;
                    
                    
                    dat_train_time_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_train_time_start/p_acq))*p_acq);             
                    dat_train_time_start_idx =dat_train_time_start_idx(1);
                    
                    dat_train_time_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_train_time_end/p_acq))*p_acq);
                    dat_train_time_end_idx = dat_train_time_end_idx(1);
                    
                    dat_test_time_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_test_time_start/p_acq))*p_acq);
                    
                    dat_test_time_start_idx = dat_test_time_start_idx(1);
                    
                    
                    dat_test_time_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_test_time_end/p_acq))*p_acq);
                    dat_test_time_end_idx =dat_test_time_end_idx(1);
                    
                    sel_feat=d_selection.select_feat
                    sel_feat_names=d_selection.select_feat_names;
                    low_pass_stat=d_selection.low_pass_stat;
                    low_cut_off=d_selection.low_cut_off;
                    parameterAcq=d_selection.parameterAcq;
                    equal_class=d_selection.equal_class;
                    evts=obj.DATA.STUDY.dataset.results.feat_events;
                    ev_struct=evts;
                    
                    
                    
                    
                    
                    save(fullfile(obj.DATA.STUDY.workspace_path,'train_cache','last_man_data_sets.mat'),'dat_train_time_start','dat_train_time_end','dat_test_time_start','dat_test_time_end','pictal_delta','dat_train_time_start_idx','dat_train_time_end_idx',...
                        'dat_test_time_start_idx','dat_test_time_end_idx','sel_feat','sel_feat_names','low_pass_stat','low_cut_off','parameterAcq','equal_class','ev_struct')
                   
                    
                    
                    
%                     disp(['selected features:',num2str(d_selection.select_feat)])
%                     
%                     set(h.ANN.features_list,'Value',d_selection.select_feat)
%                     
                    

                    train_d_matrix=[];
                    test_d_matrix=[];
                    
                    if obj.DATA.STUDY.from_raw==0%Get features from feature file
                    
                    
                    
                    n_loaded_files=size(obj.DATA.STUDY.dataset.file,2);
                    
                    
                    
                    act_tot_feat=0;
                    start_feat_idx=find(d_selection.select_feat>0);
                    
                    
                    d_selection.select_feat
                    
                    
                    for k=1:n_loaded_files

                        f_path = fullfile(obj.DATA.STUDY.dataset.file(k).path,...
                            obj.DATA.STUDY.dataset.file(k).filename);
                        
                        file_name=obj.DATA.STUDY.dataset.file(k).filename;


                        

                        feat_bin_o = feat_bin_file(f_path);

                        stop_feat_idx=find(d_selection.select_feat<=(act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features)));

                        act_feat_idx=intersect(start_feat_idx,stop_feat_idx);

                        start_feat_idx=find(d_selection.select_feat>act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features));

                        act_feat=d_selection.select_feat(act_feat_idx)-act_tot_feat;
                        
                        act_tot_feat=act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features);
                       

                        % function get_matrix
                       
                        
                        
                        train_d_matrix = [train_d_matrix,feat_bin_o.file2matrix(dat_train_time_start_idx, dat_train_time_end_idx,act_feat)];
                        [te_data,time]=feat_bin_o.file2matrix(dat_test_time_start_idx, dat_test_time_end_idx,act_feat);
                        test_d_matrix = [test_d_matrix,te_data];
                        

                        feat_bin_o.delete();
                        clear feat_bin_o;
                       

                    end
                    
                    %obj.DATA.test_time_vec=time;
                    
                    
                    
%                     if ~isempty(oth_feat_idx)%Look for other features located in other files
%                         
%                         f_path_oth = fullfile(obj.DATA.STUDY.dataset.file(f).path,...
%                         obj.DATA.STUDY.dataset.file(f).filename);
%                         feat_bin_o_oth = feat_bin_file(f_path_oth);
%                         
%                         
%                     
%                         oth_feat_curr_idx=intersect(oth_feat_idx,oth_feat_sup_idx);
%                         
%                         oth_feat=d_selection.select_feat(oth_feat_idx)-(feat_bin_o.a_n_chan*feat_bin_o.a_n_features);
%                    
%                         
%                         
%                         train_d_matrix =[train_d_matrix, feat_bin_o_oth.file2matrix(dat_train_time_start_idx, dat_train_time_end_idx)];
%                         test_d_matrix = [test_d_matrix,feat_bin_o_oth.file2matrix(dat_test_time_start_idx, dat_test_time_end_idx)];
%                         
%                     end
                    %evts=obj.DATA.STUDY.dataset.results.feat_events;
%                     train_target = build_target(obj.DATA.STUDY.dataset.file(1).data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
%                             dat_train_time_end_idx,pictal_delta); % train data_set
%                         test_target = build_target(obj.DATA.STUDY.dataset.file(1).data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
%                             dat_test_time_end_idx,pictal_delta); % test data_set
                    
                    disp(['Tamanho:',num2str(size(train_d_matrix))])
                    else%Get features from Epilab structure
                        
                        feat_types=fieldnames(obj.DATA.STUDY.dataset.results.featureExtractionMethods);
                        for ft=1:size(sel_feat_names,2)
                            for typ=1:size(feat_types,1)
                                %sel_feat_names{ft}
                                
                                tot_feats={fieldnames(h.study.dataset.results.featureExtractionMethods.(feat_types{typ}).c_)};
                                
                                tot_feats=tot_feats{1};
                                
                                for tt=1:size(tot_feats,1)
                                %    disp(tot_feats{tt})%,' with ',sel_feat_names{ft}])
                                    if strcmp(sel_feat_names{ft},tot_feats{tt,1})
                                    mat_data=h.study.dataset.results.featureExtractionMethods.(feat_types{typ}).c_.(tot_feats{tt,1});
                           
                                    
                                    train_d_matrix = [train_d_matrix,mat_data(dat_train_time_start_idx:dat_train_time_end_idx-1)'];
                                    test_d_matrix = [test_d_matrix,mat_data(dat_test_time_start_idx:dat_test_time_end_idx-1)'];
                                    end
                                    
                                %end
                            end
                        end
                        
                        
                        end
                        
                        %evts=d_selection.ev_struct;
%                         train_target = build_target(d_selection.ev_struct,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
%                             dat_train_time_end_idx,pictal_delta); % train data_set
%                         test_target = build_target(d_selection.ev_struct,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
%                             dat_test_time_end_idx,pictal_delta); % test data_set
                        
                    end
                    
                    
                    obj.DATA.test_time_vec=obj.DATA.STUDY.dataset.results.glbTime(dat_test_time_start_idx:dat_test_time_end_idx-1);
% % % %                     fclose(feat_bin_o.fd); %%%% TODO NAO CONSIGO
% FECHAR...propriedade protected na classe

                    %% 2. Create/Add target 
                    
                     %  target = build_target(events, time_vector, start_idx, end_idx, PREICTAL_TIME, EARLY_DETECTION_PERIOD, P_ACQ, NUM_CL)

                       
                        
% %                         save targets.mat train_target test_target
                    
                    
% % % %                     train_target = buildTarget(obj, dat_train_time_start_idx, dat_train_time_end_idx); % train data_set
% % % %                     test_target = buildTarget(obj, dat_test_time_start_idx, dat_test_time_end_idx); % test data_set
                    
            
                    
                    
                     
                    
                    %% 3. Create Test matrix (Test) and Train matrix (P)
                    
                    P  = train_d_matrix;
                    
                    %P=P(:,d_selection.select_feat);
                    %T = train_target';
                    Test = test_d_matrix;
                    %Test=Test(:,d_selection.select_feat);
                    %T2 = test_target';
                    
                    P=rep_nan(P,0);
                    
%                     [idx_r_tr,idx_c_tr,v]=find(isnan(P));
%                     
%                     nc=size(idx_r_tr)
%                     
%                     P(idx_n_tr,:)=[];
%                    
                    
                    Test=rep_nan(Test,0);
%                     idx_n_te=find(isnan(Test));
%                     
%                     Test(idx_n_te,:)=[];
                   
                    
                    
%                     size(P)
%                     size(T')
%                     
%                     plot(obj.DATA.STUDY.dataset.results.glbTime)
%                     pause
                    
                    
                    if low_pass_stat%If the low-pass filter check button is pressed

                        %Get the cut-off frequency from the appropriate text edit object
                        

                        
                            P=low_pass_filter(P,d_selection.low_cut_off,5,d_selection.parameterAcq)';
           
                           Test=low_pass_filter(Test,d_selection.low_cut_off,5,d_selection.parameterAcq)';
                    else
                        P=P';
                        Test=Test';
                            
                    end
                    
                    
                    
                    %[P,Test] =  normalize_set(P',Test',obj.DATA.NORMAL_STATE, obj.DATA.POS_ICTAL_STATE);
                    
                    
                    
                    [Pn,Testn,factors] =  normalize_set(P',Test',obj.DATA.NORMAL_STATE, obj.DATA.POS_ICTAL_STATE);
                    
                    P=[];
                    Test=[];
                    
                    
                    for np=1:numel(pictal_delta)
                    
                    train_target = build_target(evts,...
                        obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
                        dat_train_time_end_idx,pictal_delta(np),obj.DATA.EARLY_DETECT_TIME); % train data_set
                    test_target = build_target(evts,...
                        obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
                        dat_test_time_end_idx,pictal_delta(np),obj.DATA.EARLY_DETECT_TIME); % test data_set
                    
                    
                    Ti = train_target';
                    
                    %Test=Test(:,d_selection.select_feat);
                    T2i = test_target';
                    
                    Pi=[Pn,Ti'];
                    
                    tr_mat=delay_mat(Pi,1,obj.DATA.n_delay+1);
                    
                    Pi=tr_mat(:,1:end-1)';
                    Ti=tr_mat(:,end)';
                    
                    Testi=[Testn,T2i'];
                    te_mat=delay_mat(Testi,1,obj.DATA.n_delay+1);
                    
                    
                    
                    Testi=te_mat(:,1:end-1)';
                    T2i=te_mat(:,end)';
                    
                    
                          
                    if  equal_class
                        
                        [Pi,Ti]=equalise_classes(obj,Pi,Ti,0);
                        
                        P.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Pi;
                        
                    else
                        if np==1
                            P.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Pi;
                            
                        end
                        
                        
                    end
                    
                    
                    T.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Ti;
                    T2.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=T2i;
                    
                    end 
                    
                    
                    Test.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Testi;

            
                    
                    clear train_d_matrix
                    clear test_d_matrix
                    clear d_selection;
                    
%                     case 'v'
%                     if exist('last_man_data_sets.mat')
%                         dl=load('last_man_data_sets.mat')
%                         f_path = fullfile(obj.DATA.STUDY.dataset.file(1).path,...
%                             obj.DATA.STUDY.dataset.file(1).filename);
% 
%                         feat_bin_o = feat_bin_file(f_path);
%                         
%                         ecg_feat_idx=find(dl.sel_feat>(feat_bin_o.a_n_chan*feat_bin_o.a_n_features));
%                     
%                         ecg_feat=dl.sel_feat(ecg_feat_idx)-(feat_bin_o.a_n_chan*feat_bin_o.a_n_features);
%                         
%                         
%                         % function get_matrix
% 
%                         train_d_matrix = feat_bin_o.file2matrix(dl.dat_train_time_start_idx, dl.dat_train_time_end_idx);
%                         test_d_matrix = feat_bin_o.file2matrix(dl.dat_test_time_start_idx, dl.dat_test_time_end_idx);
%                         
%                         fclose(feat_bin_o.fd);
%                         feat_bin_o.delete();
%                     clear feat_bin_o;
%                     
%                     
%                     
%                     if ~isempty(ecg_feat)%Look for ECG features
%                         f_path_ecg = fullfile(obj.DATA.STUDY.dataset.file(2).path,...
%                         obj.DATA.STUDY.dataset.file(2).filename);
%                         feat_bin_o_ecg = feat_bin_file(f_path_ecg);
%                         
%                         train_d_matrix =[train_d_matrix, feat_bin_o_ecg.file2matrix(dl.dat_train_time_start_idx, dl.dat_train_time_end_idx)];
%                         test_d_matrix = [test_d_matrix,feat_bin_o_ecg.file2matrix(dl.dat_test_time_start_idx, dl.dat_test_time_end_idx)];
%                         
%                     end
%                         
%                         disp(['Tamanho:',num2str(size(train_d_matrix))])
%                         
% 
%                         %% 2. Create/Add target
%                         
%                         
%                         %pictal_delta=obj.DATA.PRE_ICTAL_TIME;
%                         obj.DATA.PRE_ICTAL_TIME=dl.pictal_delta;
%                         
%                         
%                          %  target = build_target(events, time_vector, start_idx, end_idx, PREICTAL_TIME, EARLY_DETECTION_PERIOD, P_ACQ, NUM_CL)
% 
%                         train_target = build_target(obj.DATA.STUDY.dataset.file.data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dl.dat_train_time_start_idx, ...
%                             dl.dat_train_time_end_idx,obj.DATA.PRE_ICTAL_TIME); % train data_set
%                         test_target = build_target(obj.DATA.STUDY.dataset.file.data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dl.dat_test_time_start_idx,...
%                             dl.dat_test_time_end_idx,obj.DATA.PRE_ICTAL_TIME); % test data_set
%                         
% % %                         
% % %                         train_target = buildTarget(obj, dl.dat_train_time_start_idx, dl.dat_train_time_end_idx); % train data_set
% % %                         test_target = buildTarget(obj, dl.dat_test_time_start_idx, dl.dat_test_time_end_idx); % test data_set
% 
% 
% 
%                         %% 3. Create Test matrix (Test) and Train matrix (P)
% 
%                         %                     P  = train_d_matrix';
%                         %                     P=P(d_selection.select_feat,:);
%                         %                     T = train_target';
%                         %                     Test = test_d_matrix';
%                         %                     Test=Test(d_selection.select_feat,:);
%                         %                     T2 = test_target';
%                         %save('1328903.mat','T')
% 
%                         P  = train_d_matrix;
%                         P=P(:,dl.sel_feat);
%                         T = train_target';
%                         Test = test_d_matrix;
%                         Test=Test(:,dl.sel_feat);
%                         T2 = test_target';
%                         
%                         
%                         
%                         idx_n_tr=find(isnan(P));
%                     
%                         P(idx_n_tr,:)=0;
%                         
%                     
%                     
%                         idx_n_te=find(isnan(P));
%                     
%                         Test(idx_n_te,:)=0;
%                         
%                         
%                         
%                         
%                         
%                         if dl.low_pass_stat%If the low-pass filter check button is pressed
% 
%                             %Get the cut-off frequency from the appropriate text edit object
% 
% 
% 
%                             P=low_pass_filter(P,dl.low_cut_off,5,dl.parameterAcq)';
%                             Test=low_pass_filter(Test,dl.low_cut_off,5,dl.parameterAcq)';
%                         else
%                             P=P';
%                             Test=Test';
% 
%                         end
%                         
%                         [P,Test] =  normalize_set(P',Test',obj.DATA.NORMAL_STATE, obj.DATA.POS_ICTAL_STATE);
%                         %save('data_test_arft10_wav5ft10_wav5fp2_wav6fz','P','T','Test','T2');
%                         
%                         P=[P,T'];
%                         
%                         tr_mat=delay_mat(P,1,obj.DATA.n_delay+1);
%                         
%                          P=tr_mat(:,1:end-1)';
%                          T=tr_mat(:,end)';
%                          
%                          Test=[Test,T2'];
%                         te_mat=delay_mat(Test,1,obj.DATA.n_delay+1);
%                         
%                          Test=te_mat(:,1:end-1)';
%                          T2=te_mat(:,end)';
%                         
%                         
%                         
%                         
%                         
% 
%                         clear train_d_matrix
%                         clear test_d_matrix
%                         %clear d_selection;
% 
% 
%                     else
%                         disp('file not exist')
%                         warndlg('Index file not found: last_man_data_sets.mat')
% 
%                     end
                    
                    case 'ii'
                        [FileName,PathName,FilterIndex] = uigetfile('*.mat')
                        
                    
                        dl=load(fullfile(PathName,FileName));
                        
                        
                        
                        
                        
%                         sel_feat=dl.sel_feat
%                         low_pass_stat=dl.low_pass_stat;
%                         low_cut_off=dl.low_cut_off;
%                         prev_pictal=dl.pictal_delta;
%                         equal_class=dl.equal_class;
%                         ev_struct=dl.ev_struct;
                        %prev_pictal=dl.i;
                    
                    
                    
                    %uiwait();
                    
                    %dataset selection 
                    
                        dat_train_time_start=dl.dat_train_time_start;
                        dat_train_time_end=dl.dat_train_time_end;
                    
                        dat_test_time_start=dl.dat_test_time_start;
                        dat_test_time_end=dl.dat_test_time_end;
                    
                    
                    
                    
                         obj.DATA.PRE_ICTAL_TIME=dl.pictal_delta;
                         pictal_delta=dl.pictal_delta;
                    
                     
                     
                    
                    
                    
                         
                         equal_class=dl.equal_class; 
                    
                         low_pass_stat=dl.low_pass_stat;
                     
                     
                    
                    
%                      if pictal_delta<obj.DATA.PRE_ICTAL_TIME
%                        pictal_delta=obj.DATA.PRE_ICTAL_TIME;
%                      end
                    
                    
                    p_acq = obj.DATA.STUDY.dataset.results.parameterAcq;
                    
                    
                    dat_train_time_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_train_time_start/p_acq))*p_acq);             
                    dat_train_time_start_idx =dat_train_time_start_idx(1);
                    
                    dat_train_time_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_train_time_end/p_acq))*p_acq);
                    dat_train_time_end_idx = dat_train_time_end_idx(1);
                    
                    dat_test_time_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_test_time_start/p_acq))*p_acq);
                    
                    dat_test_time_start_idx = dat_test_time_start_idx(1);
                    
                    
                    dat_test_time_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_test_time_end/p_acq))*p_acq);
                    dat_test_time_end_idx =dat_test_time_end_idx(1);
                    
                    sel_feat=dl.sel_feat;
                    sel_feat_names=dl.sel_feat_names;
                    low_pass_stat=dl.low_pass_stat;
                    low_cut_off=dl.low_cut_off;
                    parameterAcq=dl.parameterAcq;
                    equal_class=dl.equal_class;
                    evts=obj.DATA.STUDY.dataset.results.feat_events;
                    ev_struct=evts;
                    save(fullfile(obj.DATA.STUDY.workspace_path,'train_cache','last_man_data_sets.mat'),'dat_train_time_start','dat_train_time_end','dat_test_time_start','dat_test_time_end','pictal_delta','dat_train_time_start_idx','dat_train_time_end_idx',...
                        'dat_test_time_start_idx','dat_test_time_end_idx','sel_feat','sel_feat_names','low_pass_stat','low_cut_off','parameterAcq','equal_class','ev_struct')
                   
                    
                    
                    
%                     disp(['selected features:',num2str(d_selection.select_feat)])
%                     
%                     set(h.ANN.features_list,'Value',d_selection.select_feat)
%                     
                    

                    train_d_matrix=[];
                    test_d_matrix=[];
                    
                    if obj.DATA.STUDY.from_raw==0%Get features from feature file
                    
                    
                    
                    n_loaded_files=size(obj.DATA.STUDY.dataset.file,2);
                    
                    
                    
                    act_tot_feat=0;
                    start_feat_idx=find(sel_feat>0);
                    
                    
                    
                    
                    
                    for k=1:n_loaded_files

                        f_path = fullfile(obj.DATA.STUDY.dataset.file(k).path,...
                            obj.DATA.STUDY.dataset.file(k).filename);
                        
                        file_name=obj.DATA.STUDY.dataset.file(k).filename;


                        

                        feat_bin_o = feat_bin_file(f_path);

                        stop_feat_idx=find(dl.sel_feat<=(act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features)));

                        act_feat_idx=intersect(start_feat_idx,stop_feat_idx);

                        start_feat_idx=find(dl.sel_feat>act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features));

                        act_feat=dl.sel_feat(act_feat_idx)-act_tot_feat;
                        
                        act_tot_feat=act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features);
                       

                        % function get_matrix
                        l=act_feat
                        train_d_matrix = [train_d_matrix,feat_bin_o.file2matrix(dat_train_time_start_idx, dat_train_time_end_idx,act_feat)];
                        test_d_matrix = [test_d_matrix,feat_bin_o.file2matrix(dat_test_time_start_idx, dat_test_time_end_idx,act_feat)];
                        

                        feat_bin_o.delete();
                        clear feat_bin_o;
                       

                    end
                    
                    
                    
%                     if ~isempty(oth_feat_idx)%Look for other features located in other files
%                         
%                         f_path_oth = fullfile(obj.DATA.STUDY.dataset.file(f).path,...
%                         obj.DATA.STUDY.dataset.file(f).filename);
%                         feat_bin_o_oth = feat_bin_file(f_path_oth);
%                         
%                         
%                     
%                         oth_feat_curr_idx=intersect(oth_feat_idx,oth_feat_sup_idx);
%                         
%                         oth_feat=d_selection.select_feat(oth_feat_idx)-(feat_bin_o.a_n_chan*feat_bin_o.a_n_features);
%                    
%                         
%                         
%                         train_d_matrix =[train_d_matrix, feat_bin_o_oth.file2matrix(dat_train_time_start_idx, dat_train_time_end_idx)];
%                         test_d_matrix = [test_d_matrix,feat_bin_o_oth.file2matrix(dat_test_time_start_idx, dat_test_time_end_idx)];
%                         
%                     end
                    %evts=obj.DATA.STUDY.dataset.results.feat_events;
%                     train_target = build_target(obj.DATA.STUDY.dataset.file(1).data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
%                             dat_train_time_end_idx,pictal_delta); % train data_set
%                         test_target = build_target(obj.DATA.STUDY.dataset.file(1).data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
%                             dat_test_time_end_idx,pictal_delta); % test data_set
                    
                    disp(['Tamanho:',num2str(size(train_d_matrix))])
                    else%Get features from Epilab structure
                        
                        feat_types=fieldnames(obj.DATA.STUDY.dataset.results.featureExtractionMethods);
                        for ft=1:size(sel_feat_names,2)
                            for typ=1:size(feat_types,1)
                                %sel_feat_names{ft}
                                
                                tot_feats={fieldnames(h.study.dataset.results.featureExtractionMethods.(feat_types{typ}).c_)};
                                
                                tot_feats=tot_feats{1};
                                
                                for tt=1:size(tot_feats,1)
                                %    disp(tot_feats{tt})%,' with ',sel_feat_names{ft}])
                                    if strcmp(sel_feat_names{ft},tot_feats{tt,1})
                                    mat_data=h.study.dataset.results.featureExtractionMethods.(feat_types{typ}).c_.(tot_feats{tt,1});
                           
                                    
                                    train_d_matrix = [train_d_matrix,mat_data(dat_train_time_start_idx:dat_train_time_end_idx-1)'];
                                    test_d_matrix = [test_d_matrix,mat_data(dat_test_time_start_idx:dat_test_time_end_idx-1)'];
                                    end
                                    
                                %end
                                end
                            end
                        
                        
                        end
                        
                        %evts=ev_struct;
%                         train_target = build_target(ev_struct,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
%                             dat_train_time_end_idx,pictal_delta); % train data_set
%                         test_target = build_target(ev_struct,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
%                             dat_test_time_end_idx,pictal_delta); % test data_set
                        
                    end
                    
                    obj.DATA.pAcq=p_acq;
                    obj.DATA.pictal_delta=pictal_delta;
                    obj.DATA.test_time_vec=obj.DATA.STUDY.dataset.results.glbTime(dat_test_time_start_idx:dat_test_time_end_idx-1);
% % % %                     fclose(feat_bin_o.fd); %%%% TODO NAO CONSIGO
% FECHAR...propriedade protected na classe

                    %% 2. Create/Add target 
                    
                     %  target = build_target(events, time_vector, start_idx, end_idx, PREICTAL_TIME, EARLY_DETECTION_PERIOD, P_ACQ, NUM_CL)

                       
                        
% %                         save targets.mat train_target test_target
                    
                    
% % % %                     train_target = buildTarget(obj, dat_train_time_start_idx, dat_train_time_end_idx); % train data_set
% % % %                     test_target = buildTarget(obj, dat_test_time_start_idx, dat_test_time_end_idx); % test data_set
                    
            
                    
                    
                     
                    
                    %% 3. Create Test matrix (Test) and Train matrix (P)
                    
                    P  = train_d_matrix;
                    
                    %P=P(:,d_selection.select_feat);
%                     T = train_target';
                    Test = test_d_matrix;
                    %Test=Test(:,d_selection.select_feat);
%                     T2 = test_target';
                    
                    P=rep_nan(P,0);
                    
%                     [idx_r_tr,idx_c_tr,v]=find(isnan(P));
%                     
%                     nc=size(idx_r_tr)
%                     
%                     P(idx_n_tr,:)=[];
%                    
                    
                    Test=rep_nan(Test,0);
%                     idx_n_te=find(isnan(Test));
%                     
%                     Test(idx_n_te,:)=[];
                   
                    
                    
%                     size(P)
%                     size(T')
%                     
%                     plot(obj.DATA.STUDY.dataset.results.glbTime)
%                     pause
                    
                    
                    if low_pass_stat%If the low-pass filter check button is pressed

                        %Get the cut-off frequency from the appropriate text edit object
                        

                        
                            P=low_pass_filter(P,low_cut_off,5,p_acq)';
           
                           Test=low_pass_filter(Test,low_cut_off,5,p_acq)';
                    else
                        P=P';
                        Test=Test';
                            
                    end
                    
                    
                    
                    [Pn,Testn,factors] =  normalize_set(P',Test',obj.DATA.NORMAL_STATE, obj.DATA.POS_ICTAL_STATE);
                    
                    P=[];
                    Test=[];
                    
                    
                    for np=1:numel(pictal_delta)
                    
                    train_target = build_target(evts,...
                        obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
                        dat_train_time_end_idx,pictal_delta(np),obj.DATA.EARLY_DETECT_TIME, ...
                        obj.DATA.pAcq, obj.DATA.TARGET_SELECTED); % train data_set
                    test_target = build_target(evts,...
                        obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
                        dat_test_time_end_idx,pictal_delta(np),obj.DATA.EARLY_DETECT_TIME,...
                        obj.DATA.pAcq, obj.DATA.TARGET_SELECTED); % test data_set
                    
                    
                    Ti = train_target';
                    
                    %Test=Test(:,d_selection.select_feat);
                    T2i = test_target';
                    
                    Pi=[Pn,Ti'];
                    
                    tr_mat=delay_mat(Pi,1,obj.DATA.n_delay+1);
                    
                    Pi=tr_mat(:,1:end-1)';
                    Ti=tr_mat(:,end)';
                    
                    Testi=[Testn,T2i'];
                    te_mat=delay_mat(Testi,1,obj.DATA.n_delay+1);
                    
                    
                    
                    Testi=te_mat(:,1:end-1)';
                    T2i=te_mat(:,end)';
                    
                    
                          
                    if  equal_class
                        
                        [Pi,Ti]=equalise_classes(obj,Pi,Ti,0);
                        
                        P.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Pi;
                        
                    else
                        if np==1
                            P.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Pi;
                            
                        end
                        
                        
                    end
                    
                    
                    T.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Ti;
                    T2.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=T2i;
                    
                    end 
                    
                    
                    Test.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Testi;


            
                    
                    clear train_d_matrix
                    clear test_d_matrix
                    clear d_selection;
                       
            end
        
        
                    obj.DATA.norm_factors=factors;
        obj.DATA.train_time_start_idx=dat_train_time_start_idx;
                    obj.DATA.train_time_end_idx=dat_train_time_end_idx;
                    obj.DATA.train_time_start=dat_train_time_start;
                    obj.DATA.train_time_end=dat_train_time_end;
                    
                    obj.DATA.test_time_start_idx=dat_test_time_start_idx;
                    obj.DATA.test_time_end_idx=dat_test_time_end_idx;
                    obj.DATA.test_time_start=dat_test_time_start;
                    obj.DATA.test_time_end=dat_test_time_end;
                    
                    obj.DATA.is_equal_classes=equal_class;
                    
                    obj.DATA.inp_feat=sel_feat_names;
                    
                    obj.DATA.inp_feat_idx=sel_feat;
        
        
        
        
        
        
        
        
        
        
%         function [P T Test T2] = readEpi(obj, path, type)
%             global h;
%             switch(type)
%                 
%                 case 'i'
%                     
%                     %0. Read and normalize
%                     m=readNorm(obj, path);
%                     
%                     %1. Create Test matrix (Test)
%                     Test=m(1:3:end,:);
%                     m(1:3:end,:)=[];
%                     
%                     %2. Create the target matrix (T)
%                     T=zeros(4,length(m));
%                     for i = 1:length(m),
%                         n = m(i,1);
%                         T(n,i)=1;
%                     end
%                     
%                     %3. Create the target for Test (T2)
%                     T2=Test(:,1);
%                     
%                     %4. Create and transpose P
%                     P=m(:,2:end);
%                     P=P';
%                     
%                     %5. Clean and transpose Test
%                     Test=Test(:,2:end);
%                     Test=Test';
%                     
%                     
%                 case 'ii'
%                     %0. Read and normalize
%                     m=readNorm(obj, path(1:(end-1)));
%                     Test=readNorm(obj, path(end));
%                     
%                     %1. Create the target matrix (T)
%                     T=zeros(4,length(m));
%                     for i = 1:length(m),
%                         n = m(i,1);
%                         T(n,i)=1;
%                     end
%                     
%                     %2. Create the target for Test (T2)
%                     T2=Test(:,1);
%                     
%                     %3. Create and transpose P
%                     P=m(:,2:end);
%                     P=P';
%                     
%                     %4. Clean and transpose Test
%                     Test=Test(:,2:end);
%                     Test=Test';
%                     
%                 case 'iii'
%                     %0. Read and normalize
%                     m=readNorm(obj, path);
%                     Test=readNorm(obj, path(end));
%                     
%                     %1. Create the target matrix (T)
%                     T=zeros(4,length(m));
%                     for i = 1:length(m),
%                         n = m(i,1);
%                         T(n,i)=1;
%                     end
%                     
%                     %2. Create the target for Test (T2)
%                     T2=Test(:,1);
%                     
%                     %3. Create and transpose P
%                     P=m(:,2:end);
%                     P=P';
%                     
%                     %4. Clean and transpose Test
%                     Test=Test(:,2:end);
%                     Test=Test';
%                     
%                 case 'iv'
%                     %select data by visual inspection of the features | create feature interface
%                     
%                     if exist('last_man_data_sets.mat')
%                         dl=load('last_man_data_sets.mat')
%                         sel_feat=dl.sel_feat
%                         low_pass_stat=dl.low_pass_stat;
%                         low_cut_off=dl.low_cut_off;
%                         prev_pictal=dl.pictal_delta;
%                         
%                     else
%                         sel_feat=1;
%                         low_pass_stat=0;
%                         low_cut_off=0.1;
%                         prev_pictal=obj.DATA.PRE_ICTAL_TIME;
%                     end
%                     d_selection = MultiFeatPlot(obj.DATA.STUDY);
%                     d_selection.get_data_sets_idx(sel_feat,low_pass_stat,low_cut_off,prev_pictal);
%                     
%                     uiwait();
%                     
%                     %dataset selection
%                     try
%                         [dat_train_time_start] = d_selection.data_sets.train.start*60; %time stamp minutes - seconds
%                         [dat_train_time_end] = d_selection.data_sets.train.end*60; %time stamp minutes - seconds
%                     catch
%                         dat_train_time_start=dl.dat_train_time_start;
%                         dat_train_time_end=dl.dat_train_time_end;
%                     end
%                     try
%                         [dat_test_time_start] = d_selection.data_sets.test.start*60; %time stamp minutes - seconds
%                         [dat_test_time_end] = d_selection.data_sets.test.end*60; %time stamp minutes - seconds
%                     catch
%                         dat_test_time_start=dl.dat_test_time_start;
%                         dat_test_time_end=dl.dat_test_time_end;
%                     end
%                     
%                     try
%                          [pictal_delta] = d_selection.data_sets.preictal*60 %time stamp minutes - seconds
%                     
%                          %[pictal_time_end] = d_selection.data_sets.preictal.end*60; %time stamp minutes - seconds
%                      
%                          %pictal_delta=pictal_time_end-pictal_time_start;
%                          obj.DATA.PRE_ICTAL_TIME=pictal_delta;
%                      catch
%                          obj.DATA.PRE_ICTAL_TIME=dl.pictal_delta;
%                          pictal_delta=dl.pictal_delta;
%                      end
%                     
% %                     if pictal_delta>obj.DATA.PRE_ICTAL_TIME
% %                         obj.DATA.PRE_ICTAL_TIME=pictal_delta;
% %                     end
%                     
%                     p_acq = obj.DATA.STUDY.dataset.results.parameterAcq;
%                     
%                     
%                     dat_train_time_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
%                         (ceil(dat_train_time_start/p_acq))*p_acq);             
%                     dat_train_time_start_idx =dat_train_time_start_idx(1);
%                     
%                     dat_train_time_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
%                         (ceil(dat_train_time_end/p_acq))*p_acq);
%                     dat_train_time_end_idx = dat_train_time_end_idx(1);
%                     
%                     dat_test_time_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
%                         (ceil(dat_test_time_start/p_acq))*p_acq);
%                     
%                     dat_test_time_start_idx = dat_test_time_start_idx(1);
%                     
%                     
%                     dat_test_time_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
%                         (ceil(dat_test_time_end/p_acq))*p_acq);
%                     dat_test_time_end_idx =dat_test_time_end_idx(1);
%                     
%                     
%                     sel_feat=d_selection.select_feat;
%                     sel_feat_names=d_selection.select_feat_names;
%                     low_pass_stat=d_selection.low_pass_stat
%                     low_cut_off=d_selection.low_cut_off
%                     parameterAcq=d_selection.parameterAcq;
%                     save('last_man_data_sets.mat','dat_train_time_start','dat_train_time_end','dat_test_time_start','dat_test_time_end','pictal_delta','dat_train_time_start_idx','dat_train_time_end_idx',...
%                         'dat_test_time_start_idx','dat_test_time_end_idx','sel_feat','sel_feat_names','low_pass_stat','low_cut_off','parameterAcq')
%                    
%                     
% %                     disp(['selected features:',num2str(d_selection.select_feat)])
% %                     
% %                     set(h.ANN.features_list,'Value',d_selection.select_feat)
% %                     
%                     
%                     
%                     %% 1. Read data from bin file
%                     % create object
% %                     f_path = fullfile(obj.DATA.STUDY.dataset.file.path,...
% %                         obj.DATA.STUDY.dataset.file.filename);
% %                     
% %                     feat_bin_o = feat_bin_file(f_path);
% %                     % function get_matrix
% %                     
% %                     train_d_matrix = feat_bin_o.file2matrix(dat_train_time_start_idx, dat_train_time_end_idx);
% %                     test_d_matrix = feat_bin_o.file2matrix(dat_test_time_start_idx, dat_test_time_end_idx);
% %                     disp(['Tamanho:',num2str(size(train_d_matrix))])
% %                     fclose(feat_bin_o.fd); 
%  n_loaded_files=size(obj.DATA.STUDY.dataset.file,2);
%                     
%                     
%                     
%                     act_tot_feat=0;
%                     start_feat_idx=find(d_selection.select_feat>0);
%                     train_d_matrix=[];
%                     test_d_matrix=[];
%                     
%                     d_selection.select_feat
%                     
%                     
%                     for k=1:n_loaded_files
% 
%                         f_path = fullfile(obj.DATA.STUDY.dataset.file(k).path,...
%                             obj.DATA.STUDY.dataset.file(k).filename);
% 
% 
%                         
% 
%                         feat_bin_o = feat_bin_file(f_path);
% 
%                         stop_feat_idx=find(d_selection.select_feat<=(act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features)));
% 
%                         act_feat_idx=intersect(start_feat_idx,stop_feat_idx);
% 
%                         start_feat_idx=find(d_selection.select_feat>act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features));
% 
%                         act_feat=d_selection.select_feat(act_feat_idx)-act_tot_feat;
%                         
%                         act_tot_feat=act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features);
%                        
% 
%                         % function get_matrix
%                         l=act_feat
%                         train_d_matrix = [train_d_matrix,feat_bin_o.file2matrix(dat_train_time_start_idx, dat_train_time_end_idx,act_feat)];
%                         test_d_matrix = [test_d_matrix,feat_bin_o.file2matrix(dat_test_time_start_idx, dat_test_time_end_idx,act_feat)];
%                         
% 
%                         feat_bin_o.delete();
%                         clear feat_bin_o;
%                        
% 
%                     end
%                     
%                     disp(['Tamanho:',num2str(size(train_d_matrix))])
% 
% 
%                     %% 2. Create/Add target 
%                     
%                      train_target = build_target(obj.DATA.STUDY.dataset.file.data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dl.dat_train_time_start_idx, ...
%                             dl.dat_train_time_end_idx,obj.DATA.PRE_ICTAL_TIME); % train data_set
%                         test_target = build_target(obj.DATA.STUDY.dataset.file.data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dl.dat_test_time_start_idx,...
%                             dl.dat_test_time_end_idx,obj.DATA.PRE_ICTAL_TIME); % test data_set
%                     
%                     
% % % %                     train_target = buildTarget(obj, dat_train_time_start_idx, dat_train_time_end_idx); % train data_set
% % % %                     test_target = buildTarget(obj, dat_test_time_start_idx, dat_test_time_end_idx); % test data_set
% % % %                     
%                     
%                     
%                     %% 3. Create Test matrix (Test) and Train matrix (P)
%                     
% %                     P  = train_d_matrix';
% %                     P=P(d_selection.select_feat,:);
% %                     T = train_target';
% %                     Test = test_d_matrix';
% %                     Test=Test(d_selection.select_feat,:);
% %                     T2 = test_target';
%                     %save('1328903.mat','T')
%                     
%                     P  = train_d_matrix;
% %                     P=P(:,sel_feat);
%                     T = train_target';
%                     Test = test_d_matrix;
% %                     Test=Test(:,sel_feat);
%                     T2 = test_target';
%                     
%                     
%                     
%                     if d_selection.low_pass_stat%If the low-pass filter check button is pressed
% 
%                         %Get the cut-off frequency from the appropriate text edit object
%                         
% 
%                         
%                             P=low_pass_filter(P,d_selection.low_cut_off,5,d_selection.parameterAcq)';
%                             Test=low_pass_filter(Test,d_selection.low_cut_off,5,d_selection.parameterAcq)';
%                     else
%                         P=P';
%                         Test=Test';
%                             
%                     end
%                     [P,Test] =  normalize_set(P',Test',obj.DATA.NORMAL_STATE, obj.DATA.POS_ICTAL_STATE);
% %                     P=[P,T'];
%                         
% %                         tr_mat=delay_mat(P,1,obj.DATA.n_delay+1);
%                         
% %                          P=tr_mat(:,1:end-1)';
% %                          T=tr_mat(:,end)';
%                          
% %                          Test=[Test,T2'];
% %                         te_mat=delay_mat(Test,1,obj.DATA.n_delay+1);
%                         
% %                          Test=te_mat(:,1:end-1)';
% %                          T2=te_mat(:,end)';
%                     
%                     clear train_d_matrix
%                     clear test_d_matrix
%                     clear d_selection;
%                     
%                 case 'v'
%                     if exist('last_man_data_sets.mat')
%                         dl=load('last_man_data_sets.mat')
%                         f_path = fullfile(obj.DATA.STUDY.dataset.file.path,...
%                             obj.DATA.STUDY.dataset.file.filename);
% 
%                         feat_bin_o = feat_bin_file(f_path);
%                         % function get_matrix
% 
%                         train_d_matrix = feat_bin_o.file2matrix(dl.dat_train_time_start_idx, dl.dat_train_time_end_idx);
%                         test_d_matrix = feat_bin_o.file2matrix(dl.dat_test_time_start_idx, dl.dat_test_time_end_idx);
%                         disp(['Tamanho:',num2str(size(train_d_matrix))])
%                         fclose(feat_bin_o.fd);
% 
%                         %% 2. Create/Add target
%                         obj.DATA.PRE_ICTAL_TIME=dl.pictal_delta;
% % %                         train_target = buildTarget(obj, dl.dat_train_time_start_idx, dl.dat_train_time_end_idx); % train data_set
% % %                         test_target = buildTarget(obj, dl.dat_test_time_start_idx, dl.dat_test_time_end_idx); % test data_set
%  train_target = build_target(obj.DATA.STUDY.dataset.file.data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dl.dat_train_time_start_idx, ...
%                             dl.dat_train_time_end_idx,obj.DATA.PRE_ICTAL_TIME); % train data_set
%                         test_target = build_target(obj.DATA.STUDY.dataset.file.data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dl.dat_test_time_start_idx,...
%                             dl.dat_test_time_end_idx,obj.DATA.PRE_ICTAL_TIME); % test data_set
%                         
% 
%                         %% 3. Create Test matrix (Test) and Train matrix (P)
% 
%                         %                     P  = train_d_matrix';
%                         %                     P=P(d_selection.select_feat,:);
%                         %                     T = train_target';
%                         %                     Test = test_d_matrix';
%                         %                     Test=Test(d_selection.select_feat,:);
%                         %                     T2 = test_target';
%                         %save('1328903.mat','T')
% 
%                         P  = train_d_matrix;
%                         P=P(:,dl.sel_feat);
%                         T = train_target';
%                         Test = test_d_matrix;
%                         Test=Test(:,dl.sel_feat);
%                         T2 = test_target';
%                         
%                         if dl.low_pass_stat%If the low-pass filter check button is pressed
% 
%                             %Get the cut-off frequency from the appropriate text edit object
% 
% 
% 
%                             P=low_pass_filter(P,dl.low_cut_off,5,dl.parameterAcq)';
%                             Test=low_pass_filter(Test,dl.low_cut_off,5,dl.parameterAcq)';
%                         else
%                             P=P';
%                             Test=Test';
% 
%                         end
%                         [P,Test] =  normalize_set(P',Test',obj.DATA.NORMAL_STATE, obj.DATA.POS_ICTAL_STATE);
%                         %save('data_test_arft10_wav5ft10_wav5fp2_wav6fz','P','T','Test','T2');
%                         
% %                         P=[P,T'];
% %                         
% %                         tr_mat=delay_mat(P,1,obj.DATA.n_delay+1);
% %                         
% %                          P=tr_mat(:,1:end-1)';
% %                          T=tr_mat(:,end)';
% %                          
% %                          Test=[Test,T2'];
% %                         te_mat=delay_mat(Test,1,obj.DATA.n_delay+1);
% %                         
% %                          Test=te_mat(:,1:end-1)';
% %                          T2=te_mat(:,end)';
%                         
%                         clear train_d_matrix
%                         clear test_d_matrix
%                         %clear d_selection;
% 
% 
%                     else
%                         disp('file not exist')
%                         warndlg('Index file not found: last_man_data_sets.mat')
% 
%                     end
%                     
%                     case 'vi'
%                         [FileName,PathName,FilterIndex] = uigetfile('*.mat')
%                         
%                     
%                         dl=load(fullfile(PathName,FileName))
%                         f_path = fullfile(obj.DATA.STUDY.dataset.file.path,...
%                             obj.DATA.STUDY.dataset.file.filename);
% 
%                         feat_bin_o = feat_bin_file(f_path);
%                         % function get_matrix
% 
%                         train_d_matrix = feat_bin_o.file2matrix(dl.dat_train_time_start_idx, dl.dat_train_time_end_idx);
%                         test_d_matrix = feat_bin_o.file2matrix(dl.dat_test_time_start_idx, dl.dat_test_time_end_idx);
%                         disp(['Tamanho:',num2str(size(train_d_matrix))])
%                         fclose(feat_bin_o.fd);
% 
%                         %% 2. Create/Add target
%                         obj.DATA.PRE_ICTAL_TIME=dl.pictal_delta;
% % %                         train_target = buildTarget(obj, dl.dat_train_time_start_idx, dl.dat_train_time_end_idx); % train data_set
% % %                         test_target = buildTarget(obj, dl.dat_test_time_start_idx, dl.dat_test_time_end_idx); % test data_set
% 
%  train_target = build_target(obj.DATA.STUDY.dataset.file.data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dl.dat_train_time_start_idx, ...
%                             dl.dat_train_time_end_idx,obj.DATA.PRE_ICTAL_TIME); % train data_set
%                         test_target = build_target(obj.DATA.STUDY.dataset.file.data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dl.dat_test_time_start_idx,...
%                             dl.dat_test_time_end_idx,obj.DATA.PRE_ICTAL_TIME); % test data_set
% 
%                         %% 3. Create Test matrix (Test) and Train matrix (P)
% 
%                         %                     P  = train_d_matrix';
%                         %                     P=P(d_selection.select_feat,:);
%                         %                     T = train_target';
%                         %                     Test = test_d_matrix';
%                         %                     Test=Test(d_selection.select_feat,:);
%                         %                     T2 = test_target';
%                         %save('1328903.mat','T')
% 
%                         P  = train_d_matrix;
%                         P=P(:,dl.sel_feat);
%                         T = train_target';
%                         Test = test_d_matrix;
%                         Test=Test(:,dl.sel_feat);
%                         T2 = test_target';
%                         
%                         if dl.low_pass_stat%If the low-pass filter check button is pressed
% 
%                             %Get the cut-off frequency from the appropriate text edit object
% 
% 
% 
%                             P=low_pass_filter(P,dl.low_cut_off,5,dl.parameterAcq)';
%                             Test=low_pass_filter(Test,dl.low_cut_off,5,dl.parameterAcq)';
%                         else
%                             P=P';
%                             Test=Test';
% 
%                         end
%                         [P,Test] =  normalize_set(P',Test',obj.DATA.NORMAL_STATE, obj.DATA.POS_ICTAL_STATE);
% %               
% %                         
% %                         P=[P,T'];
% %                         
% %                         tr_mat=delay_mat(P,1,obj.DATA.n_delay+1);
% %                         
% %                          P=tr_mat(:,1:end-1)';
% %                          T=tr_mat(:,end)';
% %                          
% %                          Test=[Test,T2'];
% %                         te_mat=delay_mat(Test,1,obj.DATA.n_delay+1);
% %                         
% %                          Test=te_mat(:,1:end-1)';
% %                          T2=te_mat(:,end)';
%                         clear train_d_matrix
%                         clear test_d_matrix
%                         %clear d_selection;
%                         
%                         
%                         
%                 case 'vii'
%                     if exist('last_man_data_sets.mat')
%                         dl=load('last_man_data_sets.mat')
%                         f_path = fullfile(obj.DATA.STUDY.dataset.file.path,...
%                             obj.DATA.STUDY.dataset.file.filename);
% 
%                         feat_bin_o = feat_bin_file(f_path);
%                         % function get_matrix
% 
%                         
%                         
%                         
%                         train_d_matrix = feat_bin_o.file2matrix(dl.dat_train_time_start_idx, dl.dat_train_time_end_idx);
%                         test_d_matrix = feat_bin_o.file2matrix(dl.dat_test_time_start_idx, dl.dat_test_time_end_idx);
%                         disp(['Tamanho:',num2str(size(train_d_matrix))])
%                         
%                         fclose(feat_bin_o.fd);
% 
%                         %% 2. Create/Add target
%                         obj.DATA.PRE_ICTAL_TIME=dl.pictal_delta;
% % % % %                         train_target = buildTarget(obj, dl.dat_train_time_start_idx, dl.dat_train_time_end_idx); % train data_set
% % % % %                         test_target = buildTarget(obj, dl.dat_test_time_start_idx, dl.dat_test_time_end_idx); % test data_set
% 
%                          train_target = build_target(obj.DATA.STUDY.dataset.file.data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dl.dat_train_time_start_idx, ...
%                             dl.dat_train_time_end_idx,obj.DATA.PRE_ICTAL_TIME); % train data_set
%                         test_target = build_target(obj.DATA.STUDY.dataset.file.data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dl.dat_test_time_start_idx,...
%                             dl.dat_test_time_end_idx,obj.DATA.PRE_ICTAL_TIME); % test data_set
% 
%                         %% 3. Create Test matrix (Test) and Train matrix (P)
% 
%                         %                     P  = train_d_matrix';
%                         %                     P=P(d_selection.select_feat,:);
%                         %                     T = train_target';
%                         %                     Test = test_d_matrix';
%                         %                     Test=Test(d_selection.select_feat,:);
%                         %                     T2 = test_target';
%                         %save('1328903.mat','T')
% 
%                         P  = train_d_matrix;
%                         P=P(:,dl.sel_feat);
%                         T = train_target';
%                         Test = test_d_matrix;
%                         Test=Test(:,dl.sel_feat);
%                         T2 = test_target';
%                         
%                         if dl.low_pass_stat%If the low-pass filter check button is pressed
% 
%                             %Get the cut-off frequency from the appropriate text edit object
% 
% 
% 
%                             P=low_pass_filter(P,dl.low_cut_off,5,dl.parameterAcq)';
%                             Test=low_pass_filter(Test,dl.low_cut_off,5,dl.parameterAcq)';
%                         else
%                             P=P';
%                             Test=Test';
% 
%                         end
%                         
%                          [P,Test] =  normalize_set(P',Test',obj.DATA.NORMAL_STATE, obj.DATA.POS_ICTAL_STATE);
% %                         
% %                         
% %                         P=[P,T'];
% %                         
% %                         tr_mat=delay_mat(P,1,obj.DATA.n_delay+1);
% %                         
% %                          P=tr_mat(:,1:end-1)';
% %                          T=tr_mat(:,end)';
% %                          
% %                          Test=[Test,T2'];
% %                         te_mat=delay_mat(Test,1,obj.DATA.n_delay+1);
% %                         
% %                          Test=te_mat(:,1:end-1)';
% %                          T2=te_mat(:,end)';
% %                          
%                          
%                         [P,T]=equalise_classes(obj,P,T,0);
%                        disp('Saving data...')
%                         save('data_test_equal_arft10_wav5ft10_wav5fp2_wav6fz_nomean.mat','P','T','Test','T2');
%                         pause
%                         
%                         clear train_d_matrix
%                         clear test_d_matrix
%                         %clear d_selection;
%                     end
% 
%                     
%                     
%             end
            
            
            

            
% % % %             function target = buildTarget(obj, t_s_start_idx, t_s_end_idx)
% % % %                n_pnts = t_s_end_idx - t_s_start_idx;
% % % %                
% % % %                target = zeros(n_pnts,1);
% % % %                
% % % %                %default all point NORMAL STATE
% % % %                target(:) = obj.DATA.NORMAL_STATE;
% % % %                
% % % %                %find EVENTS
% % % %                a_events = obj.DATA.STUDY.dataset.file.data.eeg_events;
% % % %                
% % % %                
% % % %                for i=1:length(a_events)
% % % %                    e=a_events(i);
% % % %                    
% % % %                    p_acq = obj.DATA.STUDY.dataset.results.parameterAcq;
% % % %                    
% % % %                    ev_start_idx = 0; ev_end_idx = 0;
% % % %                    
% % % %                    if (strcmpi(e.type,'SEIZURE'))
% % % %                        % %                         ev_start = ceil ((e.started)/parameter_acquisition);
% % % %                        ev_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
% % % %                            (ceil ((e.started)/p_acq))*p_acq);
% % % %                        ev_start_idx=ev_start_idx(1);
% % % %                        
% % % %                        ev_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
% % % %                            (ceil ((e.stopped)/p_acq))*p_acq);
% % % %                        ev_end_idx=ev_end_idx(1);
% % % %                        
% % % %                        if ~isempty(ev_start_idx) && ~isempty (ev_end_idx)
% % % %                            
% % % %                            if ev_start_idx<t_s_end_idx && ev_start_idx>t_s_start_idx
% % % %                                
% % % %                                % ICTAL_STATE
% % % %                                if ev_end_idx<t_s_end_idx
% % % %                                    target(ev_start_idx - t_s_start_idx:ev_end_idx-t_s_start_idx) = obj.DATA.ICTAL_STATE; % Ictal state
% % % %                                else
% % % %                                    target(ev_start_idx - t_s_start_idx:end,1) = obj.DATA.ICTAL_STATE; % Ictal state
% % % %                                end
% % % %                                
% % % %                                %PRE AND POS_ICTAL_STATES
% % % %                                pre_num_idx = obj.DATA.PRE_ICTAL_TIME/p_acq;
% % % %                                pos_num_idx = obj.DATA.POS_ICTAL_TIME/p_acq;
% % % %                                
% % % %                                if ev_start_idx - pre_num_idx>t_s_start_idx
% % % %                                    target((ev_start_idx - t_s_start_idx)-pre_num_idx:...
% % % %                                        (ev_start_idx - t_s_start_idx),1)=obj.DATA.PRE_ICTAL_STATE;%pre - ictal state
% % % %                                else
% % % %                                    target(1:...
% % % %                                        (ev_start_idx - t_s_start_idx),1)=obj.DATA.PRE_ICTAL_STATE;%pre - ictal state
% % % %                                end
% % % %                                
% % % %                                if ev_end_idx + pos_num_idx<t_s_end_idx
% % % %                                    target((ev_end_idx - t_s_start_idx):...
% % % %                                        (ev_end_idx - t_s_start_idx)+pos_num_idx,1)=obj.DATA.POS_ICTAL_STATE;%pos - ictal state
% % % %                                else
% % % %                                    target((ev_end_idx - t_s_start_idx):...
% % % %                                        end,1)=obj.DATA.POS_ICTAL_STATE;%pos - ictal state
% % % %                               
% % % %                                end
% % % %                                
% % % %                            else
% % % %                                disp(['event #' num2str(i) 'is out of the segment selected']);
% % % %                                
% % % %                            end
% % % %                        end
% % % %                    end
% % % %                end
% % % %                
% % % %                
% % % %             end
            
            function m=readNorm(obj, path)
                m=[];
                %1. Read from the Excel file
                for i=1:length(path),
                    %disp({'i: ' num2str(i)});
                    p=path{i}
                    if length(p)>5
                        if isequal(p(1:6),obj.DATA.EPILAB_DS_FLAG)
                            mAux=features2Matrix(obj,str2double(p(7:end)));
                            %TODO: Add study dataset support
                        else
                            mAux=xlsread(char(path(i)));
                        end
                    else
                        mAux=xlsread(char(path(i)));
                    end
                    
                    %1.1 Normalize matrix by column
                    aux=mAux(:,1);
                    aux2=mAux(:,2:end);
                    for j=1:length(aux2(1,:))
                        aux2(:,j)=aux2(:,j)/max(max(aux2(:,j)));
                    end
                    mAux=horzcat(aux,aux2);
                    
                    m=vertcat(m,mAux);
                end
            end
        end
        
        function m=features2Matrix(obj, dataset_number)
            %1� Read features
            types = fieldnames(obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods);
            
            final_matrix = {};
            count = 2;
            features_final = [];
            types_final = {};
            
            parameter_acquisition = eval(strcat('obj.DATA.STUDY.dataset(dataset_number).results.parameterAcq'));
            
            for j=length(types):-1:1  % 2.2 For each feature type
                e = cell2mat(strcat('isempty(','obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),')'));
                a = cell2mat(strcat('fieldnames(','obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),')'));
                
                if ~eval(e)
                    features = eval(a);
                    
                    for x=length(features):-1:1  % 2.3 For each feature
                        feat = cell2mat(features(x));
                        e2 = strcat(e(1:end-1),'.',feat,')');
                        
                        if or(eval(e2), feat(1:2) ~= obj.DATA.FEATURES_TAG)
                            if strcmpi(feat, 'parameter_acquisition')%Data Aquisition (For T matrix)
                                if eval(strcat('~isempty(obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',features{x},')'))
                                    parameter_acquisition = eval(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',features{x}));
                                end
                                features(x) = [];
                            else
                                disp(feat)
                                features(x) = [];
                            end
                        end
                    end
                    m = [];
                    f = features(1);
                    
                    fields = fieldnames(eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),'.',f))));
                    features_final=vertcat(features_final,fields);
                    types_final(end+1:end+length(fields)) = types(j);
                    
                    %for x=1:length(features)  % 2.5 Add new features to final matrix
                    %    aux = eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',f,'.',features{x})));
                    %    aux = aux((length(aux)-min)+1:end);
                    %    m(:,count) = aux';
                    %    count = count + 1;
                    %end
                    
                end
            end
            
            %BEGIN: Format features by the same similar length
            min = 999999999;
            max = -1;
            
            for x=1:length(features_final)  % 2.3 Seek for the maximum time in begining of the features and the minimum of the features in the end
                %cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types_final(x),'.time'))
                aux = eval((strcat('obj.DATA.STUDY.dataset(dataset_number).results.glbTime')));
                % % % %                             %aux(1)
                % % % %                             if aux(1)>max
                % % % %                                 max = aux(1);
                % % % %                             end
                % % % %                             %aux(end)
                % % % %                             if aux(end)<min
                % % % %                                 min = aux(end);
                % % % %                             end
                
                
                max = aux(1);
                min = aux(end);
                
            end
            
            disp(['min = ' num2str(min)]);
            disp(['max = ' num2str(max)]);
            
            for x=1:length(features_final) %2.4 Cut by the similar between all the features time
                cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types_final(x),'.',f,'.',features_final{x}));
                aux = eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types_final(x),'.',f,'.',features_final{x})));
                aux2 = eval(strcat('obj.DATA.STUDY.dataset(dataset_number).results.glbTime'));
                ind_final = find(aux2 == min);
                ind_init = find(aux2 == max);
                aux = aux(ind_init:ind_final);
                if (~isempty(aux))
                    %eval(cell2mat(strcat('obj.DATA.STUDY.d
                    %ataset(dataset_number).results.featureExtractionMethods.',types{j},'.',f,'.',features{x},'=aux')));
                    m(:,count) = aux';
                    count = count + 1;
                end
            end
            
            %END: Format features by the same similar
            %length
            
            %Update the pre-ictal horizont
            if (~isempty(obj.DATA.STUDY.dataset(1).results.predictionHorizon)) %Update the prediction horizont with the value from the dataset1
                obj.DATA.PRE_ICTAL_TIME = obj.DATA.STUDY.dataset(1).results.predictionHorizon * 60; %In seconds
            end
            
            %2� Build matrix T for that dataset
            len = length(m(:,1));
            %2.1 Sampling rate
            % %             sampling_rate = obj.DATA.STUDY.dataset(dataset_number).file(1).data.sampling_rate;% TO DO
            %2.2 For each event
            events = obj.DATA.STUDY.dataset(dataset_number).results.feat_events; % TO DO
            %2.3 Fill T with 1 (normal state)
            m(:,1) = obj.DATA.NORMAL_STATE;
            global h;
            h.m = m;
            if isempty(events) %If there aren't any events defined
                %warndlg(['You have to insert events for dataset '  num2str(dataset_number) ' (go to Edit Study > Data info edition)']);
                %m = NaN;
                h.SVM.LoadingError = 0;
                return;
            end
            h.SVM.LoadingError = 0;
            
            for i=1:length(events)
                e=events(i);
                
                % % % %                             if (strcmpi(e.type,'Seizure'))
                % % % %                                 if (round ((e.stopped/sampling_rate)/parameter_acquisition) - round(max/parameter_acquisition)>0)
                % % % %
                % % % %                                     start = round ((e.started/sampling_rate)/parameter_acquisition) - round(max/parameter_acquisition);
                % % % %                                     if(start<1), start=1; end
                % % % %                                     stop = round ((e.stopped/sampling_rate)/parameter_acquisition) - round(max/parameter_acquisition);
                % % % %
                % % % %                                     if (start>length(m(:,1)) || stop>=length(m(:,1))) %Protection for situations where the seizures are outside the dataset
                % % % %                                         warndlg(['The events are outside the features for dataset ' num2str(dataset_number)]);
                % % % %                                         return;
                % % % %                                     end
                % % % %
                % % % %                                     m(start:stop,1) = obj.DATA.ICTAL_STATE; % Ictal state
                % % % %                                     h.start = start;
                % % % %                                     h.stop = stop;
                % % % %
                % % % %                                     pre = round(start - (obj.DATA.PRE_ICTAL_TIME/parameter_acquisition));
                % % % %                                     pos = round(stop + (obj.DATA.POS_ICTAL_TIME/parameter_acquisition));
                % % % %
                % % % %                                     disp('test1');
                % % % %                                     if pre < 1
                % % % %                                         pre = 1;
                % % % %                                     end
                % % % %                                     if pos > len
                % % % %                                         pos = len;
                % % % %                                     end
                % % % %
                % % % %                                     m(pre:start,1) = obj.DATA.PRE_ICTAL_STATE; % Pre-Ictal state
                % % % %                                     m(stop:pos,1) = obj.DATA.POS_ICTAL_STATE; % Pos-Ictal state
                
                if (strcmpi(e.type,'Seizure'))
                    if (round ((e.stopped)/parameter_acquisition) - round(max/parameter_acquisition)>0)
                        
                        start = round ((e.started)/parameter_acquisition) - round(max/parameter_acquisition);
                        if(start<1), start=1; end
                        stop = round ((e.stopped)/parameter_acquisition) - round(max/parameter_acquisition);
                        
                        if (start>length(m(:,1)) || stop>=length(m(:,1))) %Protection for situations where the seizures are outside the dataset
                            warndlg(['The events are outside the features for dataset ' num2str(dataset_number)]);
                            return;
                        end
                        
                        m(start:stop,1) = obj.DATA.ICTAL_STATE; % Ictal state
                        h.start = start;
                        h.stop = stop;
                        
                        pre = round(start - (obj.DATA.PRE_ICTAL_TIME/parameter_acquisition));
                        pos = round(stop + (obj.DATA.POS_ICTAL_TIME/parameter_acquisition));
                        
                        disp('test1');
                        if pre < 1
                            pre = 1;
                        end
                        if pos > len
                            pos = len;
                        end
                        
                        m(pre:start,1) = obj.DATA.PRE_ICTAL_STATE; % Pre-Ictal state
                        m(stop:pos,1) = obj.DATA.POS_ICTAL_STATE; % Pos-Ictal state
                        
                    end
                end
            end
        end
        function [SP SS AC NERRORS] = calcPerformance(obj, A, T2) 
        %Classes:
        %1 - Normal state
        %2 - Pre-ictal 
        %3 - Ictal
        %4 - Pos-ictal
        %T2 - Must have 1 column and n rows with the classes
        
            size(A)
            size(T2)
            NORMAL=obj.DATA.NORMAL_STATE;
            PREICTAL=obj.DATA.PRE_ICTAL_STATE;
            ICTAL=obj.DATA.ICTAL_STATE;
            POSICTAL=obj.DATA.POS_ICTAL_STATE;        

            %0 Calc the total number of errors and corrects
            NERRORS=zeros(4);
            CORRECTS=zeros(4,1);
            for i=1:length(A)
                aux=A(i);
                
                if aux>obj.DATA.POS_ICTAL_STATE
                    aux=obj.DATA.POS_ICTAL_STATE;
                else if aux<obj.DATA.NORMAL_STATE
                        aux=obj.DATA.NORMAL_STATE;
                    end
                end
                NERRORS(T2(i),aux(1))=NERRORS(T2(i),aux(1))+(T2(i)~=aux(1));
                CORRECTS(T2(i))=CORRECTS(T2(i))+(T2(i)==aux(1)); %Add the correct situations
            end

            %1 Calc TP, TN, FP, FN
            %1.1 True Negatives
            TN_NORMAL=(CORRECTS(NORMAL)+NERRORS(ICTAL,NORMAL)+NERRORS(POSICTAL,NORMAL));
            TN_ICTAL=(NERRORS(NORMAL,ICTAL)+CORRECTS(ICTAL)+NERRORS(POSICTAL,ICTAL));
            TN_POSICTAL=(NERRORS(NORMAL,POSICTAL)+NERRORS(ICTAL,POSICTAL)+CORRECTS(POSICTAL));
            TN=TN_NORMAL+TN_ICTAL+TN_POSICTAL;
            disp({'Neg Verdadeiros=' TN});

            %1.2 False Negatives
            FN=NERRORS(PREICTAL,NORMAL)+NERRORS(PREICTAL,ICTAL)+NERRORS(PREICTAL,POSICTAL);
            disp({'Neg Falsos=' FN});

            %1.3 True Positives
            TP=CORRECTS(PREICTAL);
            disp({'Pos Verdadeiros=' TP});

            %1.4 False Positives
            FP=NERRORS(NORMAL,PREICTAL)+NERRORS(ICTAL,PREICTAL)+NERRORS(POSICTAL,PREICTAL);
            disp({'Pos Falsos=' FP});


            %2. Metrics
            %2.1 Calc the sensitivity (TP/TP+FN)
            SS = (TP/(TP+FN))*100; 

            %2.2 Calc the specificity (TN/TN+FP)
            SP = (TN/(TN+FP))*100;  

            %2.3 Calc the classifier precision (CORRECT/TOTAL)
            CORRECT=sum(CORRECTS);
            TOTAL=length(T2);
            AC = (CORRECT/TOTAL)*100;


           
            end
    end
end

function fdata=low_pass_filter(data,freq,order,samp_freq)
%==============================================================
%Low-pass filter function
%
%Function that defines an IIR low-pass filter
%
%Inputs:
%   data-->data matrix to filter
%   freq-->Cut-off frequency
%   order-->Filter order
%   samp_freq-->data sampling frequency
%
%Output:
%   fdata-->Filtered data
%
%
%EU FP7 Grant 211713 (EPILEPSIAE)
%
%César A. D. Teixeira
%CISUC, FCTUC, University of Coimbra
%January 2010
%==============================================================
%Compute filter parameters
[b,a]=butter(order,freq/(samp_freq/2));
%Filter data
fdata=filtfilt(b,a,data);
end

