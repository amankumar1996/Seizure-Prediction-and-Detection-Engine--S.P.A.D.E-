%Defines the main class and interface of CNNs
classdef Cellular_Neural_Networks_Data < handle
   % The following properties can be set only by class methods
   properties
      
     %BEGIN: DO NOT REMOVE THESE PROPERTIES
          STUDY;
          
          %USED BY RESULTS LIST (SHOULD BE UPDATED IN INTERFACE CLASS)
          sub_module_name = 'Cellular_Neural_Networks';
          saveinfo_datasets;
          saveinfo_features;
          saveinfo_other;
          saveinfo_name = '';
          MenuitemCallback;
          loading = 0;
          EPILAB_DS_FLAG = '_study';
          FEATURES_TAG = 'c_';
          
          PRE_ICTAL_TIME = 10*60; % 10 minutes
          POS_ICTAL_TIME = 5*60; % 5 minutes
          NORMAL_STATE = 0;
          PRE_ICTAL_STATE = 1;
          ICTAL_STATE = 2;
          POS_ICTAL_STATE = 3;
          
          %PERFORMANCE VALUES
          SS = NaN;
          SP = NaN;
          AC = NaN;
          SS_AL=NaN;
          FPR=NaN;
          REL='';
          OUT_AL;
          TIME_AL;
          TAR_AL;
          
          MIN_ANT;
        MAX_ANT;
        AVG_ANT;
        STD_ANT;
          
      %END: DO NOT REMOVE THESE PROPERTIES      
      
%       %CNNs Parameters  
%       TEMPL = 3; % (Neighborhood size 3x3)
%       NVAR = 19;           % Number of variables, matrix A, B and bias Z
%       PRECI = 10;          % Precision of binary representation      


      % Training parameters (Genetic Algorithm)    
       NEIGHB = 1;
       NIND = 30;
       MAXGEN = 100; 
       EPSIL = 1e-4;
       SELEC = 0.7;
       RECOM = 0.6;
       MUTAT = 0.7;        
      
      %Train types
      TRAIN_TYPE_MERGE7030 = 'Train: All(70%) | Test: All(30%)';
      TRAIN_TYPE_MERGE_1 = 'Train: All-Last | Test: Last';
      TRAIN_TYPE_MERGE = 'Train: All | Test: Last';
      TRAIN_TYPE_MANUAL = 'Train: manual selection';
      TRAIN_TYPE_MANUAL_PREV = 'Train: Prev. manual selection';
      TRAIN_TYPE_FROM_FILE = 'Train: Parameters in file';
      TRAIN_TYPE_EQUAL = 'Train: Equalised Classes';
      TRAIN_TYPES = {};
      TRAIN_TYPES_SEL = 1;
      
      %DATA SETS
      DATA_SETS_PATHS = {};
      PATHNAME = '';
      DATA_SETS = {};
      DATA_SETS_SEL = [];
      DATA_SETS_LAST_POS = 1;
      FEATURES = {};
      FEATURES_LIST = {};
      
      %Results
      A = [];
      T2 = [];
      test_time_vec=[];
      pictal_delta=[];
      pAcq=[];
      firing_power_alarm=0.5;
      EARLY_DETECT_TIME=10;
      
      train_time_start_idx;
      train_time_end_idx;
      train_time_start;
      train_time_end;
      
      test_time_start_idx;
      test_time_end_idx;
      test_time_start;
      test_time_end;
      
      is_equal_classes;
      inp_feat;
      inp_feat_idx;
      norm_factors;
      
      
      %Model
      model=[];
      val = NaN; 
      sel_feats_name=[];
      
   end
   
   methods
      %Constructor
      function obj = Cellular_Neural_Networks_Data()
        obj.TRAIN_TYPES = {obj.TRAIN_TYPE_MANUAL,obj.TRAIN_TYPE_FROM_FILE};
      end
   end   
end