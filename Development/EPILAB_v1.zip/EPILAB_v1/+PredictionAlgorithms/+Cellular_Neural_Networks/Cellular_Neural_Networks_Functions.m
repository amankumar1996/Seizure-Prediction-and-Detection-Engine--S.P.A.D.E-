%Defines the main class and interface of classifiers
classdef Cellular_Neural_Networks_Functions
   % The following properties can be set only by class methods
   properties
        DATA;
        %sel_feat_names;
   end
    
   methods
       
      %Constructor
      function obj = Cellular_Neural_Networks_Functions(data)
          global h;
          
          obj.DATA = data;
          %obj.sel_feat_names=[];
          h.CNN.last_traintype = 'x';
          h.CNN.last_sets = 'x';
      end
      
      function [SP SS AC A T2]=train(obj, train_type)
          global h;
          
          val=get(h.CNN.datasets_list,'Value');
          
          
          obj.DATA.val = val;

          %disp(obj.DATA.DATA_SETS_PATHS(val));
          
          %BEGIN - Datasets protection
              f = '';
              a = obj.DATA.FEATURES(val);
              
              aux = zeros(1,length(a));

              for i=1:length(a)
                  aux(i) = sum(a{i});
              end                  


              if length(a)>1 %If the datasets hasn't the same number of features
                  for i=1:length(aux)
                      f = strcat(f,'aux(',num2str(i),'),');
                  end

                  e = strcat('isequal(',f(1:end-1),')');

                  if ~eval(e) 
                      errordlg('Select in all datasets choosen the same number of features.');
                      SP = 0; SS = 0; AC = 0;
                      return;
                  end   
              end

              if sum(aux(i))==0 %If none feature was selected
                  errordlg('Select at least one feature/dataset.');
                  SP = 0; SS = 0; AC = 0;
                  return;                  
              end
          %END - Datasets protection
          
          
          
          h.val = val;
          h.DATA_SETS_PATHS = obj.DATA.DATA_SETS_PATHS;
          
          switch char(train_type) %TODO: Alterar o readEpi para que funcione com o study
%                 case obj.DATA.TRAIN_TYPE_MERGE7030
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'i');
%                 case obj.DATA.TRAIN_TYPE_MERGE_1
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'ii');
%                 case obj.DATA.TRAIN_TYPE_MERGE
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'iii');
                 case obj.DATA.TRAIN_TYPE_MANUAL
                    [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'i');
                    h.CNN.LoadingError=0;
%                 case obj.DATA.TRAIN_TYPE_MANUAL_PREV
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'v');
%                     h.CNN.LoadingError=0;
                case obj.DATA.TRAIN_TYPE_FROM_FILE
                    [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'ii');
                    h.CNN.LoadingError=0;
%                 case obj.DATA.TRAIN_TYPE_EQUAL
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'vii');
%                     h.CNN.LoadingError=0;
           end
          
          
          
%           
%            switch char(train_type) %TODO: Alterar o readEpi para que funcione com o study
%                case obj.DATA.TRAIN_TYPE_MERGE7030
%                    if strcmp(h.CNN.last_traintype,char(train_type)) && strcmp(h.CNN.last_sets,cell2mat(obj.DATA.DATA_SETS_PATHS(val)))
%                        P = h.CNN.train.P;
%                        T = h.CNN.train.T;
%                        Test = h.CNN.train.Test;
%                        T2 = h.CNN.train.T2;             
%                        [SP SS AC A] = cnntrain(obj, P, T, Test, T2, a);
%                    else
%                        [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'i');
%                        [SP SS AC A] = cnntrain(obj, P, T, Test, T2, a);
%                    end
%                     
%                case obj.DATA.TRAIN_TYPE_MERGE_1
%                    if strcmp(h.CNN.last_traintype,char(train_type)) && strcmp(h.CNN.last_sets,cell2mat(obj.DATA.DATA_SETS_PATHS(val)))
%                        P = h.CNN.train.P;
%                        T = h.CNN.train.T;
%                        Test = h.CNN.train.Test;
%                        T2 = h.CNN.train.T2;             
%                        [SP SS AC A] = cnntrain(obj, P, T, Test, T2, a);
%                    else
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'ii');
%                     [SP SS AC A] = cnntrain(obj, P, T, Test, T2, a);
%                    end 
%                case obj.DATA.TRAIN_TYPE_MERGE
%                    if strcmp(h.CNN.last_traintype,char(train_type)) && strcmp(h.CNN.last_sets,cell2mat(obj.DATA.DATA_SETS_PATHS(val)))
%                        P = h.CNN.train.P;
%                        T = h.CNN.train.T;
%                        Test = h.CNN.train.Test;
%                        T2 = h.CNN.train.T2;             
%                        [SP SS AC A] = cnntrain(obj, P, T, Test, T2, a);
%                    else
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'iii');
%                     [SP SS AC A] = cnntrain(obj, P, T, Test, T2, a);
%                    end 
%                case obj.DATA.TRAIN_TYPE_CROSSVALIDATION                
%                     
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'iii');
%                     K = 10;
%                     indices = crossvalind('Kfold',P(1,:),K);
%                     
%                     SP_temp = zeros(K,1); SS_temp = zeros(K,1); AC_temp = zeros(K,1);
%                     for i = 1:K
%                         test = (indices == i); train = ~test;
%                         [SP_temp(i) SS_temp(i) AC_temp(i) A] = cnntrain(obj, P(:,train), T(train,:), P(:,test), T(test,:), a);
%                     end
%                     SS = mean(SS_temp); SP = mean(SP_temp);  AC = mean(AC_temp);
%                     std(SS_temp)
%                     std(SP_temp)
%                     std(AC_temp)
%            end  
           
%            if ~strcmp(h.CNN.last_traintype,char(train_type)) || ~strcmp(h.CNN.last_sets,cell2mat(obj.DATA.DATA_SETS_PATHS(val)))
%                h.CNN.last_traintype = char(train_type);
%                h.CNN.last_sets = cell2mat(obj.DATA.DATA_SETS_PATHS(val));
%                h.CNN.train.P = P;
%                h.CNN.train.T = T;
%                h.CNN.train.Test = Test;
%                h.CNN.train.T2 = T2;
%            end    
            [SP SS AC A] = cnntrain(obj, P, T, Test, T2, a); 
      end
      
      %CNN simulate
      %[SP SS AC obj.DATA.A obj.DATA.T2] = obj.FUNCTIONS.sim();
      
      function [SP SS AC A T]=sim(obj)
          global h;          
          
          val=get(h.CNN.datasets_list,'Value');          
          
          a = obj.DATA.FEATURES(obj.DATA.val);              
          
          if(~isempty(obj.DATA.model))
              h.DATA_SETS_PATHS = obj.DATA.DATA_SETS_PATHS;
              [P T]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'iii');
              P=P(a{1}==1,:)';
              [A,te]=simulate_cnn(obj.DATA.model,P,T);
%               bfive=find(A>5);
%                A(bfive)=5;
%                bone=find(A<1);
%                A(bone)=1;
              [SP SS AC FPR] = calcPerformance(obj, A, T);
          else
              disp('The model is not defined..');
          end    
      end
      
      
      %Function that applies the cnn training
      function [SP SS AC A T2] = cnntrain(obj, P, T, Test, T2, a)          
          global h;
                    
          if(h.CNN.LoadingError==0)           
          
          val=get(h.CNN.datasets_list,'Value');                    
          a = obj.DATA.FEATURES(obj.DATA.val);
          
              %Libraries  
              addpath(fullfile('Toolbox','libcnn'));
              addpath(fullfile('Toolbox','libgenetic'));
              
              %Train only with the selected features
%               P=P(a{1}==1,:);
%               Test=Test(a{1}==1,:);
%               P = P';
%               Test = Test';
                       
              h.T = T;
              h.P = P;
              
              %Parameters
              cnn.NEIG = obj.DATA.NEIGHB;
              cnn.NIND = obj.DATA.NIND;
              cnn.GEN = 1; %obj.DATA.MAXGEN;
              cnn.EPSI = obj.DATA.EPSIL;
              cnn.SELEC = obj.DATA.SELEC;
              cnn.RECOM = obj.DATA.RECOM;
              cnn.MUTAT = obj.DATA.MUTAT;
              
              
              %Get Number of features and electrodes
              el={};
              for f=1:numel(obj.DATA.sel_feats_name)
                  st=obj.DATA.sel_feats_name{f};
                  idx=findstr(st,'channel_');
                  el=horzcat(el,st(idx+8:end));
              end
              
              el=unique(el);
              n_el=numel(el);
              
              cnn.NFeat = size(P,1)/n_el;
              cnn.NElect =n_el;
              
              %errordlg('You have to insert events (go to Edit Study >
              %Data info edition)');
              
              io_data.InpPat=P';
              io_data.OutPat=T';
              io_data.TestInpPat=Test';
              io_data.TestOutPat=T2';

              %[cnn,err,Y]=train_cnn_predictor(io_data,cnn,lmt,n_neurons);
              
              display(sprintf('Processing Genetic Algorithm for Training'));
              tic
              [cnn, Best, A_Train, T_Train] = train_cnn_predictor(io_data, cnn);
              toc
              
              display(sprintf('Processing Genetic Algorithm for Training'));
              tic
%               T2=io_data.TestOutPat{1};
              [cnn, Best, A, T] = simulate_cnn(io_data, cnn);
              %.TestInpPat{1},T2);
              toc
              
              disp('Weight A:')
              cnn.WeightA
              disp('Weight B:')
              cnn.WeightB
              disp('Bias:')
              cnn.Bias
              %ff=figure;plot(round(out),'k');
              %hold on
              %plot(io_data.TestOutPat{1},'r')
              
              
              %[A, AC, prob_estimates] = svmpredict(T2, Test, model);
%               bfive=find(A>4);
%               A(bfive)=4;
%               bone=find(A<1);
%               A(bone)=1;
              [SS SP AC FPR] = obj.calcPerformance(A, T2);
              %SS = NaN; SP = NaN; AC = NaN; A = 0; T2 = 0;
              obj.DATA.model=cnn;
              obj.DATA.firing_power_alarm=0.5;
              
              
              
              obj.DATA.A=A;
                obj.DATA.T2=T2;
                
                obj.DATA.SS=SS;
                obj.DATA.SP=SP;
                obj.DATA.AC=AC;
                
                
                
                [out,tint,time_out,tar]=class2alarm(obj.DATA.test_time_vec,A',T2',obj.DATA.PRE_ICTAL_TIME,obj.DATA.PRE_ICTAL_STATE,obj.DATA.pAcq,obj.DATA.firing_power_alarm);
                [SS_AL,FPR,hours_estim,nseiz]=eval_results_alarm(out,tar+1);
                
                if SS_AL>0
                    time=time_out+obj.DATA.test_time_start;
                    evts=obj.DATA.STUDY.dataset.results.feat_events;
                    [min_ant,max_ant,avg_ant,std_ant]=eval_ant_times(time,tar,out,obj.DATA.PRE_ICTAL_TIME(np),evts)
                else
                    min_ant=NaN;
                    max_ant=NaN;
                    avg_ant=NaN;
                    std_ant=NaN;
                end
                
                
                
                obj.DATA.SS_AL=SS_AL;
                obj.DATA.FPR=FPR;
                obj.DATA.OUT_AL=out;
                obj.DATA.TAR_AL=tar;
                obj.DATA.TIME_AL=time_out;
                
                obj.DATA.MIN_ANT=min_ant;
                obj.DATA.MAX_ANT=max_ant;
                obj.DATA.AVG_ANT=avg_ant;
                obj.DATA.STD_ANT=std_ant;
                
                
                obj.DATA.model.('NEIGHB')=obj.DATA.NEIGHB;
                obj.DATA.model.('NIND')=obj.DATA.NIND;
                obj.DATA.model.('MAXGEN')=obj.DATA.MAXGEN;
                obj.DATA.model.('EPSIL')=obj.DATA.EPSIL;
                obj.DATA.model.('SELEC')=obj.DATA.SELEC;
                obj.DATA.model.('RECOM')=obj.DATA.RECOM;
                obj.DATA.model.('MUTAT')=obj.DATA.MUTAT;
                
                
                
                obj.DATA.model.('Firing_pow')=obj.DATA.firing_power_alarm;
                obj.DATA.model.('SP')=SP;
                obj.DATA.model.('SS')=SS;
                obj.DATA.model.('AC')=AC;
                obj.DATA.model.('FPR')=obj.DATA.FPR;
                obj.DATA.model.('SS_AL')=obj.DATA.SS_AL;
                obj.DATA.model.('REL')=obj.DATA.REL;
                obj.DATA.model.('Tar')=obj.DATA.T2;
                obj.DATA.model.('Out')=obj.DATA.A;
                obj.DATA.model.('Time')=obj.DATA.test_time_vec;
                obj.DATA.model.('Tar_al')=obj.DATA.TAR_AL;
                obj.DATA.model.('Out_al')=obj.DATA.OUT_AL;
                obj.DATA.model.('Time_al')=obj.DATA.TIME_AL;
                
                obj.DATA.model.('Train_start_idx')=obj.DATA.train_time_start_idx;
                obj.DATA.model.('Train_stop_idx')=obj.DATA.train_time_end_idx;
                obj.DATA.model.('Train_start')=obj.DATA.train_time_start;
                obj.DATA.model.('Train_stop')=obj.DATA.train_time_end;
                
                obj.DATA.model.('Test_start_idx')=obj.DATA.test_time_start_idx;
                obj.DATA.model.('Test_stop_idx')=obj.DATA.test_time_end_idx;
                obj.DATA.model.('Test_start')=obj.DATA.test_time_start;
                obj.DATA.model.('Test_stop')=obj.DATA.test_time_end;
                
                obj.DATA.model.('Is_equal_classes')=obj.DATA.is_equal_classes;
                
                obj.DATA.model.('Inp_features')=obj.DATA.inp_feat;
                obj.DATA.model.('Inp_features_idx')=obj.DATA.inp_feat_idx;
                obj.DATA.model.('Pictal')=obj.DATA.PRE_ICTAL_TIME;
                obj.DATA.model.('Pictal_state')=obj.DATA.PRE_ICTAL_STATE;
                obj.DATA.model.('norm_factors')=obj.DATA.norm_factors;
                
                
                obj.DATA.model.('MAX_ANT')=obj.DATA.MAX_ANT;
                   obj.DATA.model.('MIN_ANT')=obj.DATA.MIN_ANT;
                   obj.DATA.model.('AVG_ANT')=obj.DATA.AVG_ANT;
                   obj.DATA.model.('STD_ANT')=obj.DATA.STD_ANT;
                
                
                cnn_res=obj.DATA.STUDY.dataset.results.classifiers.Cellular_Neural_Networks;
                
                cnn_res={cnn_res{:},obj.DATA.model};
                
                obj.DATA.STUDY.dataset.results.classifiers.Cellular_Neural_Networks=cnn_res;
              
              
              
              
              
              
              
              
              
              
          else
              disp('Impossible to train the network.....')
              SS = NaN; SP = NaN; AC = NaN; A = 0; T2 = 0;
          end
      end    
      
      
      
      
      function [P T Test T2] = readEpi(obj, path, type)
            global h;
            switch(type)
              
                case 'i'
                    %select data by visual inspection of the features | create feature interface
                    
                    
                    
                   
                    
                    
                    
                    par_file=fullfile(obj.DATA.STUDY.workspace_path,'train_cache','last_man_data_sets.mat');
                    pictal_delta=obj.DATA.PRE_ICTAL_TIME;
                    
                    if exist(par_file,'file')
                        disp('last man exists')
                        dl=load(par_file)
                        sel_feat=dl.sel_feat
                        low_pass_stat=dl.low_pass_stat;
                        low_cut_off=dl.low_cut_off;
                        %prev_pictal=dl.pictal_delta;
                        %equal_class=dl.equal_class;
                        
                        %prev_pictal=dl.i;
                    else
                        disp('last man do not exists')
                        sel_feat=1;
                        low_pass_stat=0;
                        equal_class=0;
                        low_cut_off=0.1;
                        %prev_pictal=obj.DATA.PRE_ICTAL_TIME;
                    end
                    
                    
                    
                    d_selection = MultiFeatPlot(obj.DATA.STUDY);
                    d_selection.get_data_sets_idx(sel_feat,low_pass_stat,low_cut_off,pictal_delta);
                    
                    uiwait();
                    
                    %dataset selection 
                    try
                        [dat_train_time_start] = d_selection.data_sets.train.start*60; %time stamp minutes - seconds                    
                        [dat_train_time_end] = d_selection.data_sets.train.end*60; %time stamp minutes - seconds
                    catch
                        dat_train_time_start=dl.dat_train_time_start;
                        dat_train_time_end=dl.dat_train_time_end;
                    end
                    
                    try
                        [dat_test_time_start] = d_selection.data_sets.test.start*60; %time stamp minutes - seconds
                        [dat_test_time_end] = d_selection.data_sets.test.end*60; %time stamp minutes - seconds
                     catch
                        dat_test_time_start=dl.dat_test_time_start;
                        dat_test_time_end=dl.dat_test_time_end;
                    end
                    
                    
%                     try
%                          [pictal_delta] = d_selection.data_sets.preictal*60 %time stamp minutes - seconds
%                     
%                          %[pictal_time_end] = d_selection.data_sets.preictal.end*60; %time stamp minutes - seconds
%                      
%                          %pictal_delta=pictal_time_end-pictal_time_start;
%                          obj.DATA.PRE_ICTAL_TIME=pictal_delta;
%                      catch
%                          obj.DATA.PRE_ICTAL_TIME=dl.pictal_delta;
%                          pictal_delta=dl.pictal_delta;
%                     end
%                      obj.DATA.pictal_delta=pictal_delta;
                     
                    
                    
                    try
                          equal_class=d_selection.equal_class; 
                    
                         
                     catch
                         equal_class=dl.equal_class; 
                    end
                    
                    try
                          low_pass_stat=d_selection.low_pass_stat; 
                    
                         
                     catch
                         low_pass_stat=dl.low_pass_stat;
                     end
                     
                    
                    
%                      if pictal_delta<obj.DATA.PRE_ICTAL_TIME
%                        pictal_delta=obj.DATA.PRE_ICTAL_TIME;
%                      end
                    
                    
                    p_acq = obj.DATA.STUDY.dataset.results.parameterAcq;
                    obj.DATA.pAcq=p_acq;
                    
                    
                    dat_train_time_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_train_time_start/p_acq))*p_acq);             
                    dat_train_time_start_idx =dat_train_time_start_idx(1);
                    
                    dat_train_time_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_train_time_end/p_acq))*p_acq);
                    dat_train_time_end_idx = dat_train_time_end_idx(1);
                    
                    dat_test_time_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_test_time_start/p_acq))*p_acq);
                    
                    dat_test_time_start_idx = dat_test_time_start_idx(1);
                    
                    
                    dat_test_time_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_test_time_end/p_acq))*p_acq);
                    dat_test_time_end_idx =dat_test_time_end_idx(1);
                    
                    sel_feat=d_selection.select_feat
                    sel_feat_names=d_selection.select_feat_names;
                    obj.DATA.sel_feats_name=sel_feat_names;
                    low_pass_stat=d_selection.low_pass_stat;
                    low_cut_off=d_selection.low_cut_off;
                    parameterAcq=d_selection.parameterAcq;
                    equal_class=d_selection.equal_class;
                    ev_struct=obj.DATA.STUDY.dataset.results.feat_events;                           
                    save(fullfile(obj.DATA.STUDY.workspace_path,'train_cache','last_man_data_sets.mat'),'dat_train_time_start','dat_train_time_end','dat_test_time_start','dat_test_time_end','pictal_delta','dat_train_time_start_idx','dat_train_time_end_idx',...
                        'dat_test_time_start_idx','dat_test_time_end_idx','sel_feat','sel_feat_names','low_pass_stat','low_cut_off','parameterAcq','equal_class','ev_struct')
                   
                    
                    
                    
%                     disp(['selected features:',num2str(d_selection.select_feat)])
%                     
%                     set(h.ANN.features_list,'Value',d_selection.select_feat)
%                     
                    

                    train_d_matrix=[];
                    test_d_matrix=[];
                    
                    if obj.DATA.STUDY.from_raw==0%Get features from feature file
                    
                    
                    
                    n_loaded_files=size(obj.DATA.STUDY.dataset.file,2);
                    
                    
                    
                    act_tot_feat=0;
                    start_feat_idx=find(d_selection.select_feat>0);
                    
                    
                    d_selection.select_feat
                    
                    
                    for k=1:n_loaded_files

                        f_path = fullfile(obj.DATA.STUDY.dataset.file(k).path,...
                            obj.DATA.STUDY.dataset.file(k).filename);
                        
                        file_name=obj.DATA.STUDY.dataset.file(k).filename;


                        

                        feat_bin_o = feat_bin_file(f_path);

                        stop_feat_idx=find(d_selection.select_feat<=(act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features)));

                        act_feat_idx=intersect(start_feat_idx,stop_feat_idx);

                        start_feat_idx=find(d_selection.select_feat>act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features));

                        act_feat=d_selection.select_feat(act_feat_idx)-act_tot_feat;
                        
                        act_tot_feat=act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features);
                       

                        % function get_matrix
                        l=act_feat
                        
                        
                        train_d_matrix = [train_d_matrix,feat_bin_o.file2matrix(dat_train_time_start_idx, dat_train_time_end_idx,act_feat)];
                        [te_data,time]=feat_bin_o.file2matrix(dat_test_time_start_idx, dat_test_time_end_idx,act_feat);
                        test_d_matrix = [test_d_matrix,te_data];
                        

                        feat_bin_o.delete();
                        clear feat_bin_o;
                       
                    end
                 
                    
                    train_target = build_target(obj.DATA.STUDY.dataset.results.feat_events,...
                            obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
                            dat_train_time_end_idx,pictal_delta, [], [], 2)-1; % train data_set
                        test_target = build_target(obj.DATA.STUDY.dataset.results.feat_events,...
                            obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
                            dat_test_time_end_idx,pictal_delta, [], [], 2)-1; % test data_set
                    
                    disp(['Tamanho:',num2str(size(train_d_matrix))])
                    else%Get features from Epilab structure
                        
                        feat_types=fieldnames(obj.DATA.STUDY.dataset.results.featureExtractionMethods);
                        for ft=1:size(sel_feat_names,2)
                            for typ=1:size(feat_types,1)
                                %sel_feat_names{ft}
                                
                                tot_feats={fieldnames(h.study.dataset.results.featureExtractionMethods.(feat_types{typ}).c_)};
                                
                                tot_feats=tot_feats{1};
                                
                                for tt=1:size(tot_feats,1)
                                %    disp(tot_feats{tt})%,' with ',sel_feat_names{ft}])
                                    if strcmp(sel_feat_names{ft},tot_feats{tt,1})
                                    mat_data=h.study.dataset.results.featureExtractionMethods.(feat_types{typ}).c_.(tot_feats{tt,1});
                           
                                    
                                    train_d_matrix = [train_d_matrix,mat_data(dat_train_time_start_idx:dat_train_time_end_idx-1)'];
                                    test_d_matrix = [test_d_matrix,mat_data(dat_test_time_start_idx:dat_test_time_end_idx-1)'];
                                    end
                                    
                                %end
                            end
                        end
                        
                        
                        end
                        
                        
                        train_target = build_target(obj.DATA.STUDY.dataset.results.feat_events,...
                            obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
                            dat_train_time_end_idx,pictal_delta,[],[],2)-1; % train data_set
                        test_target = build_target(obj.DATA.STUDY.dataset.results.feat_events,...
                            obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
                            dat_test_time_end_idx,pictal_delta,[],[],2)-1; % test data_set
                        
                        
                        
                       
                        
                    end
                    
                    obj.DATA.test_time_vec=obj.DATA.STUDY.dataset.results.glbTime(dat_test_time_start_idx:dat_test_time_end_idx-1);
% % % %                     fclose(feat_bin_o.fd); %%%% TODO NAO CONSIGO
% FECHAR...propriedade protected na classe

                    %% 2. Create/Add target 
                    
                     %  target = build_target(events, time_vector, start_idx, end_idx, PREICTAL_TIME, EARLY_DETECTION_PERIOD, P_ACQ, NUM_CL)

                       
                        
% %                         save targets.mat train_target test_target
                    
                    
% % % %                     train_target = buildTarget(obj, dat_train_time_start_idx, dat_train_time_end_idx); % train data_set
% % % %                     test_target = buildTarget(obj, dat_test_time_start_idx, dat_test_time_end_idx); % test data_set
                    
            
                    
                    
                     
                    
                    %% 3. Create Test matrix (Test) and Train matrix (P)
                    
                    P  = train_d_matrix;
                    
                    %P=P(:,d_selection.select_feat);
                    T = train_target';
                    Test = test_d_matrix;
                    %Test=Test(:,d_selection.select_feat);
                    T2 = test_target';
                    
                    P=rep_nan(P,0);
                    
%                     [idx_r_tr,idx_c_tr,v]=find(isnan(P));
%                     
%                     nc=size(idx_r_tr)
%                     
%                     P(idx_n_tr,:)=[];
%                    
                    
                    Test=rep_nan(Test,0);
%                     idx_n_te=find(isnan(Test));
%                     
%                     Test(idx_n_te,:)=[];
                   
                    
                    
%                     size(P)
%                     size(T')
%                     
%                     plot(obj.DATA.STUDY.dataset.results.glbTime)
%                     pause
                    
                    
                    if low_pass_stat%If the low-pass filter check button is pressed

                        %Get the cut-off frequency from the appropriate text edit object
                        

                        
                            P=low_pass_filter(P,d_selection.low_cut_off,5,d_selection.parameterAcq)';
           
                           Test=low_pass_filter(Test,d_selection.low_cut_off,5,d_selection.parameterAcq)';
                    else
                        P=P';
                        Test=Test';
                            
                    end
                                     
                    
                    [P,Test,factors] =  normalize_set(P',Test',obj.DATA.NORMAL_STATE, obj.DATA.POS_ICTAL_STATE);                                                     
                    P=[P,T'];
                    tr_mat = P;
                    P=tr_mat(:,1:end-1)';
                    T=tr_mat(:,end)';                    
                    Test=[Test,T2'];
                    te_mat = Test;
                    Test = te_mat(:,1:end-1)';
                    T2 = te_mat(:,end)'; 
                        
%                     tr_mat=delay_mat(P,1,obj.DATA.n_delay+1);
%                     P=tr_mat(:,1:end-1)';
%                     T=tr_mat(:,end)';
%                     te_mat=delay_mat(Test,1,obj.DATA.n_delay+1);
%                     Test=te_mat(:,1:end-1)';
%                     T2=te_mat(:,end)';                                                                
                      
                     
                       
                      if  equal_class
                          
                        [P,T]=equalise_classes(obj,P,T,0);   
                      end
                     
                    clear train_d_matrix
                    clear test_d_matrix
                    clear d_selection;
                    

                    
                    case 'ii'
                        [FileName,PathName,FilterIndex] = uigetfile('*.mat')
                        
                    
                        dl=load(fullfile(PathName,FileName));
                        
                        
                        
                        
                        
%                         sel_feat=dl.sel_feat
%                         low_pass_stat=dl.low_pass_stat;
%                         low_cut_off=dl.low_cut_off;
%                         prev_pictal=dl.pictal_delta;
%                         equal_class=dl.equal_class;
%                         ev_struct=dl.ev_struct;
                        %prev_pictal=dl.i;
                    
                    
                    
                    %uiwait();
                    
                    %dataset selection 
                    
                        dat_train_time_start=dl.dat_train_time_start;
                        dat_train_time_end=dl.dat_train_time_end;
                    
                        dat_test_time_start=dl.dat_test_time_start;
                        dat_test_time_end=dl.dat_test_time_end;
                    
                    
                    
                    
                         obj.DATA.PRE_ICTAL_TIME=dl.pictal_delta;
                         pictal_delta=dl.pictal_delta;
                    
                     obj.DATA.pictal_delta=pictal_delta;
                     
                    
                    
                    
                         
                         equal_class=dl.equal_class; 
                    
                         low_pass_stat=dl.low_pass_stat;
                     
                     
                    
                    
%                      if pictal_delta<obj.DATA.PRE_ICTAL_TIME
%                        pictal_delta=obj.DATA.PRE_ICTAL_TIME;
%                      end
                    
                    
                    p_acq = obj.DATA.STUDY.dataset.results.parameterAcq;
                    
                    obj.DATA.pAcq=p_acq;
                    dat_train_time_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_train_time_start/p_acq))*p_acq);             
                    dat_train_time_start_idx =dat_train_time_start_idx(1);
                    
                    dat_train_time_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_train_time_end/p_acq))*p_acq);
                    dat_train_time_end_idx = dat_train_time_end_idx(1);
                    
                    dat_test_time_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_test_time_start/p_acq))*p_acq);
                    
                    dat_test_time_start_idx = dat_test_time_start_idx(1);
                    
                    
                    dat_test_time_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_test_time_end/p_acq))*p_acq);
                    dat_test_time_end_idx =dat_test_time_end_idx(1);
                    
                    sel_feat=dl.sel_feat;
                    sel_feat_names=dl.sel_feat_names;
                    obj.DATA.sel_feats_name=sel_feat_names;
                    low_pass_stat=dl.low_pass_stat;
                    low_cut_off=dl.low_cut_off;
                    parameterAcq=dl.parameterAcq;
                    equal_class=dl.equal_class;
                    ev_struct=obj.DATA.STUDY.dataset.results.feat_events;
                    save(fullfile(obj.DATA.STUDY.workspace_path,'train_cache','last_man_data_sets.mat'),'dat_train_time_start','dat_train_time_end','dat_test_time_start','dat_test_time_end','pictal_delta','dat_train_time_start_idx','dat_train_time_end_idx',...
                        'dat_test_time_start_idx','dat_test_time_end_idx','sel_feat','sel_feat_names','low_pass_stat','low_cut_off','parameterAcq','equal_class','ev_struct')
                   
                    
                    
                    
%                     disp(['selected features:',num2str(d_selection.select_feat)])
%                     
%                     set(h.ANN.features_list,'Value',d_selection.select_feat)
%                     
                    

                    train_d_matrix=[];
                    test_d_matrix=[];
                    
                    if obj.DATA.STUDY.from_raw==0%Get features from feature file
                    
                    
                    
                    n_loaded_files=size(obj.DATA.STUDY.dataset.file,2);
                    
                    
                    
                    act_tot_feat=0;
                    start_feat_idx=find(sel_feat>0);
                    
                    
                    
                    
                    
                    for k=1:n_loaded_files

                        f_path = fullfile(obj.DATA.STUDY.dataset.file(k).path,...
                            obj.DATA.STUDY.dataset.file(k).filename);
                        
                        file_name=obj.DATA.STUDY.dataset.file(k).filename;


                        

                        feat_bin_o = feat_bin_file(f_path);

                        stop_feat_idx=find(dl.sel_feat<=(act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features)));

                        act_feat_idx=intersect(start_feat_idx,stop_feat_idx);

                        start_feat_idx=find(dl.sel_feat>act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features));

                        act_feat=dl.sel_feat(act_feat_idx)-act_tot_feat;
                        
                        act_tot_feat=act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features);
                       

                        % function get_matrix
                        l=act_feat
                        train_d_matrix = [train_d_matrix,feat_bin_o.file2matrix(dat_train_time_start_idx, dat_train_time_end_idx,act_feat)];
                        test_d_matrix = [test_d_matrix,feat_bin_o.file2matrix(dat_test_time_start_idx, dat_test_time_end_idx,act_feat)];
                        

                        feat_bin_o.delete();
                        clear feat_bin_o;
                       

                    end
                    
                    
                    
%                     if ~isempty(oth_feat_idx)%Look for other features located in other files
%                         
%                         f_path_oth = fullfile(obj.DATA.STUDY.dataset.file(f).path,...
%                         obj.DATA.STUDY.dataset.file(f).filename);
%                         feat_bin_o_oth = feat_bin_file(f_path_oth);
%                         
%                         
%                     
%                         oth_feat_curr_idx=intersect(oth_feat_idx,oth_feat_sup_idx);
%                         
%                         oth_feat=d_selection.select_feat(oth_feat_idx)-(feat_bin_o.a_n_chan*feat_bin_o.a_n_features);
%                    
%                         
%                         
%                         train_d_matrix =[train_d_matrix, feat_bin_o_oth.file2matrix(dat_train_time_start_idx, dat_train_time_end_idx)];
%                         test_d_matrix = [test_d_matrix,feat_bin_o_oth.file2matrix(dat_test_time_start_idx, dat_test_time_end_idx)];
%                         
%                     end
                    
                    train_target = build_target(obj.DATA.STUDY.dataset.results.feat_events,...
                            obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
                            dat_train_time_end_idx,pictal_delta); % train data_set
                        test_target = build_target(obj.DATA.STUDY.dataset.results.feat_events,...
                            obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
                            dat_test_time_end_idx,pictal_delta); % test data_set
                    
                    disp(['Tamanho:',num2str(size(train_d_matrix))])
                    else%Get features from Epilab structure
                        
                        feat_types=fieldnames(obj.DATA.STUDY.dataset.results.featureExtractionMethods);
                        for ft=1:size(sel_feat_names,2)
                            for typ=1:size(feat_types,1)
                                %sel_feat_names{ft}
                                
                                tot_feats={fieldnames(h.study.dataset.results.featureExtractionMethods.(feat_types{typ}).c_)};
                                
                                tot_feats=tot_feats{1};
                                
                                for tt=1:size(tot_feats,1)
                                %    disp(tot_feats{tt})%,' with ',sel_feat_names{ft}])
                                    if strcmp(sel_feat_names{ft},tot_feats{tt,1})
                                    mat_data=h.study.dataset.results.featureExtractionMethods.(feat_types{typ}).c_.(tot_feats{tt,1});
                           
                                    
                                    train_d_matrix = [train_d_matrix,mat_data(dat_train_time_start_idx:dat_train_time_end_idx-1)'];
                                    test_d_matrix = [test_d_matrix,mat_data(dat_test_time_start_idx:dat_test_time_end_idx-1)'];
                                    end
                                    
                                %end
                            end
                        end
                        
                        
                        end
                        
                        
                        train_target = build_target(obj.DATA.STUDY.dataset.results.feat_events,...
                            obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
                            dat_train_time_end_idx,pictal_delta); % train data_set
                        test_target = build_target(obj.DATA.STUDY.dataset.results.feat_events,...
                            obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
                            dat_test_time_end_idx,pictal_delta); % test data_set
                        
                    end
                    
                    obj.DATA.test_time_vec=obj.DATA.STUDY.dataset.results.glbTime(dat_test_time_start_idx:dat_test_time_end_idx-1)';
% % % %                     fclose(feat_bin_o.fd); %%%% TODO NAO CONSIGO
% FECHAR...propriedade protected na classe

                    %% 2. Create/Add target 
                    
                     %  target = build_target(events, time_vector, start_idx, end_idx, PREICTAL_TIME, EARLY_DETECTION_PERIOD, P_ACQ, NUM_CL)

                       
                        
% %                         save targets.mat train_target test_target
                    
                    
% % % %                     train_target = buildTarget(obj, dat_train_time_start_idx, dat_train_time_end_idx); % train data_set
% % % %                     test_target = buildTarget(obj, dat_test_time_start_idx, dat_test_time_end_idx); % test data_set
                    
                    
                    %% 3. Create Test matrix (Test) and Train matrix (P)
                    
                    P  = train_d_matrix;
                    
                    %P=P(:,d_selection.select_feat);
                    T = train_target';
                    Test = test_d_matrix;
                    %Test=Test(:,d_selection.select_feat);
                    T2 = test_target';
                    
                    P=rep_nan(P,0);
                    
%                     [idx_r_tr,idx_c_tr,v]=find(isnan(P));
%                     
%                     nc=size(idx_r_tr)
%                     
%                     P(idx_n_tr,:)=[];
%                    
                    
                    Test=rep_nan(Test,0);
%                     idx_n_te=find(isnan(Test));
%                     
%                     Test(idx_n_te,:)=[];
                   
                    
                    
%                     size(P)
%                     size(T')
%                     
%                     plot(obj.DATA.STUDY.dataset.results.glbTime)
%                     pause
                    
                    
                    if low_pass_stat%If the low-pass filter check button is pressed
                        %Get the cut-off frequency from the appropriate
                        %text edit object                        
                        P=low_pass_filter(P,low_cut_off,5,p_acq)';                        
                        Test=low_pass_filter(Test,low_cut_off,5,p_acq)';
                    else
                        P=P';
                        Test=Test';                            
                    end              
                    
                    [P,Test,factors] =  normalize_set(P',Test',obj.DATA.NORMAL_STATE, obj.DATA.POS_ICTAL_STATE);                                     
                    P=[P,T'];
                    tr_mat = P;
                    P=tr_mat(:,1:end-1)';
                    T=tr_mat(:,end)';                    
                    Test=[Test,T2'];
                    te_mat = Test;
                    Test = te_mat(:,1:end-1)';
                    T2 = te_mat(:,end)'; 
                    
%                     tr_mat=delay_mat(P,1,obj.DATA.n_delay+1);
%                     P=tr_mat(:,1:end-1)';
%                     T=tr_mat(:,end)';
%                     Test=[Test,T2'];
%                     te_mat=delay_mat(Test,1,obj.DATA.n_delay+1);
%                     Test=te_mat(:,1:end-1)';
%                     T2=te_mat(:,end)';
                         
                     
                    if  equal_class
                       [P,T]=equalise_classes(obj,P,T,0);   
                    end        
                    
                    clear train_d_matrix
                    clear test_d_matrix
                    clear d_selection;
                       
            end
                    
            
            obj.DATA.norm_factors=factors;
            obj.DATA.train_time_start_idx=dat_train_time_start_idx;
            obj.DATA.train_time_end_idx=dat_train_time_end_idx;
            obj.DATA.train_time_start=dat_train_time_start;
            obj.DATA.train_time_end=dat_train_time_end;
            
            obj.DATA.test_time_start_idx=dat_test_time_start_idx;
            obj.DATA.test_time_end_idx=dat_test_time_end_idx;
            obj.DATA.test_time_start=dat_test_time_start;
            obj.DATA.test_time_end=dat_test_time_end;
            
            obj.DATA.is_equal_classes=equal_class;
            
            obj.DATA.inp_feat=sel_feat_names;
            
            obj.DATA.inp_feat_idx=sel_feat;
                        
            %end
      
      
      
% % % % % % 
            
            function m=readNorm(obj, path)
                m=[];
                %global h;
                
                %1. Read from the Excel file
                for i=1:length(path),
                    
                    p=path{i}
                    if length(p)>5
                        if isequal(p(1:6),obj.DATA.EPILAB_DS_FLAG)
                            mAux=features2Matrix(obj,str2double(p(7:end)));
                            %TODO: Add study dataset support
                        else
                            mAux=xlsread(char(path(i)));
                            h.CNN.LoadingError = 0;
                        end
                    else
                        mAux=xlsread(char(path(i)));
                        h.CNN.LoadingError = 0;
                    end

                    %1.1 Normalize matrix by column
                    aux=mAux(:,1);
                    aux2=mAux(:,2:end);
                    
%                     aux2=scalestd(aux2')';
                    
                    for j=1:length(aux2(1,:))
                        aux2(:,j)=aux2(:,j)/max(max(aux2(:,j)));
                    end    
                    
                    mAux=horzcat(aux,aux2);   

                    m=vertcat(m,mAux);
                end 
            end
            
            function m=features2Matrix(obj, dataset_number)
                      %1� Read features
                      types = fieldnames(obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods);

                      final_matrix = {};
                      count = 2;
                      for j=length(types):-1:1  % 2.2 For each feature type
                          e = cell2mat(strcat('isempty(','obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),')'));
                          a = cell2mat(strcat('fieldnames(','obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),')'));

                          if ~eval(e)
                            features = eval(a);

                            for x=length(features):-1:1  % 2.3 For each feature
                              feat = cell2mat(features(x));
                              e2 = strcat(e(1:end-1),'.',feat,')');

                              if or(eval(e2), feat(1:2) ~= obj.DATA.FEATURES_TAG)
                                  if strcmp(feat, 'parameter_acquisition')%Data Aquisition (For T matrix)
                                      if eval(strcat('~isempty(obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',features{x},')'))
                                        parameter_acquisition = eval(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',features{x}));
                                      end  
                                      features(x) = [];
                                  else    
                                      disp(feat)
                                      features(x) = [];
                                  end    
                              end
                            end 
                            m = [];
                            f = features(1);
                            features=fieldnames(eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),'.',f))))
                            
                            
                            %BEGIN: Format features by the same similar length
                            min = 999999999;
                            max = -1;

                            for x=1:length(features)  % 2.3 Seek for the maximum time in begining of the features and the minimum of the features in the end
                                cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),'.time'))
                                aux = eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),'(1).time')));
                                aux(1)
                                if aux(1)>max;
                                    max = aux(1);
                                end
                                aux(end)
                                if aux(end)<min;
                                    min = aux(end);
                                end
                            end
                            
                            disp(['min = ' num2str(min)]);
                            disp(['max = ' num2str(max)]);
                            
                            for x=1:length(features) %2.4 Cut by the similar between all the features time
                                aux = eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),'.',f,'.',features{x})));
                                aux2 = eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),'.time')));
                                ind_final = find(aux2 == min);
                                ind_init = find(aux2 == max);
                                aux=aux(ind_init:ind_final);
                                if (~isempty(aux))
                                    %eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',f,'.',features{x},'=aux')));
                                    m(:,count) = aux';
                                    count = count + 1;
                                end    
                            end    
                            
                            %END: Format features by the same similar length

                            
                            %for x=1:length(features)  % 2.5 Add new features to final matrix
                            %    aux = eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',f,'.',features{x})));
                            %    aux = aux((length(aux)-min)+1:end);
                            %    m(:,count) = aux';
                            %    count = count + 1;
                            %end  

                          end  
                      end
                      
                      %2� Build matrix T for that dataset
                        len = length(m(:,1));
                        %2.1 Sampling rate
                        sampling_rate = obj.DATA.STUDY.dataset(dataset_number).file.data.sampling_rate;
                        %2.2 For each event
                        events = obj.DATA.STUDY.dataset(dataset_number).results.feat_events;
                        %2.3 Fill T with 1 (normal state)
                        m(:,1) = obj.DATA.NORMAL_STATE;
                        %global h;
                        h.m = m;
                        if isempty(events) %If there aren't any events defined
                            %errordlg('You have to insert events (go to Edit Study > Data info edition)');
                            %m = NaN;
                            h.CNN.LoadingError = 1;
                            return;
                        end
                        h.CNN.LoadingError = 0;
                        
                        for i=1:length(events)
                             e=events(i);         
                            
                            if (round ((e.started/sampling_rate)/parameter_acquisition) - round(max/parameter_acquisition)>0)

                                start = round ((e.started/sampling_rate)/parameter_acquisition) - round(max/parameter_acquisition);
                                stop = round ((e.stopped/sampling_rate)/parameter_acquisition) - round(max/parameter_acquisition);
                                m(start:stop,1) = obj.DATA.ICTAL_STATE; % Ictal state

                                pre = round(start - (obj.DATA.PRE_ICTAL_TIME/parameter_acquisition))
                                pos = round(stop + (obj.DATA.POS_ICTAL_TIME/parameter_acquisition))


                                if pre < 1
                                    pre = 1;
                                end
                                if pos > len
                                    pos = len;
                                end

                                m(pre:start,1) = obj.DATA.PRE_ICTAL_STATE; % Pre-Ictal state
                                m(stop:pos,1) = obj.DATA.POS_ICTAL_STATE; % Pos-Ictal state

                                m
                            end
                        end    
            end
        end    
      
        % function [SP SS AC NERRORS] = calcPerformance(A, T2) 
        % Calculate the specificity (SP), sensitivity (SS), accuracy (AC)
        %   A - Neural network output
        %   T2 - Target of Test matrix (just one column)
        
        function [v_Sens v_Spec v_Acc v_FPR] = calcPerformance(obj, v_Output, v_Target)
            
%             s_NumClass = 2;
%             v_ByClass = zeros(1,s_NumClass);
%             v_ByTarget = zeros(1,s_NumClass);
%             v_TP = zeros(1,s_NumClass);
%             v_FP = zeros(1,s_NumClass);
%             v_FN = zeros(1,s_NumClass);
%             v_TN = zeros(1,s_NumClass);
% 
%             for s_IdxClass = 1:s_NumClass 
%                v_Index = find(v_Output == (s_IdxClass-1)); 
%                v_IdxTarget = find(v_Target == (s_IdxClass-1)); 
%                v_ByClass(s_IdxClass) = length(v_Index); 
%                v_ByTarget(s_IdxClass) = length(v_IdxTarget); 
%                v_TP(s_IdxClass) = nnz(v_Output(v_Index) == v_Target(v_Index));
%                v_FP(s_IdxClass) = nnz(v_Output(v_Index) ~= v_Target(v_Index));
%                v_FN(s_IdxClass) = nnz(v_Output(v_IdxTarget) ~= v_Target(v_IdxTarget));
%                v_TN(s_IdxClass) = nnz(v_Output(v_Target ~= (s_IdxClass-1)) ~= (s_IdxClass-1));
%             end

            
            idx_pos=find(v_Target==obj.DATA.PRE_ICTAL_STATE);
            
            idx_pos_pred=find(v_Output==obj.DATA.PRE_ICTAL_STATE);
            
            TP=sum(ismember(idx_pos,idx_pos_pred));
            
            
            
            idx_neg=find(v_Target==obj.DATA.NORMAL_STATE);
            
            idx_neg_pred=find(v_Output==obj.DATA.NORMAL_STATE);
            
            TN=sum(ismember(idx_neg,idx_neg_pred));
            
            
            FP=sum(ismember(idx_neg,idx_pos_pred));
            
            FN=sum(ismember(idx_pos,idx_neg_pred));
            
            v_Sens = (TP./(TP + FN))*100;
            v_Spec = (TN./(FP + TN))*100;
            v_Acc = mean([v_Sens; v_Spec]);    
            v_FPR = 100 - v_Spec;

        end      
   end    
end

function fdata=low_pass_filter(data,freq,order,samp_freq)
%==============================================================
%Low-pass filter function
%
%Function that defines an IIR low-pass filter
%
%Inputs:
%   data-->data matrix to filter
%   freq-->Cut-off frequency
%   order-->Filter order
%   samp_freq-->data sampling frequency
%
%Output:
%   fdata-->Filtered data
%
%
%EU FP7 Grant 211713 (EPILEPSIAE)
%
%César A. D. Teixeira
%CISUC, FCTUC, University of Coimbra
%January 2010
%==============================================================
%Compute filter parameters
[b,a]=butter(order,freq/(samp_freq/2));
%Filter data
fdata=filtfilt(b,a,data);

end
