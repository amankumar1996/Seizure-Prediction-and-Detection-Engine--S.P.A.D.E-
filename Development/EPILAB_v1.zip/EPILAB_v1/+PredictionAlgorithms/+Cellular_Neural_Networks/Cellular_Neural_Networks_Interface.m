%This class builds the graphical interface of Cellular Neural Networks
%predictions algorithms
classdef Cellular_Neural_Networks_Interface < handle
   
   properties
      panel;
      menus;
      fig;
      panel_title = 'Cellular Neural Networks CNN';
           
           
      %Graphical User Interface auxiliar variables (normalized)
      DEFAULT_EDIT_WIDTH = 0.075;
      DEFAULT_EDIT_HEIGHT = 0.10;
      
      DEFAULT_TEXT_HEIGHT = 0.10;
      DEFAULT_TEXT_WIDTH = 0.30;
      
      DEFAULT_POPUP_HEIGHT = 0.10;
      DEFAULT_POPUP_WIDTH = 0.20; 
      
      DEFAULT_SEPARATION = 0.03;
      
      CNN_PANEL_WIDTH = 0.98;
      CNN_PANEL_HEIGHT = 0.6;
      CNN_PANEL_X = 0.01;
      CNN_PANEL_Y = 0.01;
      
      DATA_PANEL_HEIGHT = 0.2;
     
      
      %Classes
      FUNCTIONS;  %Reference to the Functions Class
      DATA; %Reference to the Data Class
      STUDY;
      
      
      th_lev_edit;
   end
    
   methods
       
      %Constructor
      %REQUIRED FUNCTION
      function obj = Cellular_Neural_Networks_Interface(study)
          obj.STUDY = study;
          obj.DATA = PredictionAlgorithms.Cellular_Neural_Networks.Cellular_Neural_Networks_Data();
          obj.DATA.STUDY = study;
          obj.FUNCTIONS = PredictionAlgorithms.Cellular_Neural_Networks.Cellular_Neural_Networks_Functions(obj.DATA);
      end
      
      %Method that builds the Graphical User Interface Components
      %params: panel (uipanel where all the uicomponents are drawn)
      function draw(obj, panel)
      
           global h;
          
           set(panel,'Title',obj.panel_title, 'TitlePosition','centertop');
           
           data_panel = uipanel('Parent',panel,'Title','Select Data','ForegroundColor',[4/255 166/255 146/255],'FontWeight','bold','Units','Normalized','FontSize',10,'Position',[0,0.8,0.6,obj.DATA_PANEL_HEIGHT]);
           drawDataPanel(data_panel);
           
           perf_panel = uipanel('Parent',panel,'Title','Performance','ForegroundColor',[4/255 166/255 146/255],'FontWeight','bold','Units','Normalized','FontSize',10,'Position',[0.605,0.8,0.375,obj.DATA_PANEL_HEIGHT]);
           drawPerfPanel(perf_panel);
           
           training_panel = uipanel('Parent',panel,'Title','Training','ForegroundColor',[4/255 166/255 146/255],'FontWeight','bold','Units','Normalized','FontSize',10,'Position',[0,0,1,0.8]);
           
           create_CNNPanel(training_panel); 

           %Draw the data panel
           function drawDataPanel(data_panel)  

              h.CNN.open_dataset_button = uicontrol('Parent',data_panel,'Style','pushbutton','Units','Normalized','String','Open','FontSize',8,'Callback',{@OpenDataSet_Button},...
                   'Position',[0.03,0.01,0.1,0.25]);

              h.CNN.delete_button = uicontrol('Parent',data_panel,'Style','pushbutton','Units','Normalized','String','Del','FontSize',8,'Enable','Off','Callback',{@Delete_Button},...
                   'Position',[0.03+0.1,0.01,0.07,0.25]); 
              
              h.CNN.refresh_button = uicontrol('Parent',data_panel,'Style','pushbutton','Units','Normalized','String','Refresh','FontSize',8,'Enable','On','Callback',{@LoadStudyDatasets},...
                   'Position',[0.13+0.07,0.01,0.13,0.25]); 

              h.CNN.datasets_list = uicontrol('Parent',data_panel,'Style','listbox','Units','Normalized','String',obj.DATA.DATA_SETS,'BackgroundColor','white','Max',20,'Min',2,'Callback',{@LoadFeatures},...
                   'Position',[0.03,0.25,0.3,0.7]);  

              h.CNN.features_list = uicontrol('Parent',data_panel,'Style','listbox','Units','Normalized','BackgroundColor','white','Max',20,'Min',2,'Callback',{@SetFeatures},...
                   'Position',[0.07+0.3,0.02,0.62,0.95]);

              
              
              if obj.DATA.loading %Set the datasets when loading saved data
                set(h.CNN.datasets_list,'Value',obj.DATA.DATA_SETS_SEL);
                LoadFeatures(1, []);
                set(h.CNN.delete_button, 'Enable', 'on');
              else
                  LoadStudyDatasets;
              end    
              
              %Load datasets from xls files
              function OpenDataSet_Button(source,eventdata)
                       if(length(obj.DATA.PATHNAME)>1)
                           [ filename , pathname ] = uigetfile (  {'*.xls'} , 'Choose a xls dataset file','MultiSelect','on',obj.DATA.PATHNAME);
                       else
                           [ filename , pathname ] = uigetfile (  {'*.xls'} , 'Choose a xls dataset file','MultiSelect','on');
                       end
                        
                        current_path = pwd;
                        obj.DATA.PATHNAME = pathname(length(current_path)+2:end);
                        if isequal(filename,0)
                            disp('You must select a file!');
                        elseif ischar(filename)
                            [pathname filename];
                            obj.DATA.DATA_SETS_PATHS(obj.DATA.DATA_SETS_LAST_POS) = {[pathname filename]};
                            obj.DATA.DATA_SETS(obj.DATA.DATA_SETS_LAST_POS) = {filename};
                            obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS + 1;

                            obj.DATA.DATA_SETS;
                            set(h.CNN.datasets_list,'String',obj.DATA.DATA_SETS);
                            set(h.CNN.datasets_list,'Value',obj.DATA.DATA_SETS_LAST_POS-1);
                            LoadFeatures([],[]);

                            set(h.CNN.delete_button, 'Enable', 'on');
                        else    
                            disp('FILENAMES:');
                            strcat(pathname,char(filename));
                            aux = obj.DATA.DATA_SETS_LAST_POS;
                            for i = 1:length(filename)
                                obj.DATA.DATA_SETS_PATHS(obj.DATA.DATA_SETS_LAST_POS) = {[pathname char(filename(i))]};
                                obj.DATA.DATA_SETS(obj.DATA.DATA_SETS_LAST_POS) = {char(filename(i))};
                                obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS + 1;
                            end
                            obj.DATA.DATA_SETS;
                            obj.DATA.DATA_SETS_PATHS;
                            set(h.CNN.datasets_list,'String',obj.DATA.DATA_SETS);
                            set(h.CNN.datasets_list,'Value',aux:obj.DATA.DATA_SETS_LAST_POS-1);
                            LoadFeatures([],[]);

                            set(h.CNN.delete_button, 'Enable', 'on');
                        end
              end

              %Delete datasets from the datasets list
              function Delete_Button(source, eventdata)
                  val=get(h.CNN.datasets_list,'Value');
                  str=get(h.CNN.datasets_list,'String');
                  for i=length(val):-1:1
                      obj.DATA.FEATURES_LIST(val(i)) = [];
                      obj.DATA.FEATURES(val(i)) = [];

                      obj.DATA.DATA_SETS_PATHS(val(i)) = [];
                      obj.DATA.DATA_SETS(val(i)) = [];
                      obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS - 1;

                      set(h.CNN.datasets_list, 'Value', []);
                      set(h.CNN.datasets_list, 'String', obj.DATA.DATA_SETS);
                      set(h.CNN.features_list, 'Value', []);
                      set(h.CNN.features_list, 'String', []);
                  end   

                  str=get(h.CNN.datasets_list,'String');

                  if isempty(str)
                      set(h.CNN.delete_button, 'Enable', 'off');
                  end
              end
              
              %Load the features of datasets into the data object
              function LoadFeatures(source, eventdata)
                  val=get(h.CNN.datasets_list,'Value');
                  if ~isempty(val)                              
                      if isempty(source)
                          [num,txt] = xlsread(char(obj.DATA.DATA_SETS_PATHS(val(1))),'C1:P1');
                          set(h.CNN.features_list,'String',txt);
                          for i=1:length(val)
                              obj.DATA.FEATURES_LIST{val(i)} = txt;
                              obj.DATA.FEATURES{val(i)} = ones(1,length(txt));
                          end
                          set(h.CNN.features_list,'Value',1:length(txt));
                      else    
                          a = obj.DATA.FEATURES{val(1)};
                          %b = obj.DATA.FEATURES_LIST{val(1)};

                          h.list = obj.DATA.FEATURES_LIST;
                          h.feat = obj.DATA.FEATURES;

                          set(h.CNN.features_list,'String',obj.DATA.FEATURES_LIST{val(1)});
                          set(h.CNN.features_list,'Value',find(a==1));
                      end 

                  end
              end 

              %Update the features selected by the user in the data object
              function SetFeatures(source, eventdata)
                  
                  val=get(source,'Value');
                  str=get(source,'String');
                  pos=get(h.CNN.datasets_list,'Value');
                  
                  if ~isempty(val)
                      fea = zeros(1,length(str));
                      for i=1:length(val)
                          fea(val(i)) = 1;
                      end    

                      for i=1:length(pos) %TODO: Test these conditions
                          if length(obj.DATA.FEATURES{pos(i)}) == length(fea) %If the dest matrix is equal
                              obj.DATA.FEATURES{pos(i)} = fea;
                          elseif length(obj.DATA.FEATURES{pos(i)}) > length(fea) %If the dest matrix is bigger
                              aux = zeros(1,length(obj.DATA.FEATURES{pos(i)}));
                              aux(1:length(fea)) = fea;
                              obj.DATA.FEATURES{pos(i)} = aux;
                          else          %If the dest matrix is smaller
                              aux = fea(1,length(obj.DATA.FEATURES{pos(i)}));
                              obj.DATA.FEATURES{pos(i)} = aux;
                          end    
                      end    
                  end
              end 

              %Fill the dataset list with results from the other modules
              function LoadStudyDatasets(source, eventdata)
                  %name: studyname.datasetname
                  %studyname: study.name
                  %datasetname: study.dataset(i).name
                  %features: study.dataset(i).name.features.*
                             %study.dataset(i).name.features.c_* (~isempty)

                  %1� Insert the datasets to the list
                  ds_name = strcat(obj.STUDY.name,'.');
                  aux = obj.DATA.DATA_SETS_LAST_POS;
                  for i=1:length(obj.STUDY.dataset)
                      ds_name2 = strcat(ds_name,obj.STUDY.dataset(i).name);
                      h.DATA_SETS = obj.DATA.DATA_SETS;
                      h.ds_name2 = ds_name2;
                      
                      if isempty(obj.DATA.DATA_SETS)
                          obj.DATA.DATA_SETS(obj.DATA.DATA_SETS_LAST_POS) = {ds_name2};
                          
                          %Add position of dataset, useful for the train
                          %function to capture the right features, e.g.
                          %study1, study2, etc.
                          obj.DATA.DATA_SETS_PATHS(obj.DATA.DATA_SETS_LAST_POS) = {[obj.DATA.EPILAB_DS_FLAG num2str(i)]};
                          obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS + 1;
                          break;
                      end    
                      
                      for j=1:length(obj.DATA.DATA_SETS)
                         if strcmp(obj.DATA.DATA_SETS{j}, ds_name2)
                              obj.DATA.DATA_SETS(j) = [];
                              obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS - 1;
                              aux = aux - 1; %Update auxiliar var
                              break;
                         end
                      end  
                      
                      obj.DATA.DATA_SETS(obj.DATA.DATA_SETS_LAST_POS) = {ds_name2};
                      obj.DATA.DATA_SETS_PATHS(obj.DATA.DATA_SETS_LAST_POS) = {[obj.DATA.EPILAB_DS_FLAG num2str(i)]}; %Add reference to the paths data structure
                      obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS + 1;
                      
                  end


                  %2� Load features
                  for i=1:length(obj.STUDY.dataset) % 2.1 For each dataset

                      types = fieldnames(obj.STUDY.dataset(i).results.featureExtractionMethods);

                      final_matrix = {};
                      count = 1;
                      for j=length(types):-1:1  % 2.2 For each feature type
                          e = cell2mat(strcat('isempty(','obj.STUDY.dataset(i).results.featureExtractionMethods.',types(j),')'));
                          a = cell2mat(strcat('fieldnames(','obj.STUDY.dataset(i).results.featureExtractionMethods.',types(j),')'));

                          if ~eval(e)
                            features = eval(a);

                            for x=length(features):-1:1  % 2.3 For each feature
                              feat = cell2mat(features(x));
                              e2 = strcat(e(1:end-1),'.',feat,')');

                              if or(eval(e2), feat(1:2) ~= obj.DATA.FEATURES_TAG)
                                  disp(feat)
                                  features(x) = [];                                          
                              end
                            end 
                            f = features(1);
                            features=fieldnames(eval(cell2mat(strcat('obj.STUDY.dataset(i).results.featureExtractionMethods.',types(j),'.',f))));
                            for x=1:length(features)  % 2.4 Add new features to final matrix
                                final_matrix(count) = strcat(types(j),'.',features(x));
                                count = count + 1;
                            end  

                          end
                      end    

                      obj.DATA.FEATURES_LIST{aux} = final_matrix;
                      obj.DATA.FEATURES_LIST
                      obj.DATA.FEATURES{aux} = ones(1,length(final_matrix));
                      aux = aux + 1;

                  end

                  % 3� Apply changes to the handles
                  set(h.CNN.features_list,'String',{});
                  set(h.CNN.features_list,'String',{});

                  set(h.CNN.datasets_list,'Value',[]);
                  set(h.CNN.datasets_list,'String',obj.DATA.DATA_SETS);

                  set(h.CNN.delete_button, 'Enable', 'on');
              end    
           end

           function drawPerfPanel(perf_panel)

               h.CNN.tab_res=uitable('parent',perf_panel,'Data',{},'ColumnName', {'Name','SS_AL','FPR','MIN_ANT','MAX_ANT','AVG_ANT','STD_ANT','SS','SP','AC','Rel','P-Ictal','Th.','Radius','Pop. Sz.','Gen.','Eps.','Selec. Rate','Recom. Prob.','Mut. Prob.'},'Units','Normalized',...
    'RearrangeableColumn','on','Position',[0.01 0.01 0.98 0.99],'ColumnWidth','auto','CellSelectionCallback',@UpdateSelected);
               
               
%               IPOS = 0.05;
%               h.CNN.sens_text = uicontrol('Parent',perf_panel,'Style','text','Units','Normalized','String','Sensitivity = ','FontSize',10,...
%                                'Position',[0.1,IPOS,0.55,0.3],'HorizontalAlignment','Left');
%               IPOS = IPOS + 0.3;
%               h.CNN.spec_text = uicontrol('Parent',perf_panel,'Style','text','Units','Normalized','String','Specificity = ','FontSize',10,...
%                                'Position',[0.1,IPOS,0.55,0.3],'HorizontalAlignment','Left');
%               IPOS = IPOS + 0.3;
%               h.CNN.acc_text = uicontrol('Parent',perf_panel,'Style','text','Units','Normalized','String','Accuracy = ','FontSize',10,...
%                                'Position',[0.1,IPOS,0.55,0.3],'HorizontalAlignment','Left');
              %align([h.ANN.sens_text h.ANN.spec_text h.ANN.acc_text],'Left','None');
              
              %obj.DATA
              
              %if obj.DATA.loading
                updatePerformanceValues(obj);
              %end  
           end
           
           function  UpdateSelected (source, event)
        h.CNN.res_cel_sel=event.Indices(:,1);
    end

           function create_CNNPanel(fpanel)
                % Set current data to the selected data set.
                % TODO: Analyse the memory of constantly creating
                % uipanels
                
               %CNN parameters
               npanel = uipanel('Parent',fpanel,'BorderType','none','BorderWidth',0,'Units','Normalized','Visible','on','Position',[obj.CNN_PANEL_X,obj.CNN_PANEL_Y,obj.CNN_PANEL_WIDTH,obj.CNN_PANEL_HEIGHT]);
               IPOS = 1.3;
               %NOTE: The uicontrols are drawn in a bottom-up fashion 
                                     
               h.CNN.neighradius_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Neighborhood radius: (nxn):','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.CNN.neighradius_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.NEIGHB),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_EDIT_HEIGHT]); 
               
               IPOS = IPOS - obj.DEFAULT_SEPARATION*8;
               h.CNN.indiv_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Population size:','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.CNN.indiv_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.NIND),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_EDIT_HEIGHT]);         
               
               h.CNN.selrate_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Selection rate:','FontSize',10,...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION*4,IPOS,obj.DEFAULT_TEXT_WIDTH+0.05,obj.DEFAULT_TEXT_HEIGHT]);        
               h.CNN.selrate_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.SELEC),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION*12+obj.DEFAULT_TEXT_WIDTH/2,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT]);         
           
                              
               IPOS = IPOS - obj.DEFAULT_SEPARATION*3;
               h.CNN.maxgener_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Generations:','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.CNN.maxgener_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.MAXGEN),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_EDIT_HEIGHT]);             

               h.CNN.recomprob_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Recombination probability:','FontSize',10,...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION*4,IPOS,obj.DEFAULT_TEXT_WIDTH+0.05,obj.DEFAULT_TEXT_HEIGHT]);        
               h.CNN.recomprob_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.RECOM),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION*12+obj.DEFAULT_TEXT_WIDTH/2,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT]);         

               
               IPOS = IPOS - obj.DEFAULT_SEPARATION*3;
               h.CNN.epsilon_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Epsilon:','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.CNN.epsilon_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.EPSIL),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_EDIT_HEIGHT]); 
               
               h.CNN.mutprob_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Mutation probability:','FontSize',10,...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION*4,IPOS,obj.DEFAULT_TEXT_WIDTH+0.05,obj.DEFAULT_TEXT_HEIGHT]);        
               h.CNN.mutprob_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.MUTAT),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION*12+obj.DEFAULT_TEXT_WIDTH/2,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT]);         
               
               
               
               
               
               IPOS = IPOS - obj.DEFAULT_SEPARATION*6;
               h.CNN.pictal_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Pre-Ictal (min):','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.CNN.pictal_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',obj.DATA.PRE_ICTAL_TIME/60,'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_EDIT_HEIGHT]);
               
               
               
               IPOS = IPOS - obj.DEFAULT_SEPARATION*3;
               h.CNN.early_detect_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Early Detection Time (s):','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.CNN.early_detect_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',obj.DATA.EARLY_DETECT_TIME,'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_EDIT_HEIGHT]);
               
               IPOS = IPOS - obj.DEFAULT_SEPARATION*3;
               %Alarm threshold level
                h.CNN.threshold_lev_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Threshold Level (%):',...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]); 
               
                h.CNN.threshold_lev_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.firing_power_alarm*100),...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_EDIT_HEIGHT]); 
               obj.th_lev_edit=h.CNN.threshold_lev_edit; 
               
              
               % Train Type 
               h.CNN.train_type_list = uicontrol('Parent',npanel,'Style','listbox','Units','Normalized','String',obj.DATA.TRAIN_TYPES,...
                                                'Value',obj.DATA.TRAIN_TYPES_SEL,'BackgroundColor','white','Position',[0.2,0.05,0.3,0.2]);  
                  
               %Classify Button
               h.CNN.classify_button = uicontrol('Parent',npanel,'Style','pushbutton','Units','Normalized','String','Classify','FontSize',10,'Callback',{@(src,event)Classify_Button(obj,src,event)},...
                'Position',[0.51,0.1,0.1,0.1]);

               %Save Button
               h.CNN.save_button = uicontrol('Parent',npanel,'Style','pushbutton','Units','Normalized','String','Save','FontSize',10,'Enable','off','Callback',{@(src,event)Save_Button(obj,src,event)},...
                'Position',[0.51+0.11,0.1,0.1,0.1]);
            
               %Plot results button
               h.CNN.plotResults_button = uicontrol('Parent',npanel,'Style','pushbutton','Units','Normalized','String','Plot results','FontSize',10,'Enable','off','Callback',{@(src,event)PlotResults_ButtonCallback(obj,src,event)},...
                'Position',[0.51+0.12+0.1,0.1,0.15,0.1]);
            
               %Simulate button
               h.CNN.PlotAlarmButton = uicontrol('Parent',npanel,'Style','pushbutton','Units','Normalized','String','Plot Alarms','FontSize',10,'Enable','off','Callback',{@(src,event)PlotAlarmButtonCallback(obj,src,event)},...
                'Position',[0.51+0.12+0.1,0.20,0.15,0.1]);          
            
                
               if obj.DATA.loading %Enable PlotResults button if the ANN is being loaded
                   set(h.CNN.plotResults_button,'Enable','on');
               end    
              
               %Random Predictor Evaluation
               h.CNN.RandEvalButton = uicontrol('Parent',npanel,'Style','pushbutton','Units','Normalized','String','Evaluate','FontSize',10,'Enable','on','Callback',{@(src,event)EvaluateAlarmResultsCallback(obj,src,event)},...
                'Position',[0.51+0.12+0.1+0.16,0.1,0.1,0.2]);
               
             if ~isempty(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks)
               set(h.CNN.plotResults_button,'Enable','on');
               set(h.CNN.PlotAlarmButton,'Enable','on');
               %set(h.CNN.RandEvalButton,'Enable','on');
            end
            
            
               
            
                
               if obj.DATA.loading %Enable PlotResults button if the ANN is being loaded
                   set(h.CNN.plotResults_button,'Enable','on');
               end
               
               
              %Classify the data
              function Classify_Button(obj, source, evendata)
                   updateData(obj); 

                   s=get(h.CNN.train_type_list,'String');
                   obj.DATA.TRAIN_TYPES_SEL=get(h.CNN.train_type_list,'Value');
                   traint = s(obj.DATA.TRAIN_TYPES_SEL);
                   [SP SS AC obj.DATA.A obj.DATA.T2] = obj.FUNCTIONS.train(traint);
                   
                   %Update classifier saveinfo
                   obj.DATA.saveinfo_datasets = length(get(h.CNN.datasets_list,'Value'));
                   val = get(h.CNN.datasets_list,'Value');
                 
                   obj.DATA.saveinfo_features = sum(obj.DATA.FEATURES{val(1)});
                   
                   
                   %obj.DATA.saveinfo_other = str(val);
                   
                   obj.DATA.saveinfo_name = strcat(obj.panel_title);
                   
                   %Update dataset selection
                   obj.DATA.DATA_SETS_SEL = get(h.CNN.datasets_list,'Value');
                   
                   updatePerformanceValues(obj);

                   set(h.CNN.save_button, 'Enable' ,'on');
                   set(h.CNN.plotResults_button, 'Enable' ,'on');
                   set(h.CNN.PlotAlarmButton, 'Enable' ,'on');
              end
              
              function updateData(obj)

               obj.DATA.NEIGHB = str2double(get(h.CNN.neighradius_edit, 'String'));   
               obj.DATA.NIND = str2double(get(h.CNN.indiv_edit, 'String'));    
               obj.DATA.SELEC = str2double(get(h.CNN.selrate_edit, 'String'));   
               obj.DATA.MAXGEN = str2double(get(h.CNN.maxgener_edit, 'String'));  
               obj.DATA.RECOM = str2double(get(h.CNN.recomprob_edit, 'String'));  
               obj.DATA.EPSIL = str2double(get(h.CNN.epsilon_edit, 'String'));   
               obj.DATA.MUTAT = str2double(get(h.CNN.mutprob_edit, 'String')); 
               obj.DATA.PRE_ICTAL_TIME=eval(get(h.CNN.pictal_edit,'String')).*60;
               obj.DATA.EARLY_DETECT_TIME=eval(get(h.CNN.early_detect_edit,'String'));
               obj.DATA.firing_power_alarm=eval(get(h.CNN.threshold_lev_edit,'String'));   
              end
              
              %Save into the EpiLab data structure the classifier
              function Save_Button(obj, source, evendata)                  
                  
                  if exist(fullfile(obj.DATA.STUDY.workspace_path,'train_cache','last_man_data_sets.mat'))
                    dl=load(fullfile(obj.DATA.STUDY.workspace_path,'train_cache','last_man_data_sets.mat'));
                    
                    dat_train_time_start=dl.dat_train_time_start;
                    dat_train_time_end=dl.dat_train_time_end;
                    dat_test_time_start=dl.dat_test_time_start;
                    dat_test_time_end=dl.dat_test_time_end;
                    pictal_delta=dl.pictal_delta; 
                    dat_train_time_start_idx=dl.dat_train_time_start_idx;
                    dat_train_time_end_idx=dl.dat_train_time_end_idx;
                    dat_test_time_start_idx=dl.dat_test_time_start_idx; 
                    
                    dat_test_time_end_idx=dl.dat_test_time_end_idx;
                    
                    sel_feat=dl.sel_feat;
                    sel_feat_names=dl.sel_feat_names;
                    low_pass_stat=dl.low_pass_stat;
                    low_cut_off=dl.low_cut_off;
                    parameterAcq=dl.parameterAcq;
                    equal_class=dl.equal_class;
                    ev_struct=obj.DATA.STUDY.dataset.results.feat_events;                  
                                                          
                    c=clock();
                    
                    st=obj.DATA.STUDY.dataset.file.filename
                    idx=findstr(st,'.');
                    st=st(1:idx(1)-1);
                    save(fullfile(obj.DATA.STUDY.workspace_path,'train_cache',[st,'_cnn_',num2str(c(1)),'_',num2str(c(2)),...
                        '_',num2str(c(3)),'_',num2str(c(4)),'_',num2str(c(5)),'_',num2str(c(5)),'.mat']),'dat_train_time_start','dat_train_time_end','dat_test_time_start','dat_test_time_end','pictal_delta','dat_train_time_start_idx','dat_train_time_end_idx',...
                        'dat_test_time_start_idx','dat_test_time_end_idx','sel_feat','sel_feat_names','low_pass_stat','low_cut_off','parameterAcq','equal_class','ev_struct');
                  end            
                  
                  
                  
                  
%                   import PredictionAlgorithms.Cellular_Neural_Networks.*;
% 
%                    dest = Cellular_Neural_Networks_Data();
%                    copyAllProperties(obj, obj.DATA,dest);
% 
%                    if isempty(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks) %TODO: Change the name (automatic way)
%                        obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks = [dest];
%                    else
%                        pos=length(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks);
%                        obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks(pos+1) = dest;  
%                    end
                   set(h.CNN.save_button, 'Enable' ,'off');
              end
               
           end
          
           
           
           
           %Plot the classifier results
      function PlotResults_ButtonCallback(obj, source, evendata)

           %BEGIN - plot
           
           if ~isempty(h.CNN.res_cel_sel)
                   cnn_sel=h.CNN.res_cel_sel(1);
               figure('NumberTitle','off',...
                'Name',['Prediction Results=CNN_' num2str(cnn_sel) ', SS=' num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.SS)  ', SP=' num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.SP)  ', AC=' num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.AC)]);

               set(gcf, 'color',[0.95 0.97 0.99]);
               
               A2 = obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Out;
               time=obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Time./3600;
               plot (time,obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Tar,'-g'); hold on;
               plot (time,A2,'--r');
               
%                disp('plot')
%                size(A2)
%                size(obj.DATA.T2)
               
               %Plot seizure states
               
                        plot (time,ones(1,length(A2))*obj.DATA.NORMAL_STATE,':','color', [0.8 0.8 0.8]);
                        plot (time,ones(1,length(A2))*obj.DATA.PRE_ICTAL_STATE,':','color', [0.6 0.6 0.6]);
                        legend ('Real data (target)', 'Prediction (classifier output)',...
                        ['Non Pre-ictal State (' num2str(obj.DATA.NORMAL_STATE) ')'],...
                        ['Pre-ictal State (' num2str(obj.DATA.PRE_ICTAL_STATE) ')']);
                   

               title (['Prediction Results=CNN_' num2str(cnn_sel) ', SS=' num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.SS)  ', SP=' num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.SP)  ', AC=' num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.AC)]);
               xlabel ('Time (h)');
               ylabel ('Seizure state')
              
           else
               warndlg('Please Select a model to plot!','Plot Model')
               
           end
           %END - plot
      end
      
               
               
              
               function PlotAlarmButtonCallback(obj, source, evendata)
                   if ~isempty(h.CNN.res_cel_sel)
                   cnn_sel=h.CNN.res_cel_sel(1);
               
                   figure('NumberTitle','off',...
                       'Name',['Alarm Results=CNN_' num2str(cnn_sel) ', SS=' num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.SS_AL)  ', FPR=' num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.FPR)]);
                   
                   set(gcf, 'color',[0.95 0.97 0.99]);
                   
                   
                   act_al_lev=str2num(get(obj.th_lev_edit,'String'))/100;
                    
                   
               
                   mod_al_lev=(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Firing_pow);
               
               if (act_al_lev~=mod_al_lev) && act_al_lev>=0 && act_al_lev<=100
                   obj.DATA.firing_power_alarm=act_al_lev;
                   A=obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Out;
                   T2=obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Tar;
                   %A2=real2th(A',[obj.DATA.NORMAL_STATE obj.DATA.PRE_ICTAL_STATE obj.DATA.ICTAL_STATE obj.DATA.POS_ICTAL_STATE]);
                   
                   
                   [out,tint,time_out,tar]=class2alarm(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Time,...
                       A',T2',obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Pictal,...
                       obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Pictal_state,obj.STUDY.dataset.results.parameterAcq,obj.DATA.firing_power_alarm);
                [SS_AL,FPR,hours_estim,nseiz]=eval_results_alarm(out,tar+1);
                
                
                if SS_AL>0
                    time=time_out+obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Test_start;
                    evts=obj.DATA.STUDY.dataset.results.feat_events;
                    [min_ant,max_ant,avg_ant,std_ant]=eval_ant_times(time,tar,out,...
                        obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Pictal,evts);
                else
                    min_ant=NaN;
                    max_ant=NaN;
                    avg_ant=NaN;
                    std_ant=NaN;
                 end
                
                 obj.DATA.MIN_ANT=min_ant;
                obj.DATA.MAX_ANT=max_ant;
                obj.DATA.AVG_ANT=avg_ant;
                obj.DATA.STD_ANT=std_ant;
                
                obj.DATA.SS_AL=SS_AL;
                obj.DATA.FPR=FPR;
                obj.DATA.OUT_AL=out;
                obj.DATA.TAR_AL=tar;
                obj.DATA.TIME_AL=time_out;
                   
                
                up_mod=obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel};
                  
                  up_mod.FPR=FPR;
                  up_mod.Firing_pow=act_al_lev;
                  up_mod.SS_AL=SS_AL;
                  up_mod.('Out_al')=out;
                  
                  up_mod.MAX_ANT=obj.DATA.MAX_ANT;
                 up_mod.MIN_ANT=obj.DATA.MIN_ANT;
                 up_mod.AVG_ANT=obj.DATA.AVG_ANT;
                 up_mod.STD_ANT=obj.DATA.STD_ANT;
                  
                  cnn_res=obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks;
                   
                   cnn_res={cnn_res{:},up_mod};
                   
                   obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks=cnn_res;
                   
                   updatePerformanceValues(obj);
                   set(gcf,'Name',['Alarm Results=CNN_' num2str(cnn_sel) ', SS=' num2str(up_mod.SS_AL)  ', FPR=' num2str(up_mod.FPR)])
                   
               else
                   
                   
                   
                   
                   
                   tar = obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Tar_al;
                   time_out=obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Time_al;
                   out=obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Out_al;
                   SS_AL=obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.SS_AL;
                   FPR=obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.FPR;
                   
                   %A2=real2th(A2,[obj.DATA.NORMAL_STATE obj.DATA.PRE_ICTAL_STATE obj.DATA.ICTAL_STATE obj.DATA.POS_ICTAL_STATE]);
                   
                   
                   
                   
                       
               end 
                   
                   time_out=time_out+obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Test_start;
                   
                   
                   
                   tm=time_out./3600;
                   
                   %Transforming Target in a series of seizure onsets
                    no_pict_idx=find(tar~=obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Pictal_state);
                    pict_idx=find(tar==obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Pictal_state);
                    tar(no_pict_idx)=0;
                    tar(pict_idx)=1;
                   
                   
                     dtar=diff(tar);
                   
                   idx_up=find(dtar==1);
                   idx_dn=find(dtar==-1);
                   
                   l_Group = hggroup;

                   for p=1:numel(idx_up)
                       
                      rectangle('Position',[tm(idx_up(p)),0,tm(idx_dn(p))-tm(idx_up(p)),0.5],'Edgecolor','b','Facecolor','b')
                      
                      hl=line([tm(idx_dn(p)+1),tm(idx_dn(p)+1)],[0,1],'LineWidth',2,'color','k')
                      set(hl,'Parent',l_Group)
                      %leg=horzcat(leg,['Sz. ',num2str(p)])
                      
                      
                   end
                   hold on
                    stem(tm,(out)-0.2,'r','Marker','*','LineWidth',1)
                   
                   
                   
                   
                   
                   set(get(get(l_Group,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','on'); 
                   
                   legend ('Onset Times','Raised Alarms');
                   title (['Alarm Results: SS=' num2str(SS_AL)  ', FPR (1/h)=' num2str(FPR)]);
                   xlabel ('Time(h)');
                   ylabel ('Prediction State')
                   axis([tm(1),tm(end),0,1])
                   else
                       
                       warndlg('Please Select a model to plot!','Plot Model')
                   
                   
                   end
                   
               end
         
           
           
           
           
           
           
           
           
           
           function updatePerformanceValues(obj)
               
               
               n_cnn=numel(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks);
               
               tab_cnn=cell(n_cnn,10);
               for sv=1:n_cnn
                   tab_cnn{sv,1}=['CNN_',num2str(sv)];
                   tab_cnn{sv,2}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.SS_AL);
                   tab_cnn{sv,3}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.FPR);
                   
                   
                   tab_cnn{sv,4}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.MIN_ANT);
                   tab_cnn{sv,5}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.MAX_ANT);
                   tab_cnn{sv,6}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.AVG_ANT);
                   tab_cnn{sv,7}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.STD_ANT);
                   
                   
                   
                   
                   tab_cnn{sv,8}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.SS);
                   tab_cnn{sv,9}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.SP);
                   tab_cnn{sv,10}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.AC);
                   tab_cnn{sv,11}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.REL);
                   tab_cnn{sv,12}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.Pictal/60);
                   tab_cnn{sv,13}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.Firing_pow*100);
                   tab_cnn{sv,14}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.NEIGHB);
                   tab_cnn{sv,15}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.NIND);
                   tab_cnn{sv,16}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.MAXGEN);
                   tab_cnn{sv,17}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.EPSIL);
                   tab_cnn{sv,18}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.SELEC);
                   tab_cnn{sv,19}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.RECOM);
                   tab_cnn{sv,20}=num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,sv}.MUTAT);
                   
                   
                   
                   
               end
               set(h.CNN.tab_res,'Data',tab_cnn);

%               obj.DATA.SP = SP; obj.DATA.SS = SS; obj.DATA.AC = AC;
% 
%               set(h.CNN.sens_text,'String', sprintf('SS = %.2f',SP));
%               set(h.CNN.spec_text,'String', sprintf('SP = %.2f',SS));
%               set(h.CNN.acc_text,'String',  sprintf('AC = %.2f',AC));
              
              
              
              
              
           end
           
           
           
%            function updatePerformanceValues(obj,SP,SS,AC)
% 
%               obj.DATA.SP = SP; obj.DATA.SS = SS; obj.DATA.AC = AC;
% 
%               set(h.CNN.sens_text,'String', ['Sensitivity = ' num2str(SP)]);
%               set(h.CNN.spec_text,'String', ['Specificity = ',num2str(SS)]);
%               set(h.CNN.acc_text,'String',  ['Accuracy = ',num2str(AC)]);
%           end


function EvaluateAlarmResultsCallback(obj, source, evendata)
                   if ~isempty(h.CNN.res_cel_sel)
                       cnn_sel=h.CNN.res_cel_sel(1);

                   projectFolder='seizureanalyzer';
                   configFolder=[projectFolder '/config'];
                   featureFolder=[projectFolder '/features'];
                   condMkdir(configFolder);
                   condMkdir(featureFolder);

                   feature={{'01'}};
                   writeFeatureConfigEpilab([configFolder '/features.xml'],feature);

    %                writeProjectConfig(fileName,projectType,resultsPath,infoPath,filesPath,FPRmaxs,SOPs,ITs,
    %                thresholds,
    %                maximumBlockDistance,maximumGaps,timeAfterSeizure)

                   writeProjectConfigEpilab([configFolder '/project.xml'],'AlarmTesting','results/',...
                      '.','features','9999',num2str(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Pictal),'10','0','0','0','0');

                    % FIND SEIZURES
                    seizures=[];
                    for i=1:length(h.study.dataset.results.feat_events)
                        if(strcmp(h.study.dataset.results.feat_events(i).type,'seizure'))
                            onset=h.study.dataset.results.feat_events(i).started;
                            offset=h.study.dataset.results.feat_events(i).stopped;
                            seizures=[seizures; onset offset];
                        end
                    end

                    writePatientConfigEpilab([configFolder '/patients.xml'],1,{seizures},...
                        int32(h.study.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Test_start),...
                        int32(h.study.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Test_stop));

                    alarms=int32(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Time_al(obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Out_al>0)+...
                           obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.Test_start);
                    
                    condMkdir([configFolder '/../results/alarms/']);
                    fAlarms=fopen([configFolder '/../results/alarms/pat001.alarms'],'w');
                    fprintf(fAlarms,'01\t0.0000\t');
                    fprintf(fAlarms,'%u\t',alarms);
                    fclose(fAlarms);
                    
                    cd('seizureanalyzer')
                    if ispc
                        system('SeizureAnalyzer.exe config')
                    elseif isunix
                        system('./seizureanalyzer_linux config')
                    end
                    cd('..')
                    
                    [SPH, SOP, FPRmax, usedSeizures, prePostIctalTime, feature, threshold, corrects, ...
                        incorrects, FPR, sensitivity, correctsTimes, incorrectsTimes, correctDiffs, incorrectDiffs] = ...
                        textread('seizureanalyzer/results/pat001/epilab/parameters.txt', '%f %f %f %f %f %s %f %f %f %s %f %s %s %s %s', -1, 'bufsize', 8*4096);

                    SPH=SPH;
                    
                    dim=str2double(inputdlg('Please enter the dimension of free parameters (e.g., the number of independent models tested)'));
                    fprintf('FPR: %f, SOP: %f, usedSeizures: %i, dim: %i, alpha: %f', str2double(FPR{1})/3600,SOP,usedSeizures,dim,0.05);
                    
                    sigLevel=calculateSigLevelEpilab(str2double(FPR{1})/3600,SOP,usedSeizures,dim,0.05);

                    msg=['The sensitivity of the alarms of the classifier is ' num2str(sensitivity) ', the FPR is ' num2str(FPR{1}) '. The sensitivity of the random predictor is ' ...
                        num2str(sigLevel) ' for the chosen dimension of free parameters of ' num2str(dim) '. Hence, the result is'];
                    if(sensitivity>sigLevel+0.000001)
                        msg=[msg ' significant'];
                        obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.REL='Sig.';
                    else
                        msg=[msg ' insignificant'];
                        obj.STUDY.dataset.results.classifiers.Cellular_Neural_Networks{1,cnn_sel}.REL='N. Sig.';
                    end
                    msg=[msg '. For this analysis, ' num2str(usedSeizures) ' seizures were analyzed. Goodbye.'];
                    msgbox(msg)
                      
                   else
                       
                       warndlg('Please Select a model to Statisticaly Evaluate!','Statistical Validation')
                       
                       
                   end
               end




      end
      
%       %Plot the classifier results
%      function PlotResults_Button(obj, source, evendata)
% 
%            %BEGIN - plot
%                figure('NumberTitle','off',...
%                 'Name',['Prediction Results=' obj.DATA.saveinfo_name ', SS=' num2str(obj.DATA.SS)  ', SP=' num2str(obj.DATA.SP) ', AC=' num2str(obj.DATA.AC)]);
% 
%                set(gcf, 'color',[0.95 0.97 0.99]);
%                
%                A2 = obj.DATA.A;
%                
%                A2=real2th(A2,[obj.DATA.NORMAL_STATE obj.DATA.PRE_ICTAL_STATE obj.DATA.ICTAL_STATE obj.DATA.POS_ICTAL_STATE]);
%                
%                timeh=[1:length(A2)].*obj.DATA.STUDY.dataset.results.parameterAcq./3600;
%                timeht=[1:length(obj.DATA.T2)].*obj.DATA.STUDY.dataset.results.parameterAcq./3600;
%                plot (timeht,obj.DATA.T2,'-g'); hold on;
%                plot (timeh,A2,'-r');
%                
%                %Plot seizure states
%                plot (timeh,ones(1,length(A2))*obj.DATA.NORMAL_STATE,':','color', [0.8 0.8 0.8]);
%                plot (timeh,ones(1,length(A2))*obj.DATA.PRE_ICTAL_STATE,':','color', [0.6 0.6 0.6]);
%                plot (timeh,ones(1,length(A2))*obj.DATA.ICTAL_STATE,':','color', [0.4 0.4 0.4]);
%                plot (timeh,ones(1,length(A2))*obj.DATA.POS_ICTAL_STATE,':','color', [0.2 0.2 0.2]);
% 
%                legend ('Real data (target)', 'Prediction (classifier output)',...
%                    ['Normal State (' num2str(obj.DATA.NORMAL_STATE) ')'],...
%                    ['Pre-ictal State (' num2str(obj.DATA.PRE_ICTAL_STATE) ')'],...
%                    ['Ictal State (' num2str(obj.DATA.ICTAL_STATE) ')'],...
%                    ['Pos-Ictal State (' num2str(obj.DATA.POS_ICTAL_STATE) ')']);
%                title (['Prediction Results=' obj.DATA.saveinfo_name ', SS=' num2str(obj.DATA.SS)  ', SP=' num2str(obj.DATA.SP) ', AC=' num2str(obj.DATA.AC)]);
%                xlabel ('Time(h)');
%                ylabel ('Seizure state')
%            %END - plot
%       end
         
      %Copy all the properties
      %REQUIRED FUNCTION
      function copyAllProperties(obj, src, dest)
          prop = fieldnames(src);
          for i=1:length(prop)    
             if ~strcmp(prop{i},'STUDY')
                eval(strcat('dest.',prop{i},'=src.',prop{i},';'));
             end   
          end    
      end     
           
   end
end