%Defines the main class and interface of classifiers
classdef Radial_Basis_Functions_Functions
   % The following properties can be set only by class methods
   properties
        DATA;
   end
    
   methods
       
      %Constructor
      function obj = Radial_Basis_Functions_Functions(data)
          global h;
          
          obj.DATA = data;
          h.RBF.last_traintype = 'x';
          h.RBF.last_sets = 'x';
      end
      
      function [SP SS AC A T2]=train(obj, train_type)
          global h;
          
          val=get(h.RBF.datasets_list,'Value');
          
          
          obj.DATA.val = val;

          %disp(obj.DATA.DATA_SETS_PATHS(val));
          
          %BEGIN - Datasets protection
              f = '';
              a = obj.DATA.FEATURES(val);
              
              aux = zeros(1,length(a));

              for i=1:length(a)
                  aux(i) = sum(a{i});
              end                  


              if length(a)>1 %If the datasets hasn't the same number of features
                  for i=1:length(aux)
                      f = strcat(f,'aux(',num2str(i),'),');
                  end

                  e = strcat('isequal(',f(1:end-1),')');

                  if ~eval(e) 
                      errordlg('Select in all datasets choosen the same number of features.');
                      SP = 0; SS = 0; AC = 0;
                      return;
                  end   
              end

              if sum(aux(i))==0 %If none feature was selected
                  errordlg('Select at least one feature/dataset.');
                  SP = 0; SS = 0; AC = 0;
                  return;                  
              end
          %END - Datasets protection
          
          
          
          h.val = val;
          h.DATA_SETS_PATHS = obj.DATA.DATA_SETS_PATHS;
          
          switch char(train_type) %TODO: Alterar o readEpi para que funcione com o study
%                 case obj.DATA.TRAIN_TYPE_MERGE7030
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'i');
%                 case obj.DATA.TRAIN_TYPE_MERGE_1
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'ii');
%                 case obj.DATA.TRAIN_TYPE_MERGE
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'iii');
                 case obj.DATA.TRAIN_TYPE_MANUAL
                    [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'i');
                    h.RBF.LoadingError=0;
%                 case obj.DATA.TRAIN_TYPE_MANUAL_PREV
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'v');
%                     h.RBF.LoadingError=0;
                case obj.DATA.TRAIN_TYPE_FROM_FILE
                    [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'ii');
                    h.RBF.LoadingError=0;
%                 case obj.DATA.TRAIN_TYPE_EQUAL
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'vii');
%                     h.RBF.LoadingError=0;
            end
          
          
          
%           
%            switch char(train_type) %TODO: Alterar o readEpi para que funcione com o study
%                case obj.DATA.TRAIN_TYPE_MERGE7030
%                    if strcmp(h.RBF.last_traintype,char(train_type)) && strcmp(h.RBF.last_sets,cell2mat(obj.DATA.DATA_SETS_PATHS(val)))
%                        P = h.RBF.train.P;
%                        T = h.RBF.train.T;
%                        Test = h.RBF.train.Test;
%                        T2 = h.RBF.train.T2;             
%                        [SP SS AC A] = rbftrain(obj, P, T, Test, T2, a);
%                    else
%                        [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'i');
%                        [SP SS AC A] = rbftrain(obj, P, T, Test, T2, a);
%                    end
%                     
%                case obj.DATA.TRAIN_TYPE_MERGE_1
%                    if strcmp(h.RBF.last_traintype,char(train_type)) && strcmp(h.RBF.last_sets,cell2mat(obj.DATA.DATA_SETS_PATHS(val)))
%                        P = h.RBF.train.P;
%                        T = h.RBF.train.T;
%                        Test = h.RBF.train.Test;
%                        T2 = h.RBF.train.T2;             
%                        [SP SS AC A] = rbftrain(obj, P, T, Test, T2, a);
%                    else
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'ii');
%                     [SP SS AC A] = rbftrain(obj, P, T, Test, T2, a);
%                    end 
%                case obj.DATA.TRAIN_TYPE_MERGE
%                    if strcmp(h.RBF.last_traintype,char(train_type)) && strcmp(h.RBF.last_sets,cell2mat(obj.DATA.DATA_SETS_PATHS(val)))
%                        P = h.RBF.train.P;
%                        T = h.RBF.train.T;
%                        Test = h.RBF.train.Test;
%                        T2 = h.RBF.train.T2;             
%                        [SP SS AC A] = rbftrain(obj, P, T, Test, T2, a);
%                    else
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'iii');
%                     [SP SS AC A] = rbftrain(obj, P, T, Test, T2, a);
%                    end 
%                case obj.DATA.TRAIN_TYPE_CROSSVALIDATION                
%                     
%                     [P T Test T2]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'iii');
%                     K = 10;
%                     indices = crossvalind('Kfold',P(1,:),K);
%                     
%                     SP_temp = zeros(K,1); SS_temp = zeros(K,1); AC_temp = zeros(K,1);
%                     for i = 1:K
%                         test = (indices == i); train = ~test;
%                         [SP_temp(i) SS_temp(i) AC_temp(i) A] = rbftrain(obj, P(:,train), T(train,:), P(:,test), T(test,:), a);
%                     end
%                     SS = mean(SS_temp); SP = mean(SP_temp);  AC = mean(AC_temp);
%                     std(SS_temp)
%                     std(SP_temp)
%                     std(AC_temp)
%            end  
           
%            if ~strcmp(h.RBF.last_traintype,char(train_type)) || ~strcmp(h.RBF.last_sets,cell2mat(obj.DATA.DATA_SETS_PATHS(val)))
%                h.RBF.last_traintype = char(train_type);
%                h.RBF.last_sets = cell2mat(obj.DATA.DATA_SETS_PATHS(val));
%                h.RBF.train.P = P;
%                h.RBF.train.T = T;
%                h.RBF.train.Test = Test;
%                h.RBF.train.T2 = T2;
%            end    
            [SP SS AC A] = rbftrain(obj, P, T, Test, T2, a); 
      end
      
      %RBF simulate
      %[SP SS AC obj.DATA.A obj.DATA.T2] = obj.FUNCTIONS.sim();
      
      function [SP SS AC A T]=sim(obj)
          global h;          
          
          val=get(h.RBF.datasets_list,'Value');          
          
          a = obj.DATA.FEATURES(obj.DATA.val);              
          
          if(~isempty(obj.DATA.model))
              h.DATA_SETS_PATHS = obj.DATA.DATA_SETS_PATHS;
              [P T]=readEpi(obj,obj.DATA.DATA_SETS_PATHS(val),'iii');
              P=P(a{1}==1,:)';
              [A,te]=simulate_rbf(obj.DATA.model,P,T);
              bfive=find(A>5);
               A(bfive)=5;
               bone=find(A<1);
               A(bone)=1;
              [SP SS AC] = calcPerformance(obj, round(A), T);
              
              
              
          else
              disp('The model is not defined..');
          end    
      end
      
      
      %Function that applies the rbf training
      function [SP SS AC A T2] = rbftrain(obj, P, T, Test, T2, a)          
          global h;
          %disp(['Select features = ' mat2str(a{1})]);
          %save('data_train_pat1.mat','P','T','Test','T2');
          
          p_fields=fieldnames(T);
            n_tar=numel(p_fields);
            n_inp_sets=numel(fieldnames(P));
           
            
            for np=1:n_tar%Vary Datasets
                for nn=1:numel(obj.DATA.n_neurons)%Vary Neurons
                    
          
          if(h.RBF.LoadingError==0)
              disp('Let''s train the network.....')
               %Train only with the selected features
%                P=P(a{1}==1,:);
%                Test=Test(a{1}==1,:);
% 
%                P = P';
%                Test = Test';  

            if n_tar==n_inp_sets
                Pi = P.(p_fields{np})';
                
            else
                if np==1
                    Pi = P.(p_fields{np})';
                end
                
            end
            Testi = Test.(p_fields{end})';

               addpath(fullfile('Toolbox','predict_by_rbf'));

               %Getting number of neurons

               Ti = T.(p_fields{np});
                %h.P = P.;
                T2i = T2.(p_fields{np});

               n_neurons=obj.DATA.n_neurons(nn);
               n_delay=obj.DATA.n_delay;
               
               
               %h.T = T;
               %h.P = P;
               
               %errordlg('You have to insert events (go to Edit Study >
               %Data info edition)');
               
               io_data.InpPat=Pi;
               
               io_data.OutPat=Ti';
   
               io_data.TestInpPat={Testi};
               io_data.TestOutPat={T2i'};
               
               rbf.WITH_BIAS=1;
               rbf.BASIS_FUNCTION=obj.DATA.basis_fun;
               rbf.INIT_RANDOM='';
               rbf.ES_COUNT=10;
               rbf.NUM_LIN=0;
               rbf.WITH_LIN=0;
               rbf.test_err=[];
               rbf.EARLY_STOP=1;
               rbf.RMSE_STOP=0;

               lmt.tauf=0.001;
               lmt.MAX_ITS=512;
               lmt.WITH_W=0;


               [rbf,err,Y]=train_rbf_predictor(io_data,rbf,lmt,n_neurons);
               
               T2i=io_data.TestOutPat{1};
               if n_delay==0
                    [A,te]=simulate_rbf(rbf,io_data.TestInpPat{1},T2i);
               else
                    [A,te]=simulate_rbf_feed(rbf,io_data.TestInpPat{1},T2i,n_delay);
               end
              
          
               
               %[A, AC, prob_estimates] = svmpredict(T2, Test, model);
               bfive=find(A>4);
               A(bfive)=4;
               bone=find(A<1);
               A(bone)=1;
               [SP SS AC] = calcPerformance(obj, round(A), T2i)
              %SS = NaN; SP = NaN; AC = NaN; A = 0; T2 = 0;
             obj.DATA.model=rbf;
             %obj.DATA.firing_power_alarm=0.5;
             
             
             obj.DATA.A=A;
             obj.DATA.T2=T2i;
             
             A2=real2th(A,[obj.DATA.NORMAL_STATE obj.DATA.PRE_ICTAL_STATE obj.DATA.ICTAL_STATE obj.DATA.POS_ICTAL_STATE]);
               
               
               
               disp(obj.DATA.firing_power_alarm)
               
               [out,tint,time_out,tar]=class2alarm(obj.DATA.test_time_vec,A2,T2i,obj.DATA.PRE_ICTAL_TIME(np),obj.DATA.PRE_ICTAL_STATE,obj.DATA.pAcq,obj.DATA.firing_power_alarm);
               [SS_AL,FPR,hours_estim,nseiz]=eval_results_alarm(out,tar);
               
               if SS_AL>0
                    time=time_out+obj.DATA.test_time_start;
                    evts=obj.DATA.STUDY.dataset.results.feat_events;
                    [min_ant,max_ant,avg_ant,std_ant]=eval_ant_times(time,tar,out,obj.DATA.PRE_ICTAL_TIME(np),evts)
                else
                    min_ant=NaN;
                    max_ant=NaN;
                    avg_ant=NaN;
                    std_ant=NaN;
                end
               
               
               obj.DATA.SS_AL=SS_AL;
               obj.DATA.FPR=FPR;
               obj.DATA.TIME_AL=time_out;
               obj.DATA.OUT_AL=out;
               obj.DATA.TAR_AL=tar;
               
               obj.DATA.MIN_ANT=min_ant;
                obj.DATA.MAX_ANT=max_ant;
                obj.DATA.AVG_ANT=avg_ant;
                obj.DATA.STD_ANT=std_ant;
               
               obj.DATA.model.('Neu')=obj.DATA.n_neurons(nn);
                   
                   if obj.DATA.basis_fun==1
                       fun_st='Gaussian';
                   elseif obj.DATA.basis_fun==2
                       fun_st='Multi-Quad.';
                   elseif obj.DATA.basis_fun==3
                       fun_st='Inv. Multi-Quad.';
                   else
                       fun_st='Undef.';
                   end
                   
                   obj.DATA.model.('Transfer_Functions')=fun_st;
                   obj.DATA.model.('Firing_pow')=obj.DATA.firing_power_alarm;
                   obj.DATA.model.('SP')=SP;
                   obj.DATA.model.('SS')=SS;
                   obj.DATA.model.('AC')=AC;
                   obj.DATA.model.('FPR')=obj.DATA.FPR;
                   obj.DATA.model.('SS_AL')=obj.DATA.SS_AL;
                   obj.DATA.model.('REL')=obj.DATA.REL;
                   obj.DATA.model.('Tar')=obj.DATA.T2;
                   obj.DATA.model.('Out')=obj.DATA.A;
                   obj.DATA.model.('Time')=obj.DATA.test_time_vec;
                   obj.DATA.model.('Tar_al')=obj.DATA.TAR_AL;
                   obj.DATA.model.('Out_al')=obj.DATA.OUT_AL;
                   obj.DATA.model.('Time_al')=obj.DATA.TIME_AL;
                   
                   obj.DATA.model.('Train_start_idx')=obj.DATA.train_time_start_idx;
                   obj.DATA.model.('Train_stop_idx')=obj.DATA.train_time_end_idx;
                   obj.DATA.model.('Train_start')=obj.DATA.train_time_start;
                   obj.DATA.model.('Train_stop')=obj.DATA.train_time_end;
                    
                   obj.DATA.model.('Test_start_idx')=obj.DATA.test_time_start_idx;
                   obj.DATA.model.('Test_stop_idx')=obj.DATA.test_time_end_idx;
                    obj.DATA.model.('Test_start')=obj.DATA.test_time_start;
                    obj.DATA.model.('Test_stop')=obj.DATA.test_time_end;
                    
                    obj.DATA.model.('Is_equal_classes')=obj.DATA.is_equal_classes;
      
                    obj.DATA.model.('Inp_features')=obj.DATA.inp_feat;
                    obj.DATA.model.('Inp_features_idx')=obj.DATA.inp_feat_idx;
                    obj.DATA.model.('Pictal')=obj.DATA.PRE_ICTAL_TIME(np);
                obj.DATA.model.('Pictal_state')=obj.DATA.PRE_ICTAL_STATE;
                   obj.DATA.model.('norm_factors')=obj.DATA.norm_factors;
                    
                   
                   obj.DATA.model.('MAX_ANT')=obj.DATA.MAX_ANT;
                   obj.DATA.model.('MIN_ANT')=obj.DATA.MIN_ANT;
                   obj.DATA.model.('AVG_ANT')=obj.DATA.AVG_ANT;
                   obj.DATA.model.('STD_ANT')=obj.DATA.STD_ANT;
                   
                    rbf_res=obj.DATA.STUDY.dataset.results.classifiers.Radial_Basis_Functions;
                   
                   rbf_res={rbf_res{:},obj.DATA.model};
                   
                   obj.DATA.STUDY.dataset.results.classifiers.Radial_Basis_Functions=rbf_res;
               
               
             
          else
              disp('Impossible to train the network.....') 
               SS = NaN; SP = NaN; AC = NaN; A = 0; T2 = 0;
          end 
           
                end
            end
      end    
      
      
      
      
      function [P T Test T2] = readEpi(obj, path, type)
            global h;
            switch(type)
                
%                 case 'i'
%                     
%                     %0. Read and normalize
%                     m=readNorm(obj, path);
%                     
%                     %1. Create Test matrix (Test)
%                     Test=m(1:3:end,:);
%                     m(1:3:end,:)=[];
%                     
%                     %2. Create the target matrix (T)
%                     T=zeros(4,length(m));
%                     for i = 1:length(m),
%                         n = m(i,1);
%                         T(n,i)=1;
%                     end
%                     
%                     %3. Create the target for Test (T2)
%                     T2=Test(:,1);
%                     
%                     %4. Create and transpose P
%                     P=m(:,2:end);
%                     P=P';
%                     
%                     %5. Clean and transpose Test
%                     Test=Test(:,2:end);
%                     Test=Test';
%                     
%                     
%                 case 'ii'
%                     %0. Read and normalize
%                     m=readNorm(obj, path(1:(end-1)));
%                     Test=readNorm(obj, path(end));
%                     
%                     %1. Create the target matrix (T)
%                     T=zeros(4,length(m));
%                     for i = 1:length(m),
%                         n = m(i,1);
%                         T(n,i)=1;
%                     end
%                     
%                     %2. Create the target for Test (T2)
%                     T2=Test(:,1);
%                     
%                     %3. Create and transpose P
%                     P=m(:,2:end);
%                     P=P';
%                     
%                     %4. Clean and transpose Test
%                     Test=Test(:,2:end);
%                     Test=Test';
%                     
%                 case 'iii'
%                     %0. Read and normalize
%                     m=readNorm(obj, path);
%                     Test=readNorm(obj, path(end));
%                     
%                     %1. Create the target matrix (T)
%                     T=zeros(4,length(m));
%                     for i = 1:length(m),
%                         n = m(i,1);
%                         T(n,i)=1;
%                     end
%                     
%                     %2. Create the target for Test (T2)
%                     T2=Test(:,1);
%                     
%                     %3. Create and transpose P
%                     P=m(:,2:end);
%                     P=P';
%                     
%                     %4. Clean and transpose Test
%                     Test=Test(:,2:end);
%                     Test=Test';
                    
                case 'i'
                    %select data by visual inspection of the features | create feature interface
                    
                    
                    
                    par_file=fullfile(obj.DATA.STUDY.workspace_path,'train_cache','last_man_data_sets.mat');
                    pictal_delta=obj.DATA.PRE_ICTAL_TIME;
                    
                    if exist(par_file,'file')
                        disp('last man exists')
                        dl=load(par_file)
                        sel_feat=dl.sel_feat
                        low_pass_stat=dl.low_pass_stat;
                        low_cut_off=dl.low_cut_off;
                        %prev_pictal=dl.pictal_delta;
                        %equal_class=dl.equal_class;
                        
                        %prev_pictal=dl.i;
                    else
                        disp('last man do not exists')
                        sel_feat=1;
                        low_pass_stat=0;
                        equal_class=0;
                        low_cut_off=0.1;
                        %prev_pictal=obj.DATA.PRE_ICTAL_TIME;
                    end
                    d_selection = MultiFeatPlot(obj.DATA.STUDY);
                    d_selection.get_data_sets_idx(sel_feat,low_pass_stat,low_cut_off,pictal_delta);
                    
                    uiwait();
                    
                    %dataset selection 
                    try
                        [dat_train_time_start] = d_selection.data_sets.train.start*60; %time stamp minutes - seconds                    
                        [dat_train_time_end] = d_selection.data_sets.train.end*60; %time stamp minutes - seconds
                    catch
                        dat_train_time_start=dl.dat_train_time_start;
                        dat_train_time_end=dl.dat_train_time_end;
                    end
                    
                    try
                        [dat_test_time_start] = d_selection.data_sets.test.start*60; %time stamp minutes - seconds
                        [dat_test_time_end] = d_selection.data_sets.test.end*60; %time stamp minutes - seconds
                     catch
                        dat_test_time_start=dl.dat_test_time_start;
                        dat_test_time_end=dl.dat_test_time_end;
                    end
                    
                    
%                     try
%                          [pictal_delta] = d_selection.data_sets.preictal*60 %time stamp minutes - seconds
%                     
%                          %[pictal_time_end] = d_selection.data_sets.preictal.end*60; %time stamp minutes - seconds
%                      
%                          %pictal_delta=pictal_time_end-pictal_time_start;
%                          obj.DATA.PRE_ICTAL_TIME=pictal_delta;
%                      catch
%                          obj.DATA.PRE_ICTAL_TIME=dl.pictal_delta;
%                          pictal_delta=dl.pictal_delta;
%                     end
%                      obj.DATA.pictal_delta=pictal_delta;
                     
                    
                    
                    try
                          equal_class=d_selection.equal_class; 
                    
                         
                     catch
                         equal_class=dl.equal_class; 
                    end
                    
                    try
                          low_pass_stat=d_selection.low_pass_stat; 
                    
                         
                     catch
                         low_pass_stat=dl.low_pass_stat;
                     end
                     
                    
                    
%                      if pictal_delta<obj.DATA.PRE_ICTAL_TIME
%                        pictal_delta=obj.DATA.PRE_ICTAL_TIME;
%                      end
                    
                    
                    p_acq = obj.DATA.STUDY.dataset.results.parameterAcq;
                    obj.DATA.pAcq=p_acq;
                    
                    
                    dat_train_time_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_train_time_start/p_acq))*p_acq);             
                    dat_train_time_start_idx =dat_train_time_start_idx(1);
                    
                    dat_train_time_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_train_time_end/p_acq))*p_acq);
                    dat_train_time_end_idx = dat_train_time_end_idx(1);
                    
                    dat_test_time_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_test_time_start/p_acq))*p_acq);
                    
                    dat_test_time_start_idx = dat_test_time_start_idx(1);
                    
                    
                    dat_test_time_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_test_time_end/p_acq))*p_acq);
                    dat_test_time_end_idx =dat_test_time_end_idx(1);
                    
                    
                    sel_feat=d_selection.select_feat
                    sel_feat_names=d_selection.select_feat_names;
                    low_pass_stat=d_selection.low_pass_stat;
                    low_cut_off=d_selection.low_cut_off;
                    parameterAcq=d_selection.parameterAcq;
                    equal_class=d_selection.equal_class;
                    evts=obj.DATA.STUDY.dataset.results.feat_events;
                    ev_struct=evts;
                    
                    
                    
                    
                    
                    
                    save(fullfile(obj.DATA.STUDY.workspace_path,'train_cache','last_man_data_sets.mat'),'dat_train_time_start','dat_train_time_end','dat_test_time_start','dat_test_time_end','pictal_delta','dat_train_time_start_idx','dat_train_time_end_idx',...
                        'dat_test_time_start_idx','dat_test_time_end_idx','sel_feat','sel_feat_names','low_pass_stat','low_cut_off','parameterAcq','equal_class','ev_struct')
                   
                    
                    
                    
%                     disp(['selected features:',num2str(d_selection.select_feat)])
%                     
%                     set(h.ANN.features_list,'Value',d_selection.select_feat)
%                     
                    

                    train_d_matrix=[];
                    test_d_matrix=[];
                    
                    if obj.DATA.STUDY.from_raw==0%Get features from feature file
                    
                    
                    
                    n_loaded_files=size(obj.DATA.STUDY.dataset.file,2);
                    
                    
                    
                    act_tot_feat=0;
                    start_feat_idx=find(d_selection.select_feat>0);
                    
                    
                    d_selection.select_feat
                    
                    
                    for k=1:n_loaded_files

                        f_path = fullfile(obj.DATA.STUDY.dataset.file(k).path,...
                            obj.DATA.STUDY.dataset.file(k).filename);
                        
                        file_name=obj.DATA.STUDY.dataset.file(k).filename;


                        

                        feat_bin_o = feat_bin_file(f_path);

                        stop_feat_idx=find(d_selection.select_feat<=(act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features)));

                        act_feat_idx=intersect(start_feat_idx,stop_feat_idx);

                        start_feat_idx=find(d_selection.select_feat>act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features));

                        act_feat=d_selection.select_feat(act_feat_idx)-act_tot_feat;
                        
                        act_tot_feat=act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features);
                       

                        % function get_matrix
                        l=act_feat
                        
                        
                        train_d_matrix = [train_d_matrix,feat_bin_o.file2matrix(dat_train_time_start_idx, dat_train_time_end_idx,act_feat)];
                        [te_data,time]=feat_bin_o.file2matrix(dat_test_time_start_idx, dat_test_time_end_idx,act_feat);
                        test_d_matrix = [test_d_matrix,te_data];
                        

                        feat_bin_o.delete();
                        clear feat_bin_o;
                       

                    end
                    
                    
                    
                    
                    
%                     if ~isempty(oth_feat_idx)%Look for other features located in other files
%                         
%                         f_path_oth = fullfile(obj.DATA.STUDY.dataset.file(f).path,...
%                         obj.DATA.STUDY.dataset.file(f).filename);
%                         feat_bin_o_oth = feat_bin_file(f_path_oth);
%                         
%                         
%                     
%                         oth_feat_curr_idx=intersect(oth_feat_idx,oth_feat_sup_idx);
%                         
%                         oth_feat=d_selection.select_feat(oth_feat_idx)-(feat_bin_o.a_n_chan*feat_bin_o.a_n_features);
%                    
%                         
%                         
%                         train_d_matrix =[train_d_matrix, feat_bin_o_oth.file2matrix(dat_train_time_start_idx, dat_train_time_end_idx)];
%                         test_d_matrix = [test_d_matrix,feat_bin_o_oth.file2matrix(dat_test_time_start_idx, dat_test_time_end_idx)];
%                         
%                     end
                    

                    %evts=obj.DATA.STUDY.dataset.results.feat_events;
%                     train_target = build_target(obj.DATA.STUDY.dataset.file(1).data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
%                             dat_train_time_end_idx,pictal_delta); % train data_set
%                         test_target = build_target(obj.DATA.STUDY.dataset.file(1).data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
%                             dat_test_time_end_idx,pictal_delta); % test data_set
                    
                    disp(['Tamanho:',num2str(size(train_d_matrix))])
                    else%Get features from Epilab structure
                        
                        feat_types=fieldnames(obj.DATA.STUDY.dataset.results.featureExtractionMethods);
                        for ft=1:size(sel_feat_names,2)
                            for typ=1:size(feat_types,1)
                                %sel_feat_names{ft}
                                
                                tot_feats={fieldnames(h.study.dataset.results.featureExtractionMethods.(feat_types{typ}).c_)};
                                
                                tot_feats=tot_feats{1};
                                
                                for tt=1:size(tot_feats,1)
                                %    disp(tot_feats{tt})%,' with ',sel_feat_names{ft}])
                                    if strcmp(sel_feat_names{ft},tot_feats{tt,1})
                                    mat_data=h.study.dataset.results.featureExtractionMethods.(feat_types{typ}).c_.(tot_feats{tt,1});
                           
                                    
                                    train_d_matrix = [train_d_matrix,mat_data(dat_train_time_start_idx:dat_train_time_end_idx-1)'];
                                    test_d_matrix = [test_d_matrix,mat_data(dat_test_time_start_idx:dat_test_time_end_idx-1)'];
                                    end
                                    
                                %end
                            end
                        end
                        
                        
                        end
                        
                        %evts=d_selection.ev_struct;
                        
%                         train_target = build_target(d_selection.ev_struct,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
%                             dat_train_time_end_idx,pictal_delta); % train data_set
%                         test_target = build_target(d_selection.ev_struct,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
%                             dat_test_time_end_idx,pictal_delta); % test data_set
                        
                    end
                   % evts=obj.DATA.STUDY.dataset.results.feat_events;
                    
                    obj.DATA.test_time_vec=obj.DATA.STUDY.dataset.results.glbTime(dat_test_time_start_idx:dat_test_time_end_idx-1);
% % % %                     fclose(feat_bin_o.fd); %%%% TODO NAO CONSIGO
% FECHAR...propriedade protected na classe

                    %% 2. Create/Add target 
                    
                     %  target = build_target(events, time_vector, start_idx, end_idx, PREICTAL_TIME, EARLY_DETECTION_PERIOD, P_ACQ, NUM_CL)

                       
                        
% %                         save targets.mat train_target test_target
                    
                    
% % % %                     train_target = buildTarget(obj, dat_train_time_start_idx, dat_train_time_end_idx); % train data_set
% % % %                     test_target = buildTarget(obj, dat_test_time_start_idx, dat_test_time_end_idx); % test data_set
                    
            
                    
                    
                     
                    
                    %% 3. Create Test matrix (Test) and Train matrix (P)
                    
                    P  = train_d_matrix;
                    
                    %P=P(:,d_selection.select_feat);
                    
                    Test = test_d_matrix;
                    %Test=Test(:,d_selection.select_feat);
                    
                    
                    P=rep_nan(P,0);
                    
%                     [idx_r_tr,idx_c_tr,v]=find(isnan(P));
%                     
%                     nc=size(idx_r_tr)
%                     
%                     P(idx_n_tr,:)=[];
%                    
                    
                    Test=rep_nan(Test,0);
%                     idx_n_te=find(isnan(Test));
%                     
%                     Test(idx_n_te,:)=[];
                   
                    
                    
%                     size(P)
%                     size(T')
%                     
%                     plot(obj.DATA.STUDY.dataset.results.glbTime)
%                     pause
                    
                    
                    if low_pass_stat%If the low-pass filter check button is pressed

                        %Get the cut-off frequency from the appropriate text edit object
                        

                        
                            P=low_pass_filter(P,d_selection.low_cut_off,5,d_selection.parameterAcq)';
           
                           Test=low_pass_filter(Test,d_selection.low_cut_off,5,d_selection.parameterAcq)';
                    else
                        P=P';
                        Test=Test';
                            
                    end
                    
                    
                    
                    [Pn,Testn,factors] =  normalize_set(P',Test',obj.DATA.NORMAL_STATE, obj.DATA.POS_ICTAL_STATE);
                    
                    P=[];
                    Test=[];
                    
                    
                    for np=1:numel(pictal_delta)
                    
                    train_target = build_target(evts,...
                        obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
                        dat_train_time_end_idx,pictal_delta(np),obj.DATA.EARLY_DETECT_TIME, ...
                        obj.DATA.pAcq, obj.DATA.TARGET_SELECTED); % train data_set
                    test_target = build_target(evts,...
                        obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
                        dat_test_time_end_idx,pictal_delta(np),obj.DATA.EARLY_DETECT_TIME, ...
                        obj.DATA.pAcq, obj.DATA.TARGET_SELECTED); % test data_set
                    
                    
                    Ti = train_target';
                    
                    %Test=Test(:,d_selection.select_feat);
                    T2i = test_target';
                    
                    Pi=[Pn,Ti'];
                    
                    tr_mat=delay_mat(Pi,1,obj.DATA.n_delay+1);
                    
                    Pi=tr_mat(:,1:end-1)';
                    Ti=tr_mat(:,end)';
                    
                    Testi=[Testn,T2i'];
                    te_mat=delay_mat(Testi,1,obj.DATA.n_delay+1);
                    
                    
                    
                    Testi=te_mat(:,1:end-1)';
                    T2i=te_mat(:,end)';
                    
                    
                          
                    if  equal_class
                        
                        [Pi,Ti]=equalise_classes(obj,Pi,Ti,0);
                        
                        P.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Pi;
                        
                    else
                        if np==1
                            P.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Pi;
                            
                        end
                        
                        
                    end
                    
                    
                    T.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Ti;
                    T2.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=T2i;
                    
                    end 
                    
                    
                    Test.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Testi;
                    
%                     P=[P,T'];
%                         
%                         tr_mat=delay_mat(P,1,obj.DATA.n_delay+1);
%                         
%                          P=tr_mat(:,1:end-1)';
%                          T=tr_mat(:,end)';
%                          
%                          Test=[Test,T2'];
%                         te_mat=delay_mat(Test,1,obj.DATA.n_delay+1);
%                         
%                          Test=te_mat(:,1:end-1)';
%                          T2=te_mat(:,end)';
%                          
%                          
%                          
%                          
%                          
%                          
%                          
%                          
%                          
%                        
%                       if  equal_class
%                           
%                           
%                           T = train_target';
%                           
%                           T2 = test_target';
%                           
%                         [P,T]=equalise_classes(obj,P,T,0);   
%                       end
%                       
%                       
                        


            
                    
                    clear train_d_matrix
                    clear test_d_matrix
                    clear d_selection;
                    
%                     case 'v'
%                     if exist('last_man_data_sets.mat')
%                         dl=load('last_man_data_sets.mat')
%                         f_path = fullfile(obj.DATA.STUDY.dataset.file(1).path,...
%                             obj.DATA.STUDY.dataset.file(1).filename);
% 
%                         feat_bin_o = feat_bin_file(f_path);
%                         
%                         ecg_feat_idx=find(dl.sel_feat>(feat_bin_o.a_n_chan*feat_bin_o.a_n_features));
%                     
%                         ecg_feat=dl.sel_feat(ecg_feat_idx)-(feat_bin_o.a_n_chan*feat_bin_o.a_n_features);
%                         
%                         
%                         % function get_matrix
% 
%                         train_d_matrix = feat_bin_o.file2matrix(dl.dat_train_time_start_idx, dl.dat_train_time_end_idx);
%                         test_d_matrix = feat_bin_o.file2matrix(dl.dat_test_time_start_idx, dl.dat_test_time_end_idx);
%                         
%                         fclose(feat_bin_o.fd);
%                         feat_bin_o.delete();
%                     clear feat_bin_o;
%                     
%                     
%                     
%                     if ~isempty(ecg_feat)%Look for ECG features
%                         f_path_ecg = fullfile(obj.DATA.STUDY.dataset.file(2).path,...
%                         obj.DATA.STUDY.dataset.file(2).filename);
%                         feat_bin_o_ecg = feat_bin_file(f_path_ecg);
%                         
%                         train_d_matrix =[train_d_matrix, feat_bin_o_ecg.file2matrix(dl.dat_train_time_start_idx, dl.dat_train_time_end_idx)];
%                         test_d_matrix = [test_d_matrix,feat_bin_o_ecg.file2matrix(dl.dat_test_time_start_idx, dl.dat_test_time_end_idx)];
%                         
%                     end
%                         
%                         disp(['Tamanho:',num2str(size(train_d_matrix))])
%                         
% 
%                         %% 2. Create/Add target
%                         
%                         
%                         %pictal_delta=obj.DATA.PRE_ICTAL_TIME;
%                         obj.DATA.PRE_ICTAL_TIME=dl.pictal_delta;
%                         
%                         
%                          %  target = build_target(events, time_vector, start_idx, end_idx, PREICTAL_TIME, EARLY_DETECTION_PERIOD, P_ACQ, NUM_CL)
% 
%                         train_target = build_target(obj.DATA.STUDY.dataset.file.data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dl.dat_train_time_start_idx, ...
%                             dl.dat_train_time_end_idx,obj.DATA.PRE_ICTAL_TIME); % train data_set
%                         test_target = build_target(obj.DATA.STUDY.dataset.file.data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dl.dat_test_time_start_idx,...
%                             dl.dat_test_time_end_idx,obj.DATA.PRE_ICTAL_TIME); % test data_set
%                         
% % %                         
% % %                         train_target = buildTarget(obj, dl.dat_train_time_start_idx, dl.dat_train_time_end_idx); % train data_set
% % %                         test_target = buildTarget(obj, dl.dat_test_time_start_idx, dl.dat_test_time_end_idx); % test data_set
% 
% 
% 
%                         %% 3. Create Test matrix (Test) and Train matrix (P)
% 
%                         %                     P  = train_d_matrix';
%                         %                     P=P(d_selection.select_feat,:);
%                         %                     T = train_target';
%                         %                     Test = test_d_matrix';
%                         %                     Test=Test(d_selection.select_feat,:);
%                         %                     T2 = test_target';
%                         %save('1328903.mat','T')
% 
%                         P  = train_d_matrix;
%                         P=P(:,dl.sel_feat);
%                         T = train_target';
%                         Test = test_d_matrix;
%                         Test=Test(:,dl.sel_feat);
%                         T2 = test_target';
%                         
%                         
%                         
%                         idx_n_tr=find(isnan(P));
%                     
%                         P(idx_n_tr,:)=0;
%                         
%                     
%                     
%                         idx_n_te=find(isnan(P));
%                     
%                         Test(idx_n_te,:)=0;
%                         
%                         
%                         
%                         
%                         
%                         if dl.low_pass_stat%If the low-pass filter check button is pressed
% 
%                             %Get the cut-off frequency from the appropriate text edit object
% 
% 
% 
%                             P=low_pass_filter(P,dl.low_cut_off,5,dl.parameterAcq)';
%                             Test=low_pass_filter(Test,dl.low_cut_off,5,dl.parameterAcq)';
%                         else
%                             P=P';
%                             Test=Test';
% 
%                         end
%                         
%                         [P,Test] =  normalize_set(P',Test',obj.DATA.NORMAL_STATE, obj.DATA.POS_ICTAL_STATE);
%                         %save('data_test_arft10_wav5ft10_wav5fp2_wav6fz','P','T','Test','T2');
%                         
%                         P=[P,T'];
%                         
%                         tr_mat=delay_mat(P,1,obj.DATA.n_delay+1);
%                         
%                          P=tr_mat(:,1:end-1)';
%                          T=tr_mat(:,end)';
%                          
%                          Test=[Test,T2'];
%                         te_mat=delay_mat(Test,1,obj.DATA.n_delay+1);
%                         
%                          Test=te_mat(:,1:end-1)';
%                          T2=te_mat(:,end)';
%                         
%                         
%                         
%                         
%                         
% 
%                         clear train_d_matrix
%                         clear test_d_matrix
%                         %clear d_selection;
% 
% 
%                     else
%                         disp('file not exist')
%                         warndlg('Index file not found: last_man_data_sets.mat')
% 
%                     end
                    
                    case 'ii'
                        [FileName,PathName,FilterIndex] = uigetfile('*.mat')
                        
                    
                        dl=load(fullfile(PathName,FileName));
                        
                        
                        
                        
                        
%                         sel_feat=dl.sel_feat
%                         low_pass_stat=dl.low_pass_stat;
%                         low_cut_off=dl.low_cut_off;
%                         prev_pictal=dl.pictal_delta;
%                         equal_class=dl.equal_class;
%                         ev_struct=dl.ev_struct;
                        %prev_pictal=dl.i;
                    
                    
                    
                    %uiwait();
                    
                    %dataset selection 
                    
                        dat_train_time_start=dl.dat_train_time_start;
                        dat_train_time_end=dl.dat_train_time_end;
                    
                        dat_test_time_start=dl.dat_test_time_start;
                        dat_test_time_end=dl.dat_test_time_end;
                    
                    
                    
                    
                         obj.DATA.PRE_ICTAL_TIME=dl.pictal_delta;
                         pictal_delta=dl.pictal_delta;
                    
                     obj.DATA.pictal_delta=pictal_delta;
                     
                    
                    
                    
                         
                         equal_class=dl.equal_class; 
                    
                         low_pass_stat=dl.low_pass_stat;
                     
                     
                    
                    
%                      if pictal_delta<obj.DATA.PRE_ICTAL_TIME
%                        pictal_delta=obj.DATA.PRE_ICTAL_TIME;
%                      end
                    
                    
                    p_acq = obj.DATA.STUDY.dataset.results.parameterAcq;
                    
                    obj.DATA.pAcq=p_acq;
                    dat_train_time_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_train_time_start/p_acq))*p_acq);             
                    dat_train_time_start_idx =dat_train_time_start_idx(1);
                    
                    dat_train_time_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_train_time_end/p_acq))*p_acq);
                    dat_train_time_end_idx = dat_train_time_end_idx(1);
                    
                    
                    dat_test_time_start_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_test_time_start/p_acq))*p_acq);
                    
                    dat_test_time_start_idx = dat_test_time_start_idx(1);
                    
                    
                    dat_test_time_end_idx = find(obj.DATA.STUDY.dataset.results.glbTime >=...
                        (ceil(dat_test_time_end/p_acq))*p_acq);
                    dat_test_time_end_idx =dat_test_time_end_idx(1);
                    
                    sel_feat=dl.sel_feat;
                    sel_feat_names=dl.sel_feat_names;
                    low_pass_stat=dl.low_pass_stat;
                    low_cut_off=dl.low_cut_off;
                    parameterAcq=dl.parameterAcq;
                    equal_class=dl.equal_class;
                    evts=obj.DATA.STUDY.dataset.results.feat_events;
                    ev_struct=evts;
                    save(fullfile(obj.DATA.STUDY.workspace_path,'train_cache','last_man_data_sets.mat'),'dat_train_time_start','dat_train_time_end','dat_test_time_start','dat_test_time_end','pictal_delta','dat_train_time_start_idx','dat_train_time_end_idx',...
                        'dat_test_time_start_idx','dat_test_time_end_idx','sel_feat','sel_feat_names','low_pass_stat','low_cut_off','parameterAcq','equal_class','ev_struct')
                   
                    
                    
                    
%                     disp(['selected features:',num2str(d_selection.select_feat)])
%                     
%                     set(h.ANN.features_list,'Value',d_selection.select_feat)
%                     
                    

                    train_d_matrix=[];
                    test_d_matrix=[];
                    
                    if obj.DATA.STUDY.from_raw==0%Get features from feature file
                    
                    
                    
                    n_loaded_files=size(obj.DATA.STUDY.dataset.file,2);
                    
                    
                    
                    act_tot_feat=0;
                    start_feat_idx=find(sel_feat>0);
                    
                    
                    
                    
                    
                    for k=1:n_loaded_files

                        f_path = fullfile(obj.DATA.STUDY.dataset.file(k).path,...
                            obj.DATA.STUDY.dataset.file(k).filename);
                        
                        file_name=obj.DATA.STUDY.dataset.file(k).filename;


                        

                        feat_bin_o = feat_bin_file(f_path);

                        stop_feat_idx=find(dl.sel_feat<=(act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features)));

                        act_feat_idx=intersect(start_feat_idx,stop_feat_idx);

                        start_feat_idx=find(dl.sel_feat>act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features));

                        act_feat=dl.sel_feat(act_feat_idx)-act_tot_feat;
                        
                        act_tot_feat=act_tot_feat+(feat_bin_o.a_n_chan*feat_bin_o.a_n_features);
                       

                        % function get_matrix
                        l=act_feat
                        train_d_matrix = [train_d_matrix,feat_bin_o.file2matrix(dat_train_time_start_idx, dat_train_time_end_idx,act_feat)];
                        test_d_matrix = [test_d_matrix,feat_bin_o.file2matrix(dat_test_time_start_idx, dat_test_time_end_idx,act_feat)];
                        

                        feat_bin_o.delete();
                        clear feat_bin_o;
                       

                    end
                    
                    
                    
%                     if ~isempty(oth_feat_idx)%Look for other features located in other files
%                         
%                         f_path_oth = fullfile(obj.DATA.STUDY.dataset.file(f).path,...
%                         obj.DATA.STUDY.dataset.file(f).filename);
%                         feat_bin_o_oth = feat_bin_file(f_path_oth);
%                         
%                         
%                     
%                         oth_feat_curr_idx=intersect(oth_feat_idx,oth_feat_sup_idx);
%                         
%                         oth_feat=d_selection.select_feat(oth_feat_idx)-(feat_bin_o.a_n_chan*feat_bin_o.a_n_features);
%                    
%                         
%                         
%                         train_d_matrix =[train_d_matrix, feat_bin_o_oth.file2matrix(dat_train_time_start_idx, dat_train_time_end_idx)];
%                         test_d_matrix = [test_d_matrix,feat_bin_o_oth.file2matrix(dat_test_time_start_idx, dat_test_time_end_idx)];
%                         
%                     end
                    

                    %evts=obj.DATA.STUDY.dataset.results.feat_events;
%                     train_target = build_target(obj.DATA.STUDY.dataset.file(1).data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
%                             dat_train_time_end_idx,pictal_delta); % train data_set
%                         test_target = build_target(obj.DATA.STUDY.dataset.file(1).data.eeg_events,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
%                             dat_test_time_end_idx,pictal_delta); % test data_set
                    
                    disp(['Tamanho:',num2str(size(train_d_matrix))])
                    else%Get features from Epilab structure
                        
                        feat_types=fieldnames(obj.DATA.STUDY.dataset.results.featureExtractionMethods);
                        for ft=1:size(sel_feat_names,2)
                            for typ=1:size(feat_types,1)
                                %sel_feat_names{ft}
                                
                                tot_feats={fieldnames(h.study.dataset.results.featureExtractionMethods.(feat_types{typ}).c_)};
                                
                                tot_feats=tot_feats{1};
                                
                                for tt=1:size(tot_feats,1)
                                %    disp(tot_feats{tt})%,' with ',sel_feat_names{ft}])
                                    if strcmp(sel_feat_names{ft},tot_feats{tt,1})
                                    mat_data=h.study.dataset.results.featureExtractionMethods.(feat_types{typ}).c_.(tot_feats{tt,1});
                           
                                    
                                    train_d_matrix = [train_d_matrix,mat_data(dat_train_time_start_idx:dat_train_time_end_idx-1)'];
                                    test_d_matrix = [test_d_matrix,mat_data(dat_test_time_start_idx:dat_test_time_end_idx-1)'];
                                    end
                                    
                                %end
                            end
                        end
                        
                        
                        end
                        
                        %evts=ev_struct;
%                         train_target = build_target(ev_struct,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
%                             dat_train_time_end_idx,pictal_delta); % train data_set
%                         test_target = build_target(ev_struct,...
%                             obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
%                             dat_test_time_end_idx,pictal_delta); % test data_set
                        
                    end
                    
                    obj.DATA.test_time_vec=obj.DATA.STUDY.dataset.results.glbTime(dat_test_time_start_idx:dat_test_time_end_idx-1)';
                    
% % % %                     fclose(feat_bin_o.fd); %%%% TODO NAO CONSIGO
% FECHAR...propriedade protected na classe

                    %% 2. Create/Add target 
                    
                     %  target = build_target(events, time_vector, start_idx, end_idx, PREICTAL_TIME, EARLY_DETECTION_PERIOD, P_ACQ, NUM_CL)

                       
                        
% %                         save targets.mat train_target test_target
                    
                    
% % % %                     train_target = buildTarget(obj, dat_train_time_start_idx, dat_train_time_end_idx); % train data_set
% % % %                     test_target = buildTarget(obj, dat_test_time_start_idx, dat_test_time_end_idx); % test data_set
                    
            
                    
                    
                     
                    
                    %% 3. Create Test matrix (Test) and Train matrix (P)
                    
                    P  = train_d_matrix;
                    
                    %P=P(:,d_selection.select_feat);
                    
                    Test = test_d_matrix;
                    %Test=Test(:,d_selection.select_feat);
                    
                    
                    P=rep_nan(P,0);
                    
%                     [idx_r_tr,idx_c_tr,v]=find(isnan(P));
%                     
%                     nc=size(idx_r_tr)
%                     
%                     P(idx_n_tr,:)=[];
%                    
                    
                    Test=rep_nan(Test,0);
%                     idx_n_te=find(isnan(Test));
%                     
%                     Test(idx_n_te,:)=[];
                   
                    
                    
%                     size(P)
%                     size(T')
%                     
%                     plot(obj.DATA.STUDY.dataset.results.glbTime)
%                     pause
                    
                    
                    if low_pass_stat%If the low-pass filter check button is pressed

                        %Get the cut-off frequency from the appropriate text edit object
                        

                        
                            P=low_pass_filter(P,low_cut_off,5,p_acq)';
           
                           Test=low_pass_filter(Test,low_cut_off,5,p_acq)';
                    else
                        P=P';
                        Test=Test';
                            
                    end
                    
                    
                    
                    [Pn,Testn,factors] =  normalize_set(P',Test',obj.DATA.NORMAL_STATE, obj.DATA.POS_ICTAL_STATE);
                    
                    P=[];
                    Test=[];
                    
                    for np=1:numel(pictal_delta)
                    
                    train_target = build_target(evts,...
                        obj.DATA.STUDY.dataset.results.glbTime, dat_train_time_start_idx, ...
                        dat_train_time_end_idx,pictal_delta(np),obj.DATA.EARLY_DETECT_TIME, ...
                        obj.DATA.pAcq, obj.DATA.TARGET_SELECTED); % train data_set
                    test_target = build_target(evts,...
                        obj.DATA.STUDY.dataset.results.glbTime, dat_test_time_start_idx,...
                        dat_test_time_end_idx,pictal_delta(np),obj.DATA.EARLY_DETECT_TIME, ...
                        obj.DATA.pAcq, obj.DATA.TARGET_SELECTED); % test data_set
                    
                    
                    Ti = train_target';
                    
                    %Test=Test(:,d_selection.select_feat);
                    T2i = test_target';
                    
                    Pi=[Pn,Ti'];
                    
                    tr_mat=delay_mat(Pi,1,obj.DATA.n_delay+1);
                    
                    Pi=tr_mat(:,1:end-1)';
                    Ti=tr_mat(:,end)';
                    
                    Testi=[Testn,T2i'];
                    te_mat=delay_mat(Testi,1,obj.DATA.n_delay+1);
                    
                    
                    
                    Testi=te_mat(:,1:end-1)';
                    T2i=te_mat(:,end)';
                    
                    
                          
                    if  equal_class
                        
                        [Pi,Ti]=equalise_classes(obj,Pi,Ti,0);
                        
                        P.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Pi;
                        
                    else
                        if np==1
                            P.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Pi;
                            
                        end
                        
                        
                    end
                    
                    
                    T.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Ti;
                    T2.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=T2i;
                    
                    end 
                    
                    
                    Test.(['pictal_',num2str(ceil(pictal_delta(np)/60))])=Testi;
                    
%                     P=[P,T'];
%                         
%                         tr_mat=delay_mat(P,1,obj.DATA.n_delay+1);
%                         
%                          P=tr_mat(:,1:end-1)';
%                          T=tr_mat(:,end)';
%                          
%                          Test=[Test,T2'];
%                         te_mat=delay_mat(Test,1,obj.DATA.n_delay+1);
%                         
%                          Test=te_mat(:,1:end-1)';
%                          T2=te_mat(:,end)';
%                          
%                          
%                          
%                          
%                          
%                          
%                          
%                          
%                          
%                        
%                       if  equal_class
%                           
%                         [P,T]=equalise_classes(obj,P,T,0);   
%                       end
%                       
%                       
%                         
% 

            
                    
                    clear train_d_matrix
                    clear test_d_matrix
                    clear d_selection;
                       
            end
                    
            obj.DATA.norm_factors=factors;
            obj.DATA.train_time_start_idx=dat_train_time_start_idx;
                    obj.DATA.train_time_end_idx=dat_train_time_end_idx;
                    obj.DATA.train_time_start=dat_train_time_start;
                    obj.DATA.train_time_end=dat_train_time_end;
                    
                    obj.DATA.test_time_start_idx=dat_test_time_start_idx;
                    obj.DATA.test_time_end_idx=dat_test_time_end_idx;
                    obj.DATA.test_time_start=dat_test_time_start;
                    obj.DATA.test_time_end=dat_test_time_end;
                    
                    obj.DATA.is_equal_classes=equal_class;
                    
                    obj.DATA.inp_feat=sel_feat_names;
                    
                    obj.DATA.inp_feat_idx=sel_feat;
                        
            %end
      
      
      
% % % % % % 
            
            function m=readNorm(obj, path)
                m=[];
                %global h;
                
                %1. Read from the Excel file
                for i=1:length(path),
                    
                    p=path{i}
                    if length(p)>5
                        if isequal(p(1:6),obj.DATA.EPILAB_DS_FLAG)
                            mAux=features2Matrix(obj,str2double(p(7:end)));
                            %TODO: Add study dataset support
                        else
                            mAux=xlsread(char(path(i)));
                            h.RBF.LoadingError = 0;
                        end
                    else
                        mAux=xlsread(char(path(i)));
                        h.RBF.LoadingError = 0;
                    end

                    %1.1 Normalize matrix by column
                    aux=mAux(:,1);
                    aux2=mAux(:,2:end);
                    
%                     aux2=scalestd(aux2')';
                    
                    for j=1:length(aux2(1,:))
                        aux2(:,j)=aux2(:,j)/max(max(aux2(:,j)));
                    end    
                    
                    mAux=horzcat(aux,aux2);   

                    m=vertcat(m,mAux);
                end 
            end
            
            function m=features2Matrix(obj, dataset_number)
                      %1� Read features
                      types = fieldnames(obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods);

                      final_matrix = {};
                      count = 2;
                      for j=length(types):-1:1  % 2.2 For each feature type
                          e = cell2mat(strcat('isempty(','obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),')'));
                          a = cell2mat(strcat('fieldnames(','obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),')'));

                          if ~eval(e)
                            features = eval(a);

                            for x=length(features):-1:1  % 2.3 For each feature
                              feat = cell2mat(features(x));
                              e2 = strcat(e(1:end-1),'.',feat,')');

                              if or(eval(e2), feat(1:2) ~= obj.DATA.FEATURES_TAG)
                                  if strcmp(feat, 'parameter_acquisition')%Data Aquisition (For T matrix)
                                      if eval(strcat('~isempty(obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',features{x},')'))
                                        parameter_acquisition = eval(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',features{x}));
                                      end  
                                      features(x) = [];
                                  else    
                                      disp(feat)
                                      features(x) = [];
                                  end    
                              end
                            end 
                            m = [];
                            f = features(1);
                            features=fieldnames(eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),'.',f))))
                            
                            
                            %BEGIN: Format features by the same similar length
                            min = 999999999;
                            max = -1;

                            for x=1:length(features)  % 2.3 Seek for the maximum time in begining of the features and the minimum of the features in the end
                                cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),'.time'))
                                aux = eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),'(1).time')));
                                aux(1)
                                if aux(1)>max;
                                    max = aux(1);
                                end
                                aux(end)
                                if aux(end)<min;
                                    min = aux(end);
                                end
                            end
                            
                            disp(['min = ' num2str(min)]);
                            disp(['max = ' num2str(max)]);
                            
                            for x=1:length(features) %2.4 Cut by the similar between all the features time
                                aux = eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),'.',f,'.',features{x})));
                                aux2 = eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types(j),'.time')));
                                ind_final = find(aux2 == min);
                                ind_init = find(aux2 == max);
                                aux=aux(ind_init:ind_final);
                                if (~isempty(aux))
                                    %eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',f,'.',features{x},'=aux')));
                                    m(:,count) = aux';
                                    count = count + 1;
                                end    
                            end    
                            
                            %END: Format features by the same similar length

                            
                            %for x=1:length(features)  % 2.5 Add new features to final matrix
                            %    aux = eval(cell2mat(strcat('obj.DATA.STUDY.dataset(dataset_number).results.featureExtractionMethods.',types{j},'.',f,'.',features{x})));
                            %    aux = aux((length(aux)-min)+1:end);
                            %    m(:,count) = aux';
                            %    count = count + 1;
                            %end  

                          end  
                      end
                      
                      %2� Build matrix T for that dataset
                        len = length(m(:,1));
                        %2.1 Sampling rate
                        sampling_rate = obj.DATA.STUDY.dataset(dataset_number).file.data.sampling_rate;
                        %2.2 For each event
                        events = obj.DATA.STUDY.dataset(dataset_number).results.feat_events;
                        %2.3 Fill T with 1 (normal state)
                        m(:,1) = obj.DATA.NORMAL_STATE;
                        %global h;
                        h.m = m;
                        if isempty(events) %If there aren't any events defined
                            %errordlg('You have to insert events (go to Edit Study > Data info edition)');
                            %m = NaN;
                            h.RBF.LoadingError = 1;
                            return;
                        end
                        h.RBF.LoadingError = 0;
                        
                        for i=1:length(events)
                             e=events(i);         
                            
                            if (round ((e.started/sampling_rate)/parameter_acquisition) - round(max/parameter_acquisition)>0)

                                start = round ((e.started/sampling_rate)/parameter_acquisition) - round(max/parameter_acquisition);
                                stop = round ((e.stopped/sampling_rate)/parameter_acquisition) - round(max/parameter_acquisition);
                                m(start:stop,1) = obj.DATA.ICTAL_STATE; % Ictal state

                                pre = round(start - (obj.DATA.PRE_ICTAL_TIME/parameter_acquisition))
                                pos = round(stop + (obj.DATA.POS_ICTAL_TIME/parameter_acquisition))


                                if pre < 1
                                    pre = 1;
                                end
                                if pos > len
                                    pos = len;
                                end

                                m(pre:start,1) = obj.DATA.PRE_ICTAL_STATE; % Pre-Ictal state
                                m(stop:pos,1) = obj.DATA.POS_ICTAL_STATE; % Pos-Ictal state

                                m
                            end
                        end    
            end
        end    
      
        % function [SP SS AC NERRORS] = calcPerformance(A, T2) 
        % Calculate the specificity (SP), sensitivity (SS), accuracy (AC)
        %   A - Neural network output
        %   T2 - Target of Test matrix (just one column)
        function [SP SS AC NERRORS] = calcPerformance(obj, A, T2) 
        %Classes:
        %1 - Normal state
        %2 - Pre-ictal 
        %3 - Ictal
        %4 - Pos-ictal
        %T2 - Must have 1 column and n rows with the classes
        
            size(A)
            size(T2)
            NORMAL=obj.DATA.NORMAL_STATE;
            PREICTAL=obj.DATA.PRE_ICTAL_STATE;
            ICTAL=obj.DATA.ICTAL_STATE;
            POSICTAL=obj.DATA.POS_ICTAL_STATE;        

            %0 Calc the total number of errors and corrects
            NERRORS=zeros(4);
            CORRECTS=zeros(4,1);
            for i=1:length(A)
                aux=A(i);
                
                if aux>obj.DATA.POS_ICTAL_STATE
                    aux=obj.DATA.POS_ICTAL_STATE;
                else if aux<obj.DATA.NORMAL_STATE
                        aux=obj.DATA.NORMAL_STATE;
                    end
                end
                NERRORS(T2(i),aux(1))=NERRORS(T2(i),aux(1))+(T2(i)~=aux(1));
                CORRECTS(T2(i))=CORRECTS(T2(i))+(T2(i)==aux(1)); %Add the correct situations
            end

            %1 Calc TP, TN, FP, FN
            %1.1 True Negatives
            TN_NORMAL=(CORRECTS(NORMAL)+NERRORS(ICTAL,NORMAL)+NERRORS(POSICTAL,NORMAL));
            TN_ICTAL=(NERRORS(NORMAL,ICTAL)+CORRECTS(ICTAL)+NERRORS(POSICTAL,ICTAL));
            TN_POSICTAL=(NERRORS(NORMAL,POSICTAL)+NERRORS(ICTAL,POSICTAL)+CORRECTS(POSICTAL));
            TN=TN_NORMAL+TN_ICTAL+TN_POSICTAL;
            disp({'Neg Verdadeiros=' TN});

            %1.2 False Negatives
            FN=NERRORS(PREICTAL,NORMAL)+NERRORS(PREICTAL,ICTAL)+NERRORS(PREICTAL,POSICTAL);
            disp({'Neg Falsos=' FN});

            %1.3 True Positives
            TP=CORRECTS(PREICTAL);
            disp({'Pos Verdadeiros=' TP});

            %1.4 False Positives
            FP=NERRORS(NORMAL,PREICTAL)+NERRORS(ICTAL,PREICTAL)+NERRORS(POSICTAL,PREICTAL);
            disp({'Pos Falsos=' FP});


            %2. Metrics
            %2.1 Calc the sensitivity (TP/TP+FN)
            SS = (TP/(TP+FN))*100; 

            %2.2 Calc the specificity (TN/TN+FP)
            SP = (TN/(TN+FP))*100;  

            %2.3 Calc the classifier precision (CORRECT/TOTAL)
            CORRECT=sum(CORRECTS);
            TOTAL=length(T2);
            AC = (CORRECT/TOTAL)*100;


           
            end
   end    
end

function fdata=low_pass_filter(data,freq,order,samp_freq)
%==============================================================
%Low-pass filter function
%
%Function that defines an IIR low-pass filter
%
%Inputs:
%   data-->data matrix to filter
%   freq-->Cut-off frequency
%   order-->Filter order
%   samp_freq-->data sampling frequency
%
%Output:
%   fdata-->Filtered data
%
%
%EU FP7 Grant 211713 (EPILEPSIAE)
%
%César A. D. Teixeira
%CISUC, FCTUC, University of Coimbra
%January 2010
%==============================================================
%Compute filter parameters
[b,a]=butter(order,freq/(samp_freq/2));
%Filter data
fdata=filtfilt(b,a,data);

end
