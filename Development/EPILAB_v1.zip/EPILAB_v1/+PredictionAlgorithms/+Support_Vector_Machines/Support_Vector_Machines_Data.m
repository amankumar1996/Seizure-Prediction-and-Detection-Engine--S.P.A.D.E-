%Defines the main class and interface of classifiers
classdef Support_Vector_Machines_Data < handle
   % The following properties can be set only by class methods
   properties
      
     %BEGIN: DO NOT REMOVE THESE PROPERTIES
          STUDY;
          
          %USED BY RESULTS LIST (SHOULD BE UPDATED IN INTERFACE CLASS)
          sub_module_name = 'Support_Vector_Machines';
          saveinfo_datasets;
          saveinfo_features;
          saveinfo_other;
          saveinfo_name = '';
          MenuitemCallback;
          loading = 0;
          EPILAB_DS_FLAG = '_study';
          FEATURES_TAG = 'c_';
          
          PRE_ICTAL_TIME = 5*60; % 5 minutes (default)
          POS_ICTAL_TIME = 5*60; % 5 minutes
          NORMAL_STATE = 1;
          PRE_ICTAL_STATE = 2;
          ICTAL_STATE = 3;
          POS_ICTAL_STATE = 4;
          
          EARLY_DETECT_TIME = 10;
          
          %PERFORMANCE VALUES
          SS = NaN;
          SP = NaN;
          AC = NaN;
          
          SS_AL=NaN;
          FPR=NaN;
          REL='';
          OUT_AL;
          TIME_AL;
          TAR_AL;
          MIN_ANT;
          MAX_ANT;
          AVG_ANT;
          STD_ANT;
          
      %END: DO NOT REMOVE THESE PROPERTIES      
      
      %SVM PARAMS
      WEIGHT = 1;
      PROB = {'0', '1'};
      PROB_POS = 1;
      SHRINKING = {'1', '0'};
      SHRINKING_POS = 1;
      EPSILON_TOLERANCE = 0.001;
      EPSILON_LOSS = 0.1;
      CACHESIZE = 100;
      SVMTYPE = {'C-SVC', 'nu-SVC', 'one-class SVM', 'epsilon-SVR', 'nu-SVR'};
      SVMTYPE_POS = 1;
      KERNELTYPE = {'linear', 'polynomial', 'rbf', 'sigmoid'};
      KERNELTYPE_POS = 3;
      DEGREE = 3;
      COEF0 = 0;
      NU = 0.5;
      GAMMA = 8;
      COST = 8192;
      %Best values for a specific patient (pac8.xls)
      % COST =  8192 GAMMA = 8
      %Best values for all patients (test=pac8.xls)
      % COST =  512 GAMMA = 8
      DELAY = 0;
      
      %Train types
      TRAIN_TYPE_MERGE7030 = 'Train: All(70%) | Test: All(30%)';
      TRAIN_TYPE_MERGE_1 = 'Train: All-Last | Test: Last';
      TRAIN_TYPE_MERGE = 'Train: All | Test: Last';
      TRAIN_TYPE_MANUAL = 'Visual Selection';
      TRAIN_TYPE_MANUAL_PREV = 'Train: Prev. manual selection';
      TRAIN_TYPE_FROM_FILE = 'Parameters in file';
      TRAIN_TYPE_EQUAL = 'Train: Equalised Classes';
      TRAIN_TYPES = {};
      TRAIN_TYPES_SEL = 1;
      TARGET_CLASSES = {'2 (PREICTAL,NON-PREICTAL)', '4 (NORMAL,PREICTAL,ICTAL,NON-PREICTAL)'};
      TARGET_SELECTED = 1;
      
      %DATA SETS
      DATA_SETS_PATHS = {};
      PATHNAME = '';
      DATA_SETS = {};
      DATA_SETS_SEL = [];
      DATA_SETS_LAST_POS = 1;
      FEATURES = {};
      FEATURES_LIST = {};
      
      %Results
      A = [];
      T2 = [];
      
      %Model
      model = [];
      val = NaN;
      
      test_time_vec=[];
      pictal_delta=[];
      pAcq=[];
      firing_power_alarm=0.5;
      
      n_delay=0;
      
      train_time_start_idx;
      train_time_end_idx;
      train_time_start;
      train_time_end;
      
      test_time_start_idx;
      test_time_end_idx;
      test_time_start;
      test_time_end;
      
      is_equal_classes;
      inp_feat;
      inp_feat_idx;
      norm_factors;
      
   end
   
   methods
      %Constructor
      function obj = Support_Vector_Machines_Data()
        obj.TRAIN_TYPES = {obj.TRAIN_TYPE_MANUAL,obj.TRAIN_TYPE_FROM_FILE};
      end
   end   
end