classdef Support_Vector_Machines_Interface < handle
   properties
      panel_title = 'Support Vector Machines (using libSVM)';
      
      %Graphical User Interface auxiliar variables (normalized)
      DEFAULT_EDIT_WIDTH = 0.075;
      DEFAULT_EDIT_HEIGHT = 0.10;
      
      DEFAULT_TEXT_HEIGHT = 0.10;
      DEFAULT_TEXT_WIDTH = 0.30;
      
      DEFAULT_POPUP_HEIGHT = 0.10;
      DEFAULT_POPUP_WIDTH = 0.20; 
      
      DEFAULT_SEPARATION = 0.03;
      
      SVM_PANEL_WIDTH = 0.98;
      SVM_PANEL_HEIGHT = 0.6;
      SVM_PANEL_X = 0.01;
      SVM_PANEL_Y = 0.01;
      
      DATA_PANEL_HEIGHT = 0.2;
      
      STUDY;
      DATA;
      FUNCTIONS;
      
      th_lev_edit;
   end
    
   methods
       
      %Constructor
      %REQUIRED FUNCTION
      function obj = Support_Vector_Machines_Interface(study)
          obj.STUDY = study;
          obj.DATA = PredictionAlgorithms.Support_Vector_Machines.Support_Vector_Machines_Data();
          obj.DATA.STUDY = study;
          obj.FUNCTIONS = PredictionAlgorithms.Support_Vector_Machines.Support_Vector_Machines_Functions(obj.DATA);
      end
      
      %Method that builds the Graphical User Interface Components
      %params: panel (uipanel where all the uicomponents are drawn)
      function draw(obj, panel)
      
           global h;
          
           set(panel,'Title',obj.panel_title, 'TitlePosition','centertop');
           
           data_panel = uipanel('Parent',panel,'Title','Select Data','ForegroundColor',[4/255 166/255 146/255],'FontWeight','bold','Units','Normalized','FontSize',10,'Position',[0,0.8,0.58,obj.DATA_PANEL_HEIGHT]);
           drawDataPanel(data_panel);
           
           perf_panel = uipanel('Parent',panel,'Title','SVM Results','ForegroundColor',[4/255 166/255 146/255],'FontWeight','bold','Units','Normalized','FontSize',10,'Position',[0.585,0.8,0.4,obj.DATA_PANEL_HEIGHT]);
           drawPerfPanel(perf_panel);
           
           %perf_al_panel = uipanel('Parent',panel,'Title','Alarm Performance','ForegroundColor',[4/255 166/255 146/255],'FontWeight','bold','Units','Normalized','FontSize',10,'Position',[0.8,0.8,0.2,obj.DATA_PANEL_HEIGHT]);
           %drawPerfPanelAl(perf_al_panel);
           
           training_panel = uipanel('Parent',panel,'Title','Training','ForegroundColor',[4/255 166/255 146/255],'FontWeight','bold','Units','Normalized','FontSize',10,'Position',[0,0,1,0.8]);
           
           create_SVMPanel(training_panel); 

           %Draw the data panel
           function drawDataPanel(data_panel)  

              h.SVM.open_dataset_button = uicontrol('Parent',data_panel,'Style','pushbutton','Units','Normalized','String','Open','FontSize',8,'Callback',{@OpenDataSet_Button},...
                   'Position',[0.03,0.01,0.1,0.25]);

              h.SVM.delete_button = uicontrol('Parent',data_panel,'Style','pushbutton','Units','Normalized','String','Del','FontSize',8,'Enable','Off','Callback',{@Delete_Button},...
                   'Position',[0.03+0.1,0.01,0.07,0.25]); 
              
              h.SVM.refresh_button = uicontrol('Parent',data_panel,'Style','pushbutton','Units','Normalized','String','Refresh','FontSize',8,'Enable','On','Callback',{@LoadStudyDatasets},...
                   'Position',[0.13+0.07,0.01,0.13,0.25]); 

              h.SVM.datasets_list = uicontrol('Parent',data_panel,'Style','listbox','Units','Normalized','String',obj.DATA.DATA_SETS,'BackgroundColor','white','Max',20,'Min',2,'Callback',{@LoadFeatures},...
                   'Position',[0.03,0.25,0.3,0.7]);  

              h.SVM.features_list = uicontrol('Parent',data_panel,'Style','listbox','Units','Normalized','BackgroundColor','white','Max',20,'Min',2,'Callback',{@SetFeatures},...
                   'Position',[0.07+0.28,0.02,0.62,0.95]);

              
              
              if obj.DATA.loading %Set the datasets when loading saved data
                set(h.SVM.datasets_list,'Value',obj.DATA.DATA_SETS_SEL);
                LoadFeatures(1, []);
                set(h.SVM.delete_button, 'Enable', 'on');
              else
                LoadStudyDatasets;
              end    
             
              
              %Load datasets from xls files
              function OpenDataSet_Button(source,eventdata)
                       if(length(obj.DATA.PATHNAME)>1)
                           [ filename , pathname ] = uigetfile (  {'*.xls'} , 'Choose a xls dataset file','MultiSelect','on',obj.DATA.PATHNAME);
                       else
                           [ filename , pathname ] = uigetfile (  {'*.xls'} , 'Choose a xls dataset file','MultiSelect','on');
                       end
                        
                        current_path = pwd;
                        obj.DATA.PATHNAME = pathname(length(current_path)+2:end);
                        if isequal(filename,0)
                            disp('You must select a file!');
                        elseif ischar(filename)
                            [pathname filename];
                            obj.DATA.DATA_SETS_PATHS(obj.DATA.DATA_SETS_LAST_POS) = {[pathname filename]};
                            obj.DATA.DATA_SETS(obj.DATA.DATA_SETS_LAST_POS) = {filename};
                            obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS + 1;

                            obj.DATA.DATA_SETS;
                            set(h.SVM.datasets_list,'String',obj.DATA.DATA_SETS);
                            set(h.SVM.datasets_list,'Value',obj.DATA.DATA_SETS_LAST_POS-1);
                            LoadFeatures([],[]);

                            set(h.SVM.delete_button, 'Enable', 'on');
                        else    
                            disp('FILENAMES:');
                            strcat(pathname,char(filename));
                            aux = obj.DATA.DATA_SETS_LAST_POS;
                            for i = 1:length(filename)
                                obj.DATA.DATA_SETS_PATHS(obj.DATA.DATA_SETS_LAST_POS) = {[pathname char(filename(i))]};
                                obj.DATA.DATA_SETS(obj.DATA.DATA_SETS_LAST_POS) = {char(filename(i))};
                                obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS + 1;
                            end
                            obj.DATA.DATA_SETS;
                            obj.DATA.DATA_SETS_PATHS;
                            set(h.SVM.datasets_list,'String',obj.DATA.DATA_SETS);
                            set(h.SVM.datasets_list,'Value',aux:obj.DATA.DATA_SETS_LAST_POS-1);
                            LoadFeatures([],[]);

                            set(h.SVM.delete_button, 'Enable', 'on');
                        end
              end

              %Delete datasets from the datasets list
              function Delete_Button(source, eventdata)
                  val=get(h.SVM.datasets_list,'Value');
                  str=get(h.SVM.datasets_list,'String');
                  for i=length(val):-1:1
                      obj.DATA.FEATURES_LIST(val(i)) = [];
                      obj.DATA.FEATURES(val(i)) = [];

                      obj.DATA.DATA_SETS_PATHS(val(i)) = [];
                      obj.DATA.DATA_SETS(val(i)) = [];
                      obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS - 1;

                      set(h.SVM.datasets_list, 'Value', []);
                      set(h.SVM.datasets_list, 'String', obj.DATA.DATA_SETS);
                      set(h.SVM.features_list, 'Value', []);
                      set(h.SVM.features_list, 'String', []);
                  end   

                  str=get(h.SVM.datasets_list,'String');

                  if isempty(str)
                      set(h.SVM.delete_button, 'Enable', 'off');
                  end
              end
              
              %Load the features of datasets into the data object
              function LoadFeatures(source, eventdata)
                  val=get(h.SVM.datasets_list,'Value');
                  if ~isempty(val)                              
                      if isempty(source)
                          [num,txt] = xlsread(char(obj.DATA.DATA_SETS_PATHS(val(1))),'C1:P1');
                          set(h.SVM.features_list,'String',txt);
                          for i=1:length(val)
                              obj.DATA.FEATURES_LIST{val(i)} = txt;
                              obj.DATA.FEATURES{val(i)} = ones(1,length(txt));
                          end
                          set(h.SVM.features_list,'Value',1:length(txt));
                      else    
                          a = obj.DATA.FEATURES{val(1)};
                          %b = obj.DATA.FEATURES_LIST{val(1)};

                          h.list = obj.DATA.FEATURES_LIST;
                          h.feat = obj.DATA.FEATURES;

                          set(h.SVM.features_list,'String',obj.DATA.FEATURES_LIST{val(1)});
                          set(h.SVM.features_list,'Value',find(a==1));
                      end 

                  end
              end 

              %Update the features selected by the user in the data object
              function SetFeatures(source, eventdata)
                  
                  val=get(source,'Value');
                  str=get(source,'String');
                  pos=get(h.SVM.datasets_list,'Value');
                  
                  if ~isempty(val)
                      fea = zeros(1,length(str));
                      for i=1:length(val)
                          fea(val(i)) = 1;
                      end    

                      for i=1:length(pos) %TODO: Test these conditions
                          if length(obj.DATA.FEATURES{pos(i)}) == length(fea) %If the dest matrix is equal
                              obj.DATA.FEATURES{pos(i)} = fea;
                          elseif length(obj.DATA.FEATURES{pos(i)}) > length(fea) %If the dest matrix is bigger
                              aux = zeros(1,length(obj.DATA.FEATURES{pos(i)}));
                              aux(1:length(fea)) = fea;
                              obj.DATA.FEATURES{pos(i)} = aux;
                          else          %If the dest matrix is smaller
                              aux = fea(1,length(obj.DATA.FEATURES{pos(i)}));
                              obj.DATA.FEATURES{pos(i)} = aux;
                          end    
                      end    
                  end
              end 

              %Fill the dataset list with results from the other modules
              function LoadStudyDatasets(source, eventdata)
                  %name: studyname.datasetname
                  %studyname: study.name
                  %datasetname: study.dataset(i).name
                  %features: study.dataset(i).name.features.*
                             %study.dataset(i).name.features.c_* (~isempty)

                  tic;
                  %1� Insert the datasets to the list
                  ds_name = strcat(obj.STUDY.name,'.');
                  aux = obj.DATA.DATA_SETS_LAST_POS;
                  for i=1:length(obj.STUDY.dataset)
                      ds_name2 = strcat(ds_name,obj.STUDY.dataset(i).name);
                      h.DATA_SETS = obj.DATA.DATA_SETS;
                      h.ds_name2 = ds_name2;
                      
                      if isempty(obj.DATA.DATA_SETS)
                          obj.DATA.DATA_SETS(obj.DATA.DATA_SETS_LAST_POS) = {ds_name2};
                          
                          %Add position of dataset, useful for the train
                          %function to capture the right features, e.g.
                          %study1, study2, etc.
                          obj.DATA.DATA_SETS_PATHS(obj.DATA.DATA_SETS_LAST_POS) = {[obj.DATA.EPILAB_DS_FLAG num2str(i)]};
                          obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS + 1;
                          break;
                      end    
                      
                      for j=1:length(obj.DATA.DATA_SETS)
                         if strcmp(obj.DATA.DATA_SETS{j}, ds_name2)
                              obj.DATA.DATA_SETS(j) = [];
                              obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS - 1;
                              aux = aux - 1; %Update auxiliar var
                              break;
                         end
                      end  
                      
                      obj.DATA.DATA_SETS(obj.DATA.DATA_SETS_LAST_POS) = {ds_name2};
                      obj.DATA.DATA_SETS_PATHS(obj.DATA.DATA_SETS_LAST_POS) = {[obj.DATA.EPILAB_DS_FLAG num2str(i)]}; %Add reference to the paths data structure
                      obj.DATA.DATA_SETS_LAST_POS = obj.DATA.DATA_SETS_LAST_POS + 1;
                      
                  end


                  %2� Load features
                  for i=1:length(obj.STUDY.dataset) % 2.1 For each dataset

                      types = fieldnames(obj.STUDY.dataset(i).results.featureExtractionMethods);

                      count = 1;
                      total = 0;
                      
                      for j=length(types):-1:1  % Determine size of final matrix
                        e = cell2mat(strcat('isempty(','obj.STUDY.dataset(i).results.featureExtractionMethods.',types(j),')'));
                        a = cell2mat(strcat('fieldnames(','obj.STUDY.dataset(i).results.featureExtractionMethods.',types(j),')'));

                        if ~eval(e)
                          features = eval(a);
                          
                          for x=length(features):-1:1  % 2.3 For each feature
                            feat = cell2mat(features(x));
                            e2 = strcat(e(1:end-1),'.',feat,')');

                            if or(eval(e2), feat(1:2) ~= obj.DATA.FEATURES_TAG)
                              features(x) = [];                                          
                            end
                          end
                            
                          f = features(1);
                          features=fieldnames(eval(cell2mat(strcat('obj.STUDY.dataset(i).results.featureExtractionMethods.',types(j),'.',f))));
                          total = total + length(features);
                        end   
                      end
                      
                      final_matrix = cell(total,1);

                      for j=length(types):-1:1  % 2.2 For each feature type
                          e = cell2mat(strcat('isempty(','obj.STUDY.dataset(i).results.featureExtractionMethods.',types(j),')'));
                          a = cell2mat(strcat('fieldnames(','obj.STUDY.dataset(i).results.featureExtractionMethods.',types(j),')'));

                          if ~eval(e)
                            features = eval(a);

                            for x=length(features):-1:1  % 2.3 For each feature
                              feat = cell2mat(features(x));
                              e2 = strcat(e(1:end-1),'.',feat,')');

                              if or(eval(e2), feat(1:2) ~= obj.DATA.FEATURES_TAG)
                                  features(x) = [];                                          
                              end
                            end 
                            f = features(1);
                            features=fieldnames(eval(cell2mat(strcat('obj.STUDY.dataset(i).results.featureExtractionMethods.',types(j),'.',f))));
                            for x=1:length(features)  % 2.4 Add new features to final matrix
                                final_matrix(count) = strcat(types(j),'.',features(x));
                                count = count + 1;
                            end

                          end
                      end

                      obj.DATA.FEATURES_LIST{aux} = final_matrix;
                      obj.DATA.FEATURES{aux} = ones(1,length(final_matrix));
                      aux = aux + 1;

                  end

                  % 3� Apply changes to the handles
                  set(h.SVM.features_list,'String',{});
                  set(h.SVM.features_list,'String',{});

                  set(h.SVM.datasets_list,'Value',[]);
                  set(h.SVM.datasets_list,'String',obj.DATA.DATA_SETS);

                  set(h.SVM.delete_button, 'Enable', 'on');
                  
                  toc;
              end    
           end

           function drawPerfPanel(perf_panel)
               
               h.SVM.tab_res=uitable('parent',perf_panel,'Data',{},'ColumnName', {'Name','SS_AL','FPR','MIN_ANT','MAX_ANT','AVG_ANT','STD_ANT','SS','SP','AC','Rel','P-Ictal','Th.','Gamma','Cost','TF'},'Units','Normalized',...
    'RearrangeableColumn','on','Position',[0.01 0.01 0.98 0.99],'ColumnWidth','auto','CellSelectionCallback',@UpdateSelected);

%               IPOS = 0.05;
%               h.SVM.sens_text = uicontrol('Parent',perf_panel,'Style','text','Units','Normalized','String','SS = ','FontSize',10,...
%                                'Position',[0.1,IPOS,0.55,0.3],'HorizontalAlignment','Left');
%               IPOS = IPOS + 0.3;
%               h.SVM.spec_text = uicontrol('Parent',perf_panel,'Style','text','Units','Normalized','String','SP = ','FontSize',10,...
%                                'Position',[0.1,IPOS,0.55,0.3],'HorizontalAlignment','Left');
%               IPOS = IPOS + 0.3;
%               h.SVM.acc_text = uicontrol('Parent',perf_panel,'Style','text','Units','Normalized','String','AC = ','FontSize',10,...
%                                'Position',[0.1,IPOS,0.55,0.3],'HorizontalAlignment','Left');
%               %align([h.ANN.sens_text h.ANN.spec_text
%               %h.ANN.acc_text],'Left','None');
              
              %if obj.DATA.loading
                updatePerformanceValues(obj);
              %end  
           end
           function  UpdateSelected (source, event)
        h.SVM.res_cel_sel=event.Indices(:,1);
    end
           
%            function drawPerfPanelAl(perf_panel)
% 
%               IPOS = 0.05;
%               h.SVM.sens_text_al = uicontrol('Parent',perf_panel,'Style','text','Units','Normalized','String','SS = ','FontSize',10,...
%                                'Position',[0.1,IPOS,0.55,0.3],'HorizontalAlignment','Left');
%               IPOS = IPOS + 0.3;
%               h.SVM.fpr_text = uicontrol('Parent',perf_panel,'Style','text','Units','Normalized','String','FPR = ','FontSize',10,...
%                                'Position',[0.1,IPOS,0.55,0.3],'HorizontalAlignment','Left');
%               IPOS = IPOS + 0.3;
%               h.SVM.rel = uicontrol('Parent',perf_panel,'Style','text','Units','Normalized','String','Rel. = ','FontSize',10,...
%                                'Position',[0.1,IPOS,0.55,0.3],'HorizontalAlignment','Left');
%               %align([h.ANN.sens_text h.ANN.spec_text
%               %h.ANN.acc_text],'Left','None');
%               
%               if obj.DATA.loading
%                 updatePerformanceValuesAl(obj,obj.DATA.FPR,obj.DATA.SS_AL,obj.DATA.REL);
%               end  
%            end

           function create_SVMPanel(fpanel)
                % Set current data to the selected data set.
                % TODO: Analyse the memory of constantly creating
                % uipanels
                
               %Draw SVM parameters
               npanel = uipanel('Parent',fpanel,'BorderType','none','BorderWidth',0,'Units','Normalized','Visible','on','Position',[obj.SVM_PANEL_X,obj.SVM_PANEL_Y,obj.SVM_PANEL_WIDTH,obj.SVM_PANEL_HEIGHT]);

               IPOS = 0.15;
               %NOTE: The uicontrols are drawn in a
               %bottom-up fashion
               
               IPOS = IPOS + 0.2;
               
               h.SVM.delay_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Delay:','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.SVM.delay_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.DELAY),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_EDIT_HEIGHT]); 

               IPOS = IPOS + 0.2;

               h.SVM.weight_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Weight:','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.SVM.weight_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.WEIGHT),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_EDIT_HEIGHT]); 

               IPOS = IPOS + obj.DEFAULT_EDIT_HEIGHT;
               
               h.SVM.classes_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Number of classes:','FontSize',10,...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION*2+obj.DEFAULT_POPUP_WIDTH,IPOS-0.15,obj.DEFAULT_TEXT_WIDTH+0.05,obj.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
               h.SVM.classes_popup = uicontrol('Parent',npanel,'Style','popup','Units','Normalized','String',obj.DATA.TARGET_CLASSES,'BackgroundColor','white','enable','on',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION+obj.DEFAULT_POPUP_WIDTH+obj.DEFAULT_TEXT_WIDTH/2+obj.DEFAULT_SEPARATION+0.05,IPOS-0.15,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');
               
               h.SVM.suppvectors_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Number of SVs:','FontSize',10,...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION*2+obj.DEFAULT_POPUP_WIDTH,IPOS-0.3,obj.DEFAULT_TEXT_WIDTH+0.05,obj.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
               h.SVM.suppvectors_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','BackgroundColor','white','enable','off',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION+obj.DEFAULT_POPUP_WIDTH+obj.DEFAULT_TEXT_WIDTH/2+obj.DEFAULT_SEPARATION+0.05,IPOS-0.3,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

               h.SVM.probability_estimates_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Probability estimates:','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.SVM.probability_estimates_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.DATA.PROB,'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_POPUP_WIDTH,obj.DEFAULT_POPUP_HEIGHT]);                             
               
               IPOS = IPOS + obj.DEFAULT_POPUP_HEIGHT;

               h.SVM.epsilon_tolerance_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Epsilon (tolerance):','FontSize',10,...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION*2+obj.DEFAULT_POPUP_WIDTH,IPOS,obj.DEFAULT_TEXT_WIDTH+0.05,obj.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
               h.SVM.epsilon_tolerance_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.EPSILON_TOLERANCE),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION+obj.DEFAULT_POPUP_WIDTH+obj.DEFAULT_TEXT_WIDTH/2+obj.DEFAULT_SEPARATION+0.05,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

               h.SVM.shrinking_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Shrinking:','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.SVM.shrinking_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.DATA.SHRINKING,'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_POPUP_WIDTH,obj.DEFAULT_POPUP_HEIGHT]);

               IPOS = IPOS + obj.DEFAULT_POPUP_HEIGHT;

               h.SVM.cachesize_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Cache size:','FontSize',10,...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION*2+obj.DEFAULT_POPUP_WIDTH,IPOS,obj.DEFAULT_TEXT_WIDTH+0.05,obj.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
               h.SVM.cachesize_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.CACHESIZE),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION+obj.DEFAULT_POPUP_WIDTH+obj.DEFAULT_TEXT_WIDTH/2+obj.DEFAULT_SEPARATION+0.05,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');

               h.SVM.svm_type_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','SVM Type:','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.SVM.svm_type_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.DATA.SVMTYPE,'Value',obj.DATA.SVMTYPE_POS,'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_POPUP_WIDTH,obj.DEFAULT_POPUP_HEIGHT]); 
               
               IPOS = IPOS + obj.DEFAULT_POPUP_HEIGHT;

               h.SVM.epsilon_loss_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Epsilon (loss):','FontSize',10,...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION*2+obj.DEFAULT_POPUP_WIDTH,IPOS,obj.DEFAULT_TEXT_WIDTH+0.05,obj.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
               h.SVM.epsilon_loss_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.EPSILON_LOSS),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION+obj.DEFAULT_POPUP_WIDTH+obj.DEFAULT_TEXT_WIDTH/2+obj.DEFAULT_SEPARATION+0.05,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');               

               h.SVM.kernel_type_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Kernel Type:','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.SVM.kernel_type_popup = uicontrol('Parent',npanel,'Style','popupmenu','Units','Normalized','String',obj.DATA.KERNELTYPE,'Value',obj.DATA.KERNELTYPE_POS,'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_POPUP_WIDTH,obj.DEFAULT_POPUP_HEIGHT]); 
               
               IPOS = IPOS + obj.DEFAULT_POPUP_HEIGHT;

               h.SVM.nu_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Nu:','FontSize',10,...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION*2+obj.DEFAULT_POPUP_WIDTH,IPOS,obj.DEFAULT_TEXT_WIDTH+0.05,obj.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
               h.SVM.nu_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.NU),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION+obj.DEFAULT_POPUP_WIDTH+obj.DEFAULT_TEXT_WIDTH/2+obj.DEFAULT_SEPARATION+0.05,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');               

               h.SVM.cost_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Cost:','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.SVM.cost_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',obj.DATA.COST,'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT]); 
               
               
               IPOS = IPOS + obj.DEFAULT_EDIT_HEIGHT;

               h.SVM.coef0_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Coef0:','FontSize',10,...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION*2+obj.DEFAULT_POPUP_WIDTH,IPOS,obj.DEFAULT_TEXT_WIDTH+0.05,obj.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
               h.SVM.coef0_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.COEF0),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION+obj.DEFAULT_POPUP_WIDTH+obj.DEFAULT_TEXT_WIDTH/2+obj.DEFAULT_SEPARATION+0.05,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');               

               h.SVM.gamma_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Gamma:','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.SVM.gamma_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',obj.DATA.GAMMA,'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT]); 
               
               
               
               
               
               IPOS = IPOS + obj.DEFAULT_EDIT_HEIGHT;

               h.SVM.degree_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Degree:','FontSize',10,...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION*2+obj.DEFAULT_POPUP_WIDTH,IPOS,obj.DEFAULT_TEXT_WIDTH+0.05,obj.DEFAULT_TEXT_HEIGHT],'HorizontalAlignment','Left');
               h.SVM.degree_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.DEGREE),'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION+obj.DEFAULT_POPUP_WIDTH+obj.DEFAULT_TEXT_WIDTH/2+obj.DEFAULT_SEPARATION+0.05,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT],'HorizontalAlignment','Right');               
               
               
               
               
               
               
               h.SVM.pictal_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Pre-Ictal (min):','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.SVM.pictal_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',obj.DATA.PRE_ICTAL_TIME/60,'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT]);

               %Train type (list)
               h.SVM.train_type_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Data Selection:',...
                  'Position',[0.05,0.23,0.2,0.1]);   
               h.SVM.train_type_list = uicontrol('Parent',npanel,'Style','listbox','Units','Normalized','String',obj.DATA.TRAIN_TYPES,...
                                                 'Value',obj.DATA.TRAIN_TYPES_SEL,'BackgroundColor','white','Position',[0.04,0.05,0.3,0.2]);  
                  
                %Alarm threshold level
                h.SVM.threshold_lev_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Threshold Level (%):',...
                   'Position',[0.37,0.18,0.1,0.15]); 
               
                h.SVM.threshold_lev_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',num2str(obj.DATA.firing_power_alarm*100),...
                   'Position',[0.37,0.05,0.1,0.15]); 
               obj.th_lev_edit=h.SVM.threshold_lev_edit; 
               
               IPOS = IPOS + obj.DEFAULT_EDIT_HEIGHT;
                                             
               h.SVM.early_detect_text = uicontrol('Parent',npanel,'Style','text','Units','Normalized','String','Early Detection Time (s):','FontSize',10,...
                   'Position',[0,IPOS,obj.DEFAULT_TEXT_WIDTH,obj.DEFAULT_TEXT_HEIGHT]);
               h.SVM.early_detect_edit = uicontrol('Parent',npanel,'Style','edit','Units','Normalized','String',obj.DATA.EARLY_DETECT_TIME,'BackgroundColor','white',...
                   'Position',[obj.DEFAULT_TEXT_WIDTH+obj.DEFAULT_SEPARATION,IPOS,obj.DEFAULT_EDIT_WIDTH,obj.DEFAULT_POPUP_HEIGHT]);
                                             
                                             
               %Classify Button
               h.SVM.classify_button = uicontrol('Parent',npanel,'Style','pushbutton','Units','Normalized','String','Classify','FontSize',10,'Callback',{@(src,event)Classify_Button(obj,src,event)},...
                'Position',[0.51,0.005,0.1,0.2]);

               %Save Button
               h.SVM.save_button = uicontrol('Parent',npanel,'Style','pushbutton','Units','Normalized','String','Save','FontSize',10,'Enable','off','Callback',{@(src,event)Save_Button(obj,src,event)},...
                'Position',[0.51+0.11,0.005,0.1,0.2]);
            
               %Plot results button
               h.SVM.plotResults_button = uicontrol('Parent',npanel,'Style','pushbutton','Units','Normalized','String','Plot results','FontSize',10,'Enable','off','Callback',{@(src,event)PlotResults_ButtonCallback(obj,src,event)},...
                'Position',[0.51+0.12+0.1,0.1,0.15,0.1]);
            
            
               %Plot Alarm button
               h.SVM.PlotAlarmButton = uicontrol('Parent',npanel,'Style','pushbutton','Units','Normalized','String','Plot Alarms','FontSize',10,'Enable','off','Callback',{@(src,event)PlotAlarmButtonCallback(obj,src,event)},...
                'Position',[0.51+0.12+0.1,0.005,0.15,0.1]);
            
            %Random Predictor Evaluation
               h.SVM.RandEvalButton = uicontrol('Parent',npanel,'Style','pushbutton','Units','Normalized','String','Evaluate','FontSize',10,'Enable','on','Callback',{@(src,event)EvaluateAlarmResultsCallback(obj,src,event)},...
                'Position',[0.51+0.12+0.1+0.16,0.005,0.1,0.2]);
            
            if ~isempty(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines)
               set(h.SVM.plotResults_button,'Enable','on');
               set(h.SVM.PlotAlarmButton,'Enable','on');
               set(h.SVM.RandEvalButton,'Enable','on');
            end
            
            
               
            
                
               if obj.DATA.loading %Enable PlotResults button if the ANN is being loaded
                   set(h.SVM.plotResults_button,'Enable','on');
               end    
              
              %Classify the data
              function Classify_Button(obj, source, evendata)
                  
                                
                   updateData(obj); 
                   
                   
                   
                   act_lev=str2num(get(h.SVM.threshold_lev_edit,'String'))/100;
                   if act_lev>=0 && act_lev<=100
                       obj.DATA.firing_power_alarm=act_lev;
                   else
                      set(h.SVM.threshold_lev_edit,'String',num2str(obj.DATA.firing_power_alarm*100)); 
                   end
                   
                   

                   s=get(h.SVM.train_type_list,'String');
                   obj.DATA.TRAIN_TYPES_SEL=get(h.SVM.train_type_list,'Value');
                   traint = s(obj.DATA.TRAIN_TYPES_SEL);
                   [SP SS AC obj.DATA.A obj.DATA.T2] = obj.FUNCTIONS.train(traint);
                   
                   %Update classifier saveinfo
                   obj.DATA.saveinfo_datasets = length(get(h.SVM.datasets_list,'Value'));
                   val = get(h.SVM.datasets_list,'Value');
                   
                   obj.DATA.saveinfo_features = sum(obj.DATA.FEATURES{val(1)});
                   
                   val = get(h.SVM.train_type_list,'Value');
                   str = get(h.SVM.train_type_list,'String');
                   obj.DATA.saveinfo_other = str(val);
                   
                   obj.DATA.saveinfo_name = strcat(obj.panel_title);
                   
                   %Update dataset selection
                   obj.DATA.DATA_SETS_SEL = get(h.SVM.datasets_list,'Value');
                   
                   updatePerformanceValues(obj);

                   %updatePerformanceValuesAl(obj,obj.DATA.FPR,obj.DATA.SS_AL,obj.DATA.REL);
                   
                   
                   
                   
                   
                   
                   
                   
                   set(h.SVM.save_button, 'Enable' ,'on');
                   set(h.SVM.plotResults_button, 'Enable' ,'on');
                   set(h.SVM.PlotAlarmButton, 'Enable' ,'on');
                   set(h.SVM.RandEvalButton,'Enable','on');
                   %set(h.SVM.suppvectors_edit,'String',num2str(obj.DATA.model.totalSV));
              end
              
              function updateData(obj)

                  obj.DATA.WEIGHT = str2double(get(h.SVM.weight_edit, 'String'));
                  obj.DATA.PROB_POS = get(h.SVM.probability_estimates_popup, 'Value');
                  obj.DATA.SHRINKING_POS = get(h.SVM.shrinking_popup, 'Value');
                  obj.DATA.EPSILON_TOLERANCE = str2double(get(h.SVM.epsilon_tolerance_edit, 'String'));
                  obj.DATA.EPSILON_LOSS = str2double(get(h.SVM.epsilon_loss_edit, 'String'));
                  obj.DATA.CACHESIZE = str2double(get(h.SVM.cachesize_edit, 'String'));
                  obj.DATA.SVMTYPE_POS = get(h.SVM.svm_type_popup, 'Value');
                  obj.DATA.KERNELTYPE_POS = get(h.SVM.kernel_type_popup, 'Value');
                  obj.DATA.DEGREE = str2double(get(h.SVM.degree_edit, 'String'));
                  obj.DATA.COEF0 = str2double(get(h.SVM.coef0_edit, 'String'));
                  obj.DATA.NU = str2double(get(h.SVM.nu_edit, 'String')); 
                  obj.DATA.GAMMA = eval(get(h.SVM.gamma_edit, 'String'));
                  obj.DATA.COST = eval(get(h.SVM.cost_edit, 'String'));
                  obj.DATA.TARGET_SELECTED = get(h.SVM.classes_popup, 'Value');
                  obj.DATA.DELAY = str2double(get(h.SVM.delay_edit, 'String'));
                  obj.DATA.PRE_ICTAL_TIME=eval(get(h.SVM.pictal_edit,'String')).*60;
                  obj.DATA.EARLY_DETECT_TIME=eval(get(h.SVM.early_detect_edit,'String'));
              end
              
              %Save into the EpiLab data structure the classifier
              function Save_Button(obj, source, evendata)  
                  if exist(fullfile(obj.DATA.STUDY.workspace_path,'train_cache','last_man_data_sets.mat'))
                    dl=load(fullfile(obj.DATA.STUDY.workspace_path,'train_cache','last_man_data_sets.mat'));
                    
                    dat_train_time_start=dl.dat_train_time_start;
                    dat_train_time_end=dl.dat_train_time_end;
                    dat_test_time_start=dl.dat_test_time_start;
                    dat_test_time_end=dl.dat_test_time_end;
                    pictal_delta=dl.pictal_delta; 
                    dat_train_time_start_idx=dl.dat_train_time_start_idx;
                    dat_train_time_end_idx=dl.dat_train_time_end_idx;
                    dat_test_time_start_idx=dl.dat_test_time_start_idx; 
                    
                    dat_test_time_end_idx=dl.dat_test_time_end_idx;
                    
                    sel_feat=dl.sel_feat;
                    low_pass_stat=dl.low_pass_stat;
                    low_cut_off=dl.low_cut_off;
                    parameterAcq=dl.parameterAcq;
                    
                    
                    
                    
                    
                    c=clock();
                    
                    st=obj.DATA.STUDY.dataset.file.filename
                    idx=findstr(st,'.');
                    st=st(1:idx(1)-1);
                    save(fullfile(obj.DATA.STUDY.workspace_path,'train_cache',[st,'_svm_',num2str(c(1)),'_',num2str(c(2)),...
                        '_',num2str(c(3)),'_',num2str(c(4)),'_',num2str(c(5)),'_',num2str(c(5)),'.mat']),'dat_train_time_start','dat_train_time_end','dat_test_time_start','dat_test_time_end','pictal_delta','dat_train_time_start_idx','dat_train_time_end_idx',...
                        'dat_test_time_start_idx','dat_test_time_end_idx','sel_feat','low_pass_stat','low_cut_off','parameterAcq');
                   end
                  
                  
%                   import PredictionAlgorithms.Support_Vector_Machines.*;
% 
%                    dest = Support_Vector_Machines_Data();
%                    copyAllProperties(obj, obj.DATA, dest);
% 
%                    if isempty(obj.STUDY.dataset(1).results.classifiers.Support_Vector_Machines) %TODO: Change the name (automatic way)
%                        obj.STUDY.dataset(1).results.classifiers.Support_Vector_Machines = [dest];
%                    else
%                        pos=length(obj.STUDY.dataset(1).results.classifiers.Support_Vector_Machines);
%                        obj.STUDY.dataset(1).results.classifiers.Support_Vector_Machines(pos+1) = dest;  
%                    end
                   set(h.SVM.save_button, 'Enable' ,'off');
              end
              
              
              
               function EvaluateAlarmResultsCallback(obj, source, evendata)
                   if ~isempty(h.SVM.res_cel_sel)
                       svm_sel=h.SVM.res_cel_sel(1);

                   projectFolder='seizureanalyzer';
                   configFolder=[projectFolder '/config'];
                   featureFolder=[projectFolder '/features'];
                   condMkdir(configFolder);
                   condMkdir(featureFolder);

                   feature={{'01'}};
                   writeFeatureConfigEpilab([configFolder '/features.xml'],feature);

    %                writeProjectConfig(fileName,projectType,resultsPath,infoPath,filesPath,FPRmaxs,SOPs,ITs,
    %                thresholds,
    %                maximumBlockDistance,maximumGaps,timeAfterSeizure)

                   writeProjectConfigEpilab([configFolder '/project.xml'],'AlarmTesting','results/',...
                      '.','features','9999',num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Pictal),'10','0','0','0','0');

                    % FIND SEIZURES
                    seizures=[];
                    for i=1:length(h.study.dataset.results.feat_events)
                        if(strcmp(h.study.dataset.results.feat_events(i).type,'seizure'))
                            onset=h.study.dataset.results.feat_events(i).started;
                            offset=h.study.dataset.results.feat_events(i).stopped;
                            seizures=[seizures; onset offset];
%                         elseif(~isempty(strfind(h.study.dataset.results.feat_events(i).type,'EEG-ON')))
%                             onset=h.study.dataset.results.feat_events(i).started./h.study.dataset.file(1).data.sampling_rate;
%                             offset=h.study.dataset.results.feat_events(i).stopped./h.study.dataset.file(1).data.sampling_rate;
%                             seizures=[seizures; onset offset];
                            
                        end
                    end

                    writePatientConfigEpilab([configFolder '/patients.xml'],1,{seizures},...
                        int32(h.study.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Test_start),...
                        int32(h.study.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Test_stop));

                    alarms=int32(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Time_al(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Out_al>0)+...
                           obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Test_start);
                    
                    condMkdir([configFolder '/../results/alarms/']);
                    fAlarms=fopen([configFolder '/../results/alarms/pat001.alarms'],'w');
                    fprintf(fAlarms,'01\t0.0000\t');
                    fprintf(fAlarms,'%u\t',alarms);
                    fclose(fAlarms);
                    
                    cd('seizureanalyzer')
                    if ispc
                        system('SeizureAnalyzer.exe config')
                    elseif isunix
                        system('./seizureanalyzer_linux config')
                    end
                    cd('..')
                    
                    [SPH, SOP, FPRmax, usedSeizures, prePostIctalTime, feature, threshold, corrects, ...
                        incorrects, FPR, sensitivity, correctsTimes, incorrectsTimes, correctDiffs, incorrectDiffs] = ...
                        textread('seizureanalyzer/results/pat001/epilab/parameters.txt', '%f %f %f %f %f %s %f %f %f %s %f %s %s %s %s', -1, 'bufsize', 8*4096);

                    SPH=SPH;
                    
                    dim=str2double(inputdlg('Please enter the dimension of free parameters (e.g., the number of independent models tested)'));
                    fprintf('FPR: %f, SOP: %f, usedSeizures: %i, dim: %i, alpha: %f', str2double(FPR{1})/3600,SOP,usedSeizures,dim,0.05);
                    
                    sigLevel=calculateSigLevelEpilab(str2double(FPR{1})/3600,SOP,usedSeizures,dim,0.05);

                    msg=['The sensitivity of the alarms of the classifier is ' num2str(sensitivity) ', the FPR is ' num2str(FPR{1}) '. The sensitivity of the random predictor is ' ...
                        num2str(sigLevel) ' for the chosen dimension of free parameters of ' num2str(dim) '. Hence, the result is'];
                    if(sensitivity>sigLevel+0.000001)
                        msg=[msg ' significant'];
                        obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.REL='Sig.';
                    else
                        msg=[msg ' insignificant'];
                        obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.REL='N. Sig.';
                    end
                    msg=[msg '. For this analysis, ' num2str(usedSeizures) ' seizures were analyzed. Goodbye.'];
                    msgbox(msg)
                    updatePerformanceValues(obj);
                      
                   else
                       
                       warndlg('Please Select a model to Statisticaly Evaluate!','Statistical Validation')
                       
                       
                   end
               end

               
               
               
      %Plot the classifier results
      function PlotResults_ButtonCallback(obj, source, evendata)

           %BEGIN - plot
           
           if ~isempty(h.SVM.res_cel_sel)
                   svm_sel=h.SVM.res_cel_sel(1);
               figure('NumberTitle','off',...
                'Name',['Prediction Results=SVM_' num2str(svm_sel) ', SS=' num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.SS)  ', SP=' num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.SP)  ', AC=' num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.AC)]);

               set(gcf, 'color',[0.95 0.97 0.99]);
               
               A2 = obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Out;
               time=obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Time./3600;
               plot (time,obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Tar,'-g'); hold on;
               plot (time,A2,'--r');
               
%                disp('plot')
%                size(A2)
%                size(obj.DATA.T2)
               
               %Plot seizure states
               switch (obj.DATA.TARGET_SELECTED)                                        
                    case 1 %2 classes (binary)
                        plot (time,ones(1,length(A2))*obj.DATA.NORMAL_STATE,':','color', [0.8 0.8 0.8]);
                        plot (time,ones(1,length(A2))*obj.DATA.PRE_ICTAL_STATE,':','color', [0.6 0.6 0.6]);
                        legend ('Real data (target)', 'Prediction (classifier output)',...
                        ['Non Pre-ictal State (' num2str(obj.DATA.NORMAL_STATE) ')'],...
                        ['Pre-ictal State (' num2str(obj.DATA.PRE_ICTAL_STATE) ')']);
                    case 2 %4 classes
                        plot (time,ones(1,length(A2))*obj.DATA.NORMAL_STATE,':','color', [0.8 0.8 0.8]);
                        plot (time,ones(1,length(A2))*obj.DATA.PRE_ICTAL_STATE,':','color', [0.6 0.6 0.6]);
                        plot (time,ones(1,length(A2))*obj.DATA.ICTAL_STATE,':','color', [0.4 0.4 0.4]);
                        plot (time,ones(1,length(A2))*obj.DATA.POS_ICTAL_STATE,':','color', [0.2 0.2 0.2]);
                        
                        legend ('Real data (target)', 'Prediction (classifier output)',...
                        ['Normal State (' num2str(obj.DATA.NORMAL_STATE) ')'],...
                        ['Pre-ictal State (' num2str(obj.DATA.PRE_ICTAL_STATE) ')'],...
                        ['Ictal State (' num2str(obj.DATA.ICTAL_STATE) ')'],...
                        ['Pos-Ictal State (' num2str(obj.DATA.POS_ICTAL_STATE) ')']);
                    otherwise
                        disp('Target type.')    
               end

               title (['Prediction Results=SVM_' num2str(svm_sel) ', SS=' num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.SS)  ', SP=' num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.SP)  ', AC=' num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.AC)]);
               xlabel ('Time (h)');
               ylabel ('Seizure state')
              
           else
               warndlg('Please Select a model to plot!','Plot Model')
               
           end
           %END - plot
      end
      
               
               
              
               function PlotAlarmButtonCallback(obj, source, evendata)
                   if ~isempty(h.SVM.res_cel_sel)
                   svm_sel=h.SVM.res_cel_sel(1);
               
                   figure('NumberTitle','off',...
                       'Name',['Alarm Results= SVM_' num2str(svm_sel) ', SS=' num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.SS_AL)  ', FPR=' num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.FPR)]);
                   
                   set(gcf, 'color',[0.95 0.97 0.99]);
                   
                   
                   act_al_lev=str2num(get(obj.th_lev_edit,'String'))/100;
                    
                   
               
                   mod_al_lev=(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Firing_pow);
               
               if (act_al_lev~=mod_al_lev) && act_al_lev>=0 && act_al_lev<=100
                   obj.DATA.firing_power_alarm=act_al_lev;
                   A=obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Out;
                   T2=obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Tar;
                   %A2=real2th(A',[obj.DATA.NORMAL_STATE obj.DATA.PRE_ICTAL_STATE obj.DATA.ICTAL_STATE obj.DATA.POS_ICTAL_STATE]);
                   
                   
                   [out,tint,time_out,tar]=class2alarm(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Time,...
                       A,T2,obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Pictal,...
                       obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Pictal_state,obj.STUDY.dataset.results.parameterAcq,obj.DATA.firing_power_alarm);
                [SS_AL,FPR,hours_estim,nseiz]=eval_results_alarm(out,tar);
                
                
                 if SS_AL>0
                    time=time_out+obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Test_start;
                    evts=obj.DATA.STUDY.dataset.results.feat_events;
                    [min_ant,max_ant,avg_ant,std_ant]=eval_ant_times(time,tar,out,...
                        obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Pictal,evts)
                else
                    min_ant=NaN;
                    max_ant=NaN;
                    avg_ant=NaN;
                    std_ant=NaN;
                 end
                
                 obj.DATA.MIN_ANT=min_ant;
                obj.DATA.MAX_ANT=max_ant;
                obj.DATA.AVG_ANT=avg_ant;
                obj.DATA.STD_ANT=std_ant;
                 
                
                obj.DATA.SS_AL=SS_AL;
                obj.DATA.FPR=FPR;
                obj.DATA.OUT_AL=out;
                obj.DATA.TAR_AL=tar;
                obj.DATA.TIME_AL=time_out;
                   
                
                
                
                up_mod=obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel};
                  
                  up_mod.FPR=FPR;
                  up_mod.Firing_pow=act_al_lev;
                  up_mod.SS_AL=SS_AL;
                  up_mod.('Out_al')=out;
                  
                 up_mod.MAX_ANT=obj.DATA.MAX_ANT;
                 up_mod.MIN_ANT=obj.DATA.MIN_ANT;
                 up_mod.AVG_ANT=obj.DATA.AVG_ANT;
                 up_mod.STD_ANT=obj.DATA.STD_ANT;
                  
                  
                  svm_res=obj.STUDY.dataset.results.classifiers.Support_Vector_Machines;
                   
                   svm_res={svm_res{:},up_mod};
                   
                   obj.STUDY.dataset.results.classifiers.Support_Vector_Machines=svm_res;
                   
                   updatePerformanceValues(obj);
                   set(gcf,'Name',['Alarm Results= SVM_' num2str(numel(svm_res)) ', SS=' num2str(up_mod.SS_AL)  ', FPR=' num2str(up_mod.FPR)])
               else
                   
                   
                   
                   
                   
                   tar = obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Tar_al;
                   time_out=obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Time_al;
                   out=obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Out_al;
                   SS_AL=obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.SS_AL;
                   FPR=obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.FPR;
                   
                   %A2=real2th(A2,[obj.DATA.NORMAL_STATE obj.DATA.PRE_ICTAL_STATE obj.DATA.ICTAL_STATE obj.DATA.POS_ICTAL_STATE]);
                   
                   
                   
                   
                       
               end 
                   
                   time_out=time_out+obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Test_start;
                   
                   
                   
                   
                   
                   tm=time_out./3600;
                   
                   %Transforming Target in a series of seizure onsets
                    no_pict_idx=find(tar~=obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Pictal_state);
                    pict_idx=find(tar==obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,svm_sel}.Pictal_state);
                    tar(no_pict_idx)=0;
                    tar(pict_idx)=1;
                   
                   
                     dtar=diff(tar);
                   
                   idx_up=find(dtar==1);
                   idx_dn=find(dtar==-1);
                   
                   l_Group = hggroup;

                   for p=1:numel(idx_up)
                       
                      rectangle('Position',[tm(idx_up(p)),0,tm(idx_dn(p))-tm(idx_up(p)),0.5],'Edgecolor','b','Facecolor','b')
                      
                      hl=line([tm(idx_dn(p)+1),tm(idx_dn(p)+1)],[0,1],'LineWidth',2,'color','k')
                      set(hl,'Parent',l_Group)
                      %leg=horzcat(leg,['Sz. ',num2str(p)])
                      
                      
                   end
                   hold on
                    stem(tm,(out)-0.2,'r','Marker','*','LineWidth',1)
                   
                   
                   
                   
                   
                   set(get(get(l_Group,'Annotation'),'LegendInformation'),...
    'IconDisplayStyle','on'); 
                   
                   legend ('Onset Times','Raised Alarms');
                   title (['Alarm Results: SS=' num2str(SS_AL)  ', FPR (1/h)=' num2str(FPR)]);
                   xlabel ('Time(h)');
                   ylabel ('Prediction State')
                   %END - plot
                   
                   axis([tm(1),tm(end),0,1])
                   else
                       
                       warndlg('Please Select a model to plot!','Plot Model')
                   
                   
                   end
                   
               end
              
%               %Simulate a previous classifier
%               function Simulate_Button(obj, source, evendata)
%                    [SP SS AC obj.DATA.A obj.DATA.T2] = obj.FUNCTIONS.sim();
%                    
%                    updatePerformanceValues(obj,SP,SS,AC);
% %                     disp('sim')
% %                     size(obj.DATA.A)
% %                     size(obj.DATA.T2)
%                    set(h.SVM.save_button, 'Enable' ,'on');
%                    set(h.SVM.plotResults_button, 'Enable' ,'on');
%                    set(h.SVM.simulate_button, 'Enable' ,'on');
%                    set(h.SVM.suppvectors_edit,'String',num2str(obj.DATA.model.totalSV));
% 
%               end
               
           end
          
           function updatePerformanceValues(obj)
               
               
               n_svm=numel(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines);
               
               tab_svm=cell(n_svm,10);
               for sv=1:n_svm
                   tab_svm{sv,1}=['SVM_',num2str(sv)];
                   tab_svm{sv,2}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.SS_AL);
                   tab_svm{sv,3}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.FPR);
                   
                   
                   tab_svm{sv,4}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.MIN_ANT);
                   tab_svm{sv,5}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.MAX_ANT);
                   tab_svm{sv,6}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.AVG_ANT);
                   tab_svm{sv,7}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.STD_ANT);
                   
                   
                   
                   tab_svm{sv,8}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.SS);
                   tab_svm{sv,9}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.SP);
                   tab_svm{sv,10}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.AC);
                   tab_svm{sv,11}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.REL);
                   tab_svm{sv,12}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.Pictal/60);
                   tab_svm{sv,13}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.Firing_pow*100);
                   tab_svm{sv,14}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.Gamma);
                   tab_svm{sv,15}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.Cost);
                   
                   tab_svm{sv,16}=num2str(obj.STUDY.dataset.results.classifiers.Support_Vector_Machines{1,sv}.Transfer_Functions);
                   
                   
                   
                   
               end
               set(h.SVM.tab_res,'Data',tab_svm);

%               obj.DATA.SP = SP; obj.DATA.SS = SS; obj.DATA.AC = AC;
% 
%               set(h.SVM.sens_text,'String', sprintf('SS = %.2f',SP));
%               set(h.SVM.spec_text,'String', sprintf('SP = %.2f',SS));
%               set(h.SVM.acc_text,'String',  sprintf('AC = %.2f',AC));
              
              
              
              
              
           end
          
           
%            function updatePerformanceValuesAl(obj,FPR,SS_AL,Rel)
% 
%               obj.DATA.SS_AL = SS_AL; obj.DATA.FPR = FPR; obj.DATA.REL = Rel;
% 
%               set(h.SVM.fpr_text,'String', sprintf('FPR = %.2f',FPR));
%               set(h.SVM.sens_text_al,'String', sprintf('SS = %.2f',SS_AL));
%               set(h.SVM.rel,'String',  sprintf('Rel = %.2f',Rel));
%           end

      end
      
         
      %Copy all the properties
      %REQUIRED FUNCTION
      function copyAllProperties(obj, src, dest)
          prop = fieldnames(src);
          for i=1:length(prop)    
             if ~strcmp(prop{i},'STUDY')
                eval(strcat('dest.',prop{i},'=src.',prop{i},';'));
             end   
          end    
      end     

   end
end         