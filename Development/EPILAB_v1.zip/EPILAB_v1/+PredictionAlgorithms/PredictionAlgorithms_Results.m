%TODO:
%   Transform into a class
function PredictionAlgorithms_Results(study)

global h;

row = 0;
h.Classifiers.ResultsFig = figure ('position', [600 400 600 300], 'MenuBar', 'none', 'name', 'EpiLab : Prediction Algorithms : Results', 'NumberTitle', 'off');

defaultBackground = get(0,'defaultUicontrolBackgroundColor');
set(h.Classifiers.ResultsFig,'Color',defaultBackground);

% default panel
h.Classifiers.ResultsPanel = uipanel('Parent', h.Classifiers.ResultsFig,'Units','Normalized','Position', [0.05 0.05 0.9 0.9]);

[h.Classifiers.dat h.Classifiers.c_object] = createClassifiersTable();

cnames = {'Name','SS','SP','AC','Datasets','Features','Other'}; 
h.Classifiers.ResultsTable = uitable('Data',h.Classifiers.dat,'ColumnName',cnames,'Units','Normalized','CellSelectionCallback',@UpdateClassifier,... 
                                   'Parent',h.Classifiers.ResultsPanel,'RearrangeableColumn','on','Position',[0 0.1 1 0.9]);
                                                             
h.Classifiers.load_classifier_button = uicontrol('Parent',h.Classifiers.ResultsPanel,'Style','pushbutton','Units','Normalized','String','Open','FontSize',8,'Callback',{@LoadClassifier_Button},...
                   'Position',[0.25,0.01,0.13,0.07]);
               
h.Classifiers.delete_classifier_button = uicontrol('Parent',h.Classifiers.ResultsPanel,'Style','pushbutton','Units','Normalized','String','Delete','FontSize',8,'Callback',{@DeleteClassifier_Button},...
                   'Position',[0.4,0.01,0.12,0.07]);
               
h.Classifiers.refresh_classifier_button = uicontrol('Parent',h.Classifiers.ResultsPanel,'Style','pushbutton','Units','Normalized','String','Refresh','FontSize',8,'Callback',{@updateTable},...
                   'Position',[0.54,0.01,0.13,0.07]);
    
    function UpdateClassifier(source, event)
        row=event.Indices(:,1);
    end    
                               
    function [t obj]=createClassifiersTable()
      t = {};
      obj = {};
      count = 1;
      ds_name = strcat(study.name,'.');
      %1� Build the dataset name
      for i=1:length(study.dataset)
          
          %2� Get the classifiers types
          c = fieldnames(study.dataset(i).results.classifiers);
          for j=1:length(c)
              c2 = ['study.dataset(i).results.classifiers.' cell2mat(c(j))];
              for x=1:eval(['length(' c2 ')'])
                  name = eval([c2 '(x).saveinfo_name']);
                  SS = num2str(eval([c2 '(x).SS']));
                  SP = num2str(eval([c2 '(x).SP']));
                  AC = num2str(eval([c2 '(x).AC']));
                  ds = eval([c2 '(x).saveinfo_datasets']);
                  fea = eval([c2 '(x).saveinfo_features']);
                  other = eval([c2 '(x).saveinfo_other']);
                  name = strcat(name);
                  t{count,1} = name;
                  t{count,2} = SS;
                  t{count,3} = SP;
                  t{count,4} = AC;
                  t{count,5} = mat2str(ds);
                  t{count,6} = mat2str(fea);
                  t{count,7} = cell2mat(other);
                  obj{count} = ['study.dataset(' num2str(i) ').results.classifiers.' cell2mat(c(j)) '(' num2str(x) ')'];
                  count = count + 1;
              end    
          end    
      end
    end    
     
    function LoadClassifier_Button(source, event)
       if row(1) ~= 0
           data = h.Classifiers.c_object{row(1)};
           sub_name = eval(strcat(data,'.sub_module_name'));
           e = strcat(data, '.MenuitemCallback(',data, ',''', sub_name, ''')')
           eval(e);
       end    
    end

    function DeleteClassifier_Button(source, event)
       if row(1) ~= 0
           for i=length(row):-1:1
               strcat(h.Classifiers.c_object{row(i)}, ' = [];')
               eval(strcat(h.Classifiers.c_object{row(i)}, ' = [];'));
           end    
       end
       updateTable();
    end

    function updateTable(source, event)
        [h.Classifiers.dat h.Classifiers.c_object] = createClassifiersTable();
        set(h.Classifiers.ResultsTable,'Data',h.Classifiers.dat);
    end    

end

