# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/f74/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f152/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/faq:ins:2/;
$ref_files{$key} = "$dir".q|node85.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_fy/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sm/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f0:TOC3/;
$ref_files{$key} = "$dir".q|node8.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:LARGELYAP/;
$ref_files{$key} = "$dir".q|node49.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_JK97/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_rcd/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f139/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_fr95/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kh/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f44/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_cs97/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f186/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/f82/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f131/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/install/;
$ref_files{$key} = "$dir".q|node5.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:CORRSUM/;
$ref_files{$key} = "$dir".q|node44.html|; 
$noresave{$key} = "$nosave";

$key = q/f167/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f49/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bp1/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f19:PREP/;
$ref_files{$key} = "$dir".q|node20.html|; 
$noresave{$key} = "$nosave";

$key = q/f51/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:Q310/;
$ref_files{$key} = "$dir".q|node88.html|; 
$noresave{$key} = "$nosave";

$key = q/f145/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_hl/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_pc/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_briggs/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KantzSchreiber:1997/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Sch88/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f79/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f148/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f66/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bdws/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abar96/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f23/;
$ref_files{$key} = "$dir".q|node37.html|; 
$noresave{$key} = "$nosave";

$key = q/f29/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f72/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_cp/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_razj/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f203/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Grassberger:1993/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f158/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:Q320/;
$ref_files{$key} = "$dir".q|node88.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_AM96/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f113/;
$ref_files{$key} = "$dir".q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/f107/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f110/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f58/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f99/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f103/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f162/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Abarbanel:1996/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sir/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f179/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/f32/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f19/;
$ref_files{$key} = "$dir".q|node16.html|; 
$noresave{$key} = "$nosave";

$key = q/f206/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/f19:MEX/;
$ref_files{$key} = "$dir".q|node19.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_PK98/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_lps/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_PJK97/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f180/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/f93/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f56/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f166/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f140/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f214/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/f116/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:Q400/;
$ref_files{$key} = "$dir".q|node89.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_fb/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f125/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:QA230/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LH91/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_lg/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f34/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f64/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f75/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kaplan/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f112/;
$ref_files{$key} = "$dir".q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_wssv/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f129/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_gfce/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sp/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:BOXCOUNT/;
$ref_files{$key} = "$dir".q|node41.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_zpe/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_RSTA95/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f119/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f142/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f144/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f193/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:QA270/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/f19:RANGE/;
$ref_files{$key} = "$dir".q|node18.html|; 
$noresave{$key} = "$nosave";

$key = q/f67/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f87/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_tglef/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f0:TOC4/;
$ref_files{$key} = "$dir".q|node11.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:Q110/;
$ref_files{$key} = "$dir".q|node84.html|; 
$noresave{$key} = "$nosave";

$key = q/f120/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:QA240/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/global/;
$ref_files{$key} = "$dir".q|node6.html|; 
$noresave{$key} = "$nosave";

$key = q/f91/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f38/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_gd/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:Q410/;
$ref_files{$key} = "$dir".q|node89.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kk/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:QA100/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_pgmk95/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f137/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f159/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f174/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_theiler2/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f196/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_KP96/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_driven/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:Q300/;
$ref_files{$key} = "$dir".q|node88.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_brp/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f112:DATA/;
$ref_files{$key} = "$dir".q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:QA130/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/f112:OVER/;
$ref_files{$key} = "$dir".q|node78.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:TAKENS.ESTIMATOR/;
$ref_files{$key} = "$dir".q|node55.html|; 
$noresave{$key} = "$nosave";

$key = q/f92/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_grass/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f113:OVER/;
$ref_files{$key} = "$dir".q|node74.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Mo92/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/faq:ins:3/;
$ref_files{$key} = "$dir".q|node85.html|; 
$noresave{$key} = "$nosave";

$key = q/f161/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_th95/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kshbpfsbb/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LP88/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f185/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ks97/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_takens2/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_AB95/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f27:DATA/;
$ref_files{$key} = "$dir".q|node67.html|; 
$noresave{$key} = "$nosave";

$key = q/f121/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_pksp/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_lr/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f78/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:QA250/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/f132/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f209/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:RANGESEARCH/;
$ref_files{$key} = "$dir".q|node53.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kantz/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_hp/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f28/;
$ref_files{$key} = "$dir".q|node61.html|; 
$noresave{$key} = "$nosave";

$key = q/f41a/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f168/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_gz1/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f188/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_gp/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f26:OVER/;
$ref_files{$key} = "$dir".q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/f216/;
$ref_files{$key} = "$dir".q|node81.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Berchtold:1997/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f27:FUNCTIONS/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f124/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bkm/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_GR92/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f113:DATA/;
$ref_files{$key} = "$dir".q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:Q120/;
$ref_files{$key} = "$dir".q|node84.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_BPV84/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Belussi:1995/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f146/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f165/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Schreiber:1996/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_dm/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f60/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_er2/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sn/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f71/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f81/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f73/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f96/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f59/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:Q100/;
$ref_files{$key} = "$dir".q|node84.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sg/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Parlitz:1998/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f128/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ss/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f112:FUNCTIONS/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/f48/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_telgf/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_pcfs80/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f37/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f208/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/faq:ins:4/;
$ref_files{$key} = "$dir".q|node85.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:QA120/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_theiler1/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bba1/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f90/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ls/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_PJK96/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f106/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f86/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ghks/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/trev/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f0/;
$ref_files{$key} = "$dir".q|node3.html|; 
$noresave{$key} = "$nosave";

$key = q/f33/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_lmdib/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f184/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:FNEARNEIGH/;
$ref_files{$key} = "$dir".q|node46.html|; 
$noresave{$key} = "$nosave";

$key = q/f28:OVER/;
$ref_files{$key} = "$dir".q|node62.html|; 
$noresave{$key} = "$nosave";

$key = q/f202/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/f175/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/f102/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sauer/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f141/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_frazer1/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:NNPREPARE/;
$ref_files{$key} = "$dir".q|node50.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_egmn/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_singer/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_hcp/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_gpl/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f45/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/tc3/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f117/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f171/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f55/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f149/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f70/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f41/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f189/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/f27:OVER/;
$ref_files{$key} = "$dir".q|node66.html|; 
$noresave{$key} = "$nosave";

$key = q/f194/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_wbpp/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f136/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f63/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_brown/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f19:APPROX/;
$ref_files{$key} = "$dir".q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/f210/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/f143/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f40/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f130/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ARS96/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_aleksic/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:CORRSUM2/;
$ref_files{$key} = "$dir".q|node45.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_par/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_takens81/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_brt/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f122/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f197/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_JK95/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f68/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_frazs/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:AMUTUAL/;
$ref_files{$key} = "$dir".q|node39.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:QA280/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/f160/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f156/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f30/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f134/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:Q200/;
$ref_files{$key} = "$dir".q|node87.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Halsey:1986/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_McNames:1998/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:QA260/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/f213/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/f123/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/reconstruction/;
$ref_files{$key} = "$dir".q|node29.html|; 
$noresave{$key} = "$nosave";

$key = q/f89/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:TENTMAP/;
$ref_files{$key} = "$dir".q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/f169/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:QA140/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_HM86/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f27/;
$ref_files{$key} = "$dir".q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Pestov/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f172:DATA/;
$ref_files{$key} = "$dir".q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_frazer2/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f135/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_smith/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f205/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/f97/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f19:NNSEARCH/;
$ref_files{$key} = "$dir".q|node21.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_dc96/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sss/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Arya:1994/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:Q140/;
$ref_files{$key} = "$dir".q|node84.html|; 
$noresave{$key} = "$nosave";

$key = q/f28:DATA/;
$ref_files{$key} = "$dir".q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:BAKER/;
$ref_files{$key} = "$dir".q|node40.html|; 
$noresave{$key} = "$nosave";

$key = q/f212/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_hsdl/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f105/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f201/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/f191/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/f114/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_parlitz2/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f176/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Ott93/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f157/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_cao97/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f118/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_TS86/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f127/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f42/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f187/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sch98/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_AMJW97/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f150/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f190/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_rl97/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f163/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f101/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f182/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/f95/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f46/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f155/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f100/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Sedgewick:AlgorithmsC++/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f50/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bba2/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f153/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f133/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f77/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ss96/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kes/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f183/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/f84/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f26:DATA/;
$ref_files{$key} = "$dir".q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/f54/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:NNSEARCH/;
$ref_files{$key} = "$dir".q|node51.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_fs/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:QA290/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/f62/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_frb/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f65/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kennedy/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_psvm/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_MK86/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f108/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:PREDICT/;
$ref_files{$key} = "$dir".q|node52.html|; 
$noresave{$key} = "$nosave";

$key = q/f36/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_cs/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:RETURN.TIME/;
$ref_files{$key} = "$dir".q|node54.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:Q130/;
$ref_files{$key} = "$dir".q|node84.html|; 
$noresave{$key} = "$nosave";

$key = q/f28:FUNCTIONS/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f109/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_pd/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f94/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_osel/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f19:EXAMPLE/;
$ref_files{$key} = "$dir".q|node23.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_cefg/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bp/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:QA110/;
$ref_files{$key} = "$dir".q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sc/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f26/;
$ref_files{$key} = "$dir".q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/f115/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f83/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bp2/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f172/;
$ref_files{$key} = "$dir".q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:CHAOSYS/;
$ref_files{$key} = "$dir".q|node43.html|; 
$noresave{$key} = "$nosave";

$key = q/f52/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f216:Q210/;
$ref_files{$key} = "$dir".q|node87.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:GENDIMEST/;
$ref_files{$key} = "$dir".q|node47.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kf/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f199/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/f177/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:AKIMASPLINE/;
$ref_files{$key} = "$dir".q|node38.html|; 
$noresave{$key} = "$nosave";

$key = q/f57/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f85/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f172:OVER/;
$ref_files{$key} = "$dir".q|node70.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:CAO/;
$ref_files{$key} = "$dir".q|node42.html|; 
$noresave{$key} = "$nosave";

$key = q/f198/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/f170/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_sy/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f204/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_pad/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Water:1988/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f192/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_gz2/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Shampine/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_mamr/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f104/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_LKP97/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_parlitz1/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f151/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f43/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f98/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_gss/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f47/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f69/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f215/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/f126/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abst/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f164/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f88/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f23:HENON/;
$ref_files{$key} = "$dir".q|node48.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abk/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f178/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kbh/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f31/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f76/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_syc/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f19:RANGESEARCH/;
$ref_files{$key} = "$dir".q|node22.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_c/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f173/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kapsch/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f195/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_s95/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bggs/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_er/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f0:TOC2/;
$ref_files{$key} = "$dir".q|node4.html|; 
$noresave{$key} = "$nosave";

$key = q/f200/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_zep/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ks/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Sz97/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_abs/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f80/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f211/;
$ref_files{$key} = "$dir".q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kba/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_bk/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f138/;
$ref_files{$key} = "$dir".q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/f26:FUNCTIONS/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f172:FUNCTIONS/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/f53/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f61/;
$ref_files{$key} = "$dir".q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/f154/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/f11/;
$ref_files{$key} = "$dir".q|node14.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_rcl2/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f147/;
$ref_files{$key} = "$dir".q|node68.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_ekrc/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/faq:ins:1/;
$ref_files{$key} = "$dir".q|node85.html|; 
$noresave{$key} = "$nosave";

$key = q/f113:FUNCTIONS/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_broggi/;
$ref_files{$key} = "$dir".q|node90.html|; 
$noresave{$key} = "$nosave";

$key = q/f181/;
$ref_files{$key} = "$dir".q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/f207/;
$ref_files{$key} = "$dir".q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/faq:ins:5/;
$ref_files{$key} = "$dir".q|node85.html|; 
$noresave{$key} = "$nosave";

1;

