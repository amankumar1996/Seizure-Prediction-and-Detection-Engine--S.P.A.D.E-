function [Ci Q]=modularity_dir(A)
%[Ci Q]=modularity_dir(A); community detection via optimization of modularity.
%
%Input: weighted directed network (adjacency or weights matrix) A.
%Output: community structure Ci; maximized modularity Q.
%
%Algorithm: Newman's spectral optimization method, generalized to directed networks.
%Reference: Leicht and Newman (2008) Phys Rev Lett.
%
%Modification History:
%Jul 2008: Original -- Mika Rubinov, UNSW
%Oct 2008: Bug fixed -- positive eigenvalues not sufficient for division (Jonathan Power, WUSTL)

Ki=sum(A,1);                            %in-degree
Ko=sum(A,2);                            %out-degree
N=length(A);                            %number of vertices
m=sum(Ki);                           	%number of edges
b=A-(Ko*Ki).'/m;
B=b+b.';                            	%directed modularity matrix
Ci=ones(N,1);                           %community indices
cn=1;                                   %number of communities
U=[1 0];                                %array of unexamined communites

ind=1:N;
Bg=B;
Ng=N;

while U(1)                              %examine community U(1)
    [V D]=eig(Bg);
    [d1 i1]=max(diag(D));               %most positive eigenvalue of Bg
    v1=V(:,i1);                         %corresponding eigenvector

    S=ones(Ng,1);
    S(v1<0)=-1;
    q=S.'*Bg*S;                         %contribution to modularity

    if q>1e-10                       	%contribution positive: U(1) is divisible
        Qit=zeros(Ng,1);
        while q;                        %iterative fine-tuning
            for i=1:Ng
                S(i)=-S(i);
                Qit(i)=S.'*Bg*S;
                S(i)=-S(i);
            end
            qmax=max(Qit);
            q=(qmax>q)*qmax;
            S(Qit==q)=-S(Qit==q);
        end

        if abs(sum(S))==Ng              %unsuccessful splitting of U(1)
            U(1)=[];
        else
            cn=cn+1;
            Ci(ind(S==1))=U(1);         %split old U(1) into new U(1) and into cn
            Ci(ind(S==-1))=cn;
            U=[cn U];
        end
    else                                %contribution nonpositive: U(1) is indivisible
        U(1)=[];
    end

    ind=find(Ci==U(1));                 %indices of unexamined community U(1)
    bg=B(ind,ind);
    Bg=bg-diag(sum(bg));                %modularity matrix for U(1)
    Ng=length(ind);                     %number of vertices in U(1)
end

s=repmat(Ci,[1 N]);                     %compute modularity
Q=~(s-s.').*B/(2*m);
Q=sum(Q(:));