function BMVresults=  BiMultiVariateFeatures_Functions(study_data, sampling_rate, channels, window_shift, num_total, IM, window_IM, parameter_IM)
% The work horse to compute Bi- and Multivariate Interaction Measures (IM). 
%
%function BMVresults= BiMultiVariateFeatures_Functions(study_data, sampling_rate, channels, window_shift, num_total, IM, window_IM, parameter_IM)
%
% michael.jachan@fdm.uni-freiburg.de
% This file is a wrapper that links Interaction Measures programmed for the
% FDMa into Epilab. 
%
% study_data    = study.dataset.file.data.eeg, mean will be subtracted here. 
% sampling_rate from the user-input
% channels      Nr of channels
% window_shift  shift per feature sample
% num_total     Nr of blocks
% IM...         Interaction Measure: 
%               'PDC' Patial Directed Coherence, 
%               'DTF' Directed Transfer Function, 
%               'COH' Coherence/Partial Coherence, 
%               'MPC' Mean Phase Coherence, 
%               'MIS' Mutual Information, 
%               'CPR' Recurrence Phase Synchr. 
% window_IM     window length from user-input
% parameter_IM  frequency or delay at which the IM is evaluated (user-input)!
%
%% TODO % Switch plotting off!

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% defaultparameters for epilab 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This version of the FDMa includes the following Spectral Estimators (SPEC):
% For each SPEC all FREQMEAS and all TIMEMEAS are computed
parameters.sys.SPEC= [];
spec= 0;
if(1)
% Smoothed Periodogram (SMP)
   spec= spec+1;
   parameters.sys.SPEC(spec).name     = 'Smoothed Periodogram';
   parameters.sys.SPEC(spec).shortname= 'SMP';
   parameters.sys.SPEC(spec).bootstrap= 'twins';
end
if(1)
% Block-Averaged Periodogram (BAP)
   spec= spec+1;
   parameters.sys.SPEC(spec).name     = 'Block-Averaged Periodogram';
   parameters.sys.SPEC(spec).shortname= 'BAP';
   parameters.sys.SPEC(spec).bootstrap= 'block';
end
if(1)
% VAR Spectrum (VAR)
   spec= spec+1;
   parameters.sys.SPEC(spec).name     = 'VAR Spectrum';
   parameters.sys.SPEC(spec).shortname= 'VAR';
   parameters.sys.SPEC(spec).bootstrap= 'twins';
end
if(1)% NOT FINISHED YET
% Mutual Information Spectrum (MIS)
   spec= spec+1;
   parameters.sys.SPEC(spec).name     = 'Mutual Information Spectrum';
   parameters.sys.SPEC(spec).shortname= 'MIS';
   parameters.sys.SPEC(spec).bootstrap= 'twins';
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This version of the FDMa includes the following Flat
% Interaction Measures (FLATMEAS): 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
parameters.sys.FLATMEAS= [];
flatmeas= 0;
if(1)
% Mean Phase Coherence (MPC)
   flatmeas= flatmeas+1;
   parameters.sys.FLATMEAS(flatmeas).name     = 'Mean Phase Coherence';
   parameters.sys.FLATMEAS(flatmeas).shortname= 'MPC';
   parameters.sys.FLATMEAS(flatmeas).bootstrap= 'twins';
   parameters.sys.FLATMEAS(flatmeas).bootstrap= 'block';% NOCH FALSCH, USE C-SOURCECODE VON J. NAWRATH
end
if(1)
% Block-Averaged MPC (BAMPC)
   flatmeas= flatmeas+1;
   parameters.sys.FLATMEAS(flatmeas).name     = 'Block-Averaged MPC';
   parameters.sys.FLATMEAS(flatmeas).shortname= 'BAMPC';
   parameters.sys.FLATMEAS(flatmeas).bootstrap= 'block';
end

if(1)
% Lag Synchronization Index (LSI)
   flatmeas= flatmeas+1;
   parameters.sys.FLATMEAS(flatmeas).name     = 'Lag Synchronization Index';
   parameters.sys.FLATMEAS(flatmeas).shortname= 'LSI';
   parameters.sys.FLATMEAS(flatmeas).bootstrap= 'twins';
   parameters.sys.FLATMEAS(flatmeas).bootstrap= 'block';% NOCH FALSCH, USE C-SOURCECODE VON J. NAWRATH
end
if(1)
% Block-Averaged LSI (BALSI)
   flatmeas= flatmeas+1;
   parameters.sys.FLATMEAS(flatmeas).name     = 'Block-Averaged LSI';
   parameters.sys.FLATMEAS(flatmeas).shortname= 'BALSI';
   parameters.sys.FLATMEAS(flatmeas).bootstrap= 'block';
end

if(1)
% Corr. btw. Prob. of Recurrence (CPR)
   flatmeas= flatmeas+1;
   parameters.sys.FLATMEAS(flatmeas).name     = 'Corr. btw. Prob. of Recurrence';
   parameters.sys.FLATMEAS(flatmeas).shortname= 'CPR';
   parameters.sys.FLATMEAS(flatmeas).bootstrap= 'twins';
   parameters.sys.FLATMEAS(flatmeas).bootstrap= 'block';% NOCH FALSCH, USE C-SOURCECODE VON J. NAWRATH
end
if(1)
% Block-Averaged CPR (BACPR)
   flatmeas= flatmeas+1;
   parameters.sys.FLATMEAS(flatmeas).name     = 'Block-Averaged CPR';
   parameters.sys.FLATMEAS(flatmeas).shortname= 'BACPR';
   parameters.sys.FLATMEAS(flatmeas).bootstrap= 'block';
end


parameters.sys.silent= 1;

num_total=num_total+1; %% added by Bjoern
num_total=floor(num_total);

%parameters.silent= 1;
Fs= sampling_rate;
N= window_IM;
D= channels;
parameters.Fs    = Fs;
parameters.N     = N;
parameters.D     = D;
parameters.analyze.Nfreq         = window_IM/2;
parameters.analyze.f0            = parameter_IM;
parameters.analyze.siglev        = .05;
parameters.analyze.SMPh0Hz       = 5;% MAKE THIS USER-PARAMETER
parameters.analyze.tapertype     = 'raisedcosine';
parameters.analyze.taperparameter= 1/32;% relative length of roll-off
parameters.analyze.specsub       = 1;
parameters.analyze.anyFREQMEAS   = 0;
parameters.analyze.anyFLATMEAS   = 0;
parameters.analyze.blocklength   = N;
parameters.analyze.bootstrapping = 0;
parameters.analyze.wilson = 0;
parameters.peakest.peakest_component= 0;
parameters.plotting.switchon           = 0;
parameters.plotting.plot_neg_freq      = 0;
parameters.plotting.plot_diag          = 1;
parameters.plotting.plot_fig           = 0;
parameters.plotting.plot_eps           = 0;
parameters.plotting.plot_pdf           = 0;
parameters.plotting.plot_f0            = 1;
parameters.plotting.plot_d0            = 1;
parameters.plotting.plot_grid          = 0;
parameters.plotting.color_sini         = 'r';
parameters.plotting.color_diag         = 'g';
parameters.plotting.deltaF             = parameters.Fs/16;
parameters.plotting.deltaT             = N/16;
parameters.plotting.frequency_ticks    = 1:parameters.plotting.deltaF*2*parameters.analyze.Nfreq/parameters.Fs:window_IM;
parameters.plotting.frequency_labels   = window_IM/2/parameters.analyze.Nfreq*(parameters.plotting.frequency_ticks-1)/window_IM*parameters.Fs;
parameters.plotting.dynrange           = 90;
parameters.plotting.plotmaxfreq        = parameters.Fs/2;
parameters.plotting.plotmaxdelay       = N/2;
parameters.plotting.plot_minimal_labels= 1;
parameters.plotting.Freq               = Fs/2*(0:parameters.analyze.Nfreq-1)'/parameters.analyze.Nfreq;
parameters.plotting.Time               = N/Fs/parameters.analyze.specsub/2*(0:parameters.analyze.Nfreq-1)'/parameters.analyze.Nfreq;

switch(IM)
   case 'PDC'
      parameters.analyze.PDC        = 1;
      parameters.analyze.anyFREQMEAS= 1;
      parameters.analyze.VAR        = 1;
      parameters.analyze.Pmin       = floor(window_IM/64);
      parameters.analyze.Pmax       = floor(window_IM/64);
      parameters.analyze.P0         = floor(window_IM/64);
   case 'DTF'
      parameters.analyze.DTF        = 1;
      parameters.analyze.anyFREQMEAS= 1;
      parameters.analyze.VAR        = 1;
      parameters.analyze.Pmin       = floor(window_IM/64);
      parameters.analyze.Pmax       = floor(window_IM/64);
      parameters.analyze.P0         = floor(window_IM/64);
   case 'COH'
      parameters.analyze.COH        = 1;
      parameters.analyze.anyFREQMEAS= 0;
      parameters.analyze.SMP        = 1;
   case 'MIS'
      parameters.analyze.anyFREQMEAS= 0;
      parameters.analyze.MIS        = 1;
   case 'MPC'
      parameters.analyze.MPC        = 1;
      parameters.analyze.anyFLATMEAS= 1;
   case 'CPR'
      parameters.analyze.CPR        = 1;
      parameters.analyze.anyFLATMEAS= 1;
end%switch(IM)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% In measurematrix, distance, clusterc the features will be stored
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
measurematrix= zeros(channels, channels, num_total);
clusterc     = zeros(channels, num_total);
distance     = zeros(1, num_total);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Block-wise Processing
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
i= 1;

for i= 1:num_total
   [i num_total]
   savefilename= sprintf('%s-feature%03d', IM, i);
   data= window_IM + (i-1)*window_shift;
   X= study_data((i-1)*window_shift+1:data, :);
   % Mean subtraction
   X= X-ones(length(X), 1)*mean(X);
   parameters.Xts= X;
   parameters.Dts= channels;
   parameters.Dpp= 0;
   parameters.Xpp= {};
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   if(1)%% Spectral Estimation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      switch(IM)
         case {'PDC', 'DTF'}
            SPECresults= compute_VAR(parameters);
            parameters.plotting.axes_SPEC          = [0 parameters.plotting.plotmaxfreq *(parameters.analyze.Nfreq-1)'/parameters.analyze.Nfreq 1.3*10^(ceil(log10(SPECresults.specmax))-parameters.plotting.dynrange/10) 1.3*10^(ceil(log10(SPECresults.specmax)))];
            parameters.plotting.axes_CORR          = [0 max(parameters.plotting.Time) -1.1*SPECresults.corrmax 1.1*SPECresults.corrmax];
            SPECresults.f0est= parameters.analyze.f0;
         case 'COH'
            SPECresults= compute_SMP(parameters);
            parameters.plotting.axes_SPEC          = [0 parameters.plotting.plotmaxfreq *(parameters.analyze.Nfreq-1)'/parameters.analyze.Nfreq 1.3*10^(ceil(log10(SPECresults.specmax))-parameters.plotting.dynrange/10) 1.3*10^(ceil(log10(SPECresults.specmax)))];
            parameters.plotting.axes_CORR          = [0 max(parameters.plotting.Time) -1.1*SPECresults.corrmax 1.1*SPECresults.corrmax];
            SPECresults.f0est= parameters.analyze.f0;
         case 'MIS'
            SPECresults= compute_MIS(parameters);
            parameters.plotting.axes_SPEC          = [0 parameters.plotting.plotmaxfreq *(parameters.analyze.Nfreq-1)'/parameters.analyze.Nfreq 1.3*10^(ceil(log10(SPECresults.specmax))-parameters.plotting.dynrange/10) 1.3*10^(ceil(log10(SPECresults.specmax)))];
            parameters.plotting.axes_CORR          = [0 max(parameters.plotting.Time) -1.1*SPECresults.corrmax 1.1*SPECresults.corrmax];
            SPECresults.f0est= parameters.analyze.f0;
      end%switch(IM)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   end%if(~parameters.analyze.anyFLATMEAS)%% Spectral Estimation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Measure Computation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %figure_IM= figure;clf
   switch(IM)
      case 'PDC'
         MEASresults= compute_PDC(SPECresults, parameters);
         MEASresults.description.name                = 'Partial Directed Coherence';
         MEASresults.description.shortname           = 'PDC';
         MEASresults.description.PLOTMATRIXtitlediago= 'VAR';
         MEASresults.description.PLOTMATRIXtitleupper= 'PDC';
         MEASresults.description.PLOTMATRIXtitlelower= 'PDC';
         MEASresults.measf0   = MEASresults.meas(:, :, freq2bin(MEASresults.f0est, parameters));
         MEASresults.sinif0   = expand_significance(MEASresults.sini, parameters);
         MEASresults.sinif0   = MEASresults.sinif0(:, :, freq2bin(MEASresults.f0est, parameters));
         MEASresults.sinitest = abs(MEASresults.measf0) > MEASresults.sinif0;
         if(parameters.plotting.switchon)
            plotting_FREQMEAS(MEASresults, parameters, savefilename);
         end
      case 'DTF'
         MEASresults= compute_DTF(SPECresults, parameters);
         MEASresults.description.name                = 'Directed Transfer Function';
         MEASresults.description.shortname           = 'DTF';
         MEASresults.description.PLOTMATRIXtitlediago= 'VAR';
         MEASresults.description.PLOTMATRIXtitleupper= 'DTF';
         MEASresults.description.PLOTMATRIXtitlelower= 'DTF';
         MEASresults.measf0   = MEASresults.meas(:, :, freq2bin(MEASresults.f0est, parameters));
         MEASresults.sinif0   = expand_significance(MEASresults.sini, parameters);
         MEASresults.sinif0   = MEASresults.sinif0(:, :, freq2bin(MEASresults.f0est, parameters));
         MEASresults.sinitest = abs(MEASresults.measf0) > MEASresults.sinif0;
         if(parameters.plotting.switchon)
            plotting_FREQMEAS(MEASresults, parameters, savefilename);
         end
      case 'COH'
         MEASresults= compute_COH(SPECresults, parameters);
         MEASresults.description.name                = 'Coherence/Partial Coherence';
         MEASresults.description.shortname           = 'COH';
         MEASresults.description.PLOTMATRIXtitlediago= 'SMP';
         MEASresults.description.PLOTMATRIXtitleupper= 'COH';
         MEASresults.description.PLOTMATRIXtitlelower= 'pCOH';
         MEASresults.measf0   = MEASresults.meas(:, :, freq2bin(MEASresults.f0est, parameters));
         MEASresults.sinif0   = expand_significance(MEASresults.sini, parameters);
         MEASresults.sinif0   = MEASresults.sinif0(:, :, freq2bin(MEASresults.f0est, parameters));
         MEASresults.sinitest = abs(MEASresults.measf0) > MEASresults.sinif0;
         if(parameters.plotting.switchon)
            plotting_FREQMEAS(MEASresults, parameters, savefilename);
         end
      case 'MIS'
         MEASresults.meas= SPECresults.CORR;
         MEASresults.description.name                = 'Mutual Information';
         MEASresults.description.shortname           = 'MUT';
         MEASresults.description.PLOTMATRIXtitlediago= 'MUT';
         MEASresults.description.PLOTMATRIXtitleupper= 'MUT';
         MEASresults.description.PLOTMATRIXtitlelower= 'MUT';
         MEASresults.description.absoluteplot        = 1;
         MEASresults.description.directed            = 0;
         MEASresults.description.yaxes               = 1;
         MEASresults.d0est                           = parameter_IM;
         MEASresults.measf0                          = MEASresults.meas(:, :, delay2bin(MEASresults.d0est, parameters));
         MEASresults.sinitest                        = ones(D);
         if(parameters.plotting.switchon)
            plotting_TIMEMEAS(MEASresults, parameters, savefilename);
         end

      case 'MPC'
         MEASresults= compute_MPC(parameters);
         MEASresults.description.name                = 'Mean Phase Correlation';
         MEASresults.description.shortname           = 'MPC';
         MEASresults.description.PLOTMATRIXtitlediago= 'nix';
         MEASresults.description.PLOTMATRIXtitleupper= 'MPC';
         MEASresults.description.PLOTMATRIXtitlelower= 'pMPC';
         MEASresults.measf0   = MEASresults.meas;
         MEASresults.sinitest = abs(MEASresults.meas) > MEASresults.sini;

         
         if(parameters.plotting.switchon)
            plotting_FLATMEAS_pre(channels);
            plotting_FLATMEAS(MEASresults, parameters, savefilename, 1);
            plotting_FLATMEAS_post(channels, 1, MEASresults.description.PLOTMATRIXtitleupper, MEASresults.description.PLOTMATRIXtitlelower);
         end
      case 'CPR'
         MEASresults= compute_CPR(parameters);
         MEASresults.description.name                = 'Corr. btw. Prob. of Recurrence';
         MEASresults.description.shortname           = 'CPR';
         MEASresults.description.PLOTMATRIXtitlediago= 'nix';
         MEASresults.description.PLOTMATRIXtitleupper= 'CPR';
         MEASresults.description.PLOTMATRIXtitlelower= 'pCPR';
         MEASresults.measf0   = MEASresults.meas;
         MEASresults.sinitest = abs(MEASresults.meas) > MEASresults.sini;
         if(parameters.plotting.switchon)
            plotting_FLATMEAS_pre(channels);
            plotting_FLATMEAS(MEASresults, parameters, savefilename, 1);
            plotting_FLATMEAS_post(channels, 1, MEASresults.description.PLOTMATRIXtitleupper, MEASresults.description.PLOTMATRIXtitlelower);
         end
         
   end%switch(IM)
   %close(figure_IM)
            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% All relevant Features:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   switch(IM)
      case {'PDC', 'DTF', 'COH', 'MPC', 'CPR'}
         measurematrix(:, :, i)= abs(MEASresults.measf0-diag(diag(MEASresults.measf0)));
         %measurematrix(:, :, i)= abs(MEASresults.measf0-diag(diag(MEASresults.measf0))).*(MEASresults.sinitest-diag(diag(MEASresults.sinitest)));
      case 'MIS'
         measurematrix(:, :, i)= abs(MEASresults.measf0-diag(diag(MEASresults.measf0)));
         %measurematrix(:, :, i)= abs(MEASresults.measf0-diag(diag(MEASresults.measf0))).*(MEASresults.sinitest-diag(diag(MEASresults.sinitest)));
   end
   grmeasures            = graphing_graphmeasures_BCT(measurematrix(:, :, i), measurematrix(:, :, i)>0, MEASresults.description.directed, MEASresults.description.PLOTMATRIXtitlelower, MEASresults.description.PLOTMATRIXtitleupper, MEASresults.description.PLOTMATRIXtitlediago, parameters.analyze.f0, savefilename, 'sini', 0);
   clusterc(:, i)        = grmeasures(1).clusterindex_b'/100;
   distance(i)           = grmeasures(1).charpathlength;
end%for i= 1:num_total






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Feature Plot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(~parameters.analyze.anyFLATMEAS)
   figutetitle= sprintf('%s@%5.2f Hz: Values and Graph Measures', IM, parameter_IM);
else
   figutetitle= sprintf('%s: Values and Graph Measures', IM);
end
%figure('NumberTitle', 'off', 'Name', figutetitle);clf;hold on
%hold off 
%title(figutetitle)
%xlabel('Time (seconds)');
%set(gcf, 'color', [0.95 0.97 0.99]);
ylab= {};

k= 0;% Feature count
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plot Values
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k1= 1;
for k1= 1:channels
   if(MEASresults.description.directed)
      k2min= 1;
   else
      k2min= k1+1;
   end
   k2= k2min;
   for k2= k2min:channels
      if(k1==k2)
      else
         k= k+1;
         if(MEASresults.description.directed)
            ylab{k}= sprintf('chan%d_d_%d', k1, k2);
         else
            ylab{k}= sprintf('chan%d_w_%d', k1, k2);
         end
         for i= 1:num_total
            data= window_IM + (i-1)*window_shift;
            BMVresults.IM(k, i)= measurematrix(k1, k2, i);
            BMVresults.time(1, i)= data/sampling_rate;
         end%for i= 1:num_total
         %plot(BMVresults.time(1, :), BMVresults.IM(k, :)-k, '-g'); hold on;
      end%if(k1==k2)
   end%for k2= k1:channels
end%for k1= 1:channels

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plot Cluster Coefficients
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k1= 1;
for k1= 1:channels
   k= k+1;
   ylab{k}= sprintf('CC%d', k1);
   for i= 1:num_total
      BMVresults.IM(k, i)= clusterc(k1, i);
   end%for i= 1:num_total
   %plot(BMVresults.time(1, :), BMVresults.IM(k, :)-k, '-r'); hold on;
end%for k1= 1:channels
         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plot Mean Distance
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k= k+1;
ylab{k}= sprintf('MD');
for i= 1:num_total
   BMVresults.IM(k, i)= distance(i);
end%for i= 1:num_total
%plot(BMVresults.time(1, :), BMVresults.IM(k, :)-k, '-b'); hold on;

%axis([BMVresults.time(1, 1) 2*BMVresults.time(1, end) -k 0])
%set(gca, 'YTick', -k:-1)
%set(gca, 'YTickLabel', fliplr(ylab))

         if(0)
         events_number =  length(study.dataset.file.data.eeg_events);
         if(events_number~=0)
            EventTableAux= study.dataset.file.data.eeg_events;
            %size(EventTableAux)
            for i = 1:events_number
               vline((EventTableAux(i).started/256), 'b:', EventTableAux(i).type);
            end
         end
         end
         
BMVresults.labels=ylab;

