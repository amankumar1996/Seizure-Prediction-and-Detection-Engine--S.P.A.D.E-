function  FREQMEASresults= compute_COH(SPECresults, parameters)
% Computes the Coherence/Partial Coherence (COH) and their analytical significance levels. 
%
%function FREQMEASresults= compute_COH(SPECresults, parameters)
%
% The output FREQMEASresults is described in the dummy function
% help_FREQMEASresults. 
%

FREQMEASresults.timing= cputime;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

FREQMEASresults.description.yaxes               = 1;
FREQMEASresults.description.minimum             = 0;
FREQMEASresults.description.maximum             = 1;
FREQMEASresults.description.absoluteplot        = 1;
FREQMEASresults.description.directed            = 0;
FREQMEASresults.description.partial_in_lower    = 1;
FREQMEASresults.description.message             = '';

if(analyze.COH && any(any(any(SPECresults.SPEC~=-inf))))
   FREQMEASresults.f0est= SPECresults.f0est;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Partial Coherence into lower, Coherence into upper, SPEC onto main diagonal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   FREQMEASresults.meas= SPECresults.SPEC;
   iomega= 1;
   for iomega= 1:analyze.Nfreq
      FREQMEASresults.meas(:, :, iomega)= compute_partialized(SPECresults.SPEC(:, :, iomega));
   end%for iomega= 1:analyze.Nfreq
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Significance Levels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   switch(SPECresults.shortname)
      case {'SMP', 'BAP', 'MTP'}
% Partial coherence significance niveau
         FREQMEASresults.sini(1)= sqrt(1-analyze.siglev^(2/(SPECresults.nu-2-2*(D-2))));
% Coherence significance niveau
         FREQMEASresults.sini(2)= sqrt(1-analyze.siglev^(2/(SPECresults.nu-2)));

      case {'VAR', 'MIS'}
% Partial coherence significance niveau
         FREQMEASresults.sini(1)= inf;
% Coherence significance niveau
         FREQMEASresults.sini(2)= inf;
   end%switch(SPECresults.shortname)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract the Test and Sigmas at f0est
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   siglevel= expand_significance(FREQMEASresults.sini, parameters);
   FREQMEASresults.measf0= FREQMEASresults.meas(:, :, freq2bin(SPECresults.f0est, parameters));
   FREQMEASresults.sinif0= siglevel(:, :, freq2bin(SPECresults.f0est, parameters));   
   FREQMEASresults.sinitest = abs(FREQMEASresults.measf0) > FREQMEASresults.sinif0;
   FREQMEASresults.sinisigma= abs(FREQMEASresults.measf0)./ FREQMEASresults.sinif0.*FREQMEASresults.sinitest;
else%if(analyze.COH && any(any(any(SPECresults.SPEC~=-inf))))
   FREQMEASresults.meas= -inf;
   FREQMEASresults.f0est= analyze.f0;
end%if(analyze.COH && any(any(any(SPECresults.SPEC~=-inf))))

FREQMEASresults.timing= cputime-FREQMEASresults.timing;
