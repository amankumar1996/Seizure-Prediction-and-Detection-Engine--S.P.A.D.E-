function  FLATMEASresults= compute_CPR(parameters)
% Computaton of the Corr. btw. Prob. of Recurrence. 
%
%function FLATMEASresults= compute_CPR(parameters)
%
% Computes the Correlation btw. Probabilities of Recurrence (CPR) of the
% multivariate signal X= [Xts Xpp].
% Also, the partialized CPR (pCPR) is computed. 

FLATMEASresults.timing= cputime;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

FLATMEASresults.description.yaxes               = 1;
FLATMEASresults.description.minimum             = 0;
FLATMEASresults.description.maximum             = 1;
FLATMEASresults.description.absoluteplot        = 1;
FLATMEASresults.description.directed            = 0;
FLATMEASresults.description.partial_in_lower    = 1;
FLATMEASresults.description.message             = '';

if(analyze.CPR)
   FLATMEASresults.f0est= 0;
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compute Recurrence Plot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   RP= compute_recurrenceplot(Xts, Xpp, parameters);
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Corr. btw. Prob. of Recurrence. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   FLATMEASresults.meas= compute_partialized(compute_corrprobrecurr(RP, parameters));
%   cprmarwan= phasesynchro(Xts(:, 1), Xts(:, 2));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Significance Levels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   FLATMEASresults.sini= ones(D)*1;
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract the Test and Sigmas
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   FLATMEASresults.measf0= FLATMEASresults.meas;
   FLATMEASresults.sinif0= FLATMEASresults.sini;   
   FLATMEASresults.sinitest = abs(FLATMEASresults.measf0) > FLATMEASresults.sinif0;
   FLATMEASresults.sinisigma= abs(FLATMEASresults.measf0)./ FLATMEASresults.sinif0.*FLATMEASresults.sinitest;
else%if(analyze.CPR)
   FLATMEASresults.meas= -inf;
end%if(analyze.CPR)

FLATMEASresults.timing= cputime-FLATMEASresults.timing;
