function  FREQMEASresults= compute_DTF(SPECresults, parameters)
% Computes the Directed Transfer Function (DTF) and its analytical significance levels (some are still missing). 
%
%function FREQMEASresults= compute_DTF(SPECresults, parameters)
%
% The output FREQMEASresults is described in the dummy function FREQMEASresults. 
%
%

FREQMEASresults.timing= cputime;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

FREQMEASresults.description.yaxes               = 1;
FREQMEASresults.description.minimum             = 0;
FREQMEASresults.description.maximum             = 1;
FREQMEASresults.description.absoluteplot        = 1;
FREQMEASresults.description.directed            = 1;
FREQMEASresults.description.partial_in_lower    = 0;
FREQMEASresults.description.message             = '';

if(analyze.DTF && any(any(any(SPECresults.SPEC~=-inf))))
   FREQMEASresults.f0est= SPECresults.f0est;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Directed transfer function (DTF)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   DTFnorma= sum(SPECresults.psi0(:, :, analyze.Nfreq+1:end).*conj(SPECresults.psi0(:, :, analyze.Nfreq+1:end)), 2);
   FREQMEASresults.meas= SPECresults.SPEC;
   d2= 1;
   for d2= 1:D
      FREQMEASresults.meas(: , d2, :)= SPECresults.psi0( :, d2, analyze.Nfreq+1:end)./sqrt(DTFnorma(:, 1, :));
      FREQMEASresults.meas(d2, d2, :)= SPECresults.SPEC(d2, d2, :);
   end%for d2= 1:D

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Significance Levels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   switch(SPECresults.shortname)
      case 'SMP'
         FREQMEASresults.sini(1)= inf;
         FREQMEASresults.sini(2)= inf;

      case 'BAP'
         FREQMEASresults.sini(1)= inf;
         FREQMEASresults.sini(2)= inf;

      case 'VAR'

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Gd1d2 for DTF significance niveau
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      Gd1d2= SPECresults.SPEC;
      iomega= 1;
%       for iomega= 1:analyze.Nfreq
%          omega= pi*(iomega-1)/analyze.Nfreq;
%          BSB= SPECresults.psi0(:, :, analyze.Nfreq+iomega)*SPECresults.Sigma*SPECresults.psi0(:, :, analyze.Nfreq+iomega)';
%          d1= 1;
%          for d1= 1:D
%             d2= 1;
%             for d2= 1:D
%                interm= 0;
%                k= 1;
%                for k= 1:SPECresults.Phat
%                   l= 1;
%                   for l= 1:SPECresults.Phat
%                      Hkl= SPECresults.H((k-1)*D+1:k*D, (l-1)*D+1:l*D);
%                      BHB= SPECresults.psi0(:, :, analyze.Nfreq+iomega).'*Hkl*conj(SPECresults.psi0(:, :, analyze.Nfreq+iomega));
%                      interm= interm + BHB(d2, d2)*(cos(k*omega)*cos(l*omega) + sin(k*omega)*sin(l*omega));
%                   end
%                end
%                Gd1d2(d1, d2, iomega)= real(interm*BSB(d1, d1));
%             end%for d2= 1:D
%          end%for d1= 1:D
%       end%for iomega= 1:analyze.Nfreq

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DTF significance niveau
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      %chivalue= qchisq(1-analyze.siglev, 1);
      DTFresults.sini= SPECresults.SPEC;
%       iomega= 1;
%       for iomega= 1:analyze.Nfreq
%          d1= 1;
%          for d1= 1:D
%             d2= 1;
%             for d2= 1:D
%                %ddd= sqrt(chivalue*Gd1d2(d1, d2, iomega)/N/DTFnorma(d1, 1, iomega));
%                if(isreal(ddd))
%                else
%                   [Gd1d2(d1, d2, iomega) N DTFnorma(d1, 1, iomega)]
%                end
FREQMEASresults.sini= ones(D,D,analyze.Nfreq);
%             end
%          end
%       end

      case 'MTP'
         FREQMEASresults.sini(1)= inf;
         FREQMEASresults.sini(2)= inf;

   end%switch(SPECresults.shortname)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract the Test and Sigmas at f0est
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   siglevel= expand_significance(FREQMEASresults.sini, parameters);
   FREQMEASresults.measf0= FREQMEASresults.meas(:, :, freq2bin(SPECresults.f0est, parameters));
   FREQMEASresults.sinif0= siglevel(:, :, freq2bin(SPECresults.f0est, parameters));   
   FREQMEASresults.sinitest = abs(FREQMEASresults.measf0) > FREQMEASresults.sinif0;
   FREQMEASresults.sinisigma= abs(FREQMEASresults.measf0)./ FREQMEASresults.sinif0.*FREQMEASresults.sinitest;
else%if(analyze.DTF && any(any(any(SPECresults.SPEC~=-inf))))
   FREQMEASresults.meas= -inf;
   FREQMEASresults.f0est= analyze.f0;
end%if(analyze.DTF && any(any(any(SPECresults.SPEC~=-inf))))

FREQMEASresults.timing= cputime-FREQMEASresults.timing;
