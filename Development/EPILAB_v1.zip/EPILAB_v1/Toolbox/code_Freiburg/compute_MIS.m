function  [SPECresults, mis]= compute_MIS(parameters)
% Computation of the Mutual Information Spectrum (MIS) of a multivariate process with time series Xts and point process Xpp components. 
%
%function [SPECresults, mis]= compute_MIS(parameters)
%
% Computes the lagged mutual information of the multivariate signal X. 
% Then, an according spectrum is computed. 

SPECresults.timing= cputime;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

shortname= 'MIS';
available_SPEC= length(sys.SPEC);
ii= 1;
for ii= 1:available_SPEC
   if(strcmp(shortname, sys.SPEC(ii).shortname))
      name= sys.SPEC(ii).name;
   end
end
SPECresults.name                = name;
SPECresults.shortname           = shortname;
SPECresults.PLOTMATRIXtitlelower= shortname;
SPECresults.PLOTMATRIXtitleupper= shortname;
SPECresults.PLOTMATRIXtitlediago= shortname;

if(analyze.MIS)
   SPECresults.Ahat= eye(D);
   SPECresults.Phat= 0;
   SPECresults.Chat= eye(D);
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Convert Point Process Components into Time Series
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   X= [Xts pp2ts(Xpp, parameters)];
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Mutual Information 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   blokked= 0;
   
   mif= zeros(D, D, analyze.Nfreq);
   if(blokked)
      cmdstring= 'mifbl= mi(';
      d1= 1;
      for d1= 1:D-1
         cmdstring= [cmdstring sprintf('Xbl(:, %d), ', d1)];
      end
      cmdstring= [cmdstring sprintf('Xbl(:, %d), 10, %d', D, analyze.Nfreq-1) ', ''silent'');' ];
      bl= 1;
      for bl= 1:analyze.specsub
         Xbl= X((bl-1)*analyze.blocklength+1:bl*analyze.blocklength, :);
         eval(cmdstring)
         mif= mif + mifbl/analyze.specsub;
      end%for bl= 1:analyze.specsub
   else
      cmdstring= 'mif= mi(';
      d1= 1;
      for d1= 1:D-1
         cmdstring= [cmdstring sprintf('X(:, %d), ', d1)];
      end
      cmdstring= [cmdstring sprintf('X(:, %d), 10, %d', D, analyze.Nfreq-1) ', ''silent'');' ];
      eval(cmdstring)
   end

   corr= zeros(D, D, 2*analyze.Nfreq);
   corr(:, :, analyze.Nfreq+1:end)= mif;
   corr(:, :, 1)= mif(:, :, end)';
   for delay= 2:analyze.Nfreq
      corr(:, :, delay)= mif(:, :, analyze.Nfreq+2-delay)';
   end
   spec= fftshift(fft(fftshift(corr, 3), [], 3), 3);
   
   compressed= 0;
   if(compressed)
      spec2= spec(:, :, 1:2:end);
      spec= zeros(size(spec));
      spec(:, :, analyze.Nfreq/2+1:3*analyze.Nfreq/2)= spec2;
   end

   if(0)
   figure(444);clf
   axx= [];
   for d1= 1:D
      for d2= 1:D
         axi= subplot(D, D, (d1-1)*D+d2, 'align');hold on
         axx= [axx(); axi];
         zoom xon
         plot(real(squeeze(corr(d1, d2, :))), 'r')
         plot(imag(squeeze(corr(d1, d2, :))), 'b')
%         axis([1 analyze.Nfreq*2 0 1])
      end
   end
   linkaxes(axx, 'x')
   4
   figure(555);clf
   axx= [];
   for d1= 1:D
      for d2= 1:D
         axi= subplot(D, D, (d1-1)*D+d2, 'align');hold on
         axx= [axx(); axi];
         zoom xon
         plot(real(squeeze(spec(d1, d2, :))), 'r')
         plot(imag(squeeze(spec(d1, d2, :))), 'b')
         axis([1 analyze.Nfreq*2 -10 10])
      end
   end
   linkaxes(axx, 'x')
   4
   end
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   if(analyze.wilson)%% Wilson Factorization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      [psi0, BNULL, iter]= compute_wilsonfactor(spec, analyze.wilson_stopcrit);
      invH= psi0;
      for iomega= 1:2*analyze.Nfreq
         invH(:, :, iomega)= pinv(psi0(:, :, iomega));
      end
      SPECresults.Sigma= real(BNULL*BNULL');
      SPECresults.psi0= psi0;%(:, :, Nfreq+1:end);
      SPECresults.invH= invH;%(:, :, Nfreq+1:end);
      SPECresults.iter= iter;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   end%if(analyze.anyFREQMEAS)%% Wilson Factorization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Store smp for positive Frequencies
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   SPECresults.SPEC= spec(:, :, analyze.Nfreq+1:end);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Store corr for positive Delays
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   SPECresults.CORR= corr(:, :, analyze.Nfreq+1:end);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Amplitude ranges
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   SPECresults.specmax= max(abs(SPECresults.SPEC(:)));
   SPECresults.corrmax= max(abs(SPECresults.CORR(:)));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Degrees of Freedom with Smoothing and Tapering
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   SPECresults.nu= 0;
   SPECresults.message= '';
else
   SPECresults.SPEC= -inf;
   SPECresults.specmax= -inf;
   SPECresults.f0est= analyze.f0;
   SPECresults.message= '';
end%if(~analyze.MIS)

SPECresults.timing= cputime-SPECresults.timing;
