function  FLATMEASresults= compute_MPC(parameters)
% Computaton of the Mean Phase Coherence. 
%
%function FLATMEASresults= compute_MPC(parameters)
%
% Computes the Mean Phase Coherence (MPC) of the multivariate signal X= [Xts Xpp]. 
% Also, the partialized MPC (pMPC) is computed. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

FLATMEASresults.description.yaxes               = 1;
FLATMEASresults.description.minimum             = 0;
FLATMEASresults.description.maximum             = 1;
FLATMEASresults.description.absoluteplot        = 1;
FLATMEASresults.description.directed            = 0;
FLATMEASresults.description.partial_in_lower    = 1;
FLATMEASresults.description.message             = '';

if(analyze.MPC)
   FLATMEASresults.timing= cputime;
   FLATMEASresults.f0est= 0;
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Hilbert Phase of Time Series
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   Ph= compute_hilbertphase(Xts, Xpp, parameters);
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Mean Phase Coherence
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   FLATMEASresults.meas= compute_partialized(compute_meanphasecoherence(Ph, parameters));
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Significance Levels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   FLATMEASresults.sini= ones(D)*1;
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract the Test and Sigmas
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   FLATMEASresults.measf0= FLATMEASresults.meas;
   FLATMEASresults.sinif0= FLATMEASresults.sini;   
   FLATMEASresults.sinitest = abs(FLATMEASresults.measf0) > FLATMEASresults.sinif0;
   FLATMEASresults.sinisigma= abs(FLATMEASresults.measf0)./ FLATMEASresults.sinif0.*FLATMEASresults.sinitest;

   FLATMEASresults.timing= cputime-FLATMEASresults.timing;
else%if(analyze.MPC)
   FLATMEASresults.meas= -inf;
end%if(analyze.MPC)
