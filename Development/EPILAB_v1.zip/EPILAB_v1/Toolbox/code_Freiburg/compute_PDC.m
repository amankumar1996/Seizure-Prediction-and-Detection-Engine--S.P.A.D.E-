
function  FREQMEASresults= compute_PDC(SPECresults, parameters)
% Computes the Partial Directed Coherence (PDC) and its analytical significance levels (some are still missing). 
%
%function FREQMEASresults= compute_PDC(SPECresults, parameters)
%
% The output FREQMEASresults is described in the dummy function FREQMEASresults. 
%
%

FREQMEASresults.timing= cputime;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

FREQMEASresults.description.yaxes               = 1;
FREQMEASresults.description.minimum             = 0;
FREQMEASresults.description.maximum             = 1;
FREQMEASresults.description.absoluteplot        = 1;
FREQMEASresults.description.directed            = 1;
FREQMEASresults.description.partial_in_lower    = 0;
FREQMEASresults.description.message             = '';

if(analyze.PDC && any(any(any(SPECresults.SPEC~=-inf))))
   FREQMEASresults.f0est= SPECresults.f0est;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Partial Directed Coherence (PDC)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   PDCnorma= sum(SPECresults.invH(:, :, analyze.Nfreq+1:end).*conj(SPECresults.invH(:, :, analyze.Nfreq+1:end)), 1);
   FREQMEASresults.meas= SPECresults.SPEC;
   d1= 1;
   for d1= 1:D
      FREQMEASresults.meas(d1,  :, :)= SPECresults.invH(d1, :, analyze.Nfreq+1:end)./sqrt(PDCnorma(1, :, :));
      FREQMEASresults.meas(d1, d1, :)= SPECresults.SPEC(d1, d1, :);
   end%for d1= 1:D
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Significance Levels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   switch(SPECresults.shortname)
      case 'SMP'
         FREQMEASresults.sini(1)= inf;
         FREQMEASresults.sini(2)= inf;

      case 'BAP'
         FREQMEASresults.sini(1)= inf;
         FREQMEASresults.sini(2)= inf;

      case 'VAR'

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Cd1d2 for PDC Significance Niveau
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         Cd1d2= SPECresults.SPEC;
         interm= zeros(1, D, analyze.Nfreq);
         k= 1;
%          for k= 1:SPECresults.Phat
%             ck= cos(2*pi*((1:analyze.Nfreq)-1)/N * k);
%             sk= sin(2*pi*((1:analyze.Nfreq)-1)/N * k);
%             l= 1;
%             for l= 1:SPECresults.Phat
%                cl= cos(2*pi*((1:analyze.Nfreq)-1)/N * l);
%                sl= sin(2*pi*((1:analyze.Nfreq)-1)/N * l);
%                Hkl= SPECresults.H((k-1)*D+1:k*D, (l-1)*D+1:l*D);
%                iii= zeros(1, D, analyze.Nfreq);
%                d2= 1;
%                for d2= 1:D
%                   iii(1, d2, :)= Hkl(d2, d2)*(ck.*cl + sk.*sl);
%                end
%                interm= interm + iii;
%             end
%          end
%          d1= 1;
%          for d1= 1:D
%             d2= 1;
%             for d2= 1:D
%                Cd1d2(d1, d2, :)= interm(1, d2, :)*SPECresults.Sigma(d1, d1);
%             end
%          end%for d1= 1:D
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PDC Significance Niveau
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %       chivalue= qchisq(1-analyze.siglev, 1);
         FREQMEASresults.sini= SPECresults.SPEC;
%         d1= 1;
%          for d1= 1:D
%             FREQMEASresults.sini(d1, :, :)= sqrt(chivalue*Cd1d2(d1, :, :)./PDCnorma(1, :, :)/N);
%           end%for d1= 1:D
%          
      case 'MIS'
         FREQMEASresults.sini(1)= inf;
         FREQMEASresults.sini(2)= inf;

      case 'MTP'
         FREQMEASresults.sini(1)= inf;
         FREQMEASresults.sini(2)= inf;

   end%switch(SPECresults.shortname)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract the Test and Sigmas at f0est
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   siglevel= expand_significance(FREQMEASresults.sini, parameters);
   FREQMEASresults.measf0= FREQMEASresults.meas(:, :, freq2bin(SPECresults.f0est, parameters));
   FREQMEASresults.sinif0= siglevel(:, :, freq2bin(SPECresults.f0est, parameters));   
   FREQMEASresults.sinitest = abs(FREQMEASresults.measf0) > FREQMEASresults.sinif0;
   FREQMEASresults.sinisigma= abs(FREQMEASresults.measf0)./ FREQMEASresults.sinif0.*FREQMEASresults.sinitest;
else%if(analyze.PDC && any(any(any(SPECresults.SPEC~=-inf))))
   FREQMEASresults.meas= -inf;
   FREQMEASresults.f0est= analyze.f0;
end%if(analyze.PDC && any(any(any(SPECresults.SPEC~=-inf))))

FREQMEASresults.timing= cputime-FREQMEASresults.timing;
