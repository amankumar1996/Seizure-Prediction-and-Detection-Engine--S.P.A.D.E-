function  [SPECresults, smp]= compute_SMP(parameters)
% Computation of the Smoothed Periodogram (SMP) of a multivariate process with time series Xts and point process Xpp components. 
%
%function [SPECresults, smp]= compute_SMP(parameters)
%
% Computes the Smoothed Periodogram of the multivariate signal X. 
% Tapering and smoothing is defined in here. 
% Also performs Wilson factorization of the Smoothed Periodogram. 
%

SPECresults.timing= cputime;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

shortname= 'SMP';
available_SPEC= length(sys.SPEC);
ii= 1;
for ii= 1:available_SPEC
   if(strcmp(shortname, sys.SPEC(ii).shortname))
      name= sys.SPEC(ii).name;
   end
end
SPECresults.name                = name;
SPECresults.shortname           = shortname;
SPECresults.PLOTMATRIXtitlelower= shortname;
SPECresults.PLOTMATRIXtitleupper= shortname;
SPECresults.PLOTMATRIXtitlediago= shortname;

if(analyze.SMP)
   SPECresults.Ahat= eye(D);
   SPECresults.Phat= 0;
   SPECresults.Chat= eye(D);
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Taper Design 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   [SPECresults.taperwin, SPECresults.nutaper]= compute_taper((0:N-1)/Fs, analyze.tapertype, analyze.taperparameter, N, Fs);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Smoother Design
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   if(analyze.SMPh0Hz)
      h= floor(analyze.SMPh0Hz/Fs*N);
   else
      if(isempty(analyze.f0))
         h= 8;
      else
         h= min(ceil(N/32), ceil(min(diff([0; analyze.f0(:)]))/2/Fs*N));
      end
   end
   SPECresults.SMPh0Hz= h*Fs/N;
   SPECresults.h= h;
   [SPECresults.smootherwin, SPECresults.nusmoother]= compute_smoother('WIDTH', h);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Smoothed Periodogram of Xts and Xpp (pos and neg Frequencies)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   SMP= zeros(D, D, N);
   Xfft= fftshift(fft(Xts.*(SPECresults.taperwin*ones(1, Dts)), [], 1), 1);
   d= 1;
   for d= 1:Dpp
      [ppftpp, omega]= ppft(Xpp{d}, 2*N, 2*analyze.Nfreq, 2*Fs, analyze.tapertype, analyze.taperparameter);
      ppftpp= ppftpp(N/2+1:3*N/2);
      if(sum(abs(ppftpp).^2))
         ppftpp= ppftpp/sqrt(sum(abs(ppftpp).^2))*N;
      end
      Xfft= [Xfft ppftpp];
   end
   
   d1= 1;
   for d1= 1:D
      d2= 1;
      for d2= 1:D
         WXd1d2= conv(SPECresults.smootherwin, Xfft(:, d1).*conj(Xfft(:, d2))/N);
         WXd1d2= WXd1d2((length(SPECresults.smootherwin)+1)/2:end-(length(SPECresults.smootherwin)-1)/2);
         SMP(d1, d2, :)= WXd1d2;
      end
   end
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   if(analyze.specsub>1)% Spectral Subsampling CHANGE!!!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      smp= zeros(D, D, 2*analyze.Nfreq);
      for d1= 1:D
         for d2= 1:D
            smp(d1, d2, :)= SMP(d1, d2, 1:analyze.specsub:end);
         end
      end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   else%if(analyze.specsub>1)% Spectral Subsampling 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      smp= SMP;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   end%if(analyze.specsub>1)% Spectral Subsampling 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compute Cross Correlation Function of Xts and Xpp 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   corr= real(fftshift(ifft(fftshift(smp, 3), [], 3), 3));

   if(0)
   figure(333);clf
   axx= [];
   for d1= 1:D
      for d2= 1:D
         axi= subplot(D, D, (d1-1)*D+d2, 'align');hold on
         axx= [axx(); axi];
         zoom xon
         plot(real(squeeze(corr(d1, d2, :))), 'r')
         plot(imag(squeeze(corr(d1, d2, :))), 'b')
      end
   end
   
   linkaxes(axx, 'x')
   end
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   if(analyze.wilson)%% Wilson Factorization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      [psi0, BNULL, iter]= compute_wilsonfactor(smp, analyze.wilson_stopcrit);
      invH= psi0;
      for iomega= 1:2*analyze.Nfreq
         invH(:, :, iomega)= pinv(psi0(:, :, iomega));
      end
      SPECresults.Sigma= real(BNULL*BNULL');
      SPECresults.psi0= psi0;%(:, :, Nfreq+1:end);
      SPECresults.invH= invH;%(:, :, Nfreq+1:end);
      SPECresults.iter= iter;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   end%if(analyze.anyFREQMEAS)%% Wilson Factorization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Store smp for positive Frequencies
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   SPECresults.SPEC= smp(:, :, analyze.Nfreq+1:end);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Store corr for positive Delays
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   SPECresults.CORR= corr(:, :, analyze.Nfreq+1:end);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Amplitude ranges
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   SPECresults.specmax= max(abs(SPECresults.SPEC(:)));
   SPECresults.corrmax= max(abs(SPECresults.CORR(:)));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Degrees of Freedom with Smoothing and Tapering
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   SPECresults.nu= SPECresults.nusmoother*SPECresults.nutaper;
   SPECresults.message= sprintf('%4.2f Hz (%d, nu=%5.4f)', 2*SPECresults.SMPh0Hz, SPECresults.h, SPECresults.nu);
else
   SPECresults.SPEC= -inf;
   SPECresults.specmax= -inf;
   SPECresults.f0est= analyze.f0;
   SPECresults.message= '';
end%if(~analyze.SMP)

SPECresults.timing= cputime-SPECresults.timing;
