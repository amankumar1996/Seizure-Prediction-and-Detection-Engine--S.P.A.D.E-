function  SPECresults= compute_VAR(parameters)
% Computation of the VAR Estimate (VAR) of a multivariate process with time series Xts and point process Xpp components. 
%
%function SPECresults= compute_VAR(parameters)
%
% Computes the VAR Estimate to the multivariate signal X. Uses the function
% arfit2.m from the tsa toolbox. The point process is transformed to a time
% series by using pp2ts.m.
%

SPECresults.timing= cputime;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

shortname= 'VAR';
available_SPEC= length(sys.SPEC);
ii= 1;
for ii= 1:available_SPEC
   if(strcmp(shortname, sys.SPEC(ii).shortname))
      name= sys.SPEC(ii).name;
   end
end
SPECresults.name                = name;
SPECresults.shortname           = shortname;
SPECresults.PLOTMATRIXtitlelower= shortname;
SPECresults.PLOTMATRIXtitleupper= shortname;
SPECresults.PLOTMATRIXtitlediago= shortname;

if(analyze.VAR)
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Convert Point Process Components into Time Series
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   X= [Xts pp2ts(Xpp, parameters)];
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% VAR Estimate using the BIC
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   warning off
   [w, Ahat, Chat, sbc, aic]= arfit2(X, analyze.Pmin, analyze.Pmax, 'sbc', 'zero');
   warning on
   Phat= size(Ahat, 2)/size(Ahat, 1);
   SPECresults.Ahat= Ahat;
   SPECresults.Phat= Phat;
   SPECresults.Chat= Chat;
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Spectral Polynomial
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   Apoly= reshape([eye(D) -Ahat ], D, D, Phat+1);
   Aspec= fftshift(fft(Apoly, 2*analyze.Nfreq, 3), 3);
   SPECresults.invH= Aspec;%(:, :, analyze.Nfreq+1:end);
%   Aspec= Aspec(:, :, analyze.Nfreq+1:end);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% VAR Spectral Matrix Estimate
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   varspec= zeros(D, D, 2*analyze.Nfreq);
   iomega= 1;
   for iomega= 1:2*analyze.Nfreq
      vvv= inv(Aspec(:, :, iomega))*Chat*inv(Aspec(:, :, iomega))';
      ddd= diag(diag(real(vvv)));
      vvv= vvv.*(1-eye(D))+ddd;
      varspec(:, :, iomega)= vvv-imag(diag(diag(vvv)));
   end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compute Cross Correlation Function of Xts and Xpp 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   corr= real(fftshift(ifft(fftshift(varspec, 3), [], 3), 3));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Store varspec for positive Frequencies
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   SPECresults.SPEC= varspec(:, :, analyze.Nfreq+1:end);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Store corr for positive Delays
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   SPECresults.CORR= corr(:, :, analyze.Nfreq+1:end);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Innovations Covariance Matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   XX= [];
   p= 0;
   for p= 0:Phat
      XXX= [zeros(p, D); X(1:end-p, :)];
      XX= [XX XXX];      
   end
   SPECresults.EE= ([eye(D) -Ahat]*XX.').';
   SPECresults.Sigma= SPECresults.EE'*SPECresults.EE/N;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% VAR Transfer Function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   SPECresults.psi0= zeros(D, D, 2*analyze.Nfreq);
   iomega= 1;
   for iomega= 1:2*analyze.Nfreq
      SPECresults.psi0(:, :, iomega)= pinv(SPECresults.invH(:, :, iomega));
   end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PD times PD Correlation matrix R
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   R= XX(:, D+1:end).' * XX(:, D+1:end)/N;
   [Vev, Dev]= eig(R);
   minev= min(diag(Dev));
   if(minev<0)
      Dev= Dev+abs(minev)*1.05*eye(D*SPECresults.Phat);
   end
   SPECresults.H= Vev * ( diag(1./diag(Dev)) ) * Vev';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Amplitude ranges
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   SPECresults.specmax= max(abs(SPECresults.SPEC(:)));
   SPECresults.corrmax= max(abs(SPECresults.CORR(:)));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Degrees of Freedom with Smoothing and Tapering
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   SPECresults.nu= SPECresults.Phat;%?????????
   SPECresults.message= sprintf('P%d-%d-%d', analyze.Pmin, SPECresults.Phat, analyze.Pmax);
else
   SPECresults.SPEC= -inf;
   SPECresults.specmax= -inf;
   SPECresults.f0est= analyze.f0;
   SPECresults.message= '';
end%if(~analyze.SMP)

SPECresults.timing= cputime-SPECresults.timing;
