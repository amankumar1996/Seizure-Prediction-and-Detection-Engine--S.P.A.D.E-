function  cpr= compute_corrprobrecurr(RP, parameters)
% Computaton of the Corr. btw. Prob. of Recurrence. 
%
%function cpr= compute_corrprobrecurr(RP, parameters)
%
% Computes the Corr. btw. Prob. of Recurrence of the multivariate
% signal X. This function is a wrapper for phasesynchro.m. 
% Xpp is dummy up to now! 

[D, N, N]= size(RP);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compute Return Probabilities Ptau
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ptau= zeros(N, D);
d= 1;
for d= 1:D
   rp= squeeze(RP(d, :, :));
   sumdiag= [];
   n= 1;
   for n= 1:N
      sumdiag(n)= sum(diag(rp, n-1))/(N+1-n);
   end
   Ptau(:, d)= sumdiag';
end%for d= 1:D

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compute CPR
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cpr= ones(D, D);
d1= 1;
for d1= 1:D
   d2= d1;
   for d2= d1:D
      ccc= cov(Ptau(2:end, d1), Ptau(2:end, d2));
      cpr(d1, d2)= ccc(1, 2)/sqrt(ccc(1, 1)*ccc(2, 2));
      cpr(d2, d1)= cpr(d1, d2);
   end
end
