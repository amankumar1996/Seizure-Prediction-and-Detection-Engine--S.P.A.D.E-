function  Ph= compute_hilbertphase(XXts, XXpp, parameters)
% Computaton of the Hilbert Phase of Time Series and Point Processes. 
%
%function Ph= compute_hilbertphase(XXts, XXpp, parameters)
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

[N, Dts]= size(XXts);
Dpp= length(XXpp);
D= Dts+Dpp;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Hilbert Phase of Time Series
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Xhts= hilbert(XXts);
Phts= atan2(imag(Xhts), real(Xhts));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Phase of Point Processes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Phpp= zeros(N, Dpp);
d= 1;
for d= 1:Dpp
   oldpulse= 0;
   pp= 1;
   PP= [XXpp{d}; N/Fs];
   for pp= 1:length(PP)
      pulse= ceil(PP(pp)*Fs);
      intertime= pulse-oldpulse;
      if(intertime)
         Phpp(oldpulse+1:pulse, d)= 2*pi/intertime;
      else
         Phpp(pulse, d)= Phpp(pulse, d)+2*pi;
      end
      oldpulse= pulse;
   end
end
Phpp= cumsum(Phpp);
Phpp= Phpp(1:N, :);

if(0)
params= parameters;
params.Xts= Phpp;
params.Xpp= XXpp;
params.Yts= Phpp;
params.Ypp= XXpp;
params.Dts= Dpp;
params.Dpp= Dpp;
params.D= 2*Dpp;
params.N= N;
figure(77);clf;hold on;zoom xon
plotting_SIG('', params)
end

Ph= [Phts Phpp];
