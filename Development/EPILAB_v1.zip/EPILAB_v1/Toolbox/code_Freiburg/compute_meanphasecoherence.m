function  mpc= compute_meanphasecoherence(Ph, parameters)
% Computaton of the Mean Phase Coherence from the Hilbert Phase. 
%
%function mpc= compute_meanphasecoherence(Ph, parameters)
%
% Computes the Mean Phase Coherence of the phase
% Ph of the multivariate signal X= [Xts Xpp]. 
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

[N, D]= size(Ph);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Mean Phase Coherence 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mpc= ones(D, D);
d1= 1;
for d1= 1:D
   d2= 1;
   for d2= d1+1:D
      mpc(d1, d2)= sum(exp(1i* (Ph(:, d1)-Ph(:, d2)) ) )/N;
      mpc(d2, d1)= conj(mpc(d1, d2));
   end%for d2= 1:D
end%for d1= 1:D
