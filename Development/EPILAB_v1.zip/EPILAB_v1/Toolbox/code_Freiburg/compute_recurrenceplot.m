function  RP= compute_recurrenceplot(XXts, XXpp, parameters)
% Computaton of the Auto-Recurrence Plots and Joint(Cross)-Recurrence Plots of Time Series and Point Processes. 
%
%function RP= compute_recurrenceplot(XXts, XXpp, parameters)
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

[N, Dts]= size(XXts);
Dpp= length(XXpp);
D= Dts+Dpp;

X= [XXts pp2ts(XXpp, parameters)];

RP= zeros(D, N, N);
d= 1;
for d= 1:D
   rp= crp(X(:, d), 'silent');
   RP(d, :, :)= reshape(rp, 1, N, N);
end
