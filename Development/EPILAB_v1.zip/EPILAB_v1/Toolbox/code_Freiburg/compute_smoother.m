function  [smootherwin, nu]= compute_smoother(kind, par)
% Designs a triangular smoothing window. 
%
%function [smootherwin, nu]= compute_smoother(kind, par)
%
% Design can be performed by given half width or DOF. 
% If kind=='WIDTH', par= M= half width
% IF kind=='DOF'  , par= nu= degrees of freedom
% For the triangular it holds asymptotically: nu= 3*M+1.5. 

switch(kind)
    case 'WIDTH'
        M= par;
    case 'DOF'
        if(par==2)
           M= 0;
        else
           M= ceil((par-1.5)/3);
        end
end
N= 2*M+1;
n= (0:N-1)';
smootherwin= 2/N*(N/2-abs(n-(N-1)/2));
smootherwin= smootherwin/sum(smootherwin);

nu= 2/sum(smootherwin.^2);

if(0)
    figure(1);clf;hold on
    ff= [];
    for M= 0:10
      ff(M+1, 1)= M;
      [smootherwin, ff(M+1, 2)]= compute_smoother('WIDTH', M);
      ff(M+1, 3)= length(smootherwin);
      plot(smootherwin)
    end
    
    figure(2);clf;hold on
    ff= [];
    for nu= 2:100
      ff(nu+1, 1)= nu;
      [smootherwin, ff(nu+1, 2)]= compute_smoother('DOF', nu);
      ff(nu+1, 3)= length(smootherwin);
      plot(smootherwin)
    end
        
end