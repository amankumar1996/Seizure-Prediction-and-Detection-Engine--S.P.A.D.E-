function  bin= delay2bin(d, parameters)
% Converts seconds to bins. 
%
%function bin= delay2bin(d, parameters)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

bin= floor(d*Fs)+1;
