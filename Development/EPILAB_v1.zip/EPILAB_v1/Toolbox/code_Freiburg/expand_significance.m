function  siglevel= expand_significance(signif, parameters)
% Some significance levels are constant. This file expands them over the frequency or delay axis. 
%
%function siglevel= expand_significance(signif, parameters)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

if(length(signif)==2)
siglevel= ones(D, D, analyze.Nfreq);
d1= 1;
for d1= 1:D
   d2= 1;
   for d2= 1:D
      if(d1>d2)
         siglevel(d1, d2, :)= signif(1)*ones(1, 1, analyze.Nfreq);
      end
      if(d1<d2)
         siglevel(d1, d2, :)= signif(2)*ones(1, 1, analyze.Nfreq);
      end
   end
end
else%if(length(signif)==2)
   siglevel= signif;
end%if(length(signif)==2)
