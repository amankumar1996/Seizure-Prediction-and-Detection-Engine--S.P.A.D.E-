function  grmeasures= graphing_graphmeasures_BCT(WIJ, BIJ, directed, PLOTMATRIXtitlelower, PLOTMATRIXtitleupper, PLOTMATRIXtitlediago, f0, savefilename, sinistring, gen_output)
% The actual computation for the graph measures with the BCT toolbox. 
%
%function grmeasures= graphing_graphmeasures_BCT(WIJ, BIJ, directed, PLOTMATRIXtitlelower, PLOTMATRIXtitleupper, PLOTMATRIXtitlediago, f0, savefilename, sinistring, gen_output)
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(directed)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 1) Density of connections over the entire graph   
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   [kden, N, K]= density_dir(BIJ);
   graphmeasureso.density_nodes_vertices= [floor(kden*100), N, K];
   
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 2) Vertex degrees
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   [graphmeasureso.in_degrees, graphmeasureso.out_degrees, graphmeasureso.degrees]= degrees_dir(BIJ);
   
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 3) Vertex strengths (i.e. sum of all connection weights)   
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   [graphmeasureso.in_strengths, graphmeasureso.out_strengths, graphmeasureso.all_strengths]= strengths_dir(BIJ);

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 4) An implementation of the matching index, expressing the overlap or 
%    correlation between the connection patterns of all vertex pairs
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   [Min, Mout, Mall]= matching_ind(BIJ);
   graphmeasureso.in_matching = ceil(Min*100);
   graphmeasureso.out_matching= ceil(Mout*100);
   graphmeasureso.all_matching= ceil(Mall*100);
   
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 5) Joint degree distribution
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   [J, J_od, J_id, J_bl]= jdegree(BIJ);
   graphmeasureso.jdegree_distr= J;
   graphmeasureso.out_in_bl_nrofvertices= [J_od, J_id, J_bl];

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 6) Assortativity, after Newman, 2002. 
%    Essentially a correlation coefficient for the degrees of linked vertices. 
%    Positive assortativity indicates that edges tend to link vertices with
%    same or similar degree. 
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%   graphmeasureso.assortativty= assortativity(BIJ, 1);
      
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 7) Finds all neighbors of a central vertex (regardless whether they are
%    connected via incoming, outgoing, or bidirectional connections), then
%    finds the ratio of actually existing over all possible connections
%    between them. 
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      C= clustering_coef_bd(BIJ);
      graphmeasureso.clusterindex_b= ceil(C*100)';
      C= clustering_coef_wd(WIJ);
      graphmeasureso.clusterindex_w= ceil(C*100)';
   
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 8) Finds the reachability and distance matrices.  Note: Distance matrices
%    have nonzero entries on the main diagonal 
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   [R, D]= reachdist(BIJ+0);
   graphmeasureso.reachabilitymatrix= R;
   graphmeasureso.distancematrix= D;
   D(D==inf)= 0;
   ND= sum(sum(D>0));
   if(ND)
      graphmeasureso.charpathlength= sum(sum(D))/ND;
   else
      graphmeasureso.charpathlength= 0;
   end
   
   
   
   graphing_graphmeasures_output(graphmeasureso, PLOTMATRIXtitleupper, f0, savefilename, sinistring, gen_output);
   grmeasures= graphmeasureso;
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
else%if(directed)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
   for ss= 1:2
      if(ss==1)
         bij= tril(BIJ);
         bij= (bij+bij');
         wij= tril(WIJ);
         wij= (wij+wij')/2;
         measurename= PLOTMATRIXtitlelower;
      else
         bij= triu(BIJ);
         bij= (bij+bij');
         wij= triu(WIJ);
         wij= (wij+wij')/2;
         measurename= PLOTMATRIXtitleupper;
      end
      clear graphmeasureso
      
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 1) Density of connections over the entire graph
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      [kden, N, K]= density_und(bij);
      graphmeasureso.density_nodes_vertices= [floor(kden*100), N, K];
      
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 2) Vertex degrees, assuming undirected (symmetrical) connections   
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      graphmeasureso.degrees_nondir= degrees_und(bij);
   
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 3) Vertex strengths, assuming undirected (symmectrical) connections 
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      graphmeasureso.str_nondir= strengths_und(bij);
   
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 4) An implementation of the matching index, expressing the overlap or 
%    correlation between the connection patterns of all vertex pairs
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      [Min, Mout, Mall]= matching_ind(bij);
      graphmeasureso.in_matching = ceil(Min*100);
      graphmeasureso.out_matching= ceil(Mout*100);
      graphmeasureso.all_matching= ceil(Mall*100);
   
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 5) Joint degree distribution
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      [J, J_od, J_id, J_bl]= jdegree(bij);
      graphmeasureso.jdegree_distr= J;
      graphmeasureso.out_in_bl_nrofvertices= [J_od, J_id, J_bl];
   
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 6) Assortativity, after Newman, 2002. 
%    Essentially a correlation coefficient for the degrees of linked vertices. 
%    Positive assortativity indicates that edges tend to link vertices with
%    same or similar degree. 
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%      graphmeasureso.assortativty= assortativity(bij, 1);

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 7) Finds all neighbors of a central vertex (regardless whether they are
%    connected via incoming, outgoing, or bidirectional connections), then
%    finds the ratio of actually existing over all possible connections
%    between them. 
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      C= clustering_coef_bu(bij);
      graphmeasureso.clusterindex_b= ceil(C*100)';
      C= clustering_coef_wu(wij);
      graphmeasureso.clusterindex_w= ceil(C*100)';

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% 8) Finds the reachability and distance matrices.  Note: Distance matrices
%    have nonzero entries on the main diagonal 
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      [R, D]= reachdist(bij+0);
      graphmeasureso.reachabilitymatrix= R;
      graphmeasureso.distancematrix= D;
      D(D==inf)= 0;
      ND= sum(sum(D>0));
      if(ND)
         graphmeasureso.charpathlength= sum(sum(D))/ND;
      else
         graphmeasureso.charpathlength= 0;
      end
      
      
      
      graphing_graphmeasures_output(graphmeasureso, measurename, f0, savefilename, sinistring, gen_output);
      grmeasures(ss)= graphmeasureso;
   end%for ss= 1:2
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end%if(directed)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
