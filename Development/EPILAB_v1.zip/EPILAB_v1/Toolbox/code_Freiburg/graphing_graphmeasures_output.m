function  graphing_graphmeasures_output(graphmeasureso, measurename, f0, savefilename, sinistring, gen_output)
% Print a txt file with graphmeasureso. 
%
%function graphing_graphmeasures_output(graphmeasureso, measurename, f0, savefilename, sinistring, gen_output)
   
if(gen_output)
   system(sprintf('rm -f %s', sprintf('%s-%s-%s-%07.2f.txt', savefilename, measurename, sinistring, f0)));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract graphmeasureso 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   vars= genvarname(fieldnames(graphmeasureso));
   format compact
   %format bank
   diary(sprintf('%s-%s-%s-%07.2f.txt', savefilename, measurename, sinistring, f0));
   for i= 1:length(vars)
      eval([vars{i} '= graphmeasureso.(vars{i})']);
   end
   diary off
   format loose
end
