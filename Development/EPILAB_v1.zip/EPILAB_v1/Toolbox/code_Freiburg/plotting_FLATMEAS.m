function  plotting_FLATMEAS(FLATresults, parameters, savefilename, FLATmeasurecount)
% Plots the Figures with the Frequeny-Flat Interaction Measures. 
%
%function plotting_FLATMEAS(FLATresults, parameters, savefilename, FLATmeasurecount)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract FLATresults 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(FLATresults));
for i= 1:length(vars)
   eval([vars{i} '= FLATresults.(vars{i});'])
end

d1= 1;
for d1= 1:D
   d2= 2;
   for d2= 1:D
      if(d1~=d2)
         if(d1>d2 && description.partial_in_lower)
            plotting_FLATMEAS_plot;
         end%if(d1>d2 && description.partial_in_lower)
         if(d1<d2)
            plotting_FLATMEAS_plot;
         end%if(d1<d2)
      end%if(d1~=d2)
   end%for d2= 1:D
end%for d1= 1:D
drawnow
