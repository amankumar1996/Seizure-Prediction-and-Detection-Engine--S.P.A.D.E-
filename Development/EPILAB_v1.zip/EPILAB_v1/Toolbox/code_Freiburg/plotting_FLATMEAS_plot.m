subplot(D, D, (d1-1)*D+d2, 'align');
if(description.absoluteplot)
   line([FLATmeasurecount-.2 FLATmeasurecount+.2], abs(meas(d1, d2))*[1 1], 'Color', 'k', 'LineWidth', 2)
else
   line([FLATmeasurecount-.2 FLATmeasurecount+.2], meas(d1, d2)*[1 1]     , 'Color', 'k', 'LineWidth', 2)
end
if(exist('sini', 'var'))
   line([FLATmeasurecount-.2 FLATmeasurecount+.2], sini(d1, d2)*[1 1]     , 'Color', plotting.color_sini, 'LineWidth', 1)
end
if(exist('boot', 'var'))
   line([FLATmeasurecount-.2 FLATmeasurecount+.2], boot(d1, d2)*[1 1]     , 'Color', plotting.color_boot, 'LineWidth', 1)
end

asteriskheight= 1.01;
if(exist('sini', 'var'))
   if(sinitest(d1, d2))
      plot(FLATmeasurecount, asteriskheight, 'LineStyle', '*', 'Color', plotting.color_sini)
   end
end
if(exist('boot', 'var'))
   if(boottest(d1, d2))
      plot(FLATmeasurecount, asteriskheight, 'LineStyle', 'd', 'Color', plotting.color_boot)
   end
end
