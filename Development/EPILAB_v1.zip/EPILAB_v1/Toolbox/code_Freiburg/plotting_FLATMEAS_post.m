function  plotting_FLATMEAS_post(D, FLATmeasurecount, FLATmeasureupper, FLATmeasurelower)
% Postprocessing fot plotting the Frequency-Flat Interaction Measures. 
%function plotting_FLATMEAS_post(D, FLATmeasurecount, FLATmeasureupper, FLATmeasurelower)

d1= 1;
for d1= 1:D
   d2= 1;
   for d2= 1:D
      if(d1==d2)
      else
         subplot(D, D, (d1-1)*D+d2, 'align');
         set(gca, 'XTick', 1:FLATmeasurecount)
         if(d1>d2)
            set(gca, 'XTickLabel', FLATmeasurelower)
         else
            set(gca, 'XTickLabel', FLATmeasureupper)
         end
         grid on
         box on
      end
   end
end
axis([.5 FLATmeasurecount+.5 -.1 1.1])
drawnow
