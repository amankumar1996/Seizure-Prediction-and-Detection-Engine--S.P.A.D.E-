function  plotting_FLATMEAS_pre(D)
% Preprocessing fot plotting the Frequency-Flat Interaction Measures. 
%function plotting_FLATMEAS_pre(D)

axx= [];
d1= 1;
for d1= 1:D
   d2= 1;
   for d2= 1:D
      if(d1==d2)
      else
         axi= subplot(D, D, (d1-1)*D+d2, 'align');
         axx= [axx; axi];
         cla
         hold on
      end
   end
end
zoom xon
linkaxes(axx)
