function  plotting_TIMEMEAS(MEASresults, parameters, savefilename)
%function plotting_TIMEMEAS(MEASresults, parameters, savefilename)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract MEASresults 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(MEASresults));
for i= 1:length(vars)
   eval([vars{i} '= MEASresults.(vars{i});'])
end

axx= [];
d1= 1;
for d1= 1:D
   d2= 1;
   for d2= 1:D
      axi= subplot(D, D, (d1-1)*D+d2, 'align');
      axx= [axx; axi];
      if(d1~=d2)
         cla;hold on
         if(description.absoluteplot)
            plot(plotting.Time, abs(squeeze(meas(d1, d2, :)))    , 'Color', 'k'               , 'LineWidth', 2)
         else
            plot(plotting.Time,    (squeeze(meas(d1, d2, :)))    , 'Color', 'k'               , 'LineWidth', 2)
         end
         if(exist('sini', 'var'))
            sini_expanded= expand_significance(sini, parameters);
            plot(plotting.Time, squeeze(sini_expanded(d1, d2, :)), 'Color', plotting.color_sini, 'LineWidth', 1)
            if(~description.absoluteplot)
               plot(plotting.Time, -squeeze(sini_expanded(d1, d2, :)), 'Color', plotting.color_sini, 'LineWidth', 1)
            end
         end
         if(exist('boot', 'var'))
            boot_expanded= expand_significance(boot, parameters);
            plot(plotting.Time, squeeze(boot_expanded(d1, d2, :)), 'Color', plotting.color_boot, 'LineWidth', 1)
         end
         set(gca, 'XTick', 0:plotting.deltaT:N/Fs/2)
         switch(description.yaxes)
            case 1
               if(description.absoluteplot)
                  axis([0 parameters.plotting.plotmaxdelay -.1 1.1])
               else
                  axis([0 parameters.plotting.plotmaxdelay -1.1 1.1])
               end
               set(gca, 'YTick', -1:.5:1)
               set(gca, 'YTickLabel', {'-1.0', '-0.5', '0.0', '0.5', '1.0'})
               asteriskheight= 1.01;
            case 0
               measrange= description.maximum-description.minimum;
               axis([0 parameters.plotting.plotmaxdelay description.minimum-.1*measrange description.maximum+.1*measrange])
               asteriskheight= description.maximum+.05*measrange;
            otherwise
               axis([0 parameters.plotting.plotmaxdelay yaxes])
               asteriskheight= yaxes(2)-.01;
         end
         if(plotting.plot_minimal_labels)
            if(d1<D || d2>1);set(gca, 'XTickLabel', []);end
            if(d2~=1);set(gca, 'YTickLabel', []);end
            if(d1==D && d2==D)
               text(3*plotting.axes_CORR(2)/4, 10*plotting.axes_CORR(3), 'f')
            end
         end
         if(plotting.plot_grid), grid on;end
         box on
         if(~isempty(d0est) && plotting.plot_d0)
            line([d0est(:)'; d0est(:)'], (ones(size(d0est(:)))*[-2 2*asteriskheight])', 'Color', plotting.color_diag, 'LineStyle', '--')
            for b= 1:length(d0est)
               if(exist('sini', 'var'))
                  if(sinitest(d1, d2, b))
                     plot(d0est(b), asteriskheight, 'LineStyle', '*', 'Color', plotting.color_sini)
                  end
               end
               if(exist('boot', 'var'))
                  if(boottest(d1, d2, b))
                     plot(d0est(b), asteriskheight, 'LineStyle', 'd', 'Color', plotting.color_boot)
                  end
               end
            end
         end
      else%if(d1~=d2)
      if(plotting.plot_diag)
         cla;hold on
         plot(plotting.Time, squeeze(meas(d1, d2, :)), 'Color', 'k', 'LineWidth', 2)
%         set(gca, 'YScale', 'log')
         axis(plotting.axes_CORR)
         set(gca, 'XTick', 0:plotting.deltaT:N/Fs/2)
%         set(gca, 'XTickLabel', plotting.frequency_labels)
         if(plotting.plot_minimal_labels)
            if(d1<D || d2>1);set(gca, 'XTickLabel', []);end
            if(d2~=1);set(gca, 'YTickLabel', []);end
         end
         if(plotting.plot_grid);grid on;end
         box on
         title(sprintf('%s%d%d', description.PLOTMATRIXtitlediago, d1, d2))
      else
         axis off
         text(.5, .5, sprintf('D%d', d1))
      end
      end%if(d1~=d2)
      if(d1>d2)
         title( sprintf('%s%d%d' , description.PLOTMATRIXtitlelower, d1, d2))
         ylabel(sprintf('y%s%d%d', description.PLOTMATRIXtitlelower, d1, d2))
      end
      if(d1<d2)
         title( sprintf('%s%d%d' , description.PLOTMATRIXtitleupper, d1, d2))
         ylabel(sprintf('y%s%d%d', description.PLOTMATRIXtitleupper, d1, d2))
      end
      if(d1==d2)
         title( sprintf('%s%d%d' , description.PLOTMATRIXtitlediago, d1, d2))
         ylabel(sprintf('y%s%d%d', description.PLOTMATRIXtitlediago, d1, d2))
      end
      if(d1==D && d2==1);xlabel('delay');end
   end%for d2= 1:D
end%for d1= 1:D
drawnow
zoom xon
linkaxes(axx, 'x')
plotting_print(parameters, savefilename, sprintf('%s-%s', savefilename, description.shortname));
