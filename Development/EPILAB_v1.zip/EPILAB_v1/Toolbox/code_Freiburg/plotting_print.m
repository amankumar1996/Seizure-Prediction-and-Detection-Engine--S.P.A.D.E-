function  plotting_print(parameters, savefilename, plotfilename)
% Prints the figure as eps, fig, and pdf. 
%
%function plotting_print(parameters, savefilename, plotfilename)

warning off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Print 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if(plotting.plot_eps)
   print('-depsc2', strcat(plotfilename, '.eps'));
end%if(plotting.plot_eps)
if(plotting.plot_fig)
   saveas(gcf, plotfilename, 'fig');
end%if(plotting.plot_fig)
if(plotting.plot_pdf)
   set(gcf, 'PaperType', 'A4');
   set(gcf, 'PaperOrientation', 'landscape');
   set(gcf, 'PaperUnits', 'centimeters'); 
   set(gcf, 'PaperPositionMode', 'manual');
   set(gcf, 'PaperPosition', [0.63 0.63 28.41 19.72 ]);
   plotfilename= sprintf('%s-%szoom', savefilename, shortname);
   print('-depsc2', strcat(plotfilename, '.eps'));
   if(strcmp(computer, 'MACI'))
      system(sprintf('/usr/texbin/epstopdf %s.eps', plotfilename));
   else
      system(sprintf('/usr/bin/epstopdf %s.eps 2>/dev/null', plotfilename));
   end
end%if(plotting.plot_zoom)
warning on
