function  X= pp2ts(PP, parameters)
% Transform a point process to a time series. 
%
%function X= pp2ts(PP, parameters)
%
%% TODO Check if hist.m is faster!


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Extract parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vars= genvarname(fieldnames(parameters));
for i= 1:length(vars)
   eval([vars{i} '= parameters.(vars{i});'])
end

Dpp= size(PP, 2);

X= [];
d= 1;
for d= 1:Dpp
   x= hist(PP{d}*Fs, .5:1:N-.5)';
   x= x-mean(x);
   X= [X x/std(x)];
end
