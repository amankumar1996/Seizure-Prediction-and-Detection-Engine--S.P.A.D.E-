% Dimensionality Reduction Toolbox
% Version 0.7b 16-November-2008