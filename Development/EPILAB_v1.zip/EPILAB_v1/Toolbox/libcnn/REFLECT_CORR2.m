function y = REFLECT_CORR2(a,b)
%REFLECT_CORR2 Two-dimensional cross-correlation reflected across
%	boundry.
%	C = REFLECT_CORR2(A, B) performs the reflected 2-D correlation 
%	of matrix B on matrix A.  
%
%	See also XCORR2, CONV, CONV2, XCORR, DECONV.

% Courtesy of Kenneth R. Crounse, crounse@fred.EECS.Berkeley.EDU.

[ma,na] = size(a);
[mb,nb] = size(b);
if (nb == 1)
        b = [zeros(mb,1),b,zeros(mb,1)];
        nb = 3;
end
if (mb == 1)
	b = [zeros(1,nb);b;zeros(1,nb)];
	mb = 3;
end

mo = fix(mb/2);
no = fix(nb/2);
a1 = [fliplr(a(:,1:no)),a,fliplr(a(:,na-no+1:na))];
a2 = [flipud(a1(1:mo,:)); a1; flipud(a1(ma-mo+1:ma,:))];
b1 = rot90(b,2);
c = conv2(a2,b1);
y = c(2*mo+1:2*mo+ma,2*no+1:2*no+na);
