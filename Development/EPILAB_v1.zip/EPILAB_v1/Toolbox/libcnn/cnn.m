function m_FinalOut = cnn(v_Templates, m_NetInput, s_SideMatrix)

    s_IterTf = 1;
    s_DeltaTf = 0.1;
    s_TemplateSize = 3;
    s_m=0;
    s_n=0;
    s_PopNum = size(v_Templates, 1);
    m_FinalOut = zeros(s_SideMatrix, s_SideMatrix, s_PopNum);    
    
    for s_PopInd = 1:s_PopNum % For each individual of the population
        
        s_IterT = 0;         
        m_TemplateA = reshape(v_Templates(s_PopInd, 1:9), s_TemplateSize, s_TemplateSize);
        m_TemplateB = reshape(v_Templates(s_PopInd, 10:18), s_TemplateSize, s_TemplateSize);
        s_TemplateBias = v_Templates(s_PopInd, 19);
        m_InitState = m_NetInput;
        m_NetState = m_InitState;
        m_NetOutput = zeros(s_SideMatrix, s_SideMatrix, s_IterTf/s_DeltaTf + 1);

        s_Counter = 1;

        display(sprintf('[p_EpilabUnivariateCNN_02] - Solving differential equation It: %d', s_PopInd));
        
        tic
        while(s_IterT < s_IterTf)

            m_NetOutput(:,:,s_Counter) = pwlsig(m_InitState);
            s_IterTNext = min([s_IterTf, s_IterT + s_DeltaTf]);
            m_ConvBInput = conv2(m_NetInput,m_TemplateB, 'same');

            [s_m,s_n] = size(m_InitState);

            m_InitState = m_InitState(:);

            [v_SolT, m_NetStateTemp] = ode23(@cnnderiv, [0, s_IterTf],  m_InitState);
            s_LNetStateTemp = size(m_NetStateTemp,1);
            m_InitState = reshape(m_NetStateTemp(s_LNetStateTemp,:),s_m,s_n);
            m_NetState(:,:,s_Counter) = m_InitState;
            
            % Increment
            s_Counter = s_Counter + 1;
            s_IterT = s_IterTNext;
        end;
                
        m_FinalOut(:,:, s_PopInd) = m_NetOutput(:,:,s_Counter-1);
        toc
    end
    
        function m_DiffState = cnnderiv(s_IterT, m_State)
        m_State = reshape(m_State,s_m,s_n);
        m_ConvAState = conv2(pwlsig(m_State), m_TemplateA, 'same');
        m_DiffState = -m_State + m_ConvAState + m_ConvBInput + s_TemplateBias;
        m_DiffState = m_DiffState(:);
        end   
end
