
function m_DiffState = cnnderiv(s_IterT, m_State)
%CNNDERIV derivative of 2D CNN
% takes and returns current state as
% a column vector.
%       requires global variables A Bu I m n 
 
% global  m_TemplateA m_ConvBInput s_TemplateBias s_m s_n 

m_State = reshape(m_State,s_m,s_n);
m_ConvAState = conv2(pwlsig(m_State), m_TemplateA, 'same');
m_DiffState = -m_State + m_ConvAState + m_ConvBInput + s_TemplateBias;
m_DiffState = m_DiffState(:);

end
