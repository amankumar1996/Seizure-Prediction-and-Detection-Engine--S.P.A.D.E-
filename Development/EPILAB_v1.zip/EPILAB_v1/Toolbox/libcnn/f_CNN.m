A = magic(3);
Btem = magic(3);
Bias = rand(1, 1);
x0 = rand(40, 60);
u = rand(40, 60);
tf = 100;
dtime = 1;

Xt = viewcnn(A,Btem,Bias,x0,u,tf,dtime);
%Xt = cnn(A,Btem,Bias,x0,u,tf);



