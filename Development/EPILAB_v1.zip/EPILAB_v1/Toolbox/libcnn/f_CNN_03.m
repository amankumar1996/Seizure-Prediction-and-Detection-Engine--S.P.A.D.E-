function [m_FinalOut m_FinalState, m_NetStateTemp] = f_CNN_03(v_Templates, m_NetInput,s_NumFeatures,s_NumElectrodes)

    s_TemplateSize = 3;
    s_PopSize = size(v_Templates, 1);
    m_FinalOut = zeros(s_NumFeatures,s_NumElectrodes, s_PopSize);    
    m_FinalState = zeros(s_NumFeatures,s_NumElectrodes, s_PopSize);    
    s_DeltaT = 0.2; 
    v_Time = 0:1/s_DeltaT:10/s_DeltaT;
    
    for s_PopInd = 1:s_PopSize % For each individual of the population
        
        m_TemplateA = reshape(v_Templates(s_PopInd, 1:9), s_TemplateSize, s_TemplateSize);
        m_TemplateB = reshape(v_Templates(s_PopInd, 10:18), s_TemplateSize, s_TemplateSize);
        s_TemplateBias = v_Templates(s_PopInd, 19);
%         s_TemplateBias = v_Templates(s_PopInd, 10);
        m_NetState = m_NetInput;
        m_NetOutput = zeros(s_NumFeatures,s_NumElectrodes);
    
        %display(sprintf('[p_EpilabUnivariateCNN_02] - Solving differential equation It: %d', s_PopInd));        
        %tic            
            m_ConvBInput = conv2(m_NetInput,m_TemplateB, 'same');
            [s_m,s_n] = size(m_NetState);
            m_NetState = m_NetState(:);
            [v_SolT, m_NetStateTemp] = ode23(@cnnderiv, v_Time,  m_NetState);
            s_LNetStateTemp = size(m_NetStateTemp,1);
            m_NetStateTemp = reshape(m_NetStateTemp, s_LNetStateTemp, s_m, s_n);
            m_NetState = m_NetStateTemp(end,:,:);
            m_NetOutput(:,:) = pwlsig(m_NetState);
            m_FinalOut(:,:, s_PopInd) = m_NetOutput(:,:);
            m_FinalState(:,:, s_PopInd) = m_NetState;
        %toc
        
    end
    
%     %Dynamic plots
%     figure;
%     s_FigRows = ceil(s_PopSize/2);
%     s_FigCount = 1;
%     for s_FigRowsInd = 1:s_FigRows 
%         subplot(s_FigRowsInd, 1, s_FigCount), plot()
% %         xlabel('');
% %         ylabel('');
%     end
     
        function m_DiffState = cnnderiv(s_IterT, m_NetState)
        m_NetState = reshape(m_NetState,s_m,s_n);
        m_ConvAState = conv2(pwlsig(m_NetState), m_TemplateA, 'same');
        m_DiffState = -m_NetState + m_ConvAState + m_ConvBInput + s_TemplateBias;
%         m_DiffState = -m_NetState + m_ConvAState + s_TemplateBias;
        m_DiffState = m_DiffState(:);
        end   
    
end
