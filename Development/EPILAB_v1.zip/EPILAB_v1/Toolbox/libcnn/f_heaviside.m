function s_Output = f_heaviside(m_Input)

% m_Output = zeros(size(m_Input));
% m_Temp = 0.5 * (m_Input == 0);
% m_Output = m_Output + (m_Input > 0) + m_Temp;
% m_Class = mean(mean(m_Output, 1), 2);


s_Input = mean(mean(m_Input, 1), 2);
% % s_Output = 0;
% % s_Temp = 0.5 * (s_Input == 0);
% % s_Output = s_Output + (s_Input > 0) + s_Temp;

if s_Input>0
    s_Output = 1;
else
    s_Output = 0;
end
    
