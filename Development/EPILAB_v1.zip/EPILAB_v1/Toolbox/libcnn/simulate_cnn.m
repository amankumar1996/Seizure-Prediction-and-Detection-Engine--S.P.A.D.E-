% ****************************************************************
% ************************ simulate_cnn.m ************************
% ******* (Offline version: p_EpilabUnivariateCNNClass.m) ********
% **************** By: C Alvarado-Rojas June 2010 ****************
% ****************************************************************

% Description: Preictal period prediction with Cellular Neural Networks
% Preictal period = (electrodes x features x 10min)

function [cnn, s_LocalError, v_ResClass, v_LabelClass] = simulate_cnn(io_data, cnn)         
      
% Define variables
m_TestSet = io_data.TestInpPat;
m_TestLabel = io_data.TestOutPat;
s_NumFeatures = cnn.NFeat;
s_NumElectrodes = cnn.NElect;
m_Model = [cnn.WeightA cnn.WeightB cnn.Bias];
%Preallocation
s_LocalError = zeros(1, size(m_TestSet,1));

for s_NumTest = 1:size(m_TestSet,1)
    m_NetInput = reshape(m_TestSet(s_NumTest,:),s_NumFeatures,s_NumElectrodes);
    m_NetLabels = reshape((m_TestLabel(s_NumTest,:)*ones(1,size(m_TestSet,2))),s_NumFeatures,s_NumElectrodes); 
    [m_Output, m_State, m_StateTemp] = f_CNN_03(m_Model, m_NetInput,s_NumFeatures,s_NumElectrodes);
    if s_NumTest == 1
        m_StateTemplPre = m_State;
        m_StateTaoPre = m_StateTemp;
    elseif s_NumTest == size(m_TestSet,1)
        m_StateTemplInter = m_State;
        m_StateTaoInter = m_StateTemp;
    end
    m_Error = abs(m_NetLabels - m_Output)/2;
    s_LocalError(s_NumTest) = mean(mean(m_Error, 1), 2);
    v_ResClass(s_NumTest) = f_heaviside(m_Output(:,:));
    v_LabelClass(s_NumTest) = f_heaviside(m_NetLabels(:,:));
end
% 
% save(str_FileClass, 'm_Model', 's_LocalError', 'v_TickFeatures', 'v_TickElectrodes', ...
%       'm_StateTemplPre', 'm_StateTemplInter', 'm_StateTaoPre', ...
%       'm_StateTaoInter', 'v_ResClass', 'v_LabelClass');

% 
%    for s_NumTrain = 1:size(m_TrainSet,1)
%            m_NetInput = reshape(m_TrainSet(s_NumTrain,:),s_NumFeatures,s_NumElectrodes);
% 
%            m_NetLabels = reshape(m_TrainLabel(s_NumTrain,:),s_NumFeatures,s_NumElectrodes);
%            [m_Output, m_State, m_StateTemp] = f_CNN_03(m_Templates, m_NetInput,s_NumFeatures,s_NumElectrodes);
%            if gen == (MAXGEN - 1)
%                if s_NumTrain == 1
%                    m_StateTemplPre = m_State;
%                    m_StateTaoPre = m_StateTemp;
%                elseif s_NumTrain == size(m_TrainSet,1)
%                    m_StateTemplInter = m_State;
%                    m_StateTaoInter = m_StateTemp;
%                end    
%            end
%            m_NetLabels = repmat(m_NetLabels,[1 1 size(m_Output, 3)]);
%            m_Error = abs(m_NetLabels - m_Output);
%            s_Local = mean(mean(m_Error, 1), 2);
%            ObjVSel(:,s_NumTrain) = s_Local(:);
%            
%            if gen + 1 == MAXGEN
%                 
%            end
%            
% %            s_Classif(s_NumTrain) =                                                       
%        end
  
