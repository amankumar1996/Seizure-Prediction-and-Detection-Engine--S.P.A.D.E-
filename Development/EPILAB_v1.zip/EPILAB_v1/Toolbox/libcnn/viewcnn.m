function Xt = viewcnn(A,Btem,Bias,x0,u,tf,dtime)
% VIEWCNN (A,Btem,Bias,x0,u,tf,displaytime) 
% returning the final state matrix 
%
% A, Btem:  A and B CNN templates
% x0:    "initial" image, normally the same as u
% u:     image to process
% tf:    final time to run to
% dtime: display time.
%

% Courtesy of Kenneth R. Crounse

%index = [0:63]'/63;
%my_map = [0.7*index,1.0-2.0*abs(index-0.5),0.7*(1-index)];

%colormap(my_map)
colormap(gray(64))

t = 0; 
Xt = x0;

while(t<tf)
%image(simage(pwlsig(Xt)))
image((pwlsig(Xt)+1)*31.5+1); axis('image');
drawnow

tnext = min([tf,t+dtime]); 
Xnext = cnn(A,Btem,Bias,Xt,u,dtime);

Xt = Xnext;
t = tnext;

end;

image((pwlsig(Xt)+1)*31.5+1);  axis('image');

