% ****************************************************************
% ****************** train_cnn_predictor *************************
% ********* (Offline version: f_EpilabUnivariateCNNGA)  **********
% **************** By: C Alvarado-Rojas April 2010 ***************
% ****************************************************************

% Description: Preictal period classification training with Cellular Neural
% Networks And Genetic Algoritms
% Preictal period = (electrodes x features x 10min)

function [cnn, Best, v_ResClass, v_LabelClass] = train_cnn_predictor(io_data, cnn)
%[m_Model] = (m_TrainSet, m_TrainLabel,s_NumFeatures, s_NumElectrodes, v_TickFeatures, v_TickElectrodes, str_FileTrain)

% Variables Definition
%cnn.NIND = 30;   % Number of individuals per subpopulations
%cnn.GEN = 100;   % maximum Number of generations
%cnn.SELEC = .7;  % Generation gap, how many new individuals are created
%cnn.EPSI = 1e-4; % Epsilon of termination condition
NVAR = 19;        % Number of variables, matrix A, B and bias Z
PRECI = 10;       % Precision of binary representation

% Train set and target definition 
LenPop = zeros(1, cnn.GEN);
m_TrainSet = io_data.InpPat;
m_TrainLabel = repmat(io_data.OutPat,1,size(m_TrainSet,2));
m_TrainLabel = (m_TrainLabel == 2) - (m_TrainLabel ~= 2); %Fix labels [-1,1]
s_NumFeatures = cnn.NFeat;
s_NumElectrodes = cnn.NElect;
v_ResClass = zeros(1, size(m_TrainSet, 1));
v_LabelClass = zeros(1, size(m_TrainSet, 1));

       
% Build field descriptor
   FieldD = [rep(PRECI,[1, NVAR]); [rep([-30;30],[1.0000001, 4]) [1; 30]...
       rep([-30;30],[1, NVAR - 5])]; rep([1; 0; 1 ;1], [1, NVAR])];

% Initialise population
   Chrom = crtbp(cnn.NIND, NVAR*PRECI);

% Reset counters
   Best = NaN*ones(cnn.GEN,1);	% best in current population
   gen = 0;			% generational counter

%%Evaluate initial population 
   m_Templates = bs2rv(Chrom,FieldD);
   %Cost function
   ObjV = zeros(cnn.NIND, size(m_TrainSet,1));
% Local error
for s_NumTrain = 1:size(m_TrainSet,1)
    m_NetInput = reshape(m_TrainSet(s_NumTrain,:),s_NumFeatures,s_NumElectrodes);
    m_NetLabels = reshape(m_TrainLabel(s_NumTrain,:),s_NumFeatures,s_NumElectrodes); 
    % Run CNN
    [m_Output, m_State, m_StateTemp] = f_CNN_03(m_Templates, m_NetInput,s_NumFeatures,s_NumElectrodes);
    m_NetLabels = repmat(m_NetLabels,[1 1 cnn.NIND]);
    % Compute Output Y with heaviside function
    v_NetLabels = f_heaviside(m_NetLabels);
    v_Output = f_heaviside(m_Output);
    v_Error = abs(v_NetLabels - v_Output); 
    ObjV(:,s_NumTrain) = v_Error(:);    
end

% Global error
ObjV = mean(ObjV, 2);
ObjVTotal = ObjV;
LenPop(gen+1) = length(ObjV);

% Track best individual and display convergence
[Best(gen+1) BestInd(gen+1)] = min(ObjV);
m_Model(gen+1,:) = m_Templates(BestInd(gen+1),:);
    
%    plot(log10(Best),'ro');xlabel('generation'); ylabel('log10(f(x))');
%    text(0.5,0.95,['Best = ', num2str(Best(gen+1))],'Units','normalized');   
%    drawnow;        

% Generational loop
   while gen < cnn.GEN,

    % Assign fitness-value to entire population
       FitnV = ranking(ObjV);
    % Select individuals for breeding (reproduction)
       SelCh = select('sus', Chrom, FitnV, cnn.SELEC);
    % Recombine selected individuals (crossover)
       SelCh = recombin('xovsp',SelCh,cnn.RECOM);
    % Perform mutation on offspring
       SelCh = mut(SelCh, cnn.MUTAT);

    % Evaluate offspring, call objective function
%        ObjVSel = objfun1(bs2rv(SelCh,FieldD));
%        m_Error = (m_NetLabels - cnn(bs2rv(SelCh,FieldD), m_NetInput, s_SideMatrix));
%        ObjVSel = mean(mean(m_Error, 1), 2);
       
       m_Templates = bs2rv(SelCh,FieldD);
       m_Output = zeros(s_NumFeatures,s_NumElectrodes,size(m_Templates, 1));
       
       %%COST FUNCTION
       ObjVSel = zeros(size(m_Output, 3), size(m_TrainSet,1));
       % Local error
       for s_NumTrain = 1:size(m_TrainSet,1)
           m_NetInput = reshape(m_TrainSet(s_NumTrain,:),s_NumFeatures,s_NumElectrodes);

           m_NetLabels = reshape(m_TrainLabel(s_NumTrain,:),s_NumFeatures,s_NumElectrodes);
           [m_Output, m_State, m_StateTemp] = f_CNN_03(m_Templates, m_NetInput,s_NumFeatures,s_NumElectrodes);

           m_NetLabels = repmat(m_NetLabels,[1 1 size(m_Output, 3)]);
           v_NetLabels = f_heaviside(m_NetLabels);
           v_Output = f_heaviside(m_Output);
           v_Error = abs(v_NetLabels - v_Output); 
           ObjVSel(:,s_NumTrain) = v_Error(:);  
           
%            m_Error = abs(m_NetLabels - m_Output)/2;
%            s_Local = mean(mean(m_Error, 1), 2);
%            ObjVSel(:,s_NumTrain) = s_Local(:);

            if s_NumTrain == 1
                m_StateTemplPre = m_State;
                m_StateTaoPre = m_StateTemp;
            elseif s_NumTrain == size(m_TrainSet,1)
                m_StateTemplInter = m_State;
                m_StateTaoInter = m_StateTemp;
            end
            
            [s_minVal, s_minIndex] = min(ObjVSel(:,s_NumTrain));
            v_ResClass(s_NumTrain) = v_Output(s_minIndex);
            v_LabelClass(s_NumTrain) = v_NetLabels(s_minIndex);
       end
       % Global error
       ObjVSel = mean(ObjVSel, 2);
       
%        m_Output = cnn(m_Templates, m_NetInput, s_SideMatrix);
%        m_Output = f_CNN_03(m_Templates, m_NetInput, s_SideMatrix);
%        m_NetLabels = repmat(m_NetLabels,[1 1 size(m_Output, 3)]);
%        m_Error = abs(m_NetLabels - m_Output);
%        ObjVSel = mean(mean(m_Error, 1), 2);
%        ObjVSel = ObjVSel(:);       
           
    % Reinsert offspring into current population
       [Chrom ObjV]=reins(Chrom,SelCh,1,1,ObjV,ObjVSel);
        m_Templates = bs2rv(Chrom,FieldD);
    % Increment generational counter
       gen = gen+1;
       LenPop(gen+1) = length(ObjVSel);
       ObjVTotal = [ObjVTotal; ObjVSel]; 
       
    % Update display and record current best individual
       [Best(gen+1) BestInd(gen+1)] = min(ObjV);
       m_Model(gen+1,:) = m_Templates(BestInd(gen+1),:);
       display(sprintf('Generation: %d, Best: %f', gen, Best(gen+1)));
       
       if gen+1 > 10
           if (abs(diff(Best(gen-9:gen+1)))< cnn.EPSI)
               disp('Finished by Epsilon');
               break;
           end
       end 
       %plot(log10(Best),'ro'); xlabel('generation'); ylabel('log10(f(x))');
       %text(0.5,0.95,['Best = ', num2str(Best(gen+1))],'Units','normalized');
       %drawnow;       
     
   end      
  
   
   cnn.WeightA = m_Model(end,1:9);
   cnn.WeightB = m_Model(end,10:18);
   cnn.Bias = m_Model(end,19);
   
%      save(str_FileTrain, 'Best', 'm_Templates', 'ObjVTotal', 'LenPop', ...
%       'SelCh', 'Chrom', 'v_TickFeatures', 'v_TickElectrodes', ...
%       'm_StateTemplPre', 'm_StateTemplInter', 'm_StateTaoPre',...
%       'm_StateTaoInter', 'v_ResClass', 'v_LabelClass', 'm_Model');

