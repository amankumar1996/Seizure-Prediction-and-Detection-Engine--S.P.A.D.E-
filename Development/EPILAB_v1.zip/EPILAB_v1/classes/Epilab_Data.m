%Defines the class Epilab Data
classdef Epilab_Data < handle
   % The following properties can be set only by class methods
   
   properties
       electrodes;
       sampling_rate; % EEG sampling rate
       n_pnts; % number of points
       eeg_events= [];
       comments; % not mandatory
       time_stamp;
       
       abs_first_samp;
       start_ts;
       stop_ts;
   end
   
   methods
       function obj = Epilab_Data(sampling_rate,n_pnts, eeg_events,electrodes)

           if nargin < 4,
               obj.electrodes =1 ;
%                display(['Parameter channels = ' num2str(obj.channels) '.']);
           end
           if nargin < 3,
               obj.eeg_events = [];
%                display(['Parameter events = ' obj.eeg_events '.']);
           end
           if nargin<1 || nargin>5,
%                display ('incorrect input parameters');
           elseif nargin==4,
%                obj.eeg_original = eeg_original;
%                obj.eeg = eeg_original;
               obj.sampling_rate = sampling_rate;
               obj.n_pnts = n_pnts;
               obj.eeg_events = eeg_events;
               obj.electrodes = electrodes;
           else
%                obj.eeg_original = eeg_original;
%                obj.eeg = eeg_original;
               obj.sampling_rate = sampling_rate;
           end

       end
   end
end