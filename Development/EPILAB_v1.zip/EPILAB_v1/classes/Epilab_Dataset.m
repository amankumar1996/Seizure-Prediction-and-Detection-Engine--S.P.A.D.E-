%Defines the class Epilab Dataset
classdef Epilab_Dataset < handle
   % The following properties can be set only by class methods
   properties
       name;
       id;
       file;
       gap;
      
       results;
       
       rec_time='';
       no_data_time='';
       time_perc_with_data=0;
   end
   
   methods
       %constructor
       function obj = Epilab_Dataset(name,id)
           if nargin ==2
               obj.name = name;
               obj.id = id;
           else
               obj.name = name;
               obj.id = 0001 ;
           end
       end
       
   end
%    methods
% 
%    end
end