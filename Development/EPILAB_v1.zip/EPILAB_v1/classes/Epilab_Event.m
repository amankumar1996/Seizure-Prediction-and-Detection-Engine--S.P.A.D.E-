%Defines the class Epilab Event
classdef Epilab_Event < handle
   % The following properties can be set only by class methods
   
   properties
       type;
       started;
       stopped;
       start_ts;
       stop_ts;
 
       comments; % not mandatory
   end
   
   methods
       function obj = Epilab_Event(type,started,stopped,comments,start_ts,stop_ts)

           if nargin < 4,
               obj.comments ='' ;
               obj.start_ts ='' ;
               obj.stop_ts ='' ;
%                display(['Parameter channels = ' num2str(obj.channels) '.']);
           end
           if nargin < 3,
               obj.stopped = 0;
               obj.comments ='' ;
               obj.start_ts ='' ;
               obj.stop_ts ='' ;
%                display(['Parameter events = ' obj.eeg_events '.']);
           end
           if nargin<2 || nargin>6,
%                display ('incorrect input parameters');
           elseif nargin==4,
               obj.type = type;
               obj.started = started;
               obj.stopped = stopped;
               obj.comments = comments;
               obj.start_ts ='' ;
               obj.stop_ts ='' ;
           elseif nargin==5,
               obj.type = type;
               obj.started = started;
               obj.stopped = stopped;
               obj.comments = comments;
               obj.start_ts =start_ts ;
               obj.stop_ts ='' ;
               
           elseif nargin==6,
               obj.type = type;
               obj.started = started;
               obj.stopped = stopped;
               obj.comments = comments;
               obj.start_ts =start_ts ;
               obj.stop_ts =stop_ts ;
               
           else
               obj.type = type;
               obj.started = started;
           end

       end
   end
end