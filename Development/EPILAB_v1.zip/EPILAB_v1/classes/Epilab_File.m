%Defines the class Epilab File
classdef Epilab_File < handle
   % The following properties can be set only by class methods
   properties
       path;
       filename;
       patient;
       session;
       type; %0-N.D.; 1 - Mat-File 2-TRC
       data = [];
       
   end
   methods
       %constructor
       function obj = Epilab_File(path,filename,patient, session)
               
               if nargin < 4,
                   obj.session = 0;
               end
                if nargin < 3,
                   obj.patient = 'default';                    
               end
                               
               if nargin==4,
                   obj.path = path;
                   obj.filename = filename;
                   obj.patient = patient;
                   obj.session = session;

               elseif nargin==2,
                   obj.path = path;
                   obj.filename = filename;

               elseif nargin<2 || nargin>5,
                   %                    display ('incorrect input
                   %                    parameters');             
               end            

       end
   end

  
end