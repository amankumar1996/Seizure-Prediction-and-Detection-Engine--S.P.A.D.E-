classdef Epilab_Reader < handle
    % Defines the class Epilab Reader
    %
    % Reads a mat file format located in in the variable filePath.
    %
    % Methods:
    %
    % Epilab_Reader(f_path, n_pnts) | (Constructor)
    % Initializes the object, stores the filepath and basic file information
    % necessary to read the file
    %
    % function [trace_segment, end_file_final, n_file_off_set]  =
    % Read_MATfile (obj, samples_request, file_off_set, chan)
    % returns the segment required by samples_request and number of channels described in chan
    % and basic information about the position of the pointer in the file
    %
    % Example:
    %
    % function [trace_segment, end_file_final, n_file_off_set]  =
    % Read_MATfile (obj, 5*512, 5120, [1,2])
    % returns a double array 2*(5*512) representing the values of the MATfile
    % defined in the constructor.
    
    % Epilab is part of the EPILEPSIAE project, Grant agreement no 211713
    %
    % By Bruno Direito and Rui Costa, CISUC.
    % Feb 2009
    %
    % last update July 2009


    % The following properties can be set only by class methods
    properties

        f_path;
        n_pnts;

        n_chans;

        end_file;
        last_segment;
        chan;
        file_off_set;
        block_off_set;
        block_size;

        samples_request;

        mem_map;
        trace;

        number_maps;

        %% filter information
        ny;

        lowCutoff_param1 = [];
        highCutoff_param1 = [];

        notch_filter_param1 = [];
        notch_filter_param2 = [];
    end

    methods
        %% Constructor of the class
        function obj = Epilab_Reader(f_path, n_pnts)

            if nargin == 2,
                obj.f_path = f_path;
                obj.n_pnts = n_pnts;
            else
                display ('incorrect input parameters');
            end

            f_in = fopen (obj.f_path, 'r');

            fseek(f_in, 160, 'bof');
            % dimension of the data array
            dim = fread(f_in,2,'uint32');
            obj.n_chans = dim(1);

            fclose(f_in);

            %% information about the reading pointer position in the file
            obj.end_file = 0;
            obj.last_segment = 1;
            obj.end_file =0;

            obj.number_maps = 0;

            global h;

            %% filter difinitions
            if(h.study.filter.status)
                %Apply filters

                obj.ny = h.study.dataset(1).file.data.sampling_rate/2;
                %disp(['  ny = ' num2str(obj.ny)]);

                for x=1:length(h.study.filter.highpass)%High pass filter
                    disp([' ---> With high pass filter of ' num2str(h.study.filter.highpass(x)) 'Hz']);
                    obj.lowCutoff_param1(end+1) = h.study.filter.highpass(x)/obj.ny;
                end

                for x=1:length(h.study.filter.lowpass)%Low pass filter
                    disp([' ---> With low pass filter of ' num2str(h.study.filter.lowpass(x)) 'Hz']);
                    obj.highCutoff_param1(end+1) = h.study.filter.lowpass(x)/obj.ny;
                end

                if(~isempty(h.study.filter.notchfreq))
                    for x=1:length(h.study.filter.notchfreq(1,:))%Notch filter
                        disp([' ---> With notch filter of ' num2str(h.study.filter.notchfreq(x)) 'Hz (freq) and ' num2str(h.study.filter.notchband(x)) 'Hz (band)']);
                        obj.notch_filter_param1(end+1) = h.study.filter.notchfreq(x)/obj.ny;
                        obj.notch_filter_param2(end+1) = h.study.filter.notchband(x)/obj.ny;
                    end
                end
            end

            warning('off', 'all');
            %To avoid: Warning: Matrix is close to singular or badly scaled. Results may be inaccurate. RCOND = 7.400920e-017.
        end

        function [trace_segment, end_file_final, n_file_off_set]  = Read_MATfile (obj, samples_request, file_off_set, chan)


            end_file_final=0;
            % BLOCK Definition required

            %% Freiburg data

            %  off_set_channel_freiburg = 2; % jump two first columns
            %  obj.chan = chan + off_set_channel_freiburg;

            %% Coimbra data
            obj.chan = chan;

            %%


            if obj.last_segment
                obj.block_size = 1000 * samples_request;
                map_MATfile (samples_request,file_off_set, obj.chan);
            end
            %size (obj.trace (obj.block_off_set:obj.block_off_set+samples_request-1))
            trace_segment =  obj.trace (:,obj.block_off_set:obj.block_off_set+samples_request-1);

            %% Apply filters
            global h;

            if(h.study.filter.status)

                for x=1:length(h.study.filter.highpass)%High pass filter
                    trace_segment=obj.lowcutoff(trace_segment,x);
                end

                for x=1:length(h.study.filter.lowpass)%Low pass filter
                    trace_segment=obj.highcutoff(trace_segment,x);
                end

                if(~isempty(h.study.filter.notchfreq))
                    for x=1:length(h.study.filter.notchfreq(1,:))%Notch filter
                        trace_segment=obj.notch_filter(trace_segment, x);
                    end
                end
            end
            %% File / segment offset

            %obj.block_off_set
            %obj.block_off_set+samples_request-1
            %pause;

            obj.block_off_set = obj.block_off_set+samples_request;

            if obj.block_off_set-1 == obj.block_size, obj.last_segment = 1; end;

            % new offset = previous offset + number of samples * number of channels * 8 bytes per sample
            n_file_off_set = file_off_set + (obj.n_chans * samples_request)*8;

            %n_file_off_set
            %pause;

            % remaining_s =floor(obj.n_pnts-(((n_file_off_set-192)/(obj.n_chans*8)))+samples_request);

            % definition of end_file - last segment of the reader

            if (obj.last_segment && obj.end_file)
                end_file_final = 1;
            end

            %% memmapfile of the MATfile with the EEG/ECG data
            function map_MATfile (samples_request,file_off_set, chan)

                s_off_set = ((file_off_set-192)/(obj.n_chans*8));

                if ((s_off_set + obj.block_size) >= obj.n_pnts)

                    block = floor((obj.n_pnts - s_off_set)/samples_request);
                    obj.block_size = block*samples_request;

                    obj.end_file = 1;
                end

                obj.mem_map = memmapfile (obj.f_path, 'Format', {'double', [obj.n_chans obj.block_size], 's'},...
                    'Offset', file_off_set, 'Repeat', 1);

                aux = obj.mem_map.data;

                obj.trace = aux.s(chan, :);

                obj.last_segment = 0;
                obj.block_off_set = 1;

                %disp ('new map')
                obj.number_maps = obj.number_maps+1;

            end

        end

        %% Filter functions
        function filtered_eeg  = highcutoff (obj, eeg, x)
            % lowpass filter
            % disp('lowpass filter');
            [b,a]=butter(5, obj.highCutoff_param1(x));
            filtered_eeg=filtfilt(b,a,eeg);
        end

        function filtered_eeg  = lowcutoff (obj, eeg, x)
            % highpass filter
            %disp('highpass filter');
            [b,a]=butter(5, obj.lowCutoff_param1(x), 'high');
            filtered_eeg=filtfilt(b,a,eeg);

            %d = fdesign.highpass('n,fc',8,.6);
            %design(d,'butter');
        end

        function filtered_eeg = notch_filter(obj, s, x)
            %Performs a notch filtering at frequency freq (Hz) and appling a cuttoff band
            %of band (Hz)
            [num,den] = iirnotch(obj.notch_filter_param1(x), obj.notch_filter_param2(x));
            filtered_eeg = filter(num,den,s,[],1);
        end

        function delete(obj)
            warning('on', 'all');
        end

    end


end