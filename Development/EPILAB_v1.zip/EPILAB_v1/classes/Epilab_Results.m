    %Defines the class Epilab Results
    classdef Epilab_Results < handle
      % The following properties can be set only by class methods
      properties
          % preprocessing methods
           % This property is automatically filled with the names of the
          % sub-folder inside +preprocessingMethods
          preprocessingMethods;

          % feature extraction
          % This property is automatically filled with the names of the
          % sub-folder inside +featureExtractionMethods
          featureExtractionMethods;

          %classifiers
          % This property is automatically filled with the names of the sub-folder inside +PredictionAlgorithms
          classifiers;
          
          
          %Threshold methods
          threshold;
          
          %chans_slected
          % This property corresponds to the channels selected for
          % processing in Feature Extraction module
          chansSelected;
          mltChanComb={};
          chansEcg={};
          
          
          EEGchansSelectedInd;
          ECGchansSelectedInd;
          featureNames={};
          featureNames_mlt={};
          featureNames_ecg={};
          
          
          
          glbTime;
          
          feat_events=[];
          
          % Name of the file where the results will be saved (if it is the case)
          saveFileName;
          saveFileHandle_uni;
          saveFileHandle_mlt;
          saveFileHandle_ecg;
          saveFileHandle_evt;
          
          %predictionHorizon
          % This property corresponds to the horizon of event prediction (seizures)
          predictionHorizon;
          parameterAcq;
      end

      methods
          %constructor
          function obj = Epilab_Results()
                   obj.classifiers = loadFolders(obj, '+PredictionAlgorithms');
                   obj.('threshold')={};
                   a = loadFolders(obj, '+FeatureExtraction\+Univariate');
                   b = loadFolders(obj, '+FeatureExtraction\+Multivariate');
                   c = loadFolders(obj, '+FeatureExtraction\+ECG');
                   
                   % dynamic structure addition from both multivariate and univariate submodules
                   
                   fieldNamesAux = fieldnames(b);
                   fieldNamesAux = vertcat (fieldNamesAux, fieldnames(c));
                   for i = 1:length (fieldNamesAux)
                        s = ['a = setfield (a, ''',cell2mat(fieldNamesAux(i)),''',[]);'];
                        eval(s);
                   end

                   obj.featureExtractionMethods = a;
                   obj.preprocessingMethods = loadFolders(obj, '+Preprocessing');
                   obj.featureNames = '';
                   
                   
          end

          function var = loadFolders(obj, path, var)
              cpaths = getSubFolders(obj, path);

               s = '';
               % Dynamic Structures addition
               for i=1:length(cpaths)
                   c = cpaths{i};
                   c_name = c;
                   c_name = c_name(2:end); %Remove +

                   s = [s '''' c_name '''' ', {{}}, '];
               end
               s = ['struct (' s(1:end-2) ');'];
               
               var = eval(s);
          end

          function c=getSubFolders(obj, path)
           %Read Classifiers directory

           dirs=dir(path);
           c = {};
           for i=1:length(dirs)
               n = dirs(i).name;
               if n(1) == '+'
                   c{i} = dirs(i).name;
               end
           end
          end

      end

    end
