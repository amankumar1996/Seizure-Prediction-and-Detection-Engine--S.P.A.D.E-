%Defines the class Epilab Study
classdef Epilab_Study < handle
    % The following properties can be set only by class methods
    properties
        name;
        author;
        comments;
        pat_path;
        dataset=[];
        filter=[];
        dataset_selected;
        from_raw;
        workspace_path;

    end
    
    methods
        function obj = Epilab_Study(name,author,comments,pat_path,from_raw,workspace_path)
            
            %Filter
            obj.filter.status = 0;
            obj.filter.lowpass = [];
            obj.filter.highpass = [];
            obj.filter.notchfreq = [];
            obj.filter.notchband = [];
            
            if nargin < 3,
                obj.comments = '' ;
                obj.pat_path='';
                obj.from_raw=1;
                obj.workspace_path='.';
%                 display(['Parameter comments = ' num2str(obj.comments) '.']);
            end
            if nargin < 2,
                obj.author = 'default';
                obj.comments = '' ;
                obj.pat_path='';
                obj.from_raw=1;
                obj.workspace_path='.';
%                 display(['Parameter author = ' obj.author '.']);
            end
            if nargin==0 || nargin>6,
%                 display ('incorrect input parameters');
            elseif nargin==3,
                obj.name = name;
                obj.author = author;
                obj.comments = comments;
             elseif nargin==4,
                obj.name = name;
                obj.author = author;
                obj.comments = comments;
                obj.pat_path=pat_path;
             elseif nargin==5,
                obj.name = name;
                obj.author = author;
                obj.comments = comments;
                obj.pat_path=pat_path;
                obj.from_raw=from_raw;
             elseif nargin==6,
                obj.name = name;
                obj.author = author;
                obj.comments = comments;
                obj.pat_path=pat_path;
                obj.from_raw=from_raw;
                obj.workspace_path=workspace_path;
            else
                obj.name = name;
            end

        end
    end

end