classdef gen_epilab_reader < handle
    %======================================================================
    %Matlab class that defines the general epilab reader object. This means
    %a class that enables data streaming of the different file types that 
    %Epilab can process.
    %The first mandatory procedure is to call the "init_data_access" method. 
    %This method retrieves the first data window from the selected file, 
    %and initializes the data streaming process. Then the method 
    %"get_next_data_segment" can be called, in order to get the next 
    %non-overlaping portion of data.
    %
    %Log:
    %   -10/09/2009: Only Micromed TRC files and special Mat-Files are
    %   considered at the moment
    %
    %EU FP7 Grant 211713 (EPILEPSIAE)
    %
    %César A. D. Teixeira
    %CISUC, FCTUC, University of Coimbra
    %September 2009
    %======================================================================
    properties
        f_name;
        f_type;
        n_points;
        mat_offset;
        curr_offset;
        samp_rate;
        start_ts;
        curr_first_samp;
        chan;
        step;
        offset;
        window;
        epiread_obj;
        next_segment_cmd;
        file_obj;
    end
    methods
        %         function self=gen_epilab_reader(f_name,f_type,n_points,mat_offset,samp_rate,step,window)
        function self = gen_epilab_reader(f_name, f_type, n_points, samp_rate)
            %==============================================================
            %"gen_epilab_reader" class constructor
            %In order to create an instance of "gen_epilab_reader" class,
            %the information needed is:
            %
            %Input:
            %   f_name-->File name
            %   f_type-->File type (1-Special Mat-File, 2-TRC files)
            %   n_points-->Total number of points in the file (Only required for Mat-Files)
            %   samp_rate-->Sampling Rate (Only need for Mat-Files)
            %   step-->Step in seconds
            %   window-->Window size in seconds
            %
            %Output:
            %   self-->"gen_epilab_reader" class object
            %
            %
            %EU FP7 Grant 211713 (EPILEPSIAE)
            %
            %César A. D. Teixeira
            %CISUC, FCTUC, University of Coimbra
            %September 2009
            %==============================================================

            global g_MAT_TYPE g_TRC_TYPE g_BIN_TYPE g_NIC_TYPE

            self.f_name=f_name;
            self.f_type=f_type;

            self.samp_rate = samp_rate;

            switch self.f_type,
                case g_MAT_TYPE, % For Special Matlab file type
                    self.n_points = n_points;%Set the total number of points
                    self.mat_offset = 192;%Set the actual data offset
%                     self.samp_rate=samp_rate;%Set the data sampling rate
%                     self.step=step*self.samp_rate;%Set the step in samples
%                     self.window=window*self.samp_rate;%Set the window in samples

                case g_TRC_TYPE, % For Micromed TRC file format
                    self.file_obj = trc_file(self.f_name);%Create an instance of the "trc_file" class for TRC streaming

                case g_BIN_TYPE,
                    self.file_obj = bin_file(self.f_name);

                case g_NIC_TYPE,
                    self.file_obj = nico_file(self.f_name);

                otherwise,
                    return;
            end
            
            self.start_ts = self.file_obj.a_start_ts;
        end%End of "gen_epilab_reader"
        
        function [segment_trace, last_segment] = init_data_access(self, chan, ...
                w_request, step, offset)
            %==============================================================
            %"init_data_access" method
            %This method initializes the data access process. The only
            %required imput information is the channel to be processed.
            %This method returns a matrix with the first data window and
            %also a flag indicationg that it is or not the last data segment.
            %The next non-overlaping portions of data are obtained by the
            %"get_next_data_segment" method.
            %
            %Inputs:
            %   chans-->Define the considered channel to process
            %Outputs:
            %   segmentTrace-->Matrix containing the related data
            %   lastSegment-->This segment is or not the last one
            %
            %
            %EU FP7 Grant 211713 (EPILEPSIAE)
            %
            %César A. D. Teixeira
            %CISUC, FCTUC, University of Coimbra
            %September 2009
            %==============================================================

            segment_trace = [];
            last_segment = 0;

            if isempty(self.file_obj)
                return;
            end
            
            if ~exist('offset', 'var') || isempty(offset)
                offset = 0;
            end

            self.chan = chan;%Set the channel to process
            self.window = w_request;%Set the segment request
            self.step = step;%Set the step
            self.offset = offset;

            segment_trace = self.file_obj.def_data_access(self.window, ...
                self.step, self.chan, self.offset);

            last_segment = self.file_obj.a_is_last_segment;
            
            self.curr_first_samp = self.file_obj.a_curr_samp_offset;

        end%End "init_data_access" method
        
        function [segment_trace, last_segment] = redefine_data_access(self, ...
                w_request, step, offset)
            %==============================================================
            %"redefine_data_access" method
            % See init_data_access method.
            %
            %EU FP7 Grant 211713 (EPILEPSIAE)
            %
            %César A. D. Teixeira
            %CISUC, FCTUC, University of Coimbra
            %September 2009
            %==============================================================

            [segment_trace, last_segment] = init_data_access(self, self.chan, ...
                w_request, step, offset);

        end%End "init_data_access" method        
        
        function [segment_trace, last_segment] = get_next_data_window(self)
            %==============================================================
            %"get_next_data_window" method
            %This method returns the next window.
            %
            %
            %EU FP7 Grant 211713 (EPILEPSIAE)
            %
            %César A. D. Teixeira
            %CISUC, FCTUC, University of Coimbra
            %September 2009
            %==============================================================

            segment_trace = self.file_obj.get_next_window();
            last_segment = self.file_obj.a_is_last_segment;

        end%End of "get_next_data_window"
    end % methods
        
end%End of class