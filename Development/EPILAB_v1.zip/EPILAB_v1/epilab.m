﻿% function EpiLab.m

%

% EpiLab is a part of the EPILEPSIAE FP7 project (Grant 211713).

% Consists in an extensive set of methods and algorithms for Epileptic

% Seizure Prediction. The graphical interface defined enables the user to

% navigate through modules extracting features, visualizing data and

% classifying the features according to specific events also editable in

% EpiLab.

%

% Project Coordinator: António Dourado, University of Coimbra, Portugal (dourado@dei.uc.pt)
%

% EpiLab has been developed and programmed by several researchers of the Epilepsiae

% consortium.

% From CISUC (University of Coimbra, Portugal): Bruno Direito, César Teixeira, Rui Costa

% From CNRS (Paris, France): Mário Valderrama,Stavrous Nikolopoulos,
% Catalina Alvarado

% From ALUFR (Albert Ludwigs University of Freiburg, Germany):Björn Schelter, Hinnerk Feldwisch

%


% Reference:
%C.A. Teixeira, B. Direito, H. Feldwisch-Drentrup, M. Valderrama, R.P. Costa, C. Alvarado-Rojas, S. Nikolopoulos,
%M. Le Van Quyen, J. Timmer, B. Schelter and A. Dourado. EPILAB: A software package for studies on the prediction of epileptic seizures.
%Journal of Neuroscience Methods, 200:257-271, 2011. http://dx.doi.org/10.1016/j.jneumeth.2011.07.002

% Last update October 2010

% Last update June 2010

% Last update January 2012



function epilab
clc;
close all;
clear classes;


h = [];

%% Add necessary paths to Matlab

h.path=pwd;
addpath(fullfile(pwd,'utils'));
addpath(fullfile(pwd,'classes'));

%% Main variable initialization

study = [];


% % % % MV
global g_MAT_TYPE g_TRC_TYPE g_BIN_TYPE g_NIC_TYPE g_FILE_TYPE_STR
g_MAT_TYPE = 1;
g_TRC_TYPE = 2;
g_BIN_TYPE = 3;
g_NIC_TYPE = 4;
g_FILE_TYPE_STR = {'.MAT';'.TRC';'Binary';'Nicolet'};
% % % %


%% GUI elements and callback definition

h.fig = figure ('NumberTitle','off','position', [200 200 500 300], 'MenuBar', 'none', 'name', 'EpiLab');

defaultBackground = get(0,'defaultUicontrolBackgroundColor');
set(h.fig,'Color',defaultBackground);

%% construct the components of the GUI

h.MainPanel = uipanel('Parent', h.fig, 'Title', '' ,'Units','Normalized','Position', [0.1 0.1 0.8 0.8]);
% panel - Epilab Logo

ImAxis = axes('Parent',h.MainPanel,'units','Normalized',...
    'Position',[0.1 0.085 0.8 0.8]);

imshow('logo_epilab.png')



%% top panel menu
h.FileMenu = uimenu('Parent',h.fig,'HandleVisibility','callback','Label','Study');% File menu
h.ViewMenu = uimenu('Parent',h.fig,'Label','View', 'enable', 'off');% Edit menu
h.ModulesMenu = uimenu('Parent',h.fig,'HandleVisibility','callback','Label','Operations','enable', 'off');% access Modules/Operations menu
h.HelpMenu = uimenu('Parent',h.fig,'HandleVisibility','callback','Label','Help', 'enable', 'off');% help Menu

%% file menu

% new file
h.NewMenuitem = uimenu('Parent',h.FileMenu,'Label','New');% New study menu item
h.NewFromFileMenuitem = uimenu('Parent',h.NewMenuitem,'Label','From Raw Data');% New study menu item
h.NewFromFeatFileMenuitem = uimenu('Parent',h.NewMenuitem,'Label','From Feature Data','enable', 'on');%,'Callback', {@NewStudyFeatFileCallback,h});% New study menu item

% open previous file
h.OpenMenuitem = uimenu('Parent',h.FileMenu,'Label','Open');% Open study menu item
h.SaveMenuitem = uimenu('Parent',h.FileMenu,'Label','Save','Callback', {@SaveStudyMenuitemCallback,h});% Save study menu item

h.AddFeatFileMenuitem = uimenu('Parent',h.FileMenu,'Label','Add Feat. File','Separator','on', 'enable', 'off',...
    'Callback', {@AddFeatFileMenuitemCallback,h});% Add different dataset EpiLab item


h.ExitMenuitem = uimenu('Parent',h.FileMenu,'Label','Exit','Separator','on','Callback', {@ExitMenuitemCallback,h});%Exit EpiLab item

h.ViewDataInfoMenuitem = uimenu ('Parent',h.ViewMenu,'Label','Data Info','Callback', {@ViewDataInfoMenuitemCallback,h}); % select Edit menu
h.ViewResultsInfoMenuitem = uimenu ('Parent',h.ViewMenu,'Label','Results Info','Callback', {@ViewResultsInfoMenuitemCallback,h}); % select Edit menu
h.ViewRawDataMenuitem = uimenu ('Parent',h.ViewMenu,'Label','Raw Data','Callback', {@EEGRawPlotMenuitemCallback,h},'Enable','on'); % select Edit menu
h.ViewFeatureDataMenuitem = uimenu ('Parent',h.ViewMenu,'Label','Feature Data','Callback', {@FeatNavMenuitemCallback,h},'Enable','on'); % select Edit menu

h.SelectFeatureExtractionModules = uimenu ('Parent',h.ModulesMenu,'Label','Feature Extraction', 'Callback',...
    {@SelectFeatureExtractionModulesMenuitemCallback,h}); % select feature extraction modules menu item

h.SelectFeatureReductionSelectionModules = uimenu ('Parent',h.ModulesMenu,'Label','Feature Reduction and Selection', 'Callback', {@SelectFeatureReductionSelectionModulesMenuitemCallback,h}); % select feature reduction and selection modules menu item

h.SelectPredictionAlgorithmsModules = uimenu ('Parent',h.ModulesMenu,'Label','Prediction Algorithms', 'Callback',...
    {@SelectPredictionAlgorithmsModulesMenuitemCallback,h}); % select classifiers modules menu item



set (h.OpenMenuitem, 'Callback',{@OpenStudyMenuitemCallback,h});
set (h.NewFromFileMenuitem, 'Callback', {@NewStudyFileMenuitemCallback,h});
set (h.NewFromFeatFileMenuitem, 'Callback', {@NewStudyFeatFileCallback,h});

%% Callback definition

%% create a new file
    function h = NewStudyFileMenuitemCallback (hObject, eventData, h)
        
        if ~isempty(study)
            selection = questdlg('This operation will override previous study. Proceed?',...
                'Caution',...
                'Yes','No','Yes');
            switch selection,
                case 'Yes',
                    study = newFileStudy();
                    
                    if ~isempty(study)
                        % Enable modules
                        set (h.ViewMenu, 'enable', 'on');
                        set (h.ModulesMenu, 'enable', 'on');
                    end
                    
                case 'No'
                    return
            end
        else
            study = newFileStudy();
            
            if ~isempty(study)
                
                % Enable modules
                set (h.ViewMenu, 'enable', 'on');
                set (h.ModulesMenu, 'enable', 'on');
            end
            
        end
        
        
        
    end


%% create a new file
    function h = NewStudyFeatFileCallback (hObject, eventData, h)
        
        if ~isempty(study)
            selection = questdlg('This operation will override previous study. Proceed?',...
                'Caution',...
                'Yes','No','Yes');
            switch selection,
                case 'Yes',
                    study = newFeatFileStudy();
                    
                    if ~isempty(study)
                        
                        % Enable modules
                        set (h.ViewMenu, 'enable', 'on');
                        set (h.ModulesMenu, 'enable', 'on');
                        
                    end
                    
                case 'No'
                    return
            end
        else
            study = newFeatFileStudy();
            
            if ~isempty(study)
                % Enable modules
                set (h.ViewMenu, 'enable', 'on');
                set (h.ModulesMenu, 'enable', 'on');
                
            end
            
        end
        
        set(h.AddFeatFileMenuitem,'Enable','on');
        
    end



%% open an existing file
    function h = OpenStudyMenuitemCallback (hobject, eventdata, h)
        %openStudy();
        
        
        disp ('open study');
        
        [filename, path] = uigetfile( ...
            {  '*.*',  'All Files (*.*)'},'Select file');
        
        if ~isequal(filename,0)
            loaded  = load ([path filename]);
            
            study = loaded.study;
            % Enable modules
            set (h.ViewMenu, 'enable', 'on');
            set (h.ModulesMenu, 'enable', 'on');
            
        else
            warndlg ('No file selected','Error!!!');
        end
    end

%% add aditional dataset

    function h = AddFeatFileMenuitemCallback (hobject, eventdata, h)
        
        study = addFeatFile(study);
        
        
    end



%% save study

    function h = SaveStudyMenuitemCallback (hobject, eventdata, h)
        %saveStudy();
        disp ('save study');
        
        [file, path] = uiputfile (fullfile(study.workspace_path,'studies',[study.name '.mat']),'Save file');
        if file~=0
            eval (['save '  [path file] ' study']);
        end
    end

%% exit EpiLab

    function h = ExitMenuitemCallback (hobject, eventdata, h)
        
        disp ('exit EpiLab');
        selection = questdlg('Do you want to close the GUI?',...
            'Close Request',...
            'Yes','No','Yes');
        switch selection,
            case 'Yes',
                delete(h.fig)
            case 'No'
                return
        end
    end






%% open modules


    function h = EEGRawPlotMenuitemCallback(hObject, eventData, h)
        %modulesRawEEGPlotMenu(study);
        rp=RawEEGPlot(study);
    end


    function h = FeatNavMenuitemCallback(hObject, eventData, h)
        %modulesRawEEGPlotMenu(study);
        rp=MultiFeatPlot(study);
    end


    function h = ViewDataInfoMenuitemCallback (hObject, eventdata, h)
        ViewDataInfo(study);
    end

    function h = ViewResultsInfoMenuitemCallback (hObject, eventdata, h)
        ViewResultsInfo(study);
    end


    function h = SelectFeatureExtractionModulesMenuitemCallback (hObject, eventdata, h)
        modulesFeatureExtractionMenu(study);
    end

    function h = SelectFeatureReductionSelectionModulesMenuitemCallback (hObject, eventdata, h)
        modulesFeatureReductionSelectionMenu(study);
    end

    function h = SelectPredictionAlgorithmsModulesMenuitemCallback (hObject, eventdata, h)
        modulesPredictionAlgorithmsMenu(study);
    end



end

