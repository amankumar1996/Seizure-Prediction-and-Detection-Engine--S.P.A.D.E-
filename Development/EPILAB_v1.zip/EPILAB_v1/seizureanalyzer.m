function seizureanalyzer(study)
%
% Function: seizureanalyzer.m
%
% Description:
% Run the seizureanalyzer.
%
% Inputs:
% study: Epilab data structure

% Epilab is part of the EPILEPSIAE project, Grant agreement no 211713
%
% By Hinnerk Feldwisch, FDM.
% Dec 2009
% 

%% global variables
global v;

%% GUI elements 
v.fig = figure ('NumberTitle','off','position', [50 50 750 600], 'MenuBar', 'none',...
    'name', 'EpiLab : Seizure Analyzer Interface...');
defaultBackground = get(0,'defaultUicontrolBackgroundColor');
set(v.fig,'Color',defaultBackground);

v.StartPanel = uipanel('Parent', v.fig, 'Title', 'Start...' ,'Units','Normalized',...
    'Position', [0.01 0.15 0.97 0.1]);


%% Features available in the various dataset
% v.WriteConfigButton = uicontrol('Parent', v.StartPanel,'style','pushbutton', 'HandleVisibility','callback','Units',...
%     'Normalized', 'Position',[0.74 0.05 0.125 0.9],...
%     'String','Write config','Callback', {@WriteConfigButtonCallback});
v.RunButton = uicontrol('Parent', v.StartPanel,'style','pushbutton', 'HandleVisibility','callback','Units',...
    'Normalized', 'Position',[0.74 0.05 0.1 0.9],...
    'String','Run','Callback', {@RunButtonCallback}); 

v.ProjectFolderText = uicontrol('Parent', v.StartPanel,'style','text', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.05 0.05 0.1 0.7],'String','Folder');
v.ProjectFolderEdit = uicontrol('Parent', v.StartPanel,'style','edit', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.16 0.05 0.25 0.7],'String','seizureanalyzer');

v.PlotPanel = uipanel('Parent', v.fig, 'Title', 'Analyze results...' ,'Units','Normalized',...
    'Position', [0.01 0.05 0.97 0.1]);
v.PlotITText = uicontrol('Parent', v.PlotPanel,'style','text', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.01 0.1 0.05 0.5],'String','IT');
v.PlotITEdit = uicontrol('Parent', v.PlotPanel,'style','edit', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.07 0.1 0.08 0.5],'String','optimize');
v.PlotSOPText = uicontrol('Parent', v.PlotPanel,'style','text', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.16 0.1 0.05 0.5],'String','SOP');
v.PlotSOPEdit = uicontrol('Parent', v.PlotPanel,'style','edit', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.22 0.1 0.08 0.5],'String','30m');
v.PlotFPRmaxText = uicontrol('Parent', v.PlotPanel,'style','text', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.31 0.1 0.07 0.5],'String','FPRmax');
v.PlotFPRmaxEdit = uicontrol('Parent', v.PlotPanel,'style','edit', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.39 0.1 0.08 0.5],'String','0.15');

v.PlotButton = uicontrol('Parent', v.PlotPanel,'style','pushbutton', 'HandleVisibility','callback','Units',...
    'Normalized', 'Position',[0.5 0.1 0.125 0.9],...
    'String','Plot alarms','Callback', {@PlotButtonCallback}); 

v.EvalButton = uicontrol('Parent', v.PlotPanel,'style','pushbutton', 'HandleVisibility','callback','Units',...
    'Normalized', 'Position',[0.65 0.1 0.125 0.9],...
    'String','Evaluation','Callback', {@EvalButtonCallback}); 

v.FeaturePanel = uipanel('Parent', v.fig, 'Title', 'Features' ,'Units','Normalized',...
    'Position', [0.01 0.25 0.45 0.7]);

% dataset_available={};
for i =1:length(study.dataset)
    dataset_available(i) = cellstr(study.dataset(i).name);
end

v.DatasetText = uicontrol('Parent', v.FeaturePanel,'style','text', 'HandleVisibility','callback',...
    'Units','Normalized','Position',[0.01 0.925 0.5 0.05],'String','Select Dataset:');

v.SelectDatasetListBox =uicontrol('Parent',v.FeaturePanel,'style', 'listbox','String',dataset_available,'Units','Normalized',...
'Position',[0.05 0.55 0.45 0.35], 'Callback', {@SelectDatasetListBox});

j=1;
dataTable={};

k = get (v.SelectDatasetListBox, 'value');
epilabFeatures = fieldnames(study.dataset(k).results.featureExtractionMethods);

for i=1:length(epilabFeatures)
    if ~(eval (char(strcat('isempty(study.dataset(k).results.featureExtractionMethods.',epilabFeatures(i),')'))))
%         aux=[char(epilabFeatures(i)) '  - ' char(study.dataset(k).name)]
        dataTable (j) = epilabFeatures(i);
        j=j+1;
    end
end

v.SelectFeaturesText = uicontrol('Parent', v.FeaturePanel,'style','text', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.5 0.925 0.5 0.05],'String','Select features:');

v.SelectFeaturesListBox =uicontrol('Parent',v.FeaturePanel,'style', 'listbox','String',(dataTable),'Units','Normalized',...
'Position',[0.5 0.55 0.45 0.35], 'Callback', {@SelectFeaturesListBox},'min',1,'max',1000);

v.FeaturesPlotText = uicontrol('Parent', v.FeaturePanel,'style','text', 'HandleVisibility','callback',...
    'Units','Normalized','Position',[0.05 0.48 0.9 0.05],'String','Features to analyze:');

v.PlotListBox =uicontrol('Parent',v.FeaturePanel,'style', 'listbox','String',[],'Units','Normalized',...
'Position',[0.05 0.12 0.9 0.35],'min',1,'max',1000);

%%% project settings

v.ProjectPanel = uipanel('Parent', v.fig, 'Title', 'Project settings' ,'Units','Normalized',...
    'Position', [0.52 0.25 0.45 0.7]);

hpos=0.955;
v.ProjectTypeText = uicontrol('Parent', v.ProjectPanel,'style','text', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.05 hpos 0.4 0.05],'String','Project type');
v.ProjectTypeEdit = uicontrol('Parent', v.ProjectPanel,'style','popupmenu', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.55 hpos 0.4 0.05],'String',{'OnlineOptimizing','CircadianPredictionOptimizing','CombinedOptimizingAnd','CombinedOptimizingOr'});
hpos=hpos-0.07;

v.FPRmaxsText = uicontrol('Parent', v.ProjectPanel,'style','text', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.05 hpos 0.4 0.05],'String','FPRmaxs');
v.FPRmaxsEdit = uicontrol('Parent', v.ProjectPanel,'style','edit', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.55 hpos 0.4 0.05],'String','0.05:0.05:0.3');
hpos=hpos-0.07;

v.SOPsText = uicontrol('Parent', v.ProjectPanel,'style','text', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.05 hpos 0.4 0.05],'String','SOPs');
v.SOPsEdit = uicontrol('Parent', v.ProjectPanel,'style','edit', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.55 hpos 0.4 0.05],'String','10m:10m:60m');
hpos=hpos-0.07;

v.ITsText = uicontrol('Parent', v.ProjectPanel,'style','text', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.05 hpos 0.4 0.05],'String','ITs');
v.ITsEdit = uicontrol('Parent', v.ProjectPanel,'style','edit', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.55 hpos 0.4 0.05],'String','10m:10m:60m');
hpos=hpos-0.07;

v.ThresholdsText = uicontrol('Parent', v.ProjectPanel,'style','text', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.05 hpos 0.4 0.05],'String','Thresholds');
v.ThresholdsEdit = uicontrol('Parent', v.ProjectPanel,'style','edit', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.55 hpos 0.4 0.05],'String','0:0.001:1');
hpos=hpos-0.07;

v.MaximumBlockDistanceText = uicontrol('Parent', v.ProjectPanel,'style','text', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.05 hpos 0.4 0.05],'String','Maximum Block Dist.');
v.MaximumBlockDistanceEdit = uicontrol('Parent', v.ProjectPanel,'style','edit', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.55 hpos 0.4 0.05],'String','10s');
hpos=hpos-0.07;

v.TimeAfterSeizureText = uicontrol('Parent', v.ProjectPanel,'style','text', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.05 hpos 0.4 0.05],'String','Time after seizure');
v.TimeAfterSeizureEdit = uicontrol('Parent', v.ProjectPanel,'style','edit', 'HandleVisibility','callback','Units',...
    'Normalized','Position',[0.55 hpos 0.4 0.05],'String','0.5h');
hpos=hpos-0.07;


% v.Normalization = uicontrol('Parent',v.FeaturePanel,'Style','checkbox','String','normalize variables',...
% 'Value',0,'Units','Normalized','Position',[0.1 0.1 0.4 0.05],'Callback', {@NormalizationCallback});

    function  SelectDatasetListBox(hobject, eventdata)
        study.dataset_selected = get (v.SelectDatasetListBox, 'value');
%         dataset_list = get (v.SelectDatasetListBox, 'string');
%         dateset_selected = dataset_list(index_selected);
        
        j=1;
        dataTable={};

        k = study.dataset_selected;
        epilabFeatures = fieldnames(study.dataset(k).results.featureExtractionMethods);

        for i=1:length(epilabFeatures)
            if ~(eval (char(strcat('isempty(study.dataset(k).results.featureExtractionMethods.',epilabFeatures(i),')'))))
                dataTable (j) = epilabFeatures(i);
                j=j+1;
            end
        end
        set (v.SelectFeaturesListBox, 'String', dataTable);
    end

    function SelectFeaturesListBox(hobject, eventdata)
        index_selected = get (v.SelectFeaturesListBox, 'value');
        feature_list = get (v.SelectFeaturesListBox, 'string');
        item_selected = feature_list(index_selected);
        availableFeatures = '';

        for m = 1:length(item_selected)
            availableFeatures_name = eval(char(strcat(' study.dataset(', num2str(study.dataset_selected), ').results.featureExtractionMethods.',item_selected(m), '.c_')));
            aux = fieldnames(availableFeatures_name);
            availableFeatures = [availableFeatures; aux];  
        end
        
        set (v.PlotListBox, 'String', availableFeatures);
    end

    function NormalizationCallback (hobject, eventdata)
        index_selected_n = get (hobject, 'value');
        if index_selected_n==1
            set (v.PlotListBox, 'max',2);
            
            set (v.SelectFeaturesListBox, 'max',2);
        else
            set (v.PlotListBox, 'value',1);
            set (v.PlotListBox, 'max',1);
            
            set (v.SelectFeaturesListBox, 'value',1);
            set (v.SelectFeaturesListBox, 'max',1);
        end
    end

    function WriteConfigButtonCallback(hobject, eventdata)
        
        %%% WRITE PROJECT CONFIG
        projectFolder=get(v.ProjectFolderEdit,'string');
        configFolder=[projectFolder '/config'];
        featureFolder=[projectFolder '/features'];
        
        condMkdir(projectFolder);
        condMkdir(configFolder);
        condMkdir(featureFolder);
        
        types=get(v.ProjectTypeEdit,'string');
        
        writeProjectConfig([configFolder '/project.xml'],...
          types{get(v.ProjectTypeEdit,'value')},'results/',...
          '.','features',get(v.FPRmaxsEdit,'string'),...
          get(v.SOPsEdit,'string'),get(v.ITsEdit,'string'),get(v.ThresholdsEdit,'string'),...
          get(v.MaximumBlockDistanceEdit,'string'),'1s',...
          get(v.TimeAfterSeizureEdit,'string'));

        %%% WRITE FEATURE CONFIG
        index_selected = get (v.SelectFeaturesListBox, 'value');
        feature_list = get (v.SelectFeaturesListBox, 'string');
        
        index_selected_f = get (v.PlotListBox, 'value');
        feature_list_f = get (v.PlotListBox, 'string');    
      
        if (length(feature_list)==0)||~(length(feature_list_f)==0)     
            item_selected = feature_list(index_selected);
            item_selected_f = feature_list_f(index_selected_f);
            
            dim = length(item_selected_f);
            selectedFeatures={};
            
            delete(fullfile(featureFolder,'*'));
            
            for m = 1 : dim(1)
                found = 0;
                
                % Find feature in study
                for (j = 1:length(index_selected))
                    f=eval(char(strcat(' fieldnames(study.dataset(k).results.featureExtractionMethods.', item_selected(j), '.c_);')));
                    for i = 1:length(f)
                        if (strcmpi (item_selected_f(m,:), f(i)))
                            found = 1;
                            item_selected_aux = feature_list(index_selected(j));
                            break;
                        end
                    end
                    if (found ==1),
                        break;
                    end
                end
                
                eval(char(strcat('aux_y = study.dataset(',num2str(study.dataset_selected),').results.featureExtractionMethods.',item_selected_aux,...
                    '.c_.',item_selected_f(m,:),';')));
                
                eval(char(strcat('aux_time = study.dataset(',num2str(study.dataset_selected),').results.glbTime;')));
                
%                 if isempty(aux_time)
%                     eval(char(strcat('aux_time = study.dataset(',num2str(study.dataset_selected),').results.glbTime;')));
%                 end
                
                if ~isempty(aux_time)
                    aux_time = aux_time(:);
                end
                
                if ~isempty(aux_y)
                    aux_y = aux_y(:);
                end
                
                if length(aux_y) ~= length(aux_time)
                    aux_time = 1:length(aux_y);
                end
                
                time32=int32(aux_time);
                
                a_2 = get(v.SelectDatasetListBox,'String');
                v_2 = get(v.SelectDatasetListBox,'Value');
                
                selectedFeatures{length(selectedFeatures)+1}=item_selected_f(m,:);
                
                
                n=0; 
                lastSplit=1;
                fFeature=fopen([featureFolder '/' sprintf('%05u',n) '_' item_selected_f{m,:} '.txt' ],'w');
                for i=1:length(aux_y)
                    
                    if(i>=lastSplit+2 && (time32(i)-time32(i-1)~=time32(i-1)-time32(i-2)))
                        fclose(fFeature);
                        n=n+1;
                        fFeature=fopen([featureFolder '/' sprintf('%05u',n) '_' item_selected_f{m,:} '.txt' ],'w');
                        lastSplit=i;
                    end
                    fprintf(fFeature,'%u\t%f\n',time32(i),aux_y(i));
                end
                fclose(fFeature);

            end
            
            writeFeatureConfig([configFolder '/features.xml'],selectedFeatures);
            
          
            %%% WRITE PATIENT CONFIG
            
            % FIND SEIZURES
            seizures=[];
            %for f=1:length(study.dataset(study.dataset_selected).file)
                events=study.dataset(study.dataset_selected).results.feat_events;
                events_number=length(events);
                for i=1:events_number
                    if(strcmpi(events(i).type,'seizure'))
                        onset=events(i).started;%/study.dataset(study.dataset_selected).file(f).data.sampling_rate;
                        offset=events(i).stopped;%/study.dataset(study.dataset_selected).file(f).data.sampling_rate+60;
                        seizures=[seizures; onset offset];
                    end
                end
            %end
            
            writePatientConfig(fullfile(configFolder,'patients.xml'),1,{seizures},0,aux_time(end));
            
        else
             warndlg ('No feature selected','Error!!!');
        end
    end

    function RunButtonCallback(hobject, eventdata)
        
        WriteConfigButtonCallback(hobject, eventdata);
        
        curFolder = pwd
        
        projectFolder=get(v.ProjectFolderEdit,'string');
        cd(projectFolder)
        if ispc
            system('SeizureAnalyzer.exe config')
        elseif isunix
            system('./seizureanalyzer_linux config')
        else
            disp('Cannot Run Seizure Analyser in this OS')
        end
        
        cd(curFolder)
        
    end
        

    function EvalButtonCallback(hobject, eventdata)
        
        [SPH, SOP, FPRmax, usedSeizures, prePostIctalTime, feature, threshold, corrects, ...
            incorrects, FPR, sensitivity, correctsTimes, incorrectsTimes, correctDiffs, incorrectDiffs] = ...
            textread(fullfile('seizureanalyzer','results','pat001','epilab','bestThresholdsTimes.txt'), '%f %f %f %f %f %s %f %f %f %s %f %s %s %s %s', -1, 'bufsize', 8*4096);
        
        if(~strcmp(get(v.PlotITEdit,'String'),'optimize'))
            ITs=get(v.PlotITEdit,'String');
            ITs=strrep(ITs,'h','*3600');
            ITs=strrep(ITs,'m','*60');
            ITs=strrep(ITs,'s','');
            ITcrit=abs(SPH-eval(ITs))<0.01;
        else
            ITcrit=ones(length(SPH),1);
        end
        
        SOPs=get(v.PlotSOPEdit,'String');
        SOPs=strrep(SOPs,'h','*3600');
        SOPs=strrep(SOPs,'m','*60');
        SOPs=strrep(SOPs,'s','');
        SOPcrit=abs(SOP-eval(SOPs))<0.01;
        
        FPRcrit=abs(FPRmax-str2double(get(v.PlotFPRmaxEdit,'String')))<.001;
        
        indices=find(ITcrit+SOPcrit+FPRcrit==3);
 
        dimOrig=length(indices);
        dimMult=str2double(inputdlg('Please enter the (additional) dimension of free parameters (e.g., the number of independent models tested like this one)'));

        sensitivity=sensitivity(indices);
        FPR=FPR(indices);
        SOP=SOP(indices);
        usedSeizures=usedSeizures(indices);
        
        [maxSens, maxSensI]=max(sensitivity);
        sensitivity=sensitivity(maxSensI);
        FPR=FPR(maxSensI);
        SOP=SOP(maxSensI);
        usedSeizures=usedSeizures(maxSensI);
        
        sigLevel=calculateSigLevelEpilab(str2double(FPR{1})/3600,SOP,usedSeizures,dimOrig*dimMult,0.05);
        fprintf('FPR: %f, SOP: %f, usedSeizures: %i, dim: %i, alpha: %f\n\n', str2double(FPR{1})/3600,SOP,usedSeizures,dimOrig*dimMult,0.05);

        msg=['The sensitivity of the optimal classifier is ' num2str(sensitivity) ', the FPR is ' num2str(FPR{1}) '. The sensitivity of the random predictor is ' ...
            num2str(sigLevel) ' for the chosen dimension of free parameters of ' num2str(dimOrig*dimMult) '. Hence, the result is'];
        if(sensitivity>sigLevel+0.000001)
            msg=[msg ' significant'];
        else
            msg=[msg ' insignificant'];
        end
        msg=[msg '. For this analysis, ' num2str(usedSeizures) ' seizures were analyzed. Goodbye.'];
        msgbox(msg)
    end


    function PlotButtonCallback(hobject, eventdata)
        
        [SPH, SOP, FPRmax, usedSeizures, prePostIctalTime, feature, threshold, corrects, ...
            incorrects, FPR, sensitivity, correctsTimes, incorrectsTimes, correctDiffs, incorrectDiffs] = ...
            textread(fullfile('seizureanalyzer','results','pat001','epilab','bestThresholdsTimes.txt'), '%f %f %f %f %f %s %f %f %f %s %f %s %s %s %s', -1, 'bufsize', 8*4096);
        
        if(~strcmp(get(v.PlotITEdit,'String'),'optimize'))
            ITs=get(v.PlotITEdit,'String');
            ITs=strrep(ITs,'h','*3600');
            ITs=strrep(ITs,'m','*60');
            ITs=strrep(ITs,'s','');
            ITcrit=abs(SPH-eval(ITs))<0.01;
        else
            ITcrit=ones(length(SPH),1);
        end
        
        SOPs=get(v.PlotSOPEdit,'String');
        SOPs=strrep(SOPs,'h','*3600');
        SOPs=strrep(SOPs,'m','*60');
        SOPs=strrep(SOPs,'s','');
        SOPcrit=abs(SOP-eval(SOPs))<0.01;
        
        FPRcrit=abs(FPRmax-str2double(get(v.PlotFPRmaxEdit,'String')))<.001;
        
        indices=find(ITcrit+SOPcrit+FPRcrit==3);
        correctTimesCrit=correctsTimes(indices);
        incorrectTimesCrit=incorrectsTimes(indices);
        sensitivityCrit=sensitivity(indices);
        FPRCrit=FPR(indices);
        
        curFeat='';
        curPos=0;
        maxSens=0;
        maxIT=-1;
        
        featureResults={};

        for i=1:length(indices)
            
            if(~strcmp(curFeat, feature{indices(i)}))
                if(maxIT>-1)
                    curPos=curPos+1;
                    featureResults{curPos}.sensitivity=maxSens;
                    featureResults{curPos}.IT=maxIT;
                    featureResults{curPos}.FPR=FPR{indices(i-1)};
                    featureResults{curPos}.feature=feature{indices(i-1)};
                    featureResults{curPos}.incorrectTimes=incorrectsTimes{indices(i-1)};
                    featureResults{curPos}.correctTimes=correctsTimes{indices(i-1)};
                end
                maxSens=sensitivity(indices(i));
                maxIT=SPH(indices(i));
                curFeat=feature{indices(i)};
            else
                if(sensitivity(indices(i))>maxSens)
                    maxSens=sensitivity(indices(i));
                    maxIT=SPH(indices(i));
                end
            end
            
        end

        aux_time=load(fullfile('seizureanalyzer','results','pat001','epilab','completePeriods.txt'));

        seizures=load(fullfile('seizureanalyzer','results','pat001','epilab','usedSeizures.txt'));

        figure('name','Seizureanalyzer alarms','NumberTitle','off')

        for i=1:length(featureResults)
            subplot(length(featureResults),1, i)
            hold on
            xlim([aux_time(1) aux_time(end)])
            
            for s=1:size(seizures,1)
                line([seizures(s,1) seizures(s,1)],[0 1],'linewidth',2,'color','k');
            end
            
            if(strcmp(featureResults{i}.correctTimes,'-1'))
                corrects=[];
            else
                corrects=split(';',featureResults{i}.correctTimes);
            end
            
            if(strcmp(featureResults{i}.incorrectTimes,'-1'))
                incorrects=[];
            else
                incorrects=split(';',featureResults{i}.incorrectTimes);
            end
            
            for s=1:length(corrects)
                line(str2double(corrects{s})*[1 1],[0 0.8],'linewidth',1,'color','g')
            end
            for s=1:length(incorrects)
                line(str2double(incorrects{s})*[1 1],[0 0.8],'linewidth',1,'color','r')
            end
            
            title(['Alarms for ' featureResults{i}.feature ' (Sens: ' ...
                num2str(featureResults{i}.sensitivity) ', FPR: ' ...
                num2str(featureResults{i}.FPR) ', IT: ' ...
                num2str(featureResults{i}.IT) ')'],'interpreter','none')
            
            set(gca,'yticklabel',{})
            set(gca,'ytick',[]);
            ylim([0 1])
        end
        
        xlabel('Time [s]')
 
    end


    function writeFeatureConfig(fileName,features)

        fid=fopen(fileName,'w');

        fprintf(fid,['<?xml version="1.0"?>\n' ...
            '<DataSources>\n' ...
            '   <DataSource type="epilab" name="Epilab feature" minValue="-1000000.0" maxValue="1000000">\n\n']);

        for i=1:length(features)
            fprintf(fid,['    <Feature columnsBefore="0" columnsAfter="0">\n' ...
                '      <FileExtension>%s.txt</FileExtension>\n' ...
                '      <Abbreviation>%s</Abbreviation>\n' ...
                '    </Feature>\n'],features{i}{1},features{i}{1});
        end

        fprintf(fid,'    </DataSource>\n\n</DataSources>\n');
        fclose(fid);
    end


    function writeProjectConfig(fileName,projectType,resultsPath,infoPath,filesPath,FPRmaxs,SOPs,ITs,thresholds,maximumBlockDistance,maximumGaps,timeAfterSeizure)

        fid=fopen(fileName,'w');

        fprintf(fid,['<?xml version="1.0"?>\n' ...
            '<Project type="%s"\n' ...
            '         maximumBlockDistance="%s" maximumGap="%s" maximumBlockLength="40h"\n' ...
            '         timeBeforeSeizure="-1" timeAfterSeizure="%s"\n' ...
            '         saveExhaustiveResults="0">\n' ...
            '\n' ...
            '  <ResultsPath>%s</ResultsPath>\n' ...
            '  <InfoPath>%s</InfoPath>\n' ...
            '\n' ...
            '  <DataSources>\n' ...
            '    <DataSource type="epilab" name="Epilab Feature">\n' ...
            '      <FilesPath>%s</FilesPath>\n' ...
            '      <Thresholds direction="negative" stayAboveBelowTime="1s">\n' ...
            '        %s\n' ...
            '      </Thresholds>\n' ...
            '    </DataSource>\n' ...
            '  </DataSources>\n' ...
            '\n' ...
            '  <DataProcessors>\n' ...
            '    <DataProcessor name="MedianSmoother">\n' ...
            '      <Parameter name="windowLength">1s</Parameter>\n' ...
            '      <Parameter name="writeToFile">false</Parameter>\n' ...
            '    </DataProcessor>\n' ...
            '  </DataProcessors>\n' ...
            '\n' ...
            '  <FPRmaxs>%s</FPRmaxs>\n' ...
            '  <SOPs>%s</SOPs>\n' ...
            '  <SPHs>%s</SPHs>\n' ...
            '\n' ...
            '</Project>\n' ...
            '\n'],projectType,maximumBlockDistance,maximumGaps,timeAfterSeizure, ...
               resultsPath,infoPath,filesPath,thresholds,FPRmaxs,SOPs,ITs);

        fclose(fid);
    end

    function writePatientConfig(fileName,nos,szs,startTime,endTime)

        fid=fopen(fileName,'w');

        fprintf(fid,['<?xml version="1.0"?>\n' ...
            '<Patients>\n\n']);

        for p=1:length(nos)
            sz=szs{p};

            fprintf(fid,['<Patient number="%03i">\n' ...
                '    <Subfolder>.</Subfolder>\n' ...
                '    <ResultsSubfolder>pat%%PatNr%%</ResultsSubfolder>\n\n' ...
                '    <FeatureFiles type="wildcard">*%%FeatureFileExtension%%</FeatureFiles>\n' ...
                '    <IncludePeriods>\n' ...
                '      <Periods format="timeStamps" startOffset="0" endOffset="0">\n' ...
                '        <Period><Start>%i</Start><End>%i</End></Period>\n' ...
                '      </Periods>\n' ...
                '    </IncludePeriods>\n\n' ...
                '    <ExcludePeriods>\n' ...
                '    </ExcludePeriods>\n'],nos(p),int32(startTime),int32(endTime));%,names{p});
    %             '      <Periods format="timeStampsFile" startOffset="0" endOffset="0">%%InfoPath%%/datenluecken/pat%s.exclude</Periods>\n' ...

            fprintf(fid,'    <RealSeizurePeriods>\n      <Periods format="timeStamps" startOffset="0" endOffset="0">\n');

            for j=1:size(sz,1)
                fprintf(fid,'        <Period><Start>%i</Start><End>%i</End></Period>\n',int32(sz(j,1)),int32(sz(j,2)));       
            end
            fprintf(fid,'      </Periods>\n    </RealSeizurePeriods>\n\n');
            fprintf(fid,'  </Patient>\n');

        end

        fprintf(fid,'\n\n</Patients>\n');

        fclose(fid);
    end


    function condMkdir(dir)
        if(~exist(dir,'dir'))
            mkdir(dir)
        end
    end

end